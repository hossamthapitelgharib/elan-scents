# تقرير تشغيل اختبارات Élan Scents

- **الحالة:** FAIL
- **بدأ:** 2026-10-14T09:29:01.913Z
- **انتهى:** 2026-10-14T09:29:04.740Z
- **الاختبارات:** 186
- **الناجح:** 171
- **الفاشل:** 15
- **الأمر:** `/home/ubuntu/.nvm/versions/node/v22.13.0/bin/node --test --test-reporter=tap tests/asset-version-consistency.test.js tests/cross-browser-cart-hero.test.js tests/customer-activity-api.test.js tests/customer-activity.test.js tests/customer-orders.test.js tests/customer-product-rankings.test.js tests/design-schema.test.js tests/edit-model.test.js tests/editor-about-footer.test.js tests/editor-api.test.js tests/editor-format-panel.test.js tests/editor-host.test.js tests/editor-login-errors.test.js tests/editor-media-edit.test.js tests/editor-media.test.js tests/editor-page.test.js tests/editor-preview-isolation.test.js tests/editor-records.test.js tests/editor-root-redirect.test.js tests/frontend-cache-busting.test.js tests/guest-analytics.test.js tests/guest-cart-rate-limit.test.js tests/guest-cart.test.js tests/guest-identity-browser-id.test.js tests/guest-identity-session.test.js tests/hosting-exposure.test.js tests/login-entry.test.js tests/migrations-consistency.test.js tests/platform-customer-summary.test.js tests/platform-customers.test.js tests/platform-dashboard-ui.test.js tests/platform-order-summary.test.js tests/platform-store-detail.test.js tests/platform-store-unlinked.test.js tests/platform-stores.test.js tests/railway-server.test.js tests/regression.test.js tests/server.test.js tests/store-dashboard-orders.test.js tests/webhook-security.test.js`

## TAP output

```text
TAP version 13
# Subtest: every page, app.js and style.css reference css/js assets with ONE shared cache-busting version
ok 1 - every page, app.js and style.css reference css/js assets with ONE shared cache-busting version
  ---
  duration_ms: 3.326746
  ...
# Subtest: every local css/js asset linked from an HTML page carries a version
ok 2 - every local css/js asset linked from an HTML page carries a version
  ---
  duration_ms: 4.583203
  ...
# Subtest: bump script rewrites versions in place and rejects malformed input
ok 3 - bump script rewrites versions in place and rejects malformed input
  ---
  duration_ms: 1.940915
  ...
# Subtest: hero video retries after browser-initiated pauses and unlocks on a real gesture
ok 4 - hero video retries after browser-initiated pauses and unlocks on a real gesture
  ---
  duration_ms: 1.980774
  ...
# Subtest: hero autoplays and keeps its fallback play button hidden until needed
not ok 5 - hero autoplays and keeps its fallback play button hidden until needed
  ---
  duration_ms: 4.566438
  location: '/home/ubuntu/elan-scents/tests/cross-browser-cart-hero.test.js:22:1'
  failureType: 'testCodeFailure'
  error: |-
    The input did not match the regular expression /id="heroPlay"[^>]*hidden/. Input:
    
    '<!DOCTYPE html>\n' +
      '<html lang="ar" dir="rtl">\n' +
      '<head>\n' +
      '<meta charset="utf-8">\n' +
      '<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">\n' +
      '<title>Élan Scents</title>\n' +
      '<!-- Bump this version whenever frontend assets change to avoid stale browser caches. -->\n' +
      '<link rel="stylesheet" href="/fonts.css?v=20261014-05">\n' +
      '<link rel="stylesheet" href="/style.css?v=20261014-05">\n' +
      '</head>\n' +
      '<body><svg width="0" height="0" style="position:absolute"><defs><linearGradient id="gg" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#f0c04a"/><stop offset=".5" stop-color="#c8962a"/><stop offset="1" stop-color="#8a5e0c"/></linearGradient></defs></svg>\n' +
      '<div id="bar"><div class="gold" id="barT"></div></div>\n' +
      '<header>\n' +
      '<div class="ic"><button id="mb" aria-label="menu"><svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="url(#gg)" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" ><path d="M4 7h16M4 12h16M4 17h10"/></svg></button><button data-sheet="notif"><svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="url(#gg)" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" ><path d="M6 16V11a6 6 0 0112 0v5l2 2H4zM10 20a2 2 0 004 0"/></svg></button><button id="quickSearchBtn" aria-label="quick search"><svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="url(#gg)" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" ><circle cx="11" cy="11" r="6"/><path d="M16 16l4 4"/></svg></button></div>\n' +
      '<a class="logo home-logo" href="/" aria-label="Élan Scents home"><div><b class="gold en">Élan</b> <span class="en">Scents</span></div><small class="en">THE HOME OF GULF FRAGRANCES</small><i></i></a>\n' +
      '<div class="ic"><button data-sheet="fav"><svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="url(#gg)" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" ><path d="M12 20s-7-4.5-7-10a4 4 0 017-2.5A4 4 0 0119 10c0 5.5-7 10-7 10z"/></svg></button><button data-sheet="cart"><svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="url(#gg)" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><circle cx="9" cy="20" r="1"/><circle cx="17" cy="20" r="1"/><path d="M3 3h2l.4 2M7 13h10l4-8H5.4M7 13L5.4 5M7 13l-2.293 2.293c-.63.63-.184 1.707.707 1.707H17m0 0a2 2 0 100 4 2 2 0 000-4zm-8 2a2 2 0 11-4 0 2 2 0 014 0z"/></svg></button><button id="lg" class="en">EN</button></div>\n' +
      '</header>\n' +
      '<div id="quickSearch" hidden><form id="quickSearchForm"><input id="quickSearchInput" type="search" autocomplete="off"><button type="submit" aria-label="search">⌕</button></form><div id="quickSearchResults"></div></div>\n' +
      '<nav id="menu"></nav><div id="mov"></div>\n' +
      '<div id="sheet" hidden><div class="sb" id="sheetB"></div></div>\n' +
      '<div id="hero">\n' +
      '<video id="heroVideo" autoplay muted loop playsinline webkit-playsinline preload="auto" poster="/assets/hero-poster.jpg?v=20261009-11" x-webkit-airplay="allow">\n' +
      '<source src="/assets/hero.mp4?v=20261009-11" type="video/mp4">\n' +
      '</video>\n' +
      '<button id="heroPlay" type="button" aria-label="تشغيل فيديو العرض / Play hero video">▶</button>\n' +
      '<div class="hero-overlay"></div>\n' +
      '<div class="magic" data-go="sec|all"><h2 data-i="magic"></h2><p class="sub" data-i="view"></p></div>\n' +
      '<div class="counters">\n' +
      '<div><b id="cbn">9</b><span data-i="cb"></span></div>\n' +
      '<div><b id="csn">2</b><span data-i="cs"></span></div>\n' +
      '<div><b id="cnt">0</b><span data-i="cp"></span></div>\n' +
      '</div>\n' +
      '</div>\n' +
      '<main id="main"></main>\n' +
      '<div id="view"></div>\n' +
      '<section class="about" id="about"><div class="alogo"><div class="logo"><div><b class="gold en">Élan</b> <span class="en">Scents</span></div><small class="en">THE HOME OF GULF FRAGRANCES</small><i></i></div></div><div id="abIn"></div></section>\n' +
      '<section id="contact">\n' +
      '<h3 data-i="contactT"></h3><span class="sub" style="cursor:default"></span>\n' +
      '<form onsubmit="return sendMsg(event)"><select id="kind"></select>\n' +
      '<input data-p="name" required><input data-p="email" type="email" required><input data-p="phone" type="tel"><textarea data-p="msg" rows="4" required></textarea>\n' +
      '<button class="btn" data-i="send"></button>\n' +
      '</form>\n' +
      '</section>\n' +
      '<footer>\n' +
      '<img class="footer-logo" src="/assets/elan-scents-logo.png" alt="Élan Scents" width="2048" height="2048">\n' +
      '<div class="fdiv"></div>\n' +
      '<div id="fcols" class="fcols"></div>\n' +
      '<div id="fch" class="fch"></div>\n' +
      '<div class="fph" id="fph"></div>\n' +
      '<div class="fbar" id="fbar"></div>\n' +
      '<p class="fcred" id="fcr"></p>\n' +
      '</footer>\n' +
      `<a id="wa" href="#contact" onclick="if(CFG.waNumber){event.preventDefault();window.open('https://wa.me/'+CFG.waNumber)}"><span aria-hidden="true"><svg viewBox="0 0 32 32"><path d="M16 3.2A12.8 12.8 0 0 0 5 22.5L3.3 28.7l6.4-1.7A12.8 12.8 0 1 0 16 3.2Z" fill="none" stroke="currentColor" stroke-width="2.1"/><path d="M11.4 10.7c.4-.4 1-.4 1.4.1l1.2 1.7c.3.4.3.9 0 1.3l-.7.8c.8 1.7 2.1 3 3.8 3.8l.8-.7c.4-.3.9-.3 1.3 0l1.7 1.2c.5.4.5 1 .1 1.4l-.6.6c-.6.6-1.5.8-2.3.5-4.2-1.5-7.2-4.5-8.7-8.7-.3-.8-.1-1.7.5-2.3l.6-.6Z" fill="currentColor"/></svg></span><b class="en">Contact Us</b></a>\n` +
      '<div id="toast"></div>\n' +
      '<script src="/guest-identity.js?v=20261014-05"></script>\n' +
      '<script src="/texts.js?v=20261014-05"></script>\n' +
      '<script src="/app.js?v=20261014-05"></script>\n' +
      '<script src="/design-schema.js?v=20261014-05"></script>\n' +
      '<script src="/design-layer.js?v=20261014-05"></script>\n' +
      '<script src="/edit-boot.js?v=20261014-05"></script>\n' +
      '<script>\n' +
      '(function(){\n' +
      "  var v=document.getElementById('heroVideo');\n" +
      "  var playButton=document.getElementById('heroPlay');\n" +
      '  if(!v)return;\n' +
      '  v.__elanHeroVisible=true;\n' +
      '  v.muted=true;\n' +
      '  v.defaultMuted=true;\n' +
      '  v.autoplay=true;\n' +
      '  v.loop=true;\n' +
      '  v.playsInline=true;\n' +
      "  v.setAttribute('muted','');\n" +
      "  v.setAttribute('playsinline','');\n" +
      "  v.setAttribute('webkit-playsinline','');\n" +
      '  var pauseRetries=0,retryTimer=0;\n' +
      '  function showButton(show){\n' +
      '    if(!playButton)return;\n' +
      "    if(show)playButton.removeAttribute('hidden');else playButton.setAttribute('hidden','');\n" +
      '  }\n' +
      '  function tryPlay(){\n' +
      '    if(v.__elanHeroVisible===false||document.hidden){v.pause();return;}\n' +
      '    v.muted=true;\n' +
      '    var p;\n' +
      '    try{p=v.play();}catch(e){showButton(true);return;}\n' +
      '    if(p&&p.then)p.then(function(){showButton(false);},function(){showButton(true);});\n' +
      '  }\n' +
      '  function setHeroVisibility(visible){v.__elanHeroVisible=visible;if(visible)tryPlay();else v.pause();}\n' +
      "  if(playButton)playButton.addEventListener('click',function(e){e.preventDefault();e.stopPropagation();tryPlay();});\n" +
      "  if('IntersectionObserver' in window){var heroObserver=new IntersectionObserver(function(entries){entries.forEach(function(entry){setHeroVisibility(entry.isIntersecting&&entry.intersectionRatio>=0.05);});},{threshold:[0,0.05]});heroObserver.observe(v.parentElement);}\n" +
      "  else{var checkHeroVisibility=function(){var r=v.parentElement.getBoundingClientRect();setHeroVisibility(r.bottom>0&&r.top<window.innerHeight);};window.addEventListener('scroll',checkHeroVisibility,{passive:true});window.addEventListener('resize',checkHeroVisibility,{passive:true});checkHeroVisibility();}\n" +
      "  v.addEventListener('playing',function(){showButton(false);});\n" +
      '  // Some browsers pause muted autoplay on their own (power saving, tab restore); resume while the hero is on screen.\n' +
      "  v.addEventListener('pause',function(){\n" +
      '    if(v.ended||v.__elanHeroVisible===false||document.hidden||pauseRetries>=10)return;\n' +
      '    pauseRetries++;\n' +
      '    clearTimeout(retryTimer);\n' +
      '    retryTimer=setTimeout(tryPlay,250);\n' +
      '  });\n' +
      '  // Safety net for engines that ignore the loop attribute.\n' +
      "  v.addEventListener('ended',function(){try{v.currentTime=0}catch(e){}tryPlay();});\n" +
      "  v.addEventListener('stalled',function(){if(v.paused)tryPlay();});\n" +
      "  v.addEventListener('suspend',function(){if(v.paused)tryPlay();});\n" +
      "  v.addEventListener('loadedmetadata',tryPlay);\n" +
      "  v.addEventListener('loadeddata',tryPlay);\n" +
      "  v.addEventListener('canplay',tryPlay);\n" +
      "  v.addEventListener('canplaythrough',tryPlay);\n" +
      "  document.addEventListener('visibilitychange',function(){if(document.hidden)v.pause();else{pauseRetries=0;tryPlay();}});\n" +
      "  window.addEventListener('pageshow',function(){pauseRetries=0;tryPlay();});\n" +
      '  // iOS Low Power Mode and strict autoplay policies need one real gesture; touchend/pointerup/keydown count as activation.\n' +
      "  ['touchend','pointerup','click','keydown'].forEach(function(name){document.addEventListener(name,function(){tryPlay();},{once:true,passive:true,capture:true});});\n" +
      '  tryPlay();\n' +
      '  setTimeout(tryPlay,300);\n' +
      '  setTimeout(tryPlay,1000);\n' +
      '  setTimeout(tryPlay,2500);\n' +
      '})();\n' +
      '</script>\n' +
      '</body>\n' +
      '</html>\n'
    
  code: 'ERR_ASSERTION'
  name: 'AssertionError'
  expected:
  actual: |-
    <!DOCTYPE html>
    <html lang="ar" dir="rtl">
    <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
    <title>Élan Scents</title>
    <!-- Bump this version whenever frontend assets change to avoid stale browser caches. -->
    <link rel="stylesheet" href="/fonts.css?v=20261014-05">
    <link rel="stylesheet" href="/style.css?v=20261014-05">
    </head>
    <body><svg width="0" height="0" style="position:absolute"><defs><linearGradient id="gg" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#f0c04a"/><stop offset=".5" stop-color="#c8962a"/><stop offset="1" stop-color="#8a5e0c"/></linearGradient></defs></svg>
    <div id="bar"><div class="gold" id="barT"></div></div>
    <header>
    <div class="ic"><button id="mb" aria-label="menu"><svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="url(#gg)" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" ><path d="M4 7h16M4 12h16M4 17h10"/></svg></button><button data-sheet="notif"><svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="url(#gg)" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" ><path d="M6 16V11a6 6 0 0112 0v5l2 2H4zM10 20a2 2 0 004 0"/></svg></button><button id="quickSearchBtn" aria-label="quick search"><svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="url(#gg)" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" ><circle cx="11" cy="11" r="6"/><path d="M16 16l4 4"/></svg></button></div>
    <a class="logo home-logo" href="/" aria-label="Élan Scents home"><div><b class="gold en">Élan</b> <span class="en">Scents</span></div><small class="en">THE HOME OF GULF FRAGRANCES</small><i></i></a>
    <div class="ic"><button data-sheet="fav"><svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="url(#gg)" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" ><path d="M12 20s-7-4.5-7-10a4 4 0 017-2.5A4 4 0 0119 10c0 5.5-7 10-7 10z"/></svg></button><button data-sheet="cart"><svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="url(#gg)" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><circle cx="9" cy="20" r="1"/><circle cx="17" cy="20" r="1"/><path d="M3 3h2l.4 2M7 13h10l4-8H5.4M7 13L5.4 5M7 13l-2.293 2.293c-.63.63-.184 1.707.707 1.707H17m0 0a2 2 0 100 4 2 2 0 000-4zm-8 2a2 2 0 11-4 0 2 2 0 014 0z"/></svg></button><button id="lg" class="en">EN</button></div>
    </header>
    <div id="quickSearch" hidden><form id="quickSearchForm"><input id="quickSearchInput" type="search" autocomplete="off"><button type="submit" aria-label="search">⌕</button></form><div id="quickSearchResults"></div></div>
    <nav id="menu"></nav><div id="mov"></div>
    <div id="sheet" hidden><div class="sb" id="sheetB"></div></div>
    <div id="hero">
    <video id="heroVideo" autoplay muted loop playsinline webkit-playsinline preload="auto" poster="/assets/hero-poster.jpg?v=20261009-11" x-webkit-airplay="allow">
    <source src="/assets/hero.mp4?v=20261009-11" type="video/mp4">
    </video>
    <button id="heroPlay" type="button" aria-label="تشغيل فيديو العرض / Play hero video">▶</button>
    <div class="hero-overlay"></div>
    <div class="magic" data-go="sec|all"><h2 data-i="magic"></h2><p class="sub" data-i="view"></p></div>
    <div class="counters">
    <div><b id="cbn">9</b><span data-i="cb"></span></div>
    <div><b id="csn">2</b><span data-i="cs"></span></div>
    <div><b id="cnt">0</b><span data-i="cp"></span></div>
    </div>
    </div>
    <main id="main"></main>
    <div id="view"></div>
    <section class="about" id="about"><div class="alogo"><div class="logo"><div><b class="gold en">Élan</b> <span class="en">Scents</span></div><small class="en">THE HOME OF GULF FRAGRANCES</small><i></i></div></div><div id="abIn"></div></section>
    <section id="contact">
    <h3 data-i="contactT"></h3><span class="sub" style="cursor:default"></span>
    <form onsubmit="return sendMsg(event)"><select id="kind"></select>
    <input data-p="name" required><input data-p="email" type="email" required><input data-p="phone" type="tel"><textarea data-p="msg" rows="4" required></textarea>
    <button class="btn" data-i="send"></button>
    </form>
    </section>
    <footer>
    <img class="footer-logo" src="/assets/elan-scents-logo.png" alt="Élan Scents" width="2048" height="2048">
    <div class="fdiv"></div>
    <div id="fcols" class="fcols"></div>
    <div id="fch" class="fch"></div>
    <div class="fph" id="fph"></div>
    <div class="fbar" id="fbar"></div>
    <p class="fcred" id="fcr"></p>
    </footer>
    <a id="wa" href="#contact" onclick="if(CFG.waNumber){event.preventDefault();window.open('https://wa.me/'+CFG.waNumber)}"><span aria-hidden="true"><svg viewBox="0 0 32 32"><path d="M16 3.2A12.8 12.8 0 0 0 5 22.5L3.3 28.7l6.4-1.7A12.8 12.8 0 1 0 16 3.2Z" fill="none" stroke="currentColor" stroke-width="2.1"/><path d="M11.4 10.7c.4-.4 1-.4 1.4.1l1.2 1.7c.3.4.3.9 0 1.3l-.7.8c.8 1.7 2.1 3 3.8 3.8l.8-.7c.4-.3.9-.3 1.3 0l1.7 1.2c.5.4.5 1 .1 1.4l-.6.6c-.6.6-1.5.8-2.3.5-4.2-1.5-7.2-4.5-8.7-8.7-.3-.8-.1-1.7.5-2.3l.6-.6Z" fill="currentColor"/></svg></span><b class="en">Contact Us</b></a>
    <div id="toast"></div>
    <script src="/guest-identity.js?v=20261014-05"></script>
    <script src="/texts.js?v=20261014-05"></script>
    <script src="/app.js?v=20261014-05"></script>
    <script src="/design-schema.js?v=20261014-05"></script>
    <script src="/design-layer.js?v=20261014-05"></script>
    <script src="/edit-boot.js?v=20261014-05"></script>
    <script>
    (function(){
      var v=document.getElementById('heroVideo');
      var playButton=document.getElementById('heroPlay');
      if(!v)return;
      v.__elanHeroVisible=true;
      v.muted=true;
      v.defaultMuted=true;
      v.autoplay=true;
      v.loop=true;
      v.playsInline=true;
      v.setAttribute('muted','');
      v.setAttribute('playsinline','');
      v.setAttribute('webkit-playsinline','');
      var pauseRetries=0,retryTimer=0;
      function showButton(show){
        if(!playButton)return;
        if(show)playButton.removeAttribute('hidden');else playButton.setAttribute('hidden','');
      }
      function tryPlay(){
        if(v.__elanHeroVisible===false||document.hidden){v.pause();return;}
        v.muted=true;
        var p;
        try{p=v.play();}catch(e){showButton(true);return;}
        if(p&&p.then)p.then(function(){showButton(false);},function(){showButton(true);});
      }
      function setHeroVisibility(visible){v.__elanHeroVisible=visible;if(visible)tryPlay();else v.pause();}
      if(playButton)playButton.addEventListener('click',function(e){e.preventDefault();e.stopPropagation();tryPlay();});
      if('IntersectionObserver' in window){var heroObserver=new IntersectionObserver(function(entries){entries.forEach(function(entry){setHeroVisibility(entry.isIntersecting&&entry.intersectionRatio>=0.05);});},{threshold:[0,0.05]});heroObserver.observe(v.parentElement);}
      else{var checkHeroVisibility=function(){var r=v.parentElement.getBoundingClientRect();setHeroVisibility(r.bottom>0&&r.top<window.innerHeight);};window.addEventListener('scroll',checkHeroVisibility,{passive:true});window.addEventListener('resize',checkHeroVisibility,{passive:true});checkHeroVisibility();}
      v.addEventListener('playing',function(){showButton(false);});
      // Some browsers pause muted autoplay on their own (power saving, tab restore); resume while the hero is on screen.
      v.addEventListener('pause',function(){
        if(v.ended||v.__elanHeroVisible===false||document.hidden||pauseRetries>=10)return;
        pauseRetries++;
        clearTimeout(retryTimer);
        retryTimer=setTimeout(tryPlay,250);
      });
      // Safety net for engines that ignore the loop attribute.
      v.addEventListener('ended',function(){try{v.currentTime=0}catch(e){}tryPlay();});
      v.addEventListener('stalled',function(){if(v.paused)tryPlay();});
      v.addEventListener('suspend',function(){if(v.paused)tryPlay();});
      v.addEventListener('loadedmetadata',tryPlay);
      v.addEventListener('loadeddata',tryPlay);
      v.addEventListener('canplay',tryPlay);
      v.addEventListener('canplaythrough',tryPlay);
      document.addEventListener('visibilitychange',function(){if(document.hidden)v.pause();else{pauseRetries=0;tryPlay();}});
      window.addEventListener('pageshow',function(){pauseRetries=0;tryPlay();});
      // iOS Low Power Mode and strict autoplay policies need one real gesture; touchend/pointerup/keydown count as activation.
      ['touchend','pointerup','click','keydown'].forEach(function(name){document.addEventListener(name,function(){tryPlay();},{once:true,passive:true,capture:true});});
      tryPlay();
      setTimeout(tryPlay,300);
      setTimeout(tryPlay,1000);
      setTimeout(tryPlay,2500);
    })();
    </script>
    </body>
    </html>
    
  operator: 'match'
  stack: |-
    TestContext.<anonymous> (/home/ubuntu/elan-scents/tests/cross-browser-cart-hero.test.js:26:10)
    Test.runInAsyncScope (node:async_hooks:211:14)
    Test.run (node:internal/test_runner/test:931:25)
    Test.processPendingSubtests (node:internal/test_runner/test:629:18)
    Test.postRun (node:internal/test_runner/test:1042:19)
    Test.run (node:internal/test_runner/test:970:12)
    async startSubtestAfterBootstrap (node:internal/test_runner/harness:296:3)
  ...
# Subtest: Railway serves the hero video and poster with immutable cache headers
ok 6 - Railway serves the hero video and poster with immutable cache headers
  ---
  duration_ms: 124.36282
  ...
# Subtest: cart helpers exist in resolved app-core source
ok 7 - cart helpers exist in resolved app-core source
  ---
  duration_ms: 0.478213
  ...
# Subtest: storefront is full width, prevents horizontal overflow, and locks scroll for overlays and menu
not ok 8 - storefront is full width, prevents horizontal overflow, and locks scroll for overlays and menu
  ---
  duration_ms: 2.278414
  location: '/home/ubuntu/elan-scents/tests/cross-browser-cart-hero.test.js:55:1'
  failureType: 'testCodeFailure'
  error: |-
    The input did not match the regular expression /html,body\{overflow-x:clip!important\}/. Input:
    
    '/* ============================================================\n' +
      '   Élan Scents — Active UI stylesheet (final consolidated)\n' +
      '   Imports base theme then applies current desired overrides.\n' +
      '   Frontend display only. Do not add backend/DB rules here.\n' +
      '   ============================================================ */\n' +
      "@import url('/style-3.css?v=20261014-05');\n" +
      "@import url('/footer-9x16.css?v=20261014-05');\n" +
      '\n' +
      '/* ---------- Menu: slightly narrower panel + slightly larger items ---------- */\n' +
      '#menu {\n' +
      '  padding-top: 64px !important;\n' +
      '  width: 32% !important;\n' +
      '  max-width: 135px !important;\n' +
      '}\n' +
      '#menu a:not(.mlogo) {\n' +
      '  font-size: 13px !important;\n' +
      '  padding: 9px 0 !important;\n' +
      '}\n' +
      '#menu a.mlogo {\n' +
      '  padding-top: 4px !important;\n' +
      '  padding-bottom: 10px !important;\n' +
      '}\n' +
      '\n' +
      '/* ---------- Header logo + tagline (large final sizes) ---------- */\n' +
      'header .logo b { font-size: 48px !important; }\n' +
      'header .logo span { font-size: 22px !important; }\n' +
      'header .logo small {\n' +
      '  font-size: 9px !important;\n' +
      '  letter-spacing: 1.2px !important;\n' +
      '  display: block !important;\n' +
      '}\n' +
      '\n' +
      '/* ---------- Masterpieces card 4:3 (same size as Categories) ---------- */\n' +
      '.cb > .card.msel {\n' +
      "  background-image: url('/assets/cards/masterpieces.webp') !important;\n" +
      '  background-size: cover !important;\n' +
      '  background-position: center center !important;\n' +
      '  background-repeat: no-repeat !important;\n' +
      '  background-color: #ede8de !important;\n' +
      '  background-clip: border-box !important;\n' +
      '  background-origin: border-box !important;\n' +
      '  width: 100% !important;\n' +
      '  max-width: 340px !important;\n' +
      '  height: auto !important;\n' +
      '  min-height: 0 !important;\n' +
      '  max-height: none !important;\n' +
      '  aspect-ratio: 4 / 3 !important;\n' +
      '  padding: 0 !important;\n' +
      '  border: 0 !important;\n' +
      '  border-radius: 20px !important;\n' +
      '  overflow: hidden !important;\n' +
      '  display: block !important;\n' +
      '  box-shadow: 0 0 0 2px #c8962a, 0 2px 4px #0001 !important;\n' +
      '}\n' +
      '\n' +
      '/* ---------- Art cards images ---------- */\n' +
      '.card.art .artbg {\n' +
      '  position: absolute !important;\n' +
      '  inset: 0 !important;\n' +
      '  background: #ede8de !important;\n' +
      '  overflow: hidden !important;\n' +
      '}\n' +
      '.card.art .artbg img,\n' +
      '.card.art .artbg svg {\n' +
      '  width: 100% !important;\n' +
      '  height: 100% !important;\n' +
      '  display: block !important;\n' +
      '  object-fit: cover !important;\n' +
      '  object-position: center center !important;\n' +
      '}\n' +
      '\n' +
      '/* ---------- Hero video full cover ---------- */\n' +
      '#hero {\n' +
      '  overflow: hidden !important;\n' +
      '  background: #1a1208 !important;\n' +
      '  aspect-ratio: auto !important;\n' +
      '  max-height: none !important;\n' +
      '  height: calc(var(--app-vh, 1vh) * 100) !important;\n' +
      '  min-height: 420px !important;\n' +
      '  position: relative !important;\n' +
      '}\n' +
      '#hero video,\n' +
      '#heroVideo {\n' +
      '  position: absolute !important;\n' +
      '  inset: 0 !important;\n' +
      '  width: 100% !important;\n' +
      '  height: 100% !important;\n' +
      '  object-fit: cover !important;\n' +
      '  object-position: center center !important;\n' +
      '  z-index: 0 !important;\n' +
      '  background: #1a1208 !important;\n' +
      '  display: block !important;\n' +
      '  opacity: 1 !important;\n' +
      '  visibility: visible !important;\n' +
      '}\n' +
      '#hero .hero-overlay {\n' +
      '  position: absolute !important;\n' +
      '  inset: 0 !important;\n' +
      '  z-index: 1 !important;\n' +
      '  background: linear-gradient(\n' +
      '    180deg,\n' +
      '    rgba(20, 12, 4, 0.35) 0%,\n' +
      '    rgba(20, 12, 4, 0.15) 40%,\n' +
      '    rgba(20, 12, 4, 0.55) 100%\n' +
      '  ) !important;\n' +
      '  pointer-events: none !important;\n' +
      '}\n' +
      '#hero .magic,\n' +
      '#hero .counters {\n' +
      '  position: relative !important;\n' +
      '  z-index: 2 !important;\n' +
      '}\n' +
      '\n' +
      '/* ---------- Round / occasion / notes cards (default strip size) ---------- */\n' +
      '.card.round,\n' +
      '.card.occ-note,\n' +
      '.card.occ,\n' +
      '.card.notes,\n' +
      '.strip .card.round,\n' +
      '.grid .card.round {\n' +
      '  border-radius: 18px !important;\n' +
      '  flex: 0 0 190px !important;\n' +
      '  flex-basis: 190px !important;\n' +
      '  width: 190px !important;\n' +
      '  height: 150px !important;\n' +
      '  min-height: 150px !important;\n' +
      '  aspect-ratio: auto !important;\n' +
      '  padding: 0 10px 12px !important;\n' +
      '  overflow: hidden !important;\n' +
      '  justify-content: flex-end !important;\n' +
      '}\n' +
      '.card.round.art .artbg,\n' +
      '.card.occ-note.art .artbg,\n' +
      '.card.occ .artbg,\n' +
      '.card.notes .artbg {\n' +
      '  position: absolute;\n' +
      '  inset: 0;\n' +
      '  z-index: 0;\n' +
      '}\n' +
      '.card.round.art h4,\n' +
      '.card.round.art .st,\n' +
      '.card.round.art small,\n' +
      '.card.occ-note.art h4,\n' +
      '.card.occ-note.art .st,\n' +
      '.card.occ-note.art small,\n' +
      '.card.occ h4,\n' +
      '.card.notes h4 {\n' +
      '  position: relative;\n' +
      '  z-index: 1;\n' +
      '  color: #fff !important;\n' +
      '  text-shadow: 0 1px 4px rgba(0, 0, 0, 0.55);\n' +
      '}\n' +
      '.card.round.art .st,\n' +
      '.card.occ-note.art .st,\n' +
      '.card.occ .st,\n' +
      '.card.notes .st {\n' +
      '  color: #f5e6c0 !important;\n' +
      '}\n' +
      '.card.round.art::after,\n' +
      '.card.occ-note.art::after,\n' +
      '.card.occ.art::after,\n' +
      '.card.notes.art::after {\n' +
      "  content: '';\n" +
      '  position: absolute;\n' +
      '  inset: 0;\n' +
      '  z-index: 0;\n' +
      '  background: linear-gradient(180deg, transparent 35%, rgba(20, 12, 4, 0.72) 100%);\n' +
      '  pointer-events: none;\n' +
      '}\n' +
      '\n' +
      '/* ---------- Occasion + Notes cards: same size as Categories ---------- */\n' +
      '#occ .card.round,\n' +
      '#occ .strip .card.round,\n' +
      '#occ .card.occ,\n' +
      '#occ .card.occ-note,\n' +
      '#notes .card.round,\n' +
      '#notes .strip .card.round,\n' +
      '#notes .card.notes {\n' +
      '  flex: 0 0 340px !important;\n' +
      '  flex-basis: 340px !important;\n' +
      '  width: 340px !important;\n' +
      '  max-width: 340px !important;\n' +
      '  height: auto !important;\n' +
      '  min-height: 0 !important;\n' +
      '  aspect-ratio: 4 / 3 !important;\n' +
      '  padding: 0 !important;\n' +
      '  border-radius: 20px !important;\n' +
      '}\n' +
      '\n' +
      '/* ---------- Category cards ---------- */\n' +
      '#cats > .cb {\n' +
      '  display: flex !important;\n' +
      '  justify-content: center !important;\n' +
      '  margin: 0 auto 24px !important;\n' +
      '  width: 100% !important;\n' +
      '  max-width: 340px !important;\n' +
      '}\n' +
      '#cats > .cb:last-of-type {\n' +
      '  margin-bottom: 8px !important;\n' +
      '}\n' +
      '#cats > .cb > .card {\n' +
      '  width: 100% !important;\n' +
      '  max-width: 340px !important;\n' +
      '  height: auto !important;\n' +
      '  min-height: 0 !important;\n' +
      '  aspect-ratio: 4 / 3 !important;\n' +
      '  padding: 0 !important;\n' +
      '  overflow: hidden !important;\n' +
      '  background-clip: border-box !important;\n' +
      '}\n' +
      '#cats > .cb > .card.art .artbg img,\n' +
      '#cats > .cb > .card.art .artbg svg {\n' +
      '  object-fit: cover !important;\n' +
      '  object-position: center center !important;\n' +
      '}\n' +
      '\n' +
      '/* ---------- Footer credit + growthmark ---------- */\n' +
      '#fcr,\n' +
      '.fcred {\n' +
      '  display: flex !important;\n' +
      '  flex-direction: column !important;\n' +
      '  align-items: center !important;\n' +
      '  justify-content: center !important;\n' +
      '  gap: 8px !important;\n' +
      '  margin-top: 18px !important;\n' +
      '  padding: 0 16px 12px !important;\n' +
      '  text-align: center !important;\n' +
      '}\n' +
      '#fcr span,\n' +
      '.fcred span {\n' +
      '  font-size: 11px !important;\n' +
      '  opacity: 0.7 !important;\n' +
      '  order: 1;\n' +
      '}\n' +
      '#fcr .growthmark-img,\n' +
      '.fcred .growthmark-img,\n' +
      'img.growthmark-img {\n' +
      '  display: block !important;\n' +
      '  width: 110px !important;\n' +
      '  max-width: 40vw !important;\n' +
      '  height: auto !important;\n' +
      '  margin: 6px auto !important;\n' +
      '  object-fit: contain !important;\n' +
      '  order: 2;\n' +
      '}\n' +
      '#fcr small,\n' +
      '.fcred small {\n' +
      '  font-size: 10px !important;\n' +
      '  opacity: 0.55 !important;\n' +
      '  order: 3;\n' +
      '}\n' +
      '\n' +
      '/* ---------- Footer ---------- */\n' +
      'footer {\n' +
      '  background: #858585 !important;\n' +
      '  background: linear-gradient(180deg, #8a8a8a 0%, #858585 50%, #7a7a7a 100%) !important;\n' +
      '  color: #f5e6c0 !important;\n' +
      '  border-top: 1px solid #9a9a9a !important;\n' +
      '  padding: 36px 18px 100px !important;\n' +
      '  text-align: center !important;\n' +
      '}\n' +
      'footer .footer-logo {\n' +
      '  display: block !important;\n' +
      '  width: 140px !important;\n' +
      '  max-width: 40vw !important;\n' +
      '  height: 140px !important;\n' +
      '  margin: 0 auto 16px !important;\n' +
      '  object-fit: contain !important;\n' +
      '}\n' +
      'footer .fdiv {\n' +
      '  background: linear-gradient(90deg, transparent, #d4c4a0, transparent) !important;\n' +
      '}\n' +
      'footer a {\n' +
      '  color: #f0e0b8 !important;\n' +
      '}\n' +
      'footer .fcols h5 {\n' +
      '  background: linear-gradient(135deg, #f3c94f, #c8962a 50%, #8a5e0c) !important;\n' +
      '  -webkit-background-clip: text !important;\n' +
      '  background-clip: text !important;\n' +
      '  color: transparent !important;\n' +
      '}\n' +
      'footer .fcols a,\n' +
      'footer .fcols span {\n' +
      '  color: #e8dcc0 !important;\n' +
      '}\n' +
      'footer .fph {\n' +
      '  color: #f3c94f !important;\n' +
      '}\n' +
      'footer .fbar {\n' +
      '  border-top-color: #6a6a6a !important;\n' +
      '  color: #d9cfb8 !important;\n' +
      '}\n' +
      'footer .fcred {\n' +
      '  color: #c8b898 !important;\n' +
      '}\n' +
      '\n' +
      '/* ---------- Sheet (cart / fav / notif) ---------- */\n' +
      'body.sheet-open {\n' +
      '  overflow: hidden !important;\n' +
      '  position: fixed !important;\n' +
      '  width: 100% !important;\n' +
      '  height: 100% !important;\n' +
      '  touch-action: none !important;\n' +
      '}\n' +
      '#sheet {\n' +
      '  overscroll-behavior: contain !important;\n' +
      '  touch-action: none !important;\n' +
      '}\n' +
      '#sheet .sb,\n' +
      '#sheetB {\n' +
      '  position: relative !important;\n' +
      '  overscroll-behavior: contain !important;\n' +
      '  max-height: min(85vh, 640px) !important;\n' +
      '  overflow-y: auto !important;\n' +
      '  -webkit-overflow-scrolling: touch !important;\n' +
      '  touch-action: pan-y !important;\n' +
      '  padding-top: 28px !important;\n' +
      '}\n' +
      '#sheet .sheet-close,\n' +
      '.sheet-close {\n' +
      '  position: absolute !important;\n' +
      '  top: 10px !important;\n' +
      '  left: 12px !important;\n' +
      '  right: auto !important;\n' +
      '  z-index: 5 !important;\n' +
      '  width: 36px !important;\n' +
      '  height: 36px !important;\n' +
      '  min-width: 36px !important;\n' +
      '  padding: 0 !important;\n' +
      '  margin: 0 !important;\n' +
      '  border: 0 !important;\n' +
      '  border-radius: 50% !important;\n' +
      '  background: #f5efe3 !important;\n' +
      '  color: #8a5e0c !important;\n' +
      '  font-size: 22px !important;\n' +
      '  line-height: 36px !important;\n' +
      '  text-align: center !important;\n' +
      '  cursor: pointer !important;\n' +
      '  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.08) !important;\n' +
      '  display: grid !important;\n' +
      '  place-items: center !important;\n' +
      '}\n' +
      '#sheet .sheet-close:hover,\n' +
      '.sheet-close:hover {\n' +
      '  background: #ebe3d0 !important;\n' +
      '  color: #6b4708 !important;\n' +
      '}\n' +
      '\n' +
      '/* ============================================================\n' +
      '   Mobile adjustments (keep logo large + layout)\n' +
      '   ============================================================ */\n' +
      '@media (max-width: 960px) {\n' +
      '  header {\n' +
      '    grid-template-columns: auto minmax(0, 1fr) auto !important;\n' +
      '    padding: 8px 10px !important;\n' +
      '    gap: 4px !important;\n' +
      '  }\n' +
      '  header .ic { gap: 6px !important; }\n' +
      '  header .ic button { padding: 2px !important; }\n' +
      '  header .ic svg { width: 20px !important; height: 20px !important; }\n' +
      '  header .logo { min-width: 0 !important; overflow: hidden !important; }\n' +
      '  header .logo > div { white-space: nowrap !important; }\n' +
      '  header .logo b { font-size: 48px !important; }\n' +
      '  header .logo span { font-size: 22px !important; }\n' +
      '  header .logo small {\n' +
      '    font-size: 9px !important;\n' +
      '    letter-spacing: 1.2px !important;\n' +
      '    display: block !important;\n' +
      '  }\n' +
      '  header .logo i { width: 60% !important; }\n' +
      '  #lg { font-size: 11px !impo'... 9648 more characters
    
  code: 'ERR_ASSERTION'
  name: 'AssertionError'
  expected:
  actual: |-
    /* ============================================================
       Élan Scents — Active UI stylesheet (final consolidated)
       Imports base theme then applies current desired overrides.
       Frontend display only. Do not add backend/DB rules here.
       ============================================================ */
    @import url('/style-3.css?v=20261014-05');
    @import url('/footer-9x16.css?v=20261014-05');
    
    /* ---------- Menu: slightly narrower panel + slightly larger items ---------- */
    #menu {
      padding-top: 64px !important;
      width: 32% !important;
      max-width: 135px !important;
    }
    #menu a:not(.mlogo) {
      font-size: 13px !important;
      padding: 9px 0 !important;
    }
    #menu a.mlogo {
      padding-top: 4px !important;
      padding-bottom: 10px !important;
    }
    
    /* ---------- Header logo + tagline (large final sizes) ---------- */
    header .logo b { font-size: 48px !important; }
    header .logo span { font-size: 22px !important; }
    header .logo small {
      font-size: 9px !important;
      letter-spacing: 1.2px !important;
      display: block !important;
    }
    
    /* ---------- Masterpieces card 4:3 (same size as Categories) ---------- */
    .cb > .card.msel {
      background-image: url('/assets/cards/masterpieces.webp') !important;
      background-size: cover !important;
      background-position: center center !important;
      background-repeat: no-repeat !important;
      background-color: #ede8de !important;
      background-clip: border-box !important;
      background-origin: border-box !important;
      width: 100% !important;
      max-width: 340px !important;
      height: auto !important;
      min-height: 0 !important;
      max-height: none !important;
      aspect-ratio: 4 / 3 !important;
      padding: 0 !important;
      border: 0 !important;
      border-radius: 20px !important;
      overflow: hidden !important;
      display: block !important;
      box-shadow: 0 0 0 2px #c8962a, 0 2px 4px #0001 !important;
    }
    
    /* ---------- Art cards images ---------- */
    .card.art .artbg {
      position: absolute !important;
      inset: 0 !important;
      background: #ede8de !important;
      overflow: hidden !important;
    }
    .card.art .artbg img,
    .card.art .artbg svg {
      width: 100% !important;
      height: 100% !important;
      display: block !important;
      object-fit: cover !important;
      object-position: center center !important;
    }
    
    /* ---------- Hero video full cover ---------- */
    #hero {
      overflow: hidden !important;
      background: #1a1208 !important;
      aspect-ratio: auto !important;
      max-height: none !important;
      height: calc(var(--app-vh, 1vh) * 100) !important;
      min-height: 420px !important;
      position: relative !important;
    }
    #hero video,
    #heroVideo {
      position: absolute !important;
      inset: 0 !important;
      width: 100% !important;
      height: 100% !important;
      object-fit: cover !important;
      object-position: center center !important;
      z-index: 0 !important;
      background: #1a1208 !important;
      display: block !important;
      opacity: 1 !important;
      visibility: visible !important;
    }
    #hero .hero-overlay {
      position: absolute !important;
      inset: 0 !important;
      z-index: 1 !important;
      background: linear-gradient(
        180deg,
        rgba(20, 12, 4, 0.35) 0%,
        rgba(20, 12, 4, 0.15) 40%,
        rgba(20, 12, 4, 0.55) 100%
      ) !important;
      pointer-events: none !important;
    }
    #hero .magic,
    #hero .counters {
      position: relative !important;
      z-index: 2 !important;
    }
    
    /* ---------- Round / occasion / notes cards (default strip size) ---------- */
    .card.round,
    .card.occ-note,
    .card.occ,
    .card.notes,
    .strip .card.round,
    .grid .card.round {
      border-radius: 18px !important;
      flex: 0 0 190px !important;
      flex-basis: 190px !important;
      width: 190px !important;
      height: 150px !important;
      min-height: 150px !important;
      aspect-ratio: auto !important;
      padding: 0 10px 12px !important;
      overflow: hidden !important;
      justify-content: flex-end !important;
    }
    .card.round.art .artbg,
    .card.occ-note.art .artbg,
    .card.occ .artbg,
    .card.notes .artbg {
      position: absolute;
      inset: 0;
      z-index: 0;
    }
    .card.round.art h4,
    .card.round.art .st,
    .card.round.art small,
    .card.occ-note.art h4,
    .card.occ-note.art .st,
    .card.occ-note.art small,
    .card.occ h4,
    .card.notes h4 {
      position: relative;
      z-index: 1;
      color: #fff !important;
      text-shadow: 0 1px 4px rgba(0, 0, 0, 0.55);
    }
    .card.round.art .st,
    .card.occ-note.art .st,
    .card.occ .st,
    .card.notes .st {
      color: #f5e6c0 !important;
    }
    .card.round.art::after,
    .card.occ-note.art::after,
    .card.occ.art::after,
    .card.notes.art::after {
      content: '';
      position: absolute;
      inset: 0;
      z-index: 0;
      background: linear-gradient(180deg, transparent 35%, rgba(20, 12, 4, 0.72) 100%);
      pointer-events: none;
    }
    
    /* ---------- Occasion + Notes cards: same size as Categories ---------- */
    #occ .card.round,
    #occ .strip .card.round,
    #occ .card.occ,
    #occ .card.occ-note,
    #notes .card.round,
    #notes .strip .card.round,
    #notes .card.notes {
      flex: 0 0 340px !important;
      flex-basis: 340px !important;
      width: 340px !important;
      max-width: 340px !important;
      height: auto !important;
      min-height: 0 !important;
      aspect-ratio: 4 / 3 !important;
      padding: 0 !important;
      border-radius: 20px !important;
    }
    
    /* ---------- Category cards ---------- */
    #cats > .cb {
      display: flex !important;
      justify-content: center !important;
      margin: 0 auto 24px !important;
      width: 100% !important;
      max-width: 340px !important;
    }
    #cats > .cb:last-of-type {
      margin-bottom: 8px !important;
    }
    #cats > .cb > .card {
      width: 100% !important;
      max-width: 340px !important;
      height: auto !important;
      min-height: 0 !important;
      aspect-ratio: 4 / 3 !important;
      padding: 0 !important;
      overflow: hidden !important;
      background-clip: border-box !important;
    }
    #cats > .cb > .card.art .artbg img,
    #cats > .cb > .card.art .artbg svg {
      object-fit: cover !important;
      object-position: center center !important;
    }
    
    /* ---------- Footer credit + growthmark ---------- */
    #fcr,
    .fcred {
      display: flex !important;
      flex-direction: column !important;
      align-items: center !important;
      justify-content: center !important;
      gap: 8px !important;
      margin-top: 18px !important;
      padding: 0 16px 12px !important;
      text-align: center !important;
    }
    #fcr span,
    .fcred span {
      font-size: 11px !important;
      opacity: 0.7 !important;
      order: 1;
    }
    #fcr .growthmark-img,
    .fcred .growthmark-img,
    img.growthmark-img {
      display: block !important;
      width: 110px !important;
      max-width: 40vw !important;
      height: auto !important;
      margin: 6px auto !important;
      object-fit: contain !important;
      order: 2;
    }
    #fcr small,
    .fcred small {
      font-size: 10px !important;
      opacity: 0.55 !important;
      order: 3;
    }
    
    /* ---------- Footer ---------- */
    footer {
      background: #858585 !important;
      background: linear-gradient(180deg, #8a8a8a 0%, #858585 50%, #7a7a7a 100%) !important;
      color: #f5e6c0 !important;
      border-top: 1px solid #9a9a9a !important;
      padding: 36px 18px 100px !important;
      text-align: center !important;
    }
    footer .footer-logo {
      display: block !important;
      width: 140px !important;
      max-width: 40vw !important;
      height: 140px !important;
      margin: 0 auto 16px !important;
      object-fit: contain !important;
    }
    footer .fdiv {
      background: linear-gradient(90deg, transparent, #d4c4a0, transparent) !important;
    }
    footer a {
      color: #f0e0b8 !important;
    }
    footer .fcols h5 {
      background: linear-gradient(135deg, #f3c94f, #c8962a 50%, #8a5e0c) !important;
      -webkit-background-clip: text !important;
      background-clip: text !important;
      color: transparent !important;
    }
    footer .fcols a,
    footer .fcols span {
      color: #e8dcc0 !important;
    }
    footer .fph {
      color: #f3c94f !important;
    }
    footer .fbar {
      border-top-color: #6a6a6a !important;
      color: #d9cfb8 !important;
    }
    footer .fcred {
      color: #c8b898 !important;
    }
    
    /* ---------- Sheet (cart / fav / notif) ---------- */
    body.sheet-open {
      overflow: hidden !important;
      position: fixed !important;
      width: 100% !important;
      height: 100% !important;
      touch-action: none !important;
    }
    #sheet {
      overscroll-behavior: contain !important;
      touch-action: none !important;
    }
    #sheet .sb,
    #sheetB {
      position: relative !important;
      overscroll-behavior: contain !important;
      max-height: min(85vh, 640px) !important;
      overflow-y: auto !important;
      -webkit-overflow-scrolling: touch !important;
      touch-action: pan-y !important;
      padding-top: 28px !important;
    }
    #sheet .sheet-close,
    .sheet-close {
      position: absolute !important;
      top: 10px !important;
      left: 12px !important;
      right: auto !important;
      z-index: 5 !important;
      width: 36px !important;
      height: 36px !important;
      min-width: 36px !important;
      padding: 0 !important;
      margin: 0 !important;
      border: 0 !important;
      border-radius: 50% !important;
      background: #f5efe3 !important;
      color: #8a5e0c !important;
      font-size: 22px !important;
      line-height: 36px !important;
      text-align: center !important;
      cursor: pointer !important;
      box-shadow: 0 2px 8px rgba(0, 0, 0, 0.08) !important;
      display: grid !important;
      place-items: center !important;
    }
    #sheet .sheet-close:hover,
    .sheet-close:hover {
      background: #ebe3d0 !important;
      color: #6b4708 !important;
    }
    
    /* ============================================================
       Mobile adjustments (keep logo large + layout)
       ============================================================ */
    @media (max-width: 960px) {
      header {
        grid-template-columns: auto minmax(0, 1fr) auto !important;
        padding: 8px 10px !important;
        gap: 4px !important;
      }
      header .ic { gap: 6px !important; }
      header .ic button { padding: 2px !important; }
      header .ic svg { width: 20px !important; height: 20px !important; }
      header .logo { min-width: 0 !important; overflow: hidden !important; }
      header .logo > div { white-space: nowrap !important; }
      header .logo b { font-size: 48px !important; }
      header .logo span { font-size: 22px !important; }
      header .logo small {
        font-size: 9px !important;
        letter-spacing: 1.2px !important;
        display: block !important;
      }
      header .logo i { width: 60% !important; }
      #lg { font-size: 11px !important; }
    
      #hero {
        height: calc(var(--app-vh, 1vh) * 100) !important;
        max-height: none !important;
        aspect-ratio: auto !important;
        min-height: 460px !important;
        background: #1a1208 !important;
        padding-bottom: calc(12px + env(safe-area-inset-bottom, 0px)) !important;
      }
      .magic h2 { font-size: 22px !important; }
      .counters b { font-size: 24px !important; }
      .counters span { font-size: 11px !important; }
    
      #cats > .cb { max-width: 300px !important; margin-bottom: 20px !important; }
      #cats > .cb > .card {
        height: auto !important;
        min-height: 0 !important;
        aspect-ratio: 4 / 3 !important;
      }
      .cb > .card.msel {
        width: 100% !important;
        max-width: 300px !important;
        height: auto !important;
        min-height: 0 !important;
        aspect-ratio: 4 / 3 !important;
        background-size: cover !important;
        background-clip: border-box !important;
        border: 0 !important;
      }
    
      #occ .card.round,
      #occ .strip .card.round,
      #occ .card.occ,
      #occ .card.occ-note,
      #notes .card.round,
      #notes .strip .card.round,
      #notes .card.notes {
        flex: 0 0 300px !important;
        flex-basis: 300px !important;
        width: 300px !important;
        max-width: 300px !important;
        height: auto !important;
        min-height: 0 !important;
        aspect-ratio: 4 / 3 !important;
      }
    
      img.growthmark-img {
        width: 90px !important;
        max-width: 35vw !important;
      }
      footer .footer-logo {
        width: 130px !important;
        max-width: 38vw !important;
        height: 130px !important;
      }
    }
    
    @media (max-width: 480px) {
      header {
        padding: 6px 8px !important;
        top: calc(env(safe-area-inset-top, 0px) + 28px) !important;
      }
      #bar {
        height: 28px !important;
        font-size: 12px !important;
        padding: 5px 0 !important;
      }
      header .logo b { font-size: 40px !important; }
      header .logo span { font-size: 18px !important; }
      header .logo small {
        font-size: 8.5px !important;
        letter-spacing: 1px !important;
        display: block !important;
      }
      header .ic { gap: 4px !important; }
      header .ic svg { width: 20px !important; height: 20px !important; }
    
      #hero {
        height: calc(var(--app-vh, 1vh) * 100) !important;
        min-height: calc(var(--app-vh, 1vh) * 100) !important;
        max-height: none !important;
        aspect-ratio: auto !important;
        background: #1a1208 !important;
        padding: 0 14px calc(10px + env(safe-area-inset-bottom, 0px)) !important;
      }
      .magic { padding: 10px !important; }
      .magic p { font-size: 12px !important; }
      .counters { gap: 6px !important; }
      .counters span { font-size: 10px !important; }
      .counters b { font-size: 22px !important; }
    
      .card.round,
      .card.occ-note,
      .card.occ,
      .card.notes,
      .strip .card.round {
        flex: 0 0 160px !important;
        flex-basis: 160px !important;
        width: 160px !important;
        height: 130px !important;
        min-height: 130px !important;
      }
    
      #cats > .cb {
        max-width: 92vw !important;
        margin-bottom: 16px !important;
      }
      #cats > .cb > .card {
        height: auto !important;
        min-height: 0 !important;
        aspect-ratio: 4 / 3 !important;
        border-radius: 16px !important;
      }
      #cats > .cb > .card h4 { font-size: 18px !important; }
      #cats > .cb > .card small,
      #cats > .cb > .card .st { font-size: 11px !important; }
    
      .cb > .card.msel {
        width: 100% !important;
        max-width: 92vw !important;
        height: auto !important;
        min-height: 0 !important;
        aspect-ratio: 4 / 3 !important;
        background-size: cover !important;
        background-clip: border-box !important;
        border: 0 !important;
      }
    
      #occ .card.round,
      #occ .strip .card.round,
      #occ .card.occ,
      #occ .card.occ-note,
      #notes .card.round,
      #notes .strip .card.round,
      #notes .card.notes {
        flex: 0 0 min(300px, 92vw) !important;
        flex-basis: min(300px, 92vw) !important;
        width: min(300px, 92vw) !important;
        max-width: 92vw !important;
        height: auto !important;
        min-height: 0 !important;
        aspect-ratio: 4 / 3 !important;
        border-radius: 16px !important;
      }
    
      .card.pf { flex: 0 0 160px !important; }
      .card.pf .pim { height: 120px !important; }
    
      #menu {
        width: 52% !important;
        max-width: 190px !important;
        padding-top: 56px !important;
      }
      #menu a:not(.mlogo) {
        font-size: 13px !important;
        padding: 9px 0 !important;
      }
    
      section {
        padding-left: 12px !important;
        padding-right: 12px !important;
      }
      footer {
        padding-left: 12px !important;
        padding-right: 12px !important;
      }
      .fcols { gap: 14px !important; }
    
      img.growthmark-img {
        width: 80px !important;
        max-width: 30vw !important;
      }
      footer .footer-logo {
        width: 110px !important;
        max-width: 36vw !important;
        height: 110px !important;
      }
    
      #sheet .sheet-close,
      .sheet-close {
        top: 8px !important;
        left: 10px !important;
        width: 32px !important;
        height: 32px !important;
        min-width: 32px !important;
        font-size: 20px !important;
        line-height: 32px !important;
      }
    }
    
    @media (max-width: 360px) {
      header .logo b { font-size: 34px !important; }
      header .logo span { font-size: 16px !important; }
      header .logo small {
        font-size: 8px !important;
        letter-spacing: 0.8px !important;
        display: block !important;
      }
      #cats > .cb > .card {
        height: auto !important;
        aspect-ratio: 4 / 3 !important;
      }
    }
    
    @media (min-width: 961px) {
      #cats > .cb { max-width: 320px !important; }
      #cats > .cb > .card {
        height: auto !important;
        min-height: 0 !important;
        aspect-ratio: 4 / 3 !important;
      }
      .cb > .card.msel {
        max-width: 320px !important;
      }
      #occ .card.round,
      #occ .strip .card.round,
      #occ .card.occ,
      #occ .card.occ-note,
      #notes .card.round,
      #notes .strip .card.round,
      #notes .card.notes {
        flex: 0 0 320px !important;
        flex-basis: 320px !important;
        width: 320px !important;
        max-width: 320px !important;
      }
    }
    
    /* Cross-browser consistency layer */
    html{min-width:320px;scrollbar-gutter:stable;color-scheme:light}
    body,button,input,select,textarea{font-family:'IBM Plex Sans Arabic','Segoe UI',Tahoma,Arial,sans-serif}
    button,input,select,textarea{font-size:inherit;line-height:1.35;-webkit-appearance:none;appearance:none}
    button{font-weight:inherit;text-align:center}
    input,select,textarea{-webkit-text-size-adjust:100%;text-size-adjust:100%}
    img,svg{max-width:100%;height:auto}img{display:block}
    button,a,input,select,textarea{-webkit-tap-highlight-color:transparent}
    :focus-visible{outline:2px solid #c8962a;outline-offset:2px}
    #hero{height:calc(var(--app-vh,1vh) * 100)}
    @supports not (backdrop-filter:blur(1px)){header,#sheet{background:rgba(255,255,255,.96)!important}}
    @supports not (scrollbar-gutter:stable){html{overflow-y:scroll}}
    .orders-list{display:grid;gap:8px}.order-card{display:grid;grid-template-columns:1fr auto;gap:3px 10px;padding:12px;border:1px solid #e6d9b6;border-radius:12px;background:#fffdf8}.order-card div{display:grid;gap:2px}.order-card small{color:var(--gray);font-size:11px}.order-status{color:var(--gold3);font-size:11px;font-weight:600;align-self:center}
    @media(max-width:680px){.grid{grid-template-columns:repeat(2,minmax(0,1fr));gap:10px}.grid .card{min-width:0}}
    
    /* Keep hero playback control present in every browser; the poster remains visible if autoplay is blocked. */
    #heroPlay{position:absolute;z-index:3;right:18px;bottom:calc(18px + env(safe-area-inset-bottom,0px));width:42px;height:42px;border:1px solid rgba(255,255,255,.72);border-radius:50%;background:rgba(20,12,4,.48);color:#fff;font:700 16px/1 Arial,sans-serif;display:grid;place-items:center;cursor:pointer;backdrop-filter:blur(4px);-webkit-backdrop-filter:blur(4px)}
    #heroPlay:focus-visible{outline:2px solid #fff;outline-offset:3px}
    
    /* Hero play button hides itself once playback starts (the [hidden] attribute must beat display:grid above). */
    #heroPlay[hidden]{display:none!important}
    
    /* Cross-browser normalisation: identical text sizing, font smoothing and positioning in every engine. */
    html{-webkit-text-size-adjust:100%;-moz-text-size-adjust:100%;text-size-adjust:100%}
    body{-webkit-font-smoothing:antialiased;-moz-osx-font-smoothing:grayscale;text-rendering:optimizeLegibility}
    /* Physical fallbacks for logical/inset properties (older Safari, Samsung Internet and Android WebView ignore them). */
    #bar,header{left:0;right:0}
    #mov,#sheet,#hero video,#heroVideo,#hero .hero-overlay,#hero .slot,.card .artbg,.card.art:after{top:0;right:0;bottom:0;left:0}
    [dir=rtl] #menu{right:0;left:auto}
    [dir=ltr] #menu{left:0;right:auto}
    [dir=rtl] .mx{left:14px;right:auto}
    [dir=ltr] .mx{right:14px;left:auto}
    [dir=rtl] #bar div{padding-right:100%}
    [dir=ltr] #bar div{padding-left:100%}
    
    /* ---------- Élan Scents footer identity ---------- */
    footer {
      background: linear-gradient(180deg, #686868 0%, #777777 52%, #626262 100%) !important;
      color: #fff1cf !important;
      border-top: 1px solid #f1d58e !important;
    }
    footer .footer-logo {
      width: min(190px, 42vw) !important;
      max-width: 42vw !important;
      height: auto !important;
      aspect-ratio: 1 / 1 !important;
      margin: 0 auto 18px !important;
      object-fit: contain !important;
      border-radius: 12px !important;
      box-shadow: 0 8px 24px rgba(38, 33, 25, .24), 0 0 0 1px rgba(255, 235, 179, .36) !important;
    }
    footer .fdiv {
      background: linear-gradient(90deg, transparent, #e6c66f 35%, #fff0c7 50%, #e6c66f 65%, transparent) !important;
    }
    footer .fcols a,
    footer .fcols span,
    footer .fch span,
    footer .fbar,
    footer .fcred {
      color: #fff1cf !important;
    }
    footer .fcols h5,
    footer .fph,
    footer .fch b {
      color: #ffe4a3 !important;
    }
    footer .fbar {
      border-top-color: rgba(255, 239, 199, .38) !important;
    }
    
  operator: 'match'
  stack: |-
    TestContext.<anonymous> (/home/ubuntu/elan-scents/tests/cross-browser-cart-hero.test.js:60:10)
    Test.runInAsyncScope (node:async_hooks:211:14)
    Test.run (node:internal/test_runner/test:931:25)
    Test.processPendingSubtests (node:internal/test_runner/test:629:18)
    Test.postRun (node:internal/test_runner/test:1042:19)
    Test.run (node:internal/test_runner/test:970:12)
    process.processTicksAndRejections (node:internal/process/task_queues:105:5)
    async Test.processPendingSubtests (node:internal/test_runner/test:629:7)
  ...
# Subtest: guest sessions send only server-HMAC browser identifiers to the session RPC
ok 9 - guest sessions send only server-HMAC browser identifiers to the session RPC
  ---
  duration_ms: 52.421963
  ...
# Subtest: registered product events are attached to the authenticated customer and normalized
ok 10 - registered product events are attached to the authenticated customer and normalized
  ---
  duration_ms: 1.56587
  ...
# Subtest: anonymous product activity cannot be written without a valid visitor key
ok 11 - anonymous product activity cannot be written without a valid visitor key
  ---
  duration_ms: 0.500162
  ...
# Subtest: customer activity migration preserves RLS, full product joins, four rankings, and transfers logs on claim
ok 12 - customer activity migration preserves RLS, full product joins, four rankings, and transfers logs on claim
  ---
  duration_ms: 6.03911
  ...
# Subtest: customer orders are scoped to the authenticated owner and expose stable exact pagination
ok 13 - customer orders are scoped to the authenticated owner and expose stable exact pagination
  ---
  duration_ms: 64.404971
  ...
# Subtest: customer orders reject malformed pages without querying any order rows
ok 14 - customer orders reject malformed pages without querying any order rows
  ---
  duration_ms: 2.225409
  ...
# Subtest: non-customer roles cannot use the personal order endpoint
ok 15 - non-customer roles cannot use the personal order endpoint
  ---
  duration_ms: 1.022972
  ...
# Subtest: personal orders page exposes controls for complete active and archived order history
ok 16 - personal orders page exposes controls for complete active and archived order history
  ---
  duration_ms: 0.580324
  ...
# Subtest: ranking API returns server-paged full product snapshots only to platform admins
ok 17 - ranking API returns server-paged full product snapshots only to platform admins
  ---
  duration_ms: 79.418348
  ...
# Subtest: ranking API rejects non-admins and malformed scope or paging without running the RPC
ok 18 - ranking API rejects non-admins and malformed scope or paging without running the RPC
  ---
  duration_ms: 8.40902
  ...
# Subtest: database ranking pages sort operations descending with deterministic tie-breakers
ok 19 - database ranking pages sort operations descending with deterministic tie-breakers
  ---
  duration_ms: 0.68359
  ...
# Subtest: the committed owner design is valid and retains its saved customizations
ok 20 - the committed owner design is valid and retains its saved customizations
  ---
  duration_ms: 3.675198
  ...
# Subtest: an empty design produces an empty plan (zero DOM changes)
ok 21 - an empty design produces an empty plan (zero DOM changes)
  ---
  duration_ms: 2.581524
  ...
# Subtest: strict mode rejects anything that is not a version-1 object
ok 22 - strict mode rejects anything that is not a version-1 object
  ---
  duration_ms: 0.351691
  ...
# Subtest: unknown sections, texts keys and ids are rejected in strict mode and dropped in lenient mode
ok 23 - unknown sections, texts keys and ids are rejected in strict mode and dropped in lenient mode
  ---
  duration_ms: 0.42718
  ...
# Subtest: blocks only accept safe media URLs, links and colors
ok 24 - blocks only accept safe media URLs, links and colors
  ---
  duration_ms: 1.256023
  ...
# Subtest: block ids are namespaced (x-...) and unique, so they can never collide with page elements
ok 25 - block ids are namespaced (x-...) and unique, so they can never collide with page elements
  ---
  duration_ms: 0.350156
  ...
# Subtest: text is plain text only: control characters are stripped and length is capped
ok 26 - text is plain text only: control characters are stripped and length is capped
  ---
  duration_ms: 0.22288
  ...
# Subtest: plan: hide, retitle, add blocks and reorder
ok 27 - plan: hide, retitle, add blocks and reorder
  ---
  duration_ms: 0.392585
  ...
# Subtest: plan ignores sections that are not on the page
ok 28 - plan ignores sections that are not on the page
  ---
  duration_ms: 0.429897
  ...
# Subtest: serialize refuses invalid or oversized designs and is canonical
ok 29 - serialize refuses invalid or oversized designs and is canonical
  ---
  duration_ms: 5.814462
  ...
# Subtest: applyTexts only touches whitelisted keys
ok 30 - applyTexts only touches whitelisted keys
  ---
  duration_ms: 0.712361
  ...
# Subtest: the storefront loads the design layer after the core and keeps the cache-busting version
ok 31 - the storefront loads the design layer after the core and keeps the cache-busting version
  ---
  duration_ms: 0.777723
  ...
# Subtest: design files are served without caching by Railway
ok 32 - design files are served without caching by Railway
  ---
  duration_ms: 149.286628
  ...
# Subtest: inner pages accept blocks only for known page keys and keep ids unique across the site
ok 33 - inner pages accept blocks only for known page keys and keep ids unique across the site
  ---
  duration_ms: 1.057881
  ...
# Subtest: smart sections are stored as a reference only, never as prices or stock
ok 34 - smart sections are stored as a reference only, never as prices or stock
  ---
  duration_ms: 0.480552
  ...
# Subtest: draft starts clean and every edit stays valid for the server schema
ok 35 - draft starts clean and every edit stays valid for the server schema
  ---
  duration_ms: 14.855753
  ...
# Subtest: undo, redo, archive and restore keep the page recoverable
ok 36 - undo, redo, archive and restore keep the page recoverable
  ---
  duration_ms: 1.157579
  ...
# Subtest: the model refuses edits the schema does not allow
ok 37 - the model refuses edits the schema does not allow
  ---
  duration_ms: 0.946749
  ...
# Subtest: banners and images only accept the allowed media host and safe links
ok 38 - banners and images only accept the allowed media host and safe links
  ---
  duration_ms: 1.895084
  ...
# Subtest: inner-page blocks stay on their page, keep top/bottom placement, and survive undo and archive
ok 39 - inner-page blocks stay on their page, keep top/bottom placement, and survive undo and archive
  ---
  duration_ms: 1.662943
  ...
# Subtest: smart sections keep their definition as a draft until a saved design uses it
ok 40 - smart sections keep their definition as a draft until a saved design uses it
  ---
  duration_ms: 0.68763
  ...
# Subtest: about, contact and every footer part are editable elements with stable ids
not ok 41 - about, contact and every footer part are editable elements with stable ids
  ---
  duration_ms: 2.470801
  location: '/home/ubuntu/elan-scents/tests/editor-about-footer.test.js:7:1'
  failureType: 'testCodeFailure'
  error: "'about:p' must be registered"
  code: 'ERR_ASSERTION'
  name: 'AssertionError'
  expected: true
  actual: false
  operator: '=='
  stack: |-
    TestContext.<anonymous> (/home/ubuntu/elan-scents/tests/editor-about-footer.test.js:10:12)
    Test.runInAsyncScope (node:async_hooks:211:14)
    Test.run (node:internal/test_runner/test:931:25)
    Test.start (node:internal/test_runner/test:829:17)
    startSubtestAfterBootstrap (node:internal/test_runner/harness:296:17)
  ...
# Subtest: edit mode knows the new element kinds
not ok 42 - edit mode knows the new element kinds
  ---
  duration_ms: 2.77834
  location: '/home/ubuntu/elan-scents/tests/editor-about-footer.test.js:15:1'
  failureType: 'testCodeFailure'
  error: |-
    The input did not match the regular expression /'text-area': 'text', group: 'section', 'image-el': 'image'/. Input:
    
    '/* Élan Scents — visual edit mode (admin only, runs only inside the Élan Editor window).\n' +
      "   Everything here happens in this tab's memory. Nothing reaches customers or GitHub until the editor\n" +
      '   asks for the design (page.getState) and saves it through the server, which checks the admin again. */\n' +
      '(function () {\n' +
      "  'use strict';\n" +
      '  var layer = window.ElanDesignLayer, ED = window.ElanDesign, Bridge = window.ElanHostBridge;\n' +
      '  if (!layer || !ED || !Bridge || window.parent === window) return;\n' +
      '\n' +
      "  var work = null, baseJson = '', baseRevision = null, hostApi = null, selectedId = null, dirty = false;\n" +
      '  var undoStack = [], redoStack = [], editing = null, gesture = null, pendingMedia = null, moveArm = null;\n' +
      '  var SECTIONS_NAMES = { section: 1 };\n' +
      '\n' +
      '  function clone(o) { return JSON.parse(JSON.stringify(o)); }\n' +
      "  function lang() { return document.documentElement.lang === 'en' ? 'en' : 'ar'; }\n" +
      '  function device() { return ED.deviceOf(window.innerWidth); }\n' +
      "  function rid() { var a = new Uint8Array(5); crypto.getRandomValues(a); return Array.prototype.map.call(a, function (b) { return (b % 36).toString(36); }).join(''); }\n" +
      '\n' +
      '  /* ---------- working design ---------- */\n' +
      '  function emptyDesign() { return ED.normalize({ version: ED.VERSION }).design; }\n' +
      '  function setDirty(v) { if (!!v === dirty) return; dirty = !!v; if (hostApi) hostApi.dirty(dirty); }\n' +
      '  function checkDirty() { setDirty(JSON.stringify(work) !== baseJson); }\n' +
      '  function entries() { return layer.elements(); }\n' +
      '  function entryById(id) { var l = entries(); for (var i = 0; i < l.length; i++) if (l[i].id === id) return l[i]; return null; }\n' +
      '  function bucket(dev) { work.edits = work.edits || {}; return (work.edits[dev] = work.edits[dev] || {}); }\n' +
      '  function edit(dev, id) { var b = bucket(dev); return (b[id] = b[id] || {}); }\n' +
      '  function tidy() {\n' +
      '    if (!work.edits) return;\n' +
      '    Object.keys(work.edits).forEach(function (dev) {\n' +
      '      Object.keys(work.edits[dev]).forEach(function (id) {\n' +
      '        var e = work.edits[dev][id];\n' +
      '        if (e.style && !Object.keys(e.style).length) delete e.style;\n' +
      '        if (!Object.keys(e).length) delete work.edits[dev][id];\n' +
      '      });\n' +
      '      if (!Object.keys(work.edits[dev]).length) delete work.edits[dev];\n' +
      '    });\n' +
      '    if (!Object.keys(work.edits).length) delete work.edits;\n' +
      '  }\n' +
      '\n' +
      '  function mutate(fn) {\n' +
      '    undoStack.push(JSON.stringify(work)); if (undoStack.length > 100) undoStack.shift();\n' +
      '    redoStack = [];\n' +
      '    fn(work); tidy();\n' +
      '    checkDirty();\n' +
      '    repaint();\n' +
      '  }\n' +
      '  function repaint() { (layer.set || layer.setDesign)(work, { editing: true }); reselect(); }\n' +
      '\n' +
      '  function undo() { if (!undoStack.length) return false; redoStack.push(JSON.stringify(work)); work = JSON.parse(undoStack.pop()); checkDirty(); repaint(); return true; }\n' +
      '  function redo() { if (!redoStack.length) return false; undoStack.push(JSON.stringify(work)); work = JSON.parse(redoStack.pop()); checkDirty(); repaint(); return true; }\n' +
      '\n' +
      '  /* The order of sections and extra blocks exactly as they appear now. */\n' +
      '  function fullOrder() {\n' +
      "    var main = document.getElementById('main'), seq = [];\n" +
      '    Array.prototype.slice.call(main.children).forEach(function (c) {\n' +
      "      if (c.hasAttribute('data-elan-custom')) seq.push(c.getAttribute('data-elan-id'));\n" +
      "      else if (c.tagName === 'SECTION' && c.id && ED.BUILTIN.indexOf(c.id) !== -1) seq.push(c.id);\n" +
      '    });\n' +
      '    return seq;\n' +
      '  }\n' +
      '  function sectionOf(id) {\n' +
      "    var m = /^sec:([a-z]+)/.exec(id || '');\n" +
      '    if (m) return m[1];\n' +
      "    var e = entryById(id), s = e && e.el.closest('section[id]');\n" +
      "    return s ? s.id : (/^x-/.test(id || '') ? id : null);\n" +
      '  }\n' +
      '\n' +
      '  /* ---------- overlay ---------- */\n' +
      "  var root = document.createElement('div');\n" +
      "  root.id = 'elan-eo-root';\n" +
      "  root.innerHTML = '<style>' +\n" +
      `    '#elan-eo-root{position:fixed;inset:0;pointer-events:none;z-index:2147483000;font-family:"IBM Plex Sans Arabic",system-ui,sans-serif;direction:rtl}' +\n` +
      "    '#elan-eo-root *{box-sizing:border-box}' +\n" +
      "    '.eo-box{position:fixed;outline:2px solid #c8962a;background:rgba(200,150,42,.06);display:none}' +\n" +
      "    '.eo-h{position:absolute;width:13px;height:13px;right:-6px;bottom:-6px;background:#c8962a;border-radius:3px;cursor:nwse-resize;pointer-events:auto;touch-action:none}' +\n" +
      "    'body.eo-armed,body.eo-armed *{cursor:move!important}.eo-armed-box{outline:2px dashed #1f7a3d!important;background:rgba(31,122,61,.08)!important}' +\n" +
      "    '.eo-msg{position:fixed;bottom:12px;left:50%;transform:translateX(-50%);background:#29251c;color:#fff;padding:8px 14px;border-radius:9px;font-size:13px;display:none;max-width:90vw;pointer-events:none}' +\n" +
      "    '.eo-dlg{position:fixed;inset:0;display:none;align-items:center;justify-content:center;background:rgba(0,0,0,.35);pointer-events:auto}' +\n" +
      "    '.eo-dlg>div{background:#fffaf0;border:1px solid #c2a66a;border-radius:12px;padding:16px;width:min(420px,92vw);font-size:13px}' +\n" +
      "    '.eo-dlg input[type=text]{width:100%;padding:7px;border:1px solid #c2a66a;border-radius:7px;direction:ltr;margin:8px 0}' +\n" +
      "    '.eo-dlg button{font:inherit;padding:6px 12px;border:1px solid #c2a66a;border-radius:7px;background:#fff;cursor:pointer;margin-inline-end:6px}' +\n" +
      "    '[contenteditable]{outline:2px dashed #c8962a;outline-offset:2px}' +\n" +
      `    '</style><div class="eo-box"><i class="eo-h" data-h="se"></i></div><div class="eo-msg"></div>' +\n` +
      `    '<div class="eo-dlg"><div><b class="eo-dt"></b><input type="text" class="eo-di" dir="ltr"><p class="eo-dh" style="margin:0 0 8px;color:#7a6a52"></p><button class="eo-ok">تأكيد</button><button class="eo-no">إلغاء</button></div></div>';\n` +
      '  document.body.appendChild(root);\n' +
      '\n' +
      "  var box = root.querySelector('.eo-box'), msgEl = root.querySelector('.eo-msg'), dlg = root.querySelector('.eo-dlg');\n" +
      '\n' +
      '  var msgTimer = null;\n' +
      "  function say(text) { msgEl.textContent = text; msgEl.style.display = 'block'; clearTimeout(msgTimer); msgTimer = setTimeout(function () { msgEl.style.display = 'none'; }, 3500); }\n" +
      '\n' +
      '  function ask(title, hint, value) {\n' +
      '    return new Promise(function (resolve) {\n' +
      "      root.querySelector('.eo-dt').textContent = title;\n" +
      "      root.querySelector('.eo-dh').textContent = hint || '';\n" +
      "      var input = root.querySelector('.eo-di'); input.value = value || '';\n" +
      "      dlg.style.display = 'flex'; input.focus();\n" +
      "      function done(v) { dlg.style.display = 'none'; root.querySelector('.eo-ok').onclick = root.querySelector('.eo-no').onclick = null; resolve(v); }\n" +
      "      root.querySelector('.eo-ok').onclick = function () { done(input.value.trim()); };\n" +
      "      root.querySelector('.eo-no').onclick = function () { done(null); };\n" +
      '    });\n' +
      '  }\n' +
      '\n' +
      '  function placeBox() {\n' +
      '    var e = selectedId && entryById(selectedId);\n' +
      "    if (!e || (e.el.style.display === 'none')) { box.style.display = 'none'; return; }\n" +
      '    var r = e.el.getBoundingClientRect();\n' +
      "    box.style.display = 'block';\n" +
      "    box.style.left = r.left + 'px'; box.style.top = r.top + 'px'; box.style.width = r.width + 'px'; box.style.height = r.height + 'px';\n" +
      '  }\n' +
      '  function rgbToHex(c) {\n' +
      "    var m = /rgba?\\((\\d+),\\s*(\\d+),\\s*(\\d+)/.exec(c || '');\n" +
      "    if (!m) return '#000000';\n" +
      "    return '#' + [m[1], m[2], m[3]].map(function (n) { return ('0' + (+n).toString(16)).slice(-2); }).join('');\n" +
      '  }\n' +
      '  function cur(id) { return ED.editFor(work, device(), id) || {}; }\n' +
      "  /* What the editor needs to know about an element: the original editor's type names plus its current look. */\n" +
      "  var TYPE_OF = { section: 'section', title: 'text', 'hero-text': 'text', hero: 'section', 'hero-counters': 'text', card: 'card', block: 'block' };\n" +
      "  function solidBackground(c) { var m = /^rgba?\\((\\d+),\\s*(\\d+),\\s*(\\d+)(?:,\\s*([\\d.]+))?\\)$/.exec(c || ''); return !m || (m[4] !== undefined && parseFloat(m[4]) === 0) ? '' : rgbToHex(c); }\n" +
      '  function info(e) {\n' +
      '    if (!e) return null;\n' +
      '    var node = layer.textTarget(e) || e.el, cs = getComputedStyle(node), st = cur(e.id).style || {};\n' +
      '    var blk = work.blocks.filter(function (b) { return b.id === e.id; })[0];\n' +
      "    var type = blk ? ({ text: 'text_block', banner: 'banner', image: 'image' })[blk.type] : (TYPE_OF[e.kind] || 'text');\n" +
      '    return {\n' +
      "      id: e.id, name: e.name, kind: e.kind, type: type, text: String(node.textContent || '').trim().slice(0, 120), media: st.media || '', canText: !!layer.textTarget(e), isBlock: !!blk, dynamic: !!dynamicTarget(e),\n" +
      '      style: {\n' +
      `        fontFamily: st.fontFamily || (cs.fontFamily || '').split(',')[0].replace(/["']/g, '').trim(),\n` +
      '        fontSize: st.fontSize || Math.round(parseFloat(cs.fontSize) || 16),\n' +
      '        color: st.color || rgbToHex(cs.color), background: st.background || solidBackground(getComputedStyle(e.el).backgroundColor),\n' +
      "        align: st.align || ({ start: 'right', end: 'left', center: 'center', left: 'left', right: 'right' })[cs.textAlign] || 'right',\n" +
      "        effect: st.effect || 'none'\n" +
      '      }\n' +
      '    };\n' +
      '  }\n' +
      '  function reselect() {\n' +
      '    if (selectedId && !entryById(selectedId)) selectedId = null;\n' +
      '    placeBox();\n' +
      '    if (hostApi) hostApi.selection(info(selectedId && entryById(selectedId)));\n' +
      '  }\n' +
      '  function select(id) { selectedId = id; reselect(); }\n' +
      '\n' +
      '  function setStyle(id, key, val) {\n' +
      '    mutate(function (d) {\n' +
      "      var e = edit('all', id); e.style = e.style || {};\n" +
      '      if (val === null) delete e.style[key]; else e.style[key] = val;\n' +
      '    });\n' +
      '  }\n' +
      '  function reorder(id, delta) {\n' +
      '    var key = /^sec:/.test(id) ? id.slice(4) : id, seq = fullOrder(), i = seq.indexOf(key), j = i + delta;\n' +
      '    if (i < 0 || j < 0 || j >= seq.length) return;\n' +
      '    mutate(function (d) { seq.splice(i, 1); seq.splice(j, 0, key); d.order = seq; });\n' +
      '  }\n' +
      '  function resetElement(id) { mutate(function (d) { if (d.edits) Object.keys(d.edits).forEach(function (dev) { delete d.edits[dev][id]; }); }); }\n' +
      "  function archive(id) { mutate(function () { edit('all', id).archived = true; }); selectedId = null; reselect(); say('اتحط في الأرشيف. تقدر ترجّعه من الأرشيف.'); }\n" +
      '\n' +
      '  /* ---------- picking, drag, resize, text ---------- */\n' +
      '  function inUi(t) { return t && t.nodeType === 1 && root.contains(t); }\n' +
      '  function pick(x, y) {\n' +
      '    var map = new Map(); entries().forEach(function (e) { map.set(e.el'... 25002 more characters
    
  code: 'ERR_ASSERTION'
  name: 'AssertionError'
  expected:
  actual: |-
    /* Élan Scents — visual edit mode (admin only, runs only inside the Élan Editor window).
       Everything here happens in this tab's memory. Nothing reaches customers or GitHub until the editor
       asks for the design (page.getState) and saves it through the server, which checks the admin again. */
    (function () {
      'use strict';
      var layer = window.ElanDesignLayer, ED = window.ElanDesign, Bridge = window.ElanHostBridge;
      if (!layer || !ED || !Bridge || window.parent === window) return;
    
      var work = null, baseJson = '', baseRevision = null, hostApi = null, selectedId = null, dirty = false;
      var undoStack = [], redoStack = [], editing = null, gesture = null, pendingMedia = null, moveArm = null;
      var SECTIONS_NAMES = { section: 1 };
    
      function clone(o) { return JSON.parse(JSON.stringify(o)); }
      function lang() { return document.documentElement.lang === 'en' ? 'en' : 'ar'; }
      function device() { return ED.deviceOf(window.innerWidth); }
      function rid() { var a = new Uint8Array(5); crypto.getRandomValues(a); return Array.prototype.map.call(a, function (b) { return (b % 36).toString(36); }).join(''); }
    
      /* ---------- working design ---------- */
      function emptyDesign() { return ED.normalize({ version: ED.VERSION }).design; }
      function setDirty(v) { if (!!v === dirty) return; dirty = !!v; if (hostApi) hostApi.dirty(dirty); }
      function checkDirty() { setDirty(JSON.stringify(work) !== baseJson); }
      function entries() { return layer.elements(); }
      function entryById(id) { var l = entries(); for (var i = 0; i < l.length; i++) if (l[i].id === id) return l[i]; return null; }
      function bucket(dev) { work.edits = work.edits || {}; return (work.edits[dev] = work.edits[dev] || {}); }
      function edit(dev, id) { var b = bucket(dev); return (b[id] = b[id] || {}); }
      function tidy() {
        if (!work.edits) return;
        Object.keys(work.edits).forEach(function (dev) {
          Object.keys(work.edits[dev]).forEach(function (id) {
            var e = work.edits[dev][id];
            if (e.style && !Object.keys(e.style).length) delete e.style;
            if (!Object.keys(e).length) delete work.edits[dev][id];
          });
          if (!Object.keys(work.edits[dev]).length) delete work.edits[dev];
        });
        if (!Object.keys(work.edits).length) delete work.edits;
      }
    
      function mutate(fn) {
        undoStack.push(JSON.stringify(work)); if (undoStack.length > 100) undoStack.shift();
        redoStack = [];
        fn(work); tidy();
        checkDirty();
        repaint();
      }
      function repaint() { (layer.set || layer.setDesign)(work, { editing: true }); reselect(); }
    
      function undo() { if (!undoStack.length) return false; redoStack.push(JSON.stringify(work)); work = JSON.parse(undoStack.pop()); checkDirty(); repaint(); return true; }
      function redo() { if (!redoStack.length) return false; undoStack.push(JSON.stringify(work)); work = JSON.parse(redoStack.pop()); checkDirty(); repaint(); return true; }
    
      /* The order of sections and extra blocks exactly as they appear now. */
      function fullOrder() {
        var main = document.getElementById('main'), seq = [];
        Array.prototype.slice.call(main.children).forEach(function (c) {
          if (c.hasAttribute('data-elan-custom')) seq.push(c.getAttribute('data-elan-id'));
          else if (c.tagName === 'SECTION' && c.id && ED.BUILTIN.indexOf(c.id) !== -1) seq.push(c.id);
        });
        return seq;
      }
      function sectionOf(id) {
        var m = /^sec:([a-z]+)/.exec(id || '');
        if (m) return m[1];
        var e = entryById(id), s = e && e.el.closest('section[id]');
        return s ? s.id : (/^x-/.test(id || '') ? id : null);
      }
    
      /* ---------- overlay ---------- */
      var root = document.createElement('div');
      root.id = 'elan-eo-root';
      root.innerHTML = '<style>' +
        '#elan-eo-root{position:fixed;inset:0;pointer-events:none;z-index:2147483000;font-family:"IBM Plex Sans Arabic",system-ui,sans-serif;direction:rtl}' +
        '#elan-eo-root *{box-sizing:border-box}' +
        '.eo-box{position:fixed;outline:2px solid #c8962a;background:rgba(200,150,42,.06);display:none}' +
        '.eo-h{position:absolute;width:13px;height:13px;right:-6px;bottom:-6px;background:#c8962a;border-radius:3px;cursor:nwse-resize;pointer-events:auto;touch-action:none}' +
        'body.eo-armed,body.eo-armed *{cursor:move!important}.eo-armed-box{outline:2px dashed #1f7a3d!important;background:rgba(31,122,61,.08)!important}' +
        '.eo-msg{position:fixed;bottom:12px;left:50%;transform:translateX(-50%);background:#29251c;color:#fff;padding:8px 14px;border-radius:9px;font-size:13px;display:none;max-width:90vw;pointer-events:none}' +
        '.eo-dlg{position:fixed;inset:0;display:none;align-items:center;justify-content:center;background:rgba(0,0,0,.35);pointer-events:auto}' +
        '.eo-dlg>div{background:#fffaf0;border:1px solid #c2a66a;border-radius:12px;padding:16px;width:min(420px,92vw);font-size:13px}' +
        '.eo-dlg input[type=text]{width:100%;padding:7px;border:1px solid #c2a66a;border-radius:7px;direction:ltr;margin:8px 0}' +
        '.eo-dlg button{font:inherit;padding:6px 12px;border:1px solid #c2a66a;border-radius:7px;background:#fff;cursor:pointer;margin-inline-end:6px}' +
        '[contenteditable]{outline:2px dashed #c8962a;outline-offset:2px}' +
        '</style><div class="eo-box"><i class="eo-h" data-h="se"></i></div><div class="eo-msg"></div>' +
        '<div class="eo-dlg"><div><b class="eo-dt"></b><input type="text" class="eo-di" dir="ltr"><p class="eo-dh" style="margin:0 0 8px;color:#7a6a52"></p><button class="eo-ok">تأكيد</button><button class="eo-no">إلغاء</button></div></div>';
      document.body.appendChild(root);
    
      var box = root.querySelector('.eo-box'), msgEl = root.querySelector('.eo-msg'), dlg = root.querySelector('.eo-dlg');
    
      var msgTimer = null;
      function say(text) { msgEl.textContent = text; msgEl.style.display = 'block'; clearTimeout(msgTimer); msgTimer = setTimeout(function () { msgEl.style.display = 'none'; }, 3500); }
    
      function ask(title, hint, value) {
        return new Promise(function (resolve) {
          root.querySelector('.eo-dt').textContent = title;
          root.querySelector('.eo-dh').textContent = hint || '';
          var input = root.querySelector('.eo-di'); input.value = value || '';
          dlg.style.display = 'flex'; input.focus();
          function done(v) { dlg.style.display = 'none'; root.querySelector('.eo-ok').onclick = root.querySelector('.eo-no').onclick = null; resolve(v); }
          root.querySelector('.eo-ok').onclick = function () { done(input.value.trim()); };
          root.querySelector('.eo-no').onclick = function () { done(null); };
        });
      }
    
      function placeBox() {
        var e = selectedId && entryById(selectedId);
        if (!e || (e.el.style.display === 'none')) { box.style.display = 'none'; return; }
        var r = e.el.getBoundingClientRect();
        box.style.display = 'block';
        box.style.left = r.left + 'px'; box.style.top = r.top + 'px'; box.style.width = r.width + 'px'; box.style.height = r.height + 'px';
      }
      function rgbToHex(c) {
        var m = /rgba?\((\d+),\s*(\d+),\s*(\d+)/.exec(c || '');
        if (!m) return '#000000';
        return '#' + [m[1], m[2], m[3]].map(function (n) { return ('0' + (+n).toString(16)).slice(-2); }).join('');
      }
      function cur(id) { return ED.editFor(work, device(), id) || {}; }
      /* What the editor needs to know about an element: the original editor's type names plus its current look. */
      var TYPE_OF = { section: 'section', title: 'text', 'hero-text': 'text', hero: 'section', 'hero-counters': 'text', card: 'card', block: 'block' };
      function solidBackground(c) { var m = /^rgba?\((\d+),\s*(\d+),\s*(\d+)(?:,\s*([\d.]+))?\)$/.exec(c || ''); return !m || (m[4] !== undefined && parseFloat(m[4]) === 0) ? '' : rgbToHex(c); }
      function info(e) {
        if (!e) return null;
        var node = layer.textTarget(e) || e.el, cs = getComputedStyle(node), st = cur(e.id).style || {};
        var blk = work.blocks.filter(function (b) { return b.id === e.id; })[0];
        var type = blk ? ({ text: 'text_block', banner: 'banner', image: 'image' })[blk.type] : (TYPE_OF[e.kind] || 'text');
        return {
          id: e.id, name: e.name, kind: e.kind, type: type, text: String(node.textContent || '').trim().slice(0, 120), media: st.media || '', canText: !!layer.textTarget(e), isBlock: !!blk, dynamic: !!dynamicTarget(e),
          style: {
            fontFamily: st.fontFamily || (cs.fontFamily || '').split(',')[0].replace(/["']/g, '').trim(),
            fontSize: st.fontSize || Math.round(parseFloat(cs.fontSize) || 16),
            color: st.color || rgbToHex(cs.color), background: st.background || solidBackground(getComputedStyle(e.el).backgroundColor),
            align: st.align || ({ start: 'right', end: 'left', center: 'center', left: 'left', right: 'right' })[cs.textAlign] || 'right',
            effect: st.effect || 'none'
          }
        };
      }
      function reselect() {
        if (selectedId && !entryById(selectedId)) selectedId = null;
        placeBox();
        if (hostApi) hostApi.selection(info(selectedId && entryById(selectedId)));
      }
      function select(id) { selectedId = id; reselect(); }
    
      function setStyle(id, key, val) {
        mutate(function (d) {
          var e = edit('all', id); e.style = e.style || {};
          if (val === null) delete e.style[key]; else e.style[key] = val;
        });
      }
      function reorder(id, delta) {
        var key = /^sec:/.test(id) ? id.slice(4) : id, seq = fullOrder(), i = seq.indexOf(key), j = i + delta;
        if (i < 0 || j < 0 || j >= seq.length) return;
        mutate(function (d) { seq.splice(i, 1); seq.splice(j, 0, key); d.order = seq; });
      }
      function resetElement(id) { mutate(function (d) { if (d.edits) Object.keys(d.edits).forEach(function (dev) { delete d.edits[dev][id]; }); }); }
      function archive(id) { mutate(function () { edit('all', id).archived = true; }); selectedId = null; reselect(); say('اتحط في الأرشيف. تقدر ترجّعه من الأرشيف.'); }
    
      /* ---------- picking, drag, resize, text ---------- */
      function inUi(t) { return t && t.nodeType === 1 && root.contains(t); }
      function pick(x, y) {
        var map = new Map(); entries().forEach(function (e) { map.set(e.el, e); });
        var stack = document.elementsFromPoint(x, y), best = null;
        for (var i = 0; i < stack.length; i++) { var e = map.get(stack[i]); if (e) { best = e; break; } }
        return best;
      }
    
      function base(id) { var e = cur(id); return { dx: e.dx || 0, dy: e.dy || 0 }; }
    
      /* Move works in one step: right-click an element, choose "تحريك العنصر", then hold the left button on THAT element and
         drag it anywhere. When the button is released the move ends; to move another element, repeat from the right-click. */
      function armMove(id) {
        var e = entryById(id); if (!e) throw new Error('اختاري عنصر الأول.');
        moveArm = { id: id }; select(id);
        document.body.classList.add('eo-armed'); box.classList.add('eo-armed-box');
        say('اضغطي على العنصر بالشمال واسحبيه. لما تفكي الضغط التحريك بيخلص.');
      }
      function disarm() { if (!moveArm) return; moveArm = null; document.body.classList.remove('eo-armed'); box.classList.remove('eo-armed-box'); }
    
      /* Left click on a dynamic element (it opens another page for visitors) enters that page: the editor treats it as a separate page. */
      function dynamicTarget(e) { return e && layer.goTargetOf ? layer.goTargetOf(e.el) : null; }
      function pageName() { var h = document.querySelector('#view h3'); return (h && h.textContent.trim()) || ''; }
      function inner() { return document.body.classList.contains('inner'); }
      function goHome() { disarm(); selectedId = null; document.body.classList.remove('inner'); scrollTo(0, 0); reselect(); }
      function goBack() { disarm(); selectedId = null; try { if (typeof P !== 'undefined' && P.length > 2) { P = P.slice(0, -1); openP(); } else goHome(); } catch (_) { goHome(); } reselect(); }
      function enterPage(e) {
        var g = dynamicTarget(e); if (!g || typeof window.go !== 'function') return false;
        if (editing) commitText();
        disarm(); selectedId = null;
        window.go(g);
        setTimeout(function () { reselect(); say('دخلتي صفحة جديدة' + (pageName() ? ': ' + pageName() : '') + '. كليك يمين فيها للأدوات، ومن القايمة ترجعي.'); }, 60);
        return true;
      }
    
      window.addEventListener('pointerdown', function (ev) {
        if (inUi(ev.target) && !ev.target.classList.contains('eo-h')) return;
        if (editing) { if (editing.node.contains(ev.target)) return; commitText(); }
        var handle = ev.target.classList && ev.target.classList.contains('eo-h') ? ev.target.getAttribute('data-h') : null;
        ev.preventDefault(); ev.stopPropagation();
        if (ev.button !== undefined && ev.button !== 0) return;
        var e, mode = 'click';
        if (handle) { e = entryById(selectedId); mode = 'resize'; }
        else {
          e = pick(ev.clientX, ev.clientY);
          var armed = moveArm && entryById(moveArm.id);
          if (armed && document.elementsFromPoint(ev.clientX, ev.clientY).indexOf(armed.el) !== -1) { e = armed; mode = 'move'; select(e.id); }
          else { if (moveArm) disarm(); if (e) select(e.id); else { select(null); return; } }
        }
        if (!e) return;
        var r = e.el.getBoundingClientRect(), b = base(e.id);
        gesture = { id: e.id, el: e.el, mode: mode, handle: handle, sx: ev.clientX, sy: ev.clientY, r: r, b: b, moved: false, dx: b.dx, dy: b.dy, w: null, h: null, startOffset: e.el.style.transform };
        try { (handle ? ev.target : document.documentElement).setPointerCapture && ev.target.setPointerCapture(ev.pointerId); } catch (_) { /* optional */ }
      }, true);
    
      window.addEventListener('pointermove', function (ev) {
        if (!gesture) return;
        if (gesture.mode === 'click') { if (Math.abs(ev.clientX - gesture.sx) + Math.abs(ev.clientY - gesture.sy) >= 6) gesture.moved = true; return; }
        var g = gesture, ddx = ev.clientX - g.sx, ddy = ev.clientY - g.sy;
        if (!g.moved && Math.abs(ddx) + Math.abs(ddy) < 3) return;
        g.moved = true; ev.preventDefault();
        g.el.style.position = g.el.style.position || 'relative'; g.el.style.zIndex = '3';
        if (g.mode === 'move') {
          g.dx = Math.round(g.b.dx + ddx); g.dy = Math.round(g.b.dy + ddy);
          g.el.style.transform = 'translate(' + g.dx + 'px,' + g.dy + 'px)';
        } else {
          var h = g.handle, w = g.r.width, hh = g.r.height;
          if (h.indexOf('e') !== -1) w = g.r.width + ddx; if (h.indexOf('w') !== -1) w = g.r.width - ddx;
          if (h.indexOf('s') !== -1) hh = g.r.height + ddy; if (h.indexOf('n') !== -1) hh = g.r.height - ddy;
          w = Math.max(16, Math.round(w)); hh = Math.max(16, Math.round(hh));
          if (h.length === 2 || h === 'e' || h === 'w') { g.el.style.width = w + 'px'; g.el.style.maxWidth = 'none'; g.el.style.flex = '0 0 auto'; g.w = w; }
          if (h.length === 2 || h === 'n' || h === 's') { g.el.style.height = hh + 'px'; g.h = hh; }
          // keep the opposite edge where it was, whatever the page direction is
          var nr = g.el.getBoundingClientRect(), ox = 0, oy = 0;
          if (h.indexOf('e') !== -1) ox = g.r.left - nr.left; else if (h.indexOf('w') !== -1) ox = g.r.right - nr.right;
          if (h.indexOf('s') !== -1) oy = g.r.top - nr.top; else if (h.indexOf('n') !== -1) oy = g.r.bottom - nr.bottom;
          g.dx = Math.round(g.b.dx + ox); g.dy = Math.round(g.b.dy + oy);
          g.el.style.transform = 'translate(' + g.dx + 'px,' + g.dy + 'px)';
        }
        placeBox();
      }, true);
    
      window.addEventListener('pointerup', function (ev) {
        if (!gesture) return;
        var g = gesture; gesture = null;
        if (g.mode === 'click') { if (!g.moved) enterPage(entryById(g.id)); return; }
        if (!g.moved) return;                      // pressed without dragging: a move stays armed until the element is dragged
        ev.preventDefault();
        mutate(function () {
          var e = edit(device(), g.id);
          if (g.dx) e.dx = g.dx; else delete e.dx;
          if (g.dy) e.dy = g.dy; else delete e.dy;
          if (g.w) e.w = g.w;
          if (g.h) e.h = g.h;
        });
        if (g.mode === 'move') { disarm(); say('خلص التحريك. لتحريك عنصر تاني اضغطي كليك يمين عليه واختاري تحريك العنصر.'); }
      }, true);
    
      // Nothing on the page may act while editing: no links, no cart, no forms.
      ['click', 'auxclick', 'submit', 'dragstart'].forEach(function (t) {
        window.addEventListener(t, function (ev) { if (inUi(ev.target)) return; if (editing && editing.node.contains(ev.target)) return; ev.preventDefault(); ev.stopPropagation(); }, true);
      });
    
    
      /* Right-click: the editor shows the original context menu; this side only reports what is under the pointer. */
      window.addEventListener('contextmenu', function (ev) {
        if (inUi(ev.target)) return;
        ev.preventDefault(); ev.stopPropagation();
        if (editing) commitText();
        disarm();
        var e = pick(ev.clientX, ev.clientY);
        select(e ? e.id : null);
        if (hostApi) hostApi.context({ x: ev.clientX, y: ev.clientY, element: info(e), tools: toolList(info(e)) });
      }, true);
    
      function startText(id) {
        var e = entryById(id), node = e && layer.textTarget(e);
        if (!node) { say('العنصر ده مفيهوش نص يتعدّل مباشرة.'); return; }
        commitText();
        editing = { id: id, node: node, before: node.textContent };
        node.setAttribute('contenteditable', 'plaintext-only');
        if (node.contentEditable !== 'plaintext-only') node.setAttribute('contenteditable', 'true');
        node.focus();
        var rg = document.createRange(); rg.selectNodeContents(node); var sel = getSelection(); sel.removeAllRanges(); sel.addRange(rg);
      }
      function commitText() {
        if (!editing) return;
        var ed = editing; editing = null;
        ed.node.removeAttribute('contenteditable');
        var text = ed.node.textContent.replace(/\s+/g, ' ').trim();
        if (!text || text === ed.before) { ed.node.textContent = ed.before; return; }
        mutate(function () {
          var e = edit('all', ed.id); e.text = e.text || {};
          e.text[lang()] = text.slice(0, 600);
        });
      }
      window.addEventListener('dblclick', function (ev) {
        if (inUi(ev.target)) return;
        var e = pick(ev.clientX, ev.clientY); if (!e) return;
        ev.preventDefault(); ev.stopPropagation(); select(e.id); startText(e.id);
      }, true);
      window.addEventListener('keydown', function (ev) {
        if (editing) {
          if (ev.key === 'Enter' && !ev.shiftKey) { ev.preventDefault(); commitText(); }
          else if (ev.key === 'Escape') { ev.preventDefault(); editing.node.textContent = editing.before; editing.node.removeAttribute('contenteditable'); editing = null; }
          return;
        }
        if (inUi(ev.target)) return;
        var mod = ev.ctrlKey || ev.metaKey;
        if (mod && !ev.shiftKey && ev.key.toLowerCase() === 'z') { ev.preventDefault(); undo(); }
        else if (mod && (ev.key.toLowerCase() === 'y' || (ev.shiftKey && ev.key.toLowerCase() === 'z'))) { ev.preventDefault(); redo(); }
        else if (selectedId && ev.key === 'Delete') { ev.preventDefault(); archive(selectedId); }
        else if (ev.key === 'Escape' && moveArm) { disarm(); say('اتلغى التحريك.'); }
      }, true);
      window.addEventListener('scroll', placeBox, true);
      window.addEventListener('resize', function () { placeBox(); });
      try { new MutationObserver(function () { requestAnimationFrame(reselect); }).observe(document.getElementById('main'), { childList: true }); } catch (_) { /* optional */ }
    
      /* ---------- creating blocks ---------- */
      /* Put an element so its top-left corner sits at a point of the window, for the current screen size. */
      function placeAt(id, at) {
        var e = entryById(id); if (!e) return;
        var r = e.el.getBoundingClientRect(), b = base(id);
        var dx = Math.round(b.dx + (at.x - r.left)), dy = Math.round(b.dy + (at.y - r.top));
        mutate(function () { var t = edit(device(), id); if (dx) t.dx = dx; else delete t.dx; if (dy) t.dy = dy; else delete t.dy; });
        try { e.el.scrollIntoView({ block: 'nearest' }); } catch (_) { /* optional */ }
      }
    
      function validBlock(b) { var n = ED.normalize({ version: ED.VERSION, blocks: [b] }, { strict: true }); return n.ok && n.design.blocks.length === 1; }
    
      function insertAfterSelected(blockId) {
        var seq = fullOrder(), anchor = sectionOf(selectedId), i = seq.indexOf(anchor);
        seq.splice(i === -1 ? 0 : i + 1, 0, blockId);
        return seq;
      }
      async function createSmart(kind, c) {
        var name = String(prompt('اسم العنصر الجديد') || '').trim();
        if (!name) throw new Error('اكتبي اسم العنصر قبل الإنشاء.');
        var r = await fetch('/api/editor-data', { method: 'POST', credentials: 'same-origin', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ action: 'section.create', section: { name: name, purpose: kind, selection_mode: 'manual', filters: {} } }) });
        var j = await r.json().catch(function () { return {}; });
        if (!r.ok || !j.ok || !j.ref) throw new Error(j.error || 'تعذر إنشاء القسم المركزي.');
        return createBlock('smart', { ref: j.ref, semanticKind: kind, at: c && c.at });
      }
    
      function createBlock(kind, opts) {
        opts = opts || {};
        var id = 'x-' + rid(), b;
        if (kind === 'banner') b = { id: id, type: 'banner', title: { ar: opts.title || 'عنوان جديد' }, subtitle: { ar: opts.subtitle || 'سطر تعريفي قصير' }, style: { align: 'center', size: 'md' } };
        else if (kind === 'text_block' || kind === 'text') b = { id: id, type: 'text', text: { ar: opts.text || 'نص جديد' }, style: { align: 'center', size: 'md' } };
        else if (kind === 'image') b = { id: id, type: 'image', src: opts.src, alt: {}, style: { align: 'center', size: 'md' } };
        else if (kind === 'smart') b = { id: id, type: 'smart', ref: opts.ref, style: { align: 'center', size: 'md' }, kind: opts.semanticKind || 'section' };
        else throw new Error('نوع غير مدعوم هنا');
        if (opts.image) b.image = opts.image;
        if (!validBlock(b)) throw new Error('بيانات البلوك غير صالحة (راجعي رابط الصورة).');
        var order = insertAfterSelected(id);
        mutate(function (d) { d.blocks.push(b); d.order = order; });
        select(id);
        if (opts.at) placeAt(id, opts.at);
        return { elementId: id };
      }
    
      function mediaPrompt(forId) {
        return ask('رابط الصورة', 'لازم يبدأ بـ /assets/ أو برابط مكتبة سابابيس (site-media).', '/assets/').then(function (v) {
          if (!v) throw new Error('اتلغى');
          return v;
        });
      }
    
      function setMedia(id, src) {
        var b = work.blocks.filter(function (x) { return x.id === id; })[0];
        if (b) {
          var probe = clone(b);
          if (b.type === 'image') probe.src = src;
          else if (b.type === 'banner') probe.image = src;
          else { probe.style = probe.style || {}; probe.style.media = src; }
          if (!validBlock(probe)) throw new Error('رابط الصورة مش مسموح.');
          mutate(function (d) {
            var t = d.blocks.filter(function (x) { return x.id === id; })[0];
            if (t.type === 'image') t.src = src;
            else if (t.type === 'banner') t.image = src;
            else { t.style = t.style || {}; t.style.media = src; }
          });
          return;
        }
        if (!entryById(id)) throw new Error('العنصر غير موجود.');
        mutate(function () { var e = edit('all', id); e.style = e.style || {}; e.style.media = src; });
      }
    
      function libraryElement(c) {
        var b = work.blocks.filter(function (x) { return x.id === c.id; })[0];
        return clone(b || c.info || { id: c.id, type: 'element' });
      }
      async function saveToLibrary(c) {
        var read = await fetch('/api/editor-data?action=library', { credentials: 'same-origin', cache: 'no-store' });
        var current = await read.json().catch(function () { return {}; });
        if (!read.ok || !current.ok || !current.library) throw new Error('تعذر قراءة المكتبة المركزية.');
        var element = libraryElement(c), item = { name: element.name || element.id || 'عنصر', kind: element.kind || element.type || 'element', category: element.kind || element.type || 'general', payload: element };
        var saved = Array.isArray(current.library.savedElements) ? current.library.savedElements.slice() : [];
        saved.push(item);
        var write = await fetch('/api/editor-data', { method: 'POST', credentials: 'same-origin', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ action: 'library.save', library: { archive: current.library.archive || [], savedElements: saved } }) });
        var result = await write.json().catch(function () { return {}; });
        if (!write.ok || !result.ok) throw new Error(result.error || 'تعذر حفظ العنصر في المكتبة.');
        return { saved: true };
      }
      function downloadFromLibrary(c) {
        var element = libraryElement(c), blob = new Blob([JSON.stringify({ format: 'elan-element-v1', element: element }, null, 2)], { type: 'application/json' });
        var a = document.createElement('a'); a.href = URL.createObjectURL(blob); a.download = 'elan-element.json'; a.click();
        setTimeout(function () { URL.revokeObjectURL(a.href); }, 1000);
        return { downloaded: true };
      }
      function deleteMedia(c) {
        if (c.info && c.info.media) mutate(function () { var e = edit('all', c.id); if (e.style) delete e.style.media; });
        else archive(c.id);
        return { archived: true };
      }
    
    
      /* ---------- tools: the editor's menu is built from this list, so a new capability = one new register() call ---------- */
      var TOOLS = [];
      function registerTool(t) { TOOLS = TOOLS.filter(function (x) { return x.id !== t.id; }).concat([t]); }
      function toolList(i) {
        return TOOLS.map(function (t) { return { id: t.id, label: t.label, ui: t.ui || null, enabled: t.when ? !!t.when(i) : true }; });
      }
      function has(i) { return !!i; }
      function hasText(i) { return !!(i && i.canText); }
      registerTool({ id: 'format', label: 'تنسيق النص: الخط • اللون • الحجم • 3D', ui: 'format', when: has });
      registerTool({ id: 'move', label: 'تحريك العنصر', when: has, run: function (c) { armMove(c.id); return null; } });
      registerTool({ id: 'open', label: 'فتح العنصر (الدخول لصفحته)', when: function (i) { return !!(i && i.dynamic); }, run: function (c) { enterPage(entryById(c.id)); return null; } });
      registerTool({ id: 'go_back', label: 'رجوع للصفحة السابقة', when: inner, run: function () { goBack(); return null; } });
      registerTool({ id: 'go_home', label: 'رجوع للصفحة الرئيسية', when: inner, run: function () { goHome(); return null; } });
      [['create_section', 'إنشاء سيكشن'], ['create_brand', 'إنشاء كارت براند'], ['create_store', 'إنشاء كارت متجر'], ['create_perfume', 'إنشاء كارت عطر'], ['create_occasion', 'إنشاء مناسبة'], ['create_note', 'إنشاء نوتة عطر']].forEach(function (x) { registerTool({ id: x[0], label: x[1], run: function (c) { return createSmart(x[0].replace('create_', ''), c); } }); });
      registerTool({ id: 'create_text_block', label: 'إنشاء كتلة نصية', run: function (c) { return createBlock('text_block', { at: c.at }); } });
      registerTool({ id: 'create_banner', label: 'إنشاء بانر صورة أو فيديو', ui: 'media_new', run: function (c) { return createBlock('banner', { at: c.at, image: c.src }); } });
      registerTool({ id: 'create_image', label: 'إنشاء صورة', ui: 'media_new', run: function (c) { if (!c.src) throw new Error('اختاري صورة الأول.'); return createBlock('image', { at: c.at, src: c.src }); } });
      registerTool({ id: 'create_text', label: 'إنشاء نص', run: function (c) { return createBlock('text_block', { at: c.at }); } });
      registerTool({ id: 'media', label: 'رفع صورة أو فيديو داخل العناصر أو الهيرو', ui: 'media', when: function (i) { return !!i && ['text', 'text_block'].indexOf(i.type) === -1; }, run: function (c) { return mediaPrompt().then(function (src) { setMedia(c.id, src); return null; }); } });
      registerTool({ id: 'media_delete', label: 'حذف ميديا العنصر إلى الأرشيف', when: function (i) { return !!i && !!i.media; }, run: deleteMedia });
      registerTool({ id: 'edit_text', label: 'تعديل النص بالكيبورد', when: hasText, run: function (c) { startText(c.id); return null; } });
      registerTool({ id: 'copy', label: 'نسخ العنصر', when: has, run: function (c) { return execute('element.duplicate', { elementId: c.id }, {}); } });
      registerTool({ id: 'archive', label: 'حذف العنصر إلى الأرشيف', when: has, run: function (c) { archive(c.id); return null; } });
      registerTool({ id: 'library_save', label: 'حفظ العنصر في المكتبة', when: has, run: saveToLibrary });
      registerTool({ id: 'library_download', label: 'تنزيل العنصر للمكتبة كملف', when: has, run: downloadFromLibrary });
      window.ElanEditTools = { register: registerTool, list: function () { return TOOLS.slice(); } };
    
      /* ---------- commands from the editor ---------- */
      function archiveList() {
        var out = [], e = (work.edits && work.edits.all) || {};
        Object.keys(e).forEach(function (id) { if (e[id].archived) out.push({ id: id, name: (entryById(id) || { name: id }).name }); });
        return out;
      }
      function snapshot() { return { revision: baseRevision, design: clone(work), device: device(), dirty: dirty, archive: archiveList(), selected: info(selectedId && entryById(selectedId)) }; }
      function need(id) { var e = id && entryById(id); if (!e) throw new Error('اختاري عنصر الأول.'); return e; }
    
      async function execute(action, p, meta) {
        p = p || {};
        switch (action) {
          case 'page.getState': return snapshot();
          case 'page.markSaved': baseRevision = p.revision; undoStack = []; redoStack = []; baseJson = JSON.stringify(work); dirty = true; setDirty(false); if (hostApi) hostApi.revision(baseRevision); return snapshot();
          case 'element.select': select(need(p.elementId).id); return { selected: selectedId };
          case 'element.move': { var e1 = need(p.elementId || selectedId); mutate(function () { var t = edit(device(), e1.id); t.dx = Math.round(+p.dx || 0); t.dy = Math.round(+p.dy || 0); }); return null; }
          case 'element.resize': { var e2 = need(p.elementId || selectedId); mutate(function () { var t = edit(device(), e2.id); if (p.w) t.w = Math.round(p.w); if (p.h) t.h = Math.round(p.h); }); return null; }
          case 'element.format': { var e3 = need(p.elementId || selectedId), sty = p.style || {}; mutate(function (d) { var t = edit('all', e3.id); t.style = t.style || {}; Object.keys(sty).forEach(function (k) { if (sty[k] === null) delete t.style[k]; else t.style[k] = sty[k]; }); }); return null; }
          case 'element.setText': { var e4 = need(p.elementId || selectedId); mutate(function () { var t = edit('all', e4.id); t.text = t.text || {}; t.text[lang()] = String(p.text || '').slice(0, 600); }); return null; }
          case 'element.setMedia': { var e5 = need(p.elementId || selectedId); setMedia(e5.id, p.src || await mediaPrompt(e5.id)); return null; }
          case 'element.create': return createBlock(p.kind, p);
          case 'element.duplicate': {
            var e6 = need(p.elementId || selectedId), src = work.blocks.filter(function (b) { return b.id === e6.id; })[0];
            if (!src) throw new Error('التكرار متاح للبلوكات الإضافية بس.');
            var copy = clone(src); copy.id = 'x-' + rid(); var order = fullOrder(), b0 = base(src.id); order.splice(order.indexOf(src.id) + 1, 0, copy.id);
            var r0 = e6.el.getBoundingClientRect();
            mutate(function (d) { d.blocks.push(copy); d.order = order; var from = d.edits && ((d.edits.all || {})[src.id]); if (from) d.edits.all[copy.id] = JSON.parse(JSON.stringify(from)); });
            select(copy.id); placeAt(copy.id, { x: r0.left + 20, y: r0.top + 20 }); return { elementId: copy.id };
          }
          case 'tool.run': {
            var tool = TOOLS.filter(function (x) { return x.id === p.id; })[0];
            if (!tool) throw new Error('أداة غير معروفة');
            var ei = p.elementId ? entryById(p.elementId) : null, inf = info(ei);
            if (tool.when && !tool.when(inf)) throw new Error('الأداة دي مش متاحة للعنصر ده.');
            var out = await tool.run({ id: p.elementId || null, info: inf, at: p.at || null, src: typeof p.src === 'string' ? p.src : null });
            return out === undefined ? null : out;
          }
          case 'element.nudge': {
            var en = need(p.elementId || selectedId), nb = base(en.id);
            var ndx = nb.dx + Math.round(+p.dx || 0), ndy = nb.dy + Math.round(+p.dy || 0);
            mutate(function () { var t = edit(device(), en.id); if (ndx) t.dx = ndx; else delete t.dx; if (ndy) t.dy = ndy; else delete t.dy; });
            return null;
          }
          case 'element.edit': { var e9 = need(p.elementId || selectedId); startText(e9.id); return null; }
          case 'element.archive': archive(need(p.elementId || selectedId).id); return null;
          case 'archive.restore': mutate(function (d) { if (d.edits) Object.keys(d.edits).forEach(function (dev) { if (d.edits[dev][p.elementId]) delete d.edits[dev][p.elementId].archived; }); }); return snapshot();
          case 'history.undo': return { ok: undo() };
          case 'history.redo': return { ok: redo() };
          case 'ui.openFormatPanel': if (p.elementId) select(need(p.elementId).id); if (!selectedId) throw new Error('اضغطي على عنصر في الصفحة الأول.'); return null;
          case 'ui.openMediaPanel': { var id7 = p.elementId || selectedId; if (!id7) throw new Error('اختاري بانر أو صورة الأول.'); setMedia(id7, await mediaPrompt(id7)); return null; }
          case 'ui.openCreatePanel':
            if (p.kind === 'banner' || p.kind === 'text_block' || p.kind === 'text') return createBlock(p.kind === 'text' ? 'text_block' : p.kind, { at: p.at });
            if (p.kind === 'image') { var src8 = await mediaPrompt(); return createBlock('image', { src: src8, at: p.at }); }
            if (['section', 'brand', 'store', 'perfume', 'occasion', 'note'].indexOf(p.kind) !== -1) return createSmart(p.kind, { at: p.at });
            throw new Error('نوع إنشاء غير مدعوم: ' + p.kind);
          case 'library.open': return { openLibrary: true };
          case 'page.save': throw new Error('الحفظ بيتم من الإديتور نفسه بعد التحقق من الإدارة.');
          default: throw new Error('أمر غير مدعوم');
        }
      }
    
      async function loadBase() {
        var r = await fetch('/api/editor?action=state', { credentials: 'same-origin', cache: 'no-store' });
        var j = await r.json().catch(function () { return {}; });
        if (!r.ok || !j.ok) {
          var why = r.status === 503 ? 'إعدادات الإديتور ناقصة على السيرفر' + (j.missing && j.missing.length ? ': ' + j.missing.join('، ') : '') + '.'
            : r.status === 401 || r.status === 403 ? 'الحساب ده مش مصرح له (محتاج أدمن المنصة). سجلي الدخول تاني.'
            : 'تعذر قراءة آخر إصدار منشور (' + r.status + ').';
          var e = new Error('state'); e.userMessage = why; throw e;
        }
        baseRevision = j.revision === null || j.revision === undefined ? 'initial' : j.revision;
        work = ED.normalize(j.design || { version: ED.VERSION }, { strict: false }).design;
        undoStack = []; redoStack = []; dirty = false; baseJson = JSON.stringify(work);
        repaint();
        return { revision: baseRevision, design: clone(work) };
      }
    
      hostApi = Bridge.install({
        allowedEditorOrigins: [location.origin],
        authorize: async function () {
          try { var r = await fetch('/api/editor-session', { credentials: 'same-origin', cache: 'no-store' }); return r.ok; } catch (_) { return false; }
        },
        getState: async function () { if (!work) await loadBase(); return snapshot(); },
        execute: execute
      });
      work = null;
      window.ElanEditMode = { state: snapshot, execute: function (a, p) { return execute(a, p || {}, {}); }, _debug: function () { return work; } };
    })();
    
  operator: 'match'
  stack: |-
    TestContext.<anonymous> (/home/ubuntu/elan-scents/tests/editor-about-footer.test.js:17:10)
    Test.runInAsyncScope (node:async_hooks:211:14)
    Test.run (node:internal/test_runner/test:931:25)
    Test.processPendingSubtests (node:internal/test_runner/test:629:18)
    Test.postRun (node:internal/test_runner/test:1042:19)
    Test.run (node:internal/test_runner/test:970:12)
    async startSubtestAfterBootstrap (node:internal/test_runner/harness:296:3)
  ...
# Subtest: the editor handler is hosted by the Railway API adapter
ok 43 - the editor handler is hosted by the Railway API adapter
  ---
  duration_ms: 2.271429
  ...
# Subtest: git blob hashing matches git itself
ok 44 - git blob hashing matches git itself
  ---
  duration_ms: 1.386815
  ...
# Subtest: rejects anonymous callers and non-admin roles before touching GitHub
ok 45 - rejects anonymous callers and non-admin roles before touching GitHub
  ---
  duration_ms: 2.344967
  ...
# Subtest: only GET and POST are accepted and unknown actions are refused
ok 46 - only GET and POST are accepted and unknown actions are refused
  ---
  duration_ms: 1.565854
  ...
# Subtest: keeps editor state readable but refuses writes when GitHub is not configured
not ok 47 - keeps editor state readable but refuses writes when GitHub is not configured
  ---
  duration_ms: 2.281194
  location: '/home/ubuntu/elan-scents/tests/editor-api.test.js:97:1'
  failureType: 'testCodeFailure'
  error: |-
    Expected values to be strictly equal:
    
    503 !== 200
    
  code: 'ERR_ASSERTION'
  name: 'AssertionError'
  expected: 200
  actual: 503
  operator: 'strictEqual'
  stack: |-
    TestContext.<anonymous> (/home/ubuntu/elan-scents/tests/editor-api.test.js:99:10)
    async Test.run (node:internal/test_runner/test:932:9)
    async Test.processPendingSubtests (node:internal/test_runner/test:629:7)
  ...
# Subtest: non-production environments cannot write main, while production targets main
ok 48 - non-production environments cannot write main, while production targets main
  ---
  duration_ms: 4.444097
  ...
# Subtest: state returns the committed design and its revision
ok 49 - state returns the committed design and its revision
  ---
  duration_ms: 3.897816
  ...
# Subtest: save commits exactly one file, on the configured branch, with the expected sha
ok 50 - save commits exactly one file, on the configured branch, with the expected sha
  ---
  duration_ms: 2.621968
  ...
# Subtest: save refuses invalid designs, missing revision and missing request id without calling GitHub to write
ok 51 - save refuses invalid designs, missing revision and missing request id without calling GitHub to write
  ---
  duration_ms: 3.201451
  ...
# Subtest: a stale revision is rejected and nothing is overwritten
ok 52 - a stale revision is rejected and nothing is overwritten
  ---
  duration_ms: 1.721785
  ...
# Subtest: a race between read and write is caught by GitHub and reported as a conflict
ok 53 - a race between read and write is caught by GitHub and reported as a conflict
  ---
  duration_ms: 1.236641
  ...
# Subtest: retrying a save that already landed is a safe no-op success (network dropped after commit)
ok 54 - retrying a save that already landed is a safe no-op success (network dropped after commit)
  ---
  duration_ms: 1.613551
  ...
# Subtest: GitHub failures are reported clearly and never as success
ok 55 - GitHub failures are reported clearly and never as success
  ---
  duration_ms: 1.19728
  ...
# Subtest: first save creates the file when it does not exist yet
ok 56 - first save creates the file when it does not exist yet
  ---
  duration_ms: 0.720511
  ...
# Subtest: status reports published only when the live site serves the committed bytes
ok 57 - status reports published only when the live site serves the committed bytes
  ---
  duration_ms: 2.029056
  ...
# Subtest: every font offered in the format panel is accepted by the design schema
ok 58 - every font offered in the format panel is accepted by the design schema
  ---
  duration_ms: 4.928292
  ...
# Subtest: format apply only sends what the owner changed and opens with the real values
not ok 59 - format apply only sends what the owner changed and opens with the real values
  ---
  duration_ms: 4.331587
  location: '/home/ubuntu/elan-scents/tests/editor-format-panel.test.js:19:1'
  failureType: 'testCodeFailure'
  error: |-
    The input did not match the regular expression /if\(col!==init\.color\)style\.color=col/. Input:
    
    `<!doctype html><html lang="ar" dir="rtl"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>محرر إيلان — بداية جديدة</title><style>*{box-sizing:border-box}body{margin:0;font-family:Tahoma,Arial;background:#eae7e1;color:#222}header{height:68px;background:#191919;color:#eeddb8;display:flex;align-items:center;gap:10px;padding:12px 20px;position:sticky;top:0;z-index:5}button,input,select{font:inherit}button{cursor:pointer;border:1px solid #c2a66a;border-radius:7px;padding:9px 13px;background:#fffaf0;color:#29251c}header strong{margin-left:auto}#status{font-size:12px;color:#ddd}#hint{padding:12px;text-align:center;font-size:13px;line-height:1.7}#viewport{overflow:auto;padding:20px;height:calc(100vh - 125px)}#canvas{width:1100px;height:900px;position:relative;background:#fffdf9;box-shadow:0 8px 40px #0001;margin:0 auto;direction:rtl}.item{position:absolute;touch-action:none;outline:none;overflow:hidden}.item.selected{outline:2px solid #a88032;overflow:visible}.content{width:100%;height:100%;overflow:hidden}.text .content{white-space:pre-wrap;line-height:1.4;cursor:move}.editing .content{cursor:text;user-select:text;overflow:auto}.image img{width:100%;height:100%;object-fit:cover;pointer-events:none}.card .content{padding:22px;border:1px solid #bd9c57;border-radius:16px;box-shadow:0 8px 20px #0001;background:#fffdf8}.handle{position:absolute;width:13px;height:13px;background:#fff;border:2px solid #a88032;right:-7px;bottom:-7px;cursor:nwse-resize;z-index:3;display:none;touch-action:none}.selected .handle{display:block}#menu{display:none;position:fixed;z-index:20;width:220px;max-height:80vh;overflow:auto;padding:8px;border:1px solid #b59655;border-radius:12px;background:#fff;box-shadow:0 10px 35px #0003}#menu button{display:block;width:100%;text-align:right;margin:4px 0}dialog{border:1px solid #c0a064;border-radius:14px;padding:24px;max-width:95vw;max-height:90vh;overflow:auto}dialog::backdrop{background:#0005}label{display:block;margin:12px 0}input,select,textarea{padding:8px;border:1px solid #ccb98d;border-radius:6px;max-width:100%}#archiveList button{display:block;margin:8px 0}small{display:block;line-height:1.7;color:#666}button:disabled{opacity:.4;cursor:default}</style></head><body><header><strong>Élan Scents · محرر تجريبي جديد</strong><button id="undo">↶ تراجع</button><button id="redo">↷ إعادة</button><button id="save">حفظ</button><button id="library">المكتبة</button><span id="status">حفظ محلي فقط</span></header><div id="hint">كليك شمال للتحديد والسحب. اسحب المقبض لتغيير الحجم. كليك يمين للأدوات. اضغط مرتين على النص واكتب بالكيبورد. هذه مساحة اختبار ثابتة، وليست منصة متصلة.</div><div id="viewport"><div id="canvas"></div></div><div id="menu"></div><input id="upload" type="file" accept="image/*,video/*" hidden><dialog id="format"><h3>تنسيق العنصر</h3><label>الخط <select id="font"><option>Tahoma</option><option>Arial</option><option>Georgia</option><option>Times New Roman</option><option>Verdana</option></select></label><label>حجم الخط <input id="size" type="number" min="8" max="160"></label><label>لون النص <input id="color" type="color"></label><label>لون الخلفية <input id="bg" type="color"></label><label>المحاذاة <select id="align"><option value="right">يمين</option><option value="center">وسط</option><option value="left">يسار</option></select></label><button id="apply">تطبيق</button> <button onclick="this.closest('dialog').close()">إغلاق</button></dialog><dialog id="libraryDialog"><h3>المكتبة والأرشيف المحلي</h3><button id="addMedia">رفع صورة أو فيديو</button><h4>الميديا المحفوظة</h4><div id="mediaList"></div><h4>العناصر المحذوفة</h4><div id="archiveList"></div><small>للملفات الصغيرة فقط، حد الملف 1 ميجابايت. ليست مكتبة سحابية.</small><button onclick="this.closest('dialog').close()">إغلاق</button></dialog><script src="/editor/editor-data-bridge.js?v=20261014-01"></script><script>\n` +
      "const canvas=document.getElementById('canvas'),menu=document.getElementById('menu'),status=document.getElementById('status');const storageKey='elan-fresh-editor-v1';let state={items:[{id:'title',type:'text',x:280,y:90,w:540,h:110,text:'Élan Scents',font:'Georgia',size:64,color:'#a17b35',bg:'#fffdf9',align:'center'},{id:'subtitle',type:'text',x:280,y:220,w:540,h:65,text:'سحر الخليج بين يديك',font:'Tahoma',size:30,color:'#282828',bg:'#fffdf9',align:'center'},{id:'card',type:'card',x:390,y:360,w:300,h:200,text:'كارت عطر تجريبي\\nليست بيانات متجر حقيقية',font:'Tahoma',size:22,color:'#282828',bg:'#fffdf9',align:'center'}],archive:[],media:[]};let selected=null,history=[],future=[],dirty=false,editing=false,gesture=null,replaceId=null;\n" +
      "try{const s=JSON.parse(localStorage.getItem(storageKey));if(s&&Array.isArray(s.items)&&Array.isArray(s.archive)&&Array.isArray(s.media))state=s;}catch(e){status.textContent='تعذر قراءة الحفظ السابق.';}\n" +
      "const clone=x=>JSON.parse(JSON.stringify(x));function checkpoint(){history.push(clone(state));if(history.length>30)history.shift();future=[];}function changed(){dirty=true;status.textContent='تعديلات غير محفوظة';document.getElementById('undo').disabled=!history.length;document.getElementById('redo').disabled=!future.length;}function current(){return state.items.find(i=>i.id===selected);}function uid(){return 'item-'+Date.now()+'-'+Math.random().toString(16).slice(2,8);}function select(id){selected=id;canvas.querySelectorAll('.item').forEach(el=>el.classList.toggle('selected',el.dataset.id===id));}\n" +
      "function render(){canvas.replaceChildren();state.items.forEach(item=>{const el=document.createElement('div');el.className='item '+item.type;el.dataset.id=item.id;Object.assign(el.style,{left:item.x+'px',top:item.y+'px',width:item.w+'px',height:item.h+'px',zIndex:String(item.z||1)});const content=document.createElement('div');content.className='content';Object.assign(content.style,{fontFamily:item.font||'Tahoma',fontSize:(item.size||24)+'px',color:item.color||'#222',backgroundColor:item.bg||'#fffdf9',textAlign:item.align||'right',whiteSpace:'pre-wrap'});if(item.type==='image'){const img=document.createElement('img');img.src=item.src;img.alt='صورة في التصميم';content.append(img);}else if(item.type==='video'){const v=document.createElement('video');v.src=item.src;v.controls=true;v.style.cssText='width:100%;height:100%;object-fit:contain';content.append(v);}else content.textContent=item.text||'';el.append(content);const handle=document.createElement('div');handle.className='handle';el.append(handle);canvas.append(el);\n" +
      "el.addEventListener('pointerdown',e=>{if(e.button!==0||editing||e.target.closest('video'))return;e.preventDefault();select(item.id);menu.style.display='none';checkpoint();gesture={id:item.id,mode:e.target===handle?'resize':'move',sx:e.clientX,sy:e.clientY,x:item.x,y:item.y,w:item.w,h:item.h};el.setPointerCapture(e.pointerId);});el.addEventListener('pointermove',e=>{if(!gesture||gesture.id!==item.id)return;const dx=e.clientX-gesture.sx,dy=e.clientY-gesture.sy;if(gesture.mode==='resize'){item.w=Math.max(40,Math.min(1100-item.x,gesture.w+dx));item.h=Math.max(30,Math.min(900-item.y,gesture.h+dy));}else{item.x=Math.max(0,Math.min(1100-item.w,gesture.x+dx));item.y=Math.max(0,Math.min(900-item.h,gesture.y+dy));}Object.assign(el.style,{left:item.x+'px',top:item.y+'px',width:item.w+'px',height:item.h+'px'});changed();});function finish(){gesture=null;}el.addEventListener('pointerup',finish);el.addEventListener('pointercancel',finish);\n" +
      "el.addEventListener('dblclick',e=>{if(!['text','card'].includes(item.type))return;select(item.id);checkpoint();editing=true;el.classList.add('editing');content.contentEditable='plaintext-only';content.focus();});content.addEventListener('input',()=>{if(editing){item.text=content.innerText;changed();}});content.addEventListener('blur',()=>{content.contentEditable='false';el.classList.remove('editing');editing=false;});el.addEventListener('contextmenu',e=>{e.preventDefault();e.stopPropagation();select(item.id);showMenu(e);});});select(selected);document.getElementById('undo').disabled=!history.length;document.getElementById('redo').disabled=!future.length;}\n" +
      "function add(type,src){checkpoint();const item={id:uid(),type,x:350,y:300,w:320,h:type==='text'?90:220,text:type==='text'?'اكتب نصك هنا':'كارت جديد',font:'Tahoma',size:26,color:'#252525',bg:'#fffdf9',align:'right',src};state.items.push(item);selected=item.id;changed();render();}\n" +
      "function action(label,callback,enabled=true){const b=document.createElement('button');b.textContent=label;b.disabled=!enabled;b.onclick=()=>{menu.style.display='none';callback();};menu.append(b);}\n" +
      `function showMenu(e){menu.replaceChildren();const item=current();action('إضافة نص',()=>add('text'));action('إضافة كارت',()=>add('card'));action('إضافة صورة أو فيديو',()=>{replaceId=null;document.getElementById('upload').click();});action('تعديل النص بالكيبورد',()=>{const el=canvas.querySelector('[data-id="'+selected+'"]');el?.dispatchEvent(new MouseEvent('dblclick',{bubbles:true}));},!!item&&['text','card'].includes(item.type));action('الخط واللون والحجم',openFormat,!!item);action('تكبير الخط +',()=>resizeText(2),!!item&&['text','card'].includes(item.type));action('تصغير الخط −',()=>resizeText(-2),!!item&&['text','card'].includes(item.type));action('استبدال الصورة أو الفيديو',()=>{replaceId=selected;document.getElementById('upload').click();},!!item&&['image','video'].includes(item.type));action('نسخ العنصر',()=>{checkpoint();const copy=clone(current());copy.id=uid();copy.x=Math.min(1100-copy.w,copy.x+20);copy.y=Math.min(900-copy.h,copy.y+20);state.items.push(copy);selected=copy.id;changed();render();},!!item);action('حذف إلى الأرشيف',()=>{checkpoint();state.archive.push(clone(current()));state.items=state.items.filter(i=>i.id!==selected);selected=null;changed();render();},!!item);menu.style.display='block';const r=menu.getBoundingClientRect();menu.style.left=Math.max(4,Math.min(e.clientX,innerWidth-r.width-8))+'px';menu.style.top=Math.max(4,Math.min(e.clientY,innerHeight-r.height-8))+'px';}\n` +
      'function resizeText(d){const '... 182017 more characters
    
  code: 'ERR_ASSERTION'
  name: 'AssertionError'
  expected:
  actual: |-
    <!doctype html><html lang="ar" dir="rtl"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>محرر إيلان — بداية جديدة</title><style>*{box-sizing:border-box}body{margin:0;font-family:Tahoma,Arial;background:#eae7e1;color:#222}header{height:68px;background:#191919;color:#eeddb8;display:flex;align-items:center;gap:10px;padding:12px 20px;position:sticky;top:0;z-index:5}button,input,select{font:inherit}button{cursor:pointer;border:1px solid #c2a66a;border-radius:7px;padding:9px 13px;background:#fffaf0;color:#29251c}header strong{margin-left:auto}#status{font-size:12px;color:#ddd}#hint{padding:12px;text-align:center;font-size:13px;line-height:1.7}#viewport{overflow:auto;padding:20px;height:calc(100vh - 125px)}#canvas{width:1100px;height:900px;position:relative;background:#fffdf9;box-shadow:0 8px 40px #0001;margin:0 auto;direction:rtl}.item{position:absolute;touch-action:none;outline:none;overflow:hidden}.item.selected{outline:2px solid #a88032;overflow:visible}.content{width:100%;height:100%;overflow:hidden}.text .content{white-space:pre-wrap;line-height:1.4;cursor:move}.editing .content{cursor:text;user-select:text;overflow:auto}.image img{width:100%;height:100%;object-fit:cover;pointer-events:none}.card .content{padding:22px;border:1px solid #bd9c57;border-radius:16px;box-shadow:0 8px 20px #0001;background:#fffdf8}.handle{position:absolute;width:13px;height:13px;background:#fff;border:2px solid #a88032;right:-7px;bottom:-7px;cursor:nwse-resize;z-index:3;display:none;touch-action:none}.selected .handle{display:block}#menu{display:none;position:fixed;z-index:20;width:220px;max-height:80vh;overflow:auto;padding:8px;border:1px solid #b59655;border-radius:12px;background:#fff;box-shadow:0 10px 35px #0003}#menu button{display:block;width:100%;text-align:right;margin:4px 0}dialog{border:1px solid #c0a064;border-radius:14px;padding:24px;max-width:95vw;max-height:90vh;overflow:auto}dialog::backdrop{background:#0005}label{display:block;margin:12px 0}input,select,textarea{padding:8px;border:1px solid #ccb98d;border-radius:6px;max-width:100%}#archiveList button{display:block;margin:8px 0}small{display:block;line-height:1.7;color:#666}button:disabled{opacity:.4;cursor:default}</style></head><body><header><strong>Élan Scents · محرر تجريبي جديد</strong><button id="undo">↶ تراجع</button><button id="redo">↷ إعادة</button><button id="save">حفظ</button><button id="library">المكتبة</button><span id="status">حفظ محلي فقط</span></header><div id="hint">كليك شمال للتحديد والسحب. اسحب المقبض لتغيير الحجم. كليك يمين للأدوات. اضغط مرتين على النص واكتب بالكيبورد. هذه مساحة اختبار ثابتة، وليست منصة متصلة.</div><div id="viewport"><div id="canvas"></div></div><div id="menu"></div><input id="upload" type="file" accept="image/*,video/*" hidden><dialog id="format"><h3>تنسيق العنصر</h3><label>الخط <select id="font"><option>Tahoma</option><option>Arial</option><option>Georgia</option><option>Times New Roman</option><option>Verdana</option></select></label><label>حجم الخط <input id="size" type="number" min="8" max="160"></label><label>لون النص <input id="color" type="color"></label><label>لون الخلفية <input id="bg" type="color"></label><label>المحاذاة <select id="align"><option value="right">يمين</option><option value="center">وسط</option><option value="left">يسار</option></select></label><button id="apply">تطبيق</button> <button onclick="this.closest('dialog').close()">إغلاق</button></dialog><dialog id="libraryDialog"><h3>المكتبة والأرشيف المحلي</h3><button id="addMedia">رفع صورة أو فيديو</button><h4>الميديا المحفوظة</h4><div id="mediaList"></div><h4>العناصر المحذوفة</h4><div id="archiveList"></div><small>للملفات الصغيرة فقط، حد الملف 1 ميجابايت. ليست مكتبة سحابية.</small><button onclick="this.closest('dialog').close()">إغلاق</button></dialog><script src="/editor/editor-data-bridge.js?v=20261014-01"></script><script>
    const canvas=document.getElementById('canvas'),menu=document.getElementById('menu'),status=document.getElementById('status');const storageKey='elan-fresh-editor-v1';let state={items:[{id:'title',type:'text',x:280,y:90,w:540,h:110,text:'Élan Scents',font:'Georgia',size:64,color:'#a17b35',bg:'#fffdf9',align:'center'},{id:'subtitle',type:'text',x:280,y:220,w:540,h:65,text:'سحر الخليج بين يديك',font:'Tahoma',size:30,color:'#282828',bg:'#fffdf9',align:'center'},{id:'card',type:'card',x:390,y:360,w:300,h:200,text:'كارت عطر تجريبي\nليست بيانات متجر حقيقية',font:'Tahoma',size:22,color:'#282828',bg:'#fffdf9',align:'center'}],archive:[],media:[]};let selected=null,history=[],future=[],dirty=false,editing=false,gesture=null,replaceId=null;
    try{const s=JSON.parse(localStorage.getItem(storageKey));if(s&&Array.isArray(s.items)&&Array.isArray(s.archive)&&Array.isArray(s.media))state=s;}catch(e){status.textContent='تعذر قراءة الحفظ السابق.';}
    const clone=x=>JSON.parse(JSON.stringify(x));function checkpoint(){history.push(clone(state));if(history.length>30)history.shift();future=[];}function changed(){dirty=true;status.textContent='تعديلات غير محفوظة';document.getElementById('undo').disabled=!history.length;document.getElementById('redo').disabled=!future.length;}function current(){return state.items.find(i=>i.id===selected);}function uid(){return 'item-'+Date.now()+'-'+Math.random().toString(16).slice(2,8);}function select(id){selected=id;canvas.querySelectorAll('.item').forEach(el=>el.classList.toggle('selected',el.dataset.id===id));}
    function render(){canvas.replaceChildren();state.items.forEach(item=>{const el=document.createElement('div');el.className='item '+item.type;el.dataset.id=item.id;Object.assign(el.style,{left:item.x+'px',top:item.y+'px',width:item.w+'px',height:item.h+'px',zIndex:String(item.z||1)});const content=document.createElement('div');content.className='content';Object.assign(content.style,{fontFamily:item.font||'Tahoma',fontSize:(item.size||24)+'px',color:item.color||'#222',backgroundColor:item.bg||'#fffdf9',textAlign:item.align||'right',whiteSpace:'pre-wrap'});if(item.type==='image'){const img=document.createElement('img');img.src=item.src;img.alt='صورة في التصميم';content.append(img);}else if(item.type==='video'){const v=document.createElement('video');v.src=item.src;v.controls=true;v.style.cssText='width:100%;height:100%;object-fit:contain';content.append(v);}else content.textContent=item.text||'';el.append(content);const handle=document.createElement('div');handle.className='handle';el.append(handle);canvas.append(el);
    el.addEventListener('pointerdown',e=>{if(e.button!==0||editing||e.target.closest('video'))return;e.preventDefault();select(item.id);menu.style.display='none';checkpoint();gesture={id:item.id,mode:e.target===handle?'resize':'move',sx:e.clientX,sy:e.clientY,x:item.x,y:item.y,w:item.w,h:item.h};el.setPointerCapture(e.pointerId);});el.addEventListener('pointermove',e=>{if(!gesture||gesture.id!==item.id)return;const dx=e.clientX-gesture.sx,dy=e.clientY-gesture.sy;if(gesture.mode==='resize'){item.w=Math.max(40,Math.min(1100-item.x,gesture.w+dx));item.h=Math.max(30,Math.min(900-item.y,gesture.h+dy));}else{item.x=Math.max(0,Math.min(1100-item.w,gesture.x+dx));item.y=Math.max(0,Math.min(900-item.h,gesture.y+dy));}Object.assign(el.style,{left:item.x+'px',top:item.y+'px',width:item.w+'px',height:item.h+'px'});changed();});function finish(){gesture=null;}el.addEventListener('pointerup',finish);el.addEventListener('pointercancel',finish);
    el.addEventListener('dblclick',e=>{if(!['text','card'].includes(item.type))return;select(item.id);checkpoint();editing=true;el.classList.add('editing');content.contentEditable='plaintext-only';content.focus();});content.addEventListener('input',()=>{if(editing){item.text=content.innerText;changed();}});content.addEventListener('blur',()=>{content.contentEditable='false';el.classList.remove('editing');editing=false;});el.addEventListener('contextmenu',e=>{e.preventDefault();e.stopPropagation();select(item.id);showMenu(e);});});select(selected);document.getElementById('undo').disabled=!history.length;document.getElementById('redo').disabled=!future.length;}
    function add(type,src){checkpoint();const item={id:uid(),type,x:350,y:300,w:320,h:type==='text'?90:220,text:type==='text'?'اكتب نصك هنا':'كارت جديد',font:'Tahoma',size:26,color:'#252525',bg:'#fffdf9',align:'right',src};state.items.push(item);selected=item.id;changed();render();}
    function action(label,callback,enabled=true){const b=document.createElement('button');b.textContent=label;b.disabled=!enabled;b.onclick=()=>{menu.style.display='none';callback();};menu.append(b);}
    function showMenu(e){menu.replaceChildren();const item=current();action('إضافة نص',()=>add('text'));action('إضافة كارت',()=>add('card'));action('إضافة صورة أو فيديو',()=>{replaceId=null;document.getElementById('upload').click();});action('تعديل النص بالكيبورد',()=>{const el=canvas.querySelector('[data-id="'+selected+'"]');el?.dispatchEvent(new MouseEvent('dblclick',{bubbles:true}));},!!item&&['text','card'].includes(item.type));action('الخط واللون والحجم',openFormat,!!item);action('تكبير الخط +',()=>resizeText(2),!!item&&['text','card'].includes(item.type));action('تصغير الخط −',()=>resizeText(-2),!!item&&['text','card'].includes(item.type));action('استبدال الصورة أو الفيديو',()=>{replaceId=selected;document.getElementById('upload').click();},!!item&&['image','video'].includes(item.type));action('نسخ العنصر',()=>{checkpoint();const copy=clone(current());copy.id=uid();copy.x=Math.min(1100-copy.w,copy.x+20);copy.y=Math.min(900-copy.h,copy.y+20);state.items.push(copy);selected=copy.id;changed();render();},!!item);action('حذف إلى الأرشيف',()=>{checkpoint();state.archive.push(clone(current()));state.items=state.items.filter(i=>i.id!==selected);selected=null;changed();render();},!!item);menu.style.display='block';const r=menu.getBoundingClientRect();menu.style.left=Math.max(4,Math.min(e.clientX,innerWidth-r.width-8))+'px';menu.style.top=Math.max(4,Math.min(e.clientY,innerHeight-r.height-8))+'px';}
    function resizeText(d){const i=current();if(!i)return;checkpoint();i.size=Math.max(8,Math.min(160,(i.size||24)+d));changed();render();}
    function openFormat(){const i=current();if(!i)return;document.getElementById('font').value=i.font||'Tahoma';document.getElementById('size').value=i.size||24;document.getElementById('color').value=i.color||'#222222';document.getElementById('bg').value=i.bg||'#fffdf9';document.getElementById('align').value=i.align||'right';document.getElementById('format').showModal();}
    document.getElementById('apply').onclick=()=>{const i=current();if(!i)return;checkpoint();i.font=document.getElementById('font').value;i.size=Math.max(8,Math.min(160,Number(document.getElementById('size').value)||24));i.color=document.getElementById('color').value;i.bg=document.getElementById('bg').value;i.align=document.getElementById('align').value;changed();render();document.getElementById('format').close();};
    canvas.addEventListener('contextmenu',e=>{e.preventDefault();select(null);showMenu(e);});canvas.addEventListener('pointerdown',e=>{if(e.target===canvas){select(null);menu.style.display='none';}});document.addEventListener('pointerdown',e=>{if(!menu.contains(e.target))menu.style.display='none';});document.addEventListener('keydown',e=>{if(e.key==='Escape')menu.style.display='none';});
    document.getElementById('undo').onclick=()=>{if(!history.length)return;future.push(clone(state));state=history.pop();changed();render();};document.getElementById('redo').onclick=()=>{if(!future.length)return;history.push(clone(state));state=future.pop();changed();render();};document.getElementById('save').onclick=()=>{try{localStorage.setItem(storageKey,JSON.stringify(state));dirty=false;status.textContent='تم الحفظ في هذا المتصفح فقط';}catch(e){status.textContent='فشل الحفظ: مساحة المتصفح غير كافية';}};
    function library(){const media=document.getElementById('mediaList'),archive=document.getElementById('archiveList');media.replaceChildren();archive.replaceChildren();if(!state.media.length)media.textContent='لم تُرفع ميديا بعد.';state.media.forEach(m=>{const b=document.createElement('button');b.textContent='إضافة: '+m.name;b.onclick=()=>{add(m.type,m.src);document.getElementById('libraryDialog').close();};media.append(b);});if(!state.archive.length)archive.textContent='الأرشيف فارغ.';state.archive.forEach((i,index)=>{const b=document.createElement('button');b.textContent='استرجاع: '+(i.text?.slice(0,25)||i.type);b.onclick=()=>{checkpoint();const copy=clone(i);if(state.items.some(x=>x.id===copy.id))copy.id=uid();state.items.push(copy);state.archive.splice(index,1);selected=copy.id;changed();render();library();};archive.append(b);});if(!document.getElementById('libraryDialog').open)document.getElementById('libraryDialog').showModal();}
    document.getElementById('library').onclick=library;document.getElementById('addMedia').onclick=()=>{replaceId=null;document.getElementById('upload').click();};document.getElementById('upload').onchange=e=>{const f=e.target.files[0];if(!f)return;if(f.size>1024*1024){alert('هذه نسخة محلية: استخدم ملفًا أقل من 1 ميجابايت.');return;}if(!f.type.startsWith('image/')&&!f.type.startsWith('video/'))return;const target=replaceId;const reader=new FileReader();reader.onload=()=>{checkpoint();const type=f.type.startsWith('image/')?'image':'video';state.media.push({name:f.name,src:reader.result,type});const i=state.items.find(i=>i.id===target);if(i){i.src=reader.result;i.type=type;changed();render();}else{add(type,reader.result);}if(document.getElementById('libraryDialog').open)library();};reader.readAsDataURL(f);e.target.value='';};window.addEventListener('beforeunload',e=>{if(dirty){e.preventDefault();e.returnValue='';}});// Keep the simple editor, extend cards and visual effects.
    const extraStyle=document.createElement('style');extraStyle.textContent='.card .content{position:relative;z-index:2;background:transparent}.card .cardMedia{position:absolute;inset:0;width:100%;height:100%;object-fit:cover;border-radius:16px;z-index:1}.item.card{border-radius:16px}.item.card:not(.selected){overflow:hidden}.section .content{border-radius:16px;border:1px solid #c2a66a}.item.text{z-index:100}.item.selected{z-index:200!important}';document.head.appendChild(extraStyle);
    const effectLabel=document.createElement('label');effectLabel.textContent='تأثير ثلاثي الأبعاد ';const effectSelect=document.createElement('select');[['none','بدون تأثير'],['soft','بروز ناعم'],['gold','ذهبي بارز'],['deep','عمق واضح']].forEach(([value,label])=>{const o=document.createElement('option');o.value=value;o.textContent=label;effectSelect.append(o);});effectLabel.append(effectSelect);document.getElementById('apply').before(effectLabel);
    const fitLabel=document.createElement('label');fitLabel.textContent='عرض الصورة داخل الكارت ';const fitSelect=document.createElement('select');[['cover','ملء الكارت، مع قص الأطراف عند الحاجة'],['contain','الصورة كاملة، بدون قص']].forEach(([value,label])=>{const o=document.createElement('option');o.value=value;o.textContent=label;fitSelect.append(o);});fitLabel.append(fitSelect);document.getElementById('apply').before(fitLabel);
    const originalFormat=openFormat;openFormat=function(){originalFormat();const i=current();if(i){effectSelect.value=i.effect||'none';fitSelect.value=i.fit||'cover';}};
    const previousApply=document.getElementById('apply').onclick;document.getElementById('apply').onclick=()=>{const i=current();if(!i)return;const effect=effectSelect.value,fit=fitSelect.value;previousApply();i.effect=effect;i.fit=fit;changed();render();};
    const baseRender=render;render=function(){baseRender();state.items.forEach(i=>{const el=Array.from(canvas.children).find(e=>e.dataset.id===i.id);if(!el)return;const content=el.querySelector('.content');if(i.type==='text')el.style.zIndex=String(i.z||100);if(['card','section'].includes(i.type)){content.style.backgroundColor=i.mediaSrc?'transparent':(i.bg||'#fffdf9');if(i.mediaSrc){const media=document.createElement(i.mediaType==='video'?'video':'img');media.className='cardMedia';media.src=i.mediaSrc;if(i.mediaType==='video'){media.muted=true;media.loop=true;media.autoplay=true;media.playsInline=true;}else media.alt='ميديا الكارت';media.style.objectFit=i.fit||'contain';el.prepend(media);}}if(i.effect==='soft'){content.style.textShadow='0 1px 0 #fff,0 3px 4px rgba(0,0,0,.22)';el.style.boxShadow='0 7px 18px rgba(0,0,0,.14)';}if(i.effect==='gold'){content.style.color='#ae852e';content.style.textShadow='0 1px 0 #fceab1,0 2px 0 #77541e,0 4px 6px rgba(80,52,0,.3)';el.style.boxShadow='0 2px 0 #d6bc79,0 9px 22px rgba(101,72,18,.22)';}if(i.effect==='deep'){content.style.textShadow='1px 1px 0 rgba(255,255,255,.6),2px 3px 3px rgba(0,0,0,.3)';el.style.boxShadow='0 4px 0 rgba(0,0,0,.13),0 14px 26px rgba(0,0,0,.22)';}});};
    function addKind(kind){if(kind==='section'){add('section');const i=current();i.text='سيكشن جديد';i.w=1000;i.h=240;i.x=50;i.y=420;i.z=0;changed();render();return;}add('card');const i=current();i.kind=kind;i.text=kind==='brand'?'اسم البراند':kind==='store'?'اسم المتجر':'اسم العطر\nبيانات تجريبية';i.w=300;i.h=240;changed();render();}
    const originalShowMenu=showMenu;showMenu=function(e){originalShowMenu(e);const i=current();action('إنشاء سيكشن',()=>addKind('section'));action('إنشاء كارت براند',()=>addKind('brand'));action('إنشاء كارت متجر',()=>addKind('store'));action('إنشاء كارت عطر',()=>addKind('perfume'));action('رفع ميديا داخل الكارت',()=>{replaceId=selected;document.getElementById('upload').click();},!!i&&i.type==='card');action('نص فوق العنصر',()=>{const anchor=current();add('text');const t=current();if(anchor){t.x=anchor.x+15;t.y=anchor.y+15;t.w=Math.max(40,anchor.w-30);t.h=Math.min(90,anchor.h);}t.z=100;t.bg='#fffdf9';t.transparent=true;t.overlayOf=anchor?.id||null;changed();render();});action('خلفية نص شفافة',()=>{checkpoint();current().transparent=true;changed();render();},!!i&&i.type==='text');action('حذف ميديا الكارت',()=>{checkpoint();delete current().mediaSrc;delete current().mediaType;changed();render();},!!i&&!!i.mediaSrc);const r=menu.getBoundingClientRect();menu.style.left=Math.max(4,Math.min(e.clientX,innerWidth-r.width-8))+'px';menu.style.top=Math.max(4,Math.min(e.clientY,innerHeight-r.height-8))+'px';};
    const mediaRender=render;render=function(){mediaRender();state.items.forEach(i=>{if(i.transparent){const el=Array.from(canvas.children).find(e=>e.dataset.id===i.id);if(el)el.querySelector('.content').style.backgroundColor='transparent';}});};
    document.getElementById('upload').onchange=e=>{const f=e.target.files[0];if(!f)return;if(f.size>1024*1024){alert('حد الملف المحلي 1 ميجابايت. الفيديوهات الكبيرة تحتاج تخزينًا خارجيًا لاحقًا.');e.target.value='';return;}if(!f.type.startsWith('image/')&&!f.type.startsWith('video/'))return;const selectedItem=current();const target=replaceId||(selectedItem?.type==='card'?selectedItem.id:null);const reader=new FileReader();reader.onload=()=>{checkpoint();const type=f.type.startsWith('image/')?'image':'video';state.media.push({name:f.name,src:reader.result,type});const i=state.items.find(i=>i.id===target);if(i&&['card','section'].includes(i.type)){i.mediaSrc=reader.result;i.mediaType=type;i.fit=i.fit||'contain';changed();render();}else if(i&&['image','video'].includes(i.type)){i.src=reader.result;i.type=type;changed();render();}else add(type,reader.result);replaceId=null;if(document.getElementById('libraryDialog').open)library();};reader.readAsDataURL(f);e.target.value='';};
    const flowButton=document.createElement('button');flowButton.textContent='ترتيب تلقائي: مفعّل';let autoFlow=true;document.querySelector('header').append(flowButton);flowButton.onclick=()=>{autoFlow=!autoFlow;flowButton.textContent='ترتيب تلقائي: '+(autoFlow?'مفعّل':'متوقف');};
    function packCards(){const cards=state.items.filter(i=>i.type==='card').sort((a,b)=>a.y-b.y||a.x-b.x);if(!cards.length)return;let x=40,y=340,rowHeight=0;cards.forEach(i=>{const oldX=i.x,oldY=i.y;if(x+i.w>1060){x=40;y+=rowHeight+24;rowHeight=0;}i.x=x;i.y=y;state.items.filter(t=>t.overlayOf===i.id).forEach(t=>{t.x+=i.x-oldX;t.y+=i.y-oldY;});x+=i.w+24;rowHeight=Math.max(rowHeight,i.h);});canvas.style.height=Math.max(900,y+rowHeight+60)+'px';}
    let dragWasCard=false;let dragStartPoint=null;canvas.addEventListener('pointerdown',e=>{dragStartPoint={x:e.clientX,y:e.clientY};},true);canvas.addEventListener('pointerup',e=>{if(dragStartPoint&&Math.hypot(e.clientX-dragStartPoint.x,e.clientY-dragStartPoint.y)<4)dragWasCard=false;dragStartPoint=null;},true);canvas.addEventListener('pointerdown',e=>{const el=e.target.closest('.item');dragWasCard=!!el&&state.items.find(i=>i.id===el.dataset.id)?.type==='card'&&!e.target.classList.contains('handle');},true);canvas.addEventListener('pointerup',()=>{if(autoFlow&&dragWasCard&&!editing){packCards();changed();render();}dragWasCard=false;});
    const kindDblClick=canvas.addEventListener('dblclick',e=>{const el=e.target.closest('.item');const i=state.items.find(i=>i.id===el?.dataset.id);if(i?.type==='section'){checkpoint();editing=true;el.classList.add('editing');const c=el.querySelector('.content');c.contentEditable='plaintext-only';c.focus();}});
    document.getElementById('hint').textContent='حدد الكارت ثم كليك يمين لرفع الميديا داخله. النص طبقة مستقلة فوق العناصر. ترتيب تلقائي يرص الكروت بعد سحبها، ويمكن إيقافه. الحفظ محلي، مساحة اختبار ثابتة.';
    // Visible version marker and direct access to the requested functions.
    document.querySelector('header strong').textContent='Élan Scents · النسخة 3 — ميديا داخل الكارت';
    const quick=document.createElement('div');quick.style.cssText='display:flex;gap:8px;flex-wrap:wrap;justify-content:center;padding:10px;background:#f6f0e4';document.getElementById('hint').after(quick);function quickButton(label,callback){const b=document.createElement('button');b.textContent=label;b.onclick=callback;quick.append(b);}quickButton('+ سيكشن',()=>addKind('section'));quickButton('+ كارت براند',()=>addKind('brand'));quickButton('+ كارت متجر',()=>addKind('store'));quickButton('+ كارت عطر',()=>addKind('perfume'));quickButton('ميديا داخل الكارت المحدد',()=>{const i=current();if(!i||i.type!=='card'){alert('حدد كارتًا أولًا بكليك شمال، ثم اضغط هذا الزر.');return;}replaceId=i.id;document.getElementById('upload').click();});quickButton('تنسيق وتأثير 3D',()=>{if(!current()){alert('حدد عنصرًا أولًا.');return;}openFormat();});quickButton('نص فوق العنصر',()=>{const anchor=current();add('text');const t=current();t.transparent=true;t.z=100;t.overlayOf=anchor?.id||null;if(anchor){t.x=anchor.x+15;t.y=anchor.y+15;t.w=Math.max(40,anchor.w-30);}changed();render();});
    const menuWithAdditions=showMenu;showMenu=function(e){menuWithAdditions(e);const buttons=Array.from(menu.children);const additions=buttons.slice(-8);additions.reverse().forEach(b=>menu.prepend(b));};
    const originalLibrary=library;library=function(){originalLibrary();const holder=document.getElementById('mediaList');Array.from(holder.children).forEach((b,index)=>{const m=state.media[index];if(!m)return;b.textContent='استخدام: '+m.name;b.onclick=()=>{const i=current();if(i&&['card','section'].includes(i.type)){checkpoint();i.mediaSrc=m.src;i.mediaType=m.type;i.fit=i.fit||'contain';changed();render();}else add(m.type,m.src);document.getElementById('libraryDialog').close();};});};document.getElementById('library').onclick=()=>library();
    const correctedRender=render;render=function(){correctedRender();state.items.forEach(i=>{const el=Array.from(canvas.children).find(e=>e.dataset.id===i.id);if(!el)return;const content=el.querySelector('.content');if(i.mediaSrc&&i.type==='card'){el.style.backgroundColor=i.bg||'#fffdf9';const media=el.querySelector('.cardMedia');if(media){media.style.pointerEvents='none';media.style.clipPath='inset(0 round 16px)';}content.style.backgroundColor='transparent';}if(i.effect==='gold'&&!i.mediaSrc&&!i.transparent)content.style.backgroundImage='linear-gradient(145deg,'+(i.bg||'#fffdf9')+' 0%,#e9dbba 55%,'+(i.bg||'#fffdf9')+' 100%)';if(i.effect==='soft'&&!i.mediaSrc&&!i.transparent)content.style.backgroundImage='linear-gradient(145deg,#ffffff,'+(i.bg||'#fffdf9')+')';});};
    document.getElementById('hint').textContent='نسخة 3: حدّد كارتًا وارفع الميديا داخله. الأدوات الجديدة ظاهرة في الشريط المختصر وكليك يمين. الترتيب التلقائي للكروت فقط، والسيكشن ليس حاوية متكاملة بعد. الحفظ محلي.';
    // Repair interaction layering and keep all creation tools in the context menu.
    quick.remove();flowButton.remove();document.querySelector('header strong').textContent='Élan Scents · النسخة 4 — إصلاح التفاعل';
    const repairs=document.createElement('style');repairs.textContent='#menu{z-index:2147483000!important;direction:rtl}.item{user-select:none}.editing .content{user-select:text}.card .cardMedia{object-fit:contain}#format{min-width:320px}';document.head.appendChild(repairs);
    state.items.forEach(i=>{if(i.type==='card')i.fit='contain';});
    let contextPoint={x:350,y:300};let pendingInsertIndex=null;let dropTarget=null;
    function cardOrder(){return state.items.filter(i=>i.type==='card').sort((a,b)=>a.y-b.y||a.x-b.x);}
    function nearestCard(x,y,exclude){const cards=cardOrder().filter(c=>c.id!==exclude);let nearest=null,best=Infinity;cards.forEach(c=>{const distance=Math.hypot(x-(c.x+c.w/2),y-(c.y+c.h/2));if(distance<best){best=distance;nearest=c;}});return nearest;}
    packCards=function(){const cards=cardOrder();if(!cards.length)return;const moving=cards.find(c=>c.id===selected);if(moving&&dropTarget){const target=cards.find(c=>c.id===dropTarget.id);if(target){const without=cards.filter(c=>c.id!==moving.id);let idx=without.findIndex(c=>c.id===target.id)+(dropTarget.after?1:0);without.splice(Math.max(0,idx),0,moving);cards.splice(0,cards.length,...without);}}let x=40,y=340,rowHeight=0;cards.forEach(i=>{const oldX=i.x,oldY=i.y;if(x+i.w>1060){x=40;y+=rowHeight+24;rowHeight=0;}i.x=x;i.y=y;state.items.filter(t=>t.overlayOf===i.id).forEach(t=>{t.x+=i.x-oldX;t.y+=i.y-oldY;});x+=i.w+24;rowHeight=Math.max(rowHeight,i.h);});canvas.style.height=Math.max(900,y+rowHeight+60)+'px';dropTarget=null;};
    canvas.addEventListener('pointermove',e=>{if(!gesture||gesture.mode!=='move')return;const moving=state.items.find(i=>i.id===gesture.id);if(!moving||moving.type!=='card')return;const rect=canvas.getBoundingClientRect();const x=e.clientX-rect.left,y=e.clientY-rect.top;const target=nearestCard(x,y,moving.id);dropTarget=target?{id:target.id,after:x>target.x+target.w/2}:null;canvas.querySelectorAll('.item').forEach(el=>{el.style.borderLeft='';el.style.borderRight='';if(dropTarget&&el.dataset.id===dropTarget.id)el.style[dropTarget.after?'borderRight':'borderLeft']='4px solid #b48b38';});});
    const menuRepair=showMenu;showMenu=function(e){const rect=canvas.getBoundingClientRect();contextPoint={x:Math.max(0,Math.min(1000,e.clientX-rect.left)),y:Math.max(0,e.clientY-rect.top)};menuRepair(e);const formatButton=Array.from(menu.children).find(b=>b.textContent==='الخط واللون والحجم');if(formatButton){formatButton.disabled=!current();formatButton.textContent='تنسيق النص: الخط • اللون • الحجم • 3D';formatButton.onclick=()=>{menu.style.display='none';if(current())openFormat();};menu.prepend(formatButton);}action('الترتيب التلقائي: '+(autoFlow?'مفعّل':'متوقف'),()=>{autoFlow=!autoFlow;status.textContent=autoFlow?'الترتيب التلقائي للكروت مفعّل':'التحريك الحر مفعّل؛ العناصر الأخرى لن تتحرك';});const r=menu.getBoundingClientRect();menu.style.left=Math.max(4,Math.min(e.clientX,innerWidth-r.width-8))+'px';menu.style.top=Math.max(4,Math.min(e.clientY,innerHeight-r.height-8))+'px';};
    const addAtClick=add;add=function(type,src){addAtClick(type,src);const i=current();if(!i)return;i.x=Math.min(1100-i.w,contextPoint.x);i.y=contextPoint.y;if(type==='text'){i.transparent=true;i.z=100;}if(type==='card'&&autoFlow){const t=nearestCard(contextPoint.x,contextPoint.y,i.id);dropTarget=t?{id:t.id,after:contextPoint.x>t.x+t.w/2}:null;packCards();}render();};
    const oldKind=addKind;addKind=function(kind){oldKind(kind);if(kind!=='section'&&autoFlow){packCards();render();}};
    const interactionRender=render;render=function(){interactionRender();canvas.querySelectorAll('.item').forEach(el=>{const content=el.querySelector('.content');content.addEventListener('dblclick',()=>{const i=state.items.find(i=>i.id===el.dataset.id);if(i&&['text','card','section'].includes(i.type)){select(i.id);content.contentEditable='plaintext-only';content.focus();}});});};
    // Expand movement bounds to the current canvas height.
    canvas.addEventListener('pointermove',e=>{if(!gesture)return;const i=state.items.find(i=>i.id===gesture.id);const el=Array.from(canvas.children).find(el=>el.dataset.id===gesture.id);if(!i||!el)return;const height=Math.max(900,canvas.offsetHeight);if(gesture.mode==='move'){i.y=Math.max(0,Math.min(height-i.h,gesture.y+e.clientY-gesture.sy));el.style.top=i.y+'px';}else{i.h=Math.max(30,Math.min(height-i.y,gesture.h+e.clientY-gesture.sy));el.style.height=i.h+'px';}});
    document.getElementById('hint').textContent='كليك يمين لإنشاء العناصر أو تنسيق النص. الصور كاملة داخل الكارت بدون قص افتراضيًا؛ اختلاف النسب قد يترك فراغًا. عند سحب كارت يظهر خط ذهبي لتحديد موضع إدراجه. النصوص تتحرك بحرية. لا يوجد ربط أو نشر.';
    // Repair text editing and make media behavior explicit for all visual containers.
    const mediaCSS=document.createElement('style');mediaCSS.textContent='.section .content{position:relative;z-index:2}.section .cardMedia{position:absolute;inset:0;width:100%;height:100%;z-index:1;border-radius:16px;pointer-events:none}.item .cardMedia{pointer-events:none}';document.head.appendChild(mediaCSS);
    const adaptOption=document.createElement('option');adaptOption.value='adapt';adaptOption.textContent='الصورة كاملة: تعديل ارتفاع الإطار ليناسب أبعادها';fitSelect.append(adaptOption);
    const transparencyLabel=document.createElement('label');const transparencyInput=document.createElement('input');transparencyInput.type='checkbox';transparencyLabel.append(transparencyInput,' خلفية النص شفافة');document.getElementById('apply').before(transparencyLabel);
    let formatTargetId=null;openFormat=function(){const i=current();if(!i)return;formatTargetId=i.id;document.getElementById('font').value=i.font||'Tahoma';document.getElementById('size').value=i.size||24;document.getElementById('color').value=/^#[0-9a-f]{6}$/i.test(i.color||'')?i.color:'#222222';document.getElementById('bg').value=/^#[0-9a-f]{6}$/i.test(i.bg||'')?i.bg:'#fffdf9';document.getElementById('align').value=i.align||'right';effectSelect.value=i.effect||'none';fitSelect.value=i.fit||'cover';transparencyInput.checked=!!i.transparent;document.getElementById('format').showModal();};
    document.getElementById('bg').oninput=()=>transparencyInput.checked=false;
    function applyMediaAspect(i){if(!i.mediaSrc||i.fit!=='adapt')return;const probe=document.createElement(i.mediaType==='video'?'video':'img');const update=()=>{const width=probe.naturalWidth||probe.videoWidth;const height=probe.naturalHeight||probe.videoHeight;if(width&&height){i.h=Math.max(30,Math.round(i.w*height/width));canvas.style.height=Math.max(canvas.offsetHeight,i.y+i.h+50)+'px';render();}};if(i.mediaType==='video')probe.onloadedmetadata=update;else probe.onload=update;probe.src=i.mediaSrc;}
    document.getElementById('apply').onclick=()=>{const i=state.items.find(i=>i.id===formatTargetId);if(!i)return;checkpoint();i.font=document.getElementById('font').value;i.size=Math.max(8,Math.min(160,Number(document.getElementById('size').value)||24));i.color=document.getElementById('color').value;i.bg=document.getElementById('bg').value;i.align=document.getElementById('align').value;i.effect=effectSelect.value;i.fit=fitSelect.value;i.transparent=transparencyInput.checked;selected=i.id;changed();render();applyMediaAspect(i);document.getElementById('format').close();};
    const finalMediaRender=render;render=function(){finalMediaRender();state.items.forEach(i=>{const el=Array.from(canvas.children).find(e=>e.dataset.id===i.id);if(!el)return;const media=el.querySelector('.cardMedia');if(media){media.style.objectFit=i.fit==='contain'?'contain':'cover';media.style.width='100%';media.style.height='100%';el.querySelector('.content').style.backgroundColor='transparent';}if(i.type==='text'&&!i.transparent)el.querySelector('.content').style.backgroundColor=i.bg||'#fffdf9';});};
    let explicitUploadTarget=null;const previousUpload=document.getElementById('upload').onchange;document.getElementById('upload').onchange=e=>{const i=state.items.find(i=>i.id===replaceId)||current();if(i&&['card','section'].includes(i.type)){replaceId=i.id;i.fit='cover';}previousUpload(e);};
    const fixedMenu=showMenu;showMenu=function(e){fixedMenu(e);const i=current();Array.from(menu.children).forEach(b=>{if(b.textContent==='إضافة كارت'){b.textContent='إضافة بانر';b.onclick=()=>{menu.style.display='none';addKind('section');const item=current();item.text='';item.kind='banner';render();};}if(b.textContent.startsWith('تنسيق النص:')||b.textContent==='الخط واللون والحجم'){b.disabled=!i;b.onclick=()=>{menu.style.display='none';openFormat();};}if(b.textContent==='رفع ميديا داخل الكارت'){b.textContent='رفع صورة أو فيديو داخل العنصر';b.disabled=!i||!['card','section'].includes(i.type);b.onclick=()=>{menu.style.display='none';replaceId=selected;document.getElementById('upload').click();};}});action('مسح الاسم أو النص التلقائي',()=>{const target=current();if(!target)return;checkpoint();target.text='';changed();render();},!!i&&['text','card','section'].includes(i.type));action('كتابة أو تعديل نص العنصر',()=>{const target=current();if(!target)return;const value=prompt('اكتب النص أو اتركه فارغًا لمسحه',target.text||'');if(value===null)return;checkpoint();target.text=value;changed();render();},!!i&&['text','card','section'].includes(i.type));const r=menu.getBoundingClientRect();menu.style.top=Math.max(4,Math.min(e.clientY,innerHeight-r.height-8))+'px';};
    document.querySelector('header strong').textContent='Élan Scents · النسخة 5 — النصوص والبانر';document.getElementById('hint').textContent='كليك يمين: تنسيق الخط واللون والحجم والخلفية، أو مسح النص التلقائي. الميديا تملأ الإطار مع قص عند اختلاف النسب؛ اختر تعديل ارتفاع الإطار من التنسيق لعرضها كاملة بدون قص. حفظ محلي فقط.';
    // Requested border controls and a consolidated context menu.
    const borderControls=document.createElement('fieldset');borderControls.style.cssText='border:1px solid #d6c49d;border-radius:10px;margin:16px 0;padding:12px';const borderLegend=document.createElement('legend');borderLegend.textContent='إطار مربع النص أو العنصر';borderControls.append(borderLegend);
    function borderField(label,input){const l=document.createElement('label');l.append(label,input);borderControls.append(l);}
    const borderColor=document.createElement('input');borderColor.type='color';borderField(' لون الإطار ',borderColor);
    const borderTransparent=document.createElement('input');borderTransparent.type='checkbox';borderField(' إطار شفاف ',borderTransparent);borderColor.oninput=()=>borderTransparent.checked=false;
    const borderDepth=document.createElement('input');borderDepth.type='checkbox';borderField(' تفعيل تأثير 3D للإطار ',borderDepth);
    const borderShape=document.createElement('select');[['rectangle','مستطيل'],['circle','دائرة']].forEach(([value,text])=>{const o=document.createElement('option');o.value=value;o.textContent=text;borderShape.append(o);});borderField(' شكل مربع النص ',borderShape);document.getElementById('apply').before(borderControls);
    const formatBeforeBorder=openFormat;openFormat=function(){formatBeforeBorder();const i=state.items.find(i=>i.id===formatTargetId);if(!i)return;borderColor.value=i.borderColor||'#b99755';borderTransparent.checked=i.borderTransparent!==false;borderDepth.checked=!!i.borderDepth;borderShape.value=i.borderShape||'rectangle';};
    const applyBeforeBorder=document.getElementById('apply').onclick;document.getElementById('apply').onclick=()=>{const i=state.items.find(i=>i.id===formatTargetId);if(!i)return;const values={borderColor:borderColor.value,borderTransparent:borderTransparent.checked,borderDepth:borderDepth.checked,borderShape:borderShape.value};applyBeforeBorder();Object.assign(i,values);if(i.borderShape==='circle')i.h=i.w;changed();render();};
    const renderBeforeBorder=render;render=function(){renderBeforeBorder();state.items.forEach(i=>{const el=Array.from(canvas.children).find(e=>e.dataset.id===i.id);if(!el)return;const content=el.querySelector('.content');if(i.borderShape){const radius=i.borderShape==='circle'?'50%':'0px';content.style.borderRadius=radius;content.style.border='2px solid '+(i.borderTransparent?'transparent':(i.borderColor||'#b99755'));content.style.boxShadow=i.borderDepth&&!i.borderTransparent?'inset 1px 1px 2px rgba(255,255,255,.85),inset -2px -2px 3px rgba(0,0,0,.25),0 5px 10px rgba(0,0,0,.2)':'none';el.style.borderRadius=radius;const media=el.querySelector('.cardMedia');if(media){media.style.borderRadius=radius;media.style.clipPath=i.borderShape==='circle'?'circle(50%)':'inset(0)';}}});};
    const menuBeforeCleanup=showMenu;showMenu=function(e){menuBeforeCleanup(e);const elements=Array.from(menu.children);let createText=null,banner=null,perfume=null;elements.forEach(b=>{const text=b.textContent;if(text==='إضافة نص'||text==='نص فوق العنصر'){if(!createText){createText=b;b.textContent='إنشاء نص';b.disabled=false;b.onclick=()=>{menu.style.display='none';const anchor=current();add('text');const t=current();t.transparent=true;t.z=100;t.overlayOf=anchor?.id||null;if(anchor){t.x=anchor.x+15;t.y=anchor.y+15;t.w=Math.max(40,anchor.w-30);}changed();render();};}else b.remove();}else if(text==='خلفية نص شفافة'||text==='إضافة صورة أو فيديو'){b.remove();}else if(text==='إضافة بانر'){banner=b;b.textContent='إنشاء بانر صورة أو فيديو';}else if(text==='إنشاء كارت عطر'){perfume=b;}else if(text==='رفع صورة أو فيديو داخل العنصر'){b.textContent='رفع صورة أو فيديو داخل العناصر أو الهيرو';b.disabled=!current()||!['card','section','image','video'].includes(current().type);}else if(text==='حذف ميديا الكارت'){b.textContent='حذف ميديا الكارت أو الهيرو إلى الأرشيف';const i=current();b.disabled=!i||!(i.mediaSrc||(['image','video'].includes(i.type)&&i.src));b.onclick=()=>{menu.style.display='none';const target=current();if(!target)return;checkpoint();if(target.mediaSrc){state.archive.push({id:uid(),type:target.mediaType==='video'?'video':'image',src:target.mediaSrc,x:target.x,y:target.y,w:target.w,h:target.h,text:'',font:'Tahoma',size:24,color:'#222222',bg:'#fffdf9',align:'right'});delete target.mediaSrc;delete target.mediaType;}else if(['image','video'].includes(target.type)&&target.src){state.archive.push(clone(target));state.items=state.items.filter(i=>i.id!==target.id);selected=null;}changed();render();};}});if(perfume){let after=perfume;if(banner){after.after(banner);after=banner;}if(createText)after.after(createText);}const r=menu.getBoundingClientRect();menu.style.top=Math.max(4,Math.min(e.clientY,innerHeight-r.height-8))+'px';};
    canvas.addEventListener('pointerup',()=>{const i=current();if(i?.borderShape==='circle'){i.h=i.w;render();}});
    document.querySelector('header strong').textContent='Élan Scents · النسخة 6 — الإطار والقائمة';
    // Working empty banner and a clearer, contextual formatting panel.
    const bannerMenu=showMenu;showMenu=function(e){bannerMenu(e);const b=Array.from(menu.children).find(b=>b.textContent==='إنشاء بانر صورة أو فيديو');if(b){b.disabled=false;b.onclick=()=>{menu.style.display='none';add('card');const i=current();i.kind='banner';i.text='';i.w=300;i.h=240;i.borderColor='#b99755';i.borderTransparent=false;i.borderShape='rectangle';if(autoFlow)packCards();changed();render();};}};
    const formatPanel=document.getElementById('format');formatPanel.style.width='540px';formatPanel.querySelector('h3').textContent='تنسيق العنصر';
    const panelStyle=document.createElement('style');panelStyle.textContent='#format{background:#fffdf8;color:#28251e;padding:20px}#format h3{margin:0 0 18px;color:#86632b}#format fieldset{border:1px solid #e0d1b0;border-radius:12px;padding:12px;margin:12px 0}#format legend{font-weight:bold;color:#87642e;padding:0 8px}#format .fieldGrid{display:grid;grid-template-columns:1fr 1fr;gap:12px}#format label{margin:0;display:flex;flex-direction:column;gap:7px;font-size:13px}#format label:has(input[type=checkbox]){flex-direction:row;align-items:center;grid-column:1/-1}#format select,#format input[type=number]{width:100%;background:white;min-height:38px}#format .colorRow{display:flex;align-items:center;gap:8px;direction:ltr}#format input[type=color]{width:55px;height:40px;padding:3px;cursor:pointer}#format .colorValue{font-family:Arial;font-size:12px;border:1px solid #d8c69f;background:white;padding:8px;border-radius:7px}#format .sample{padding:18px;border:1px solid #e0d1b0;border-radius:12px;margin:12px 0;background:#f1eee7}#format .sample span{display:block;padding:14px;text-align:center}#format .panelActions{display:flex;gap:10px;padding-top:10px}#format .panelActions button{flex:1}#format .panelActions #apply{background:#26231d;color:#efddaf}@media(max-width:480px){#format .fieldGrid{grid-template-columns:1fr}}';document.head.append(panelStyle);
    function panelGroup(title){const f=document.createElement('fieldset');const l=document.createElement('legend');l.textContent=title;const grid=document.createElement('div');grid.className='fieldGrid';f.append(l,grid);formatPanel.append(f);return {fieldset:f,grid};}
    const textGroup=panelGroup('الكتابة');textGroup.grid.append(document.getElementById('font').closest('label'),document.getElementById('size').closest('label'),document.getElementById('align').closest('label'));
    const colorsGroup=panelGroup('ألوان النص والخلفية');colorsGroup.grid.append(document.getElementById('color').closest('label'),document.getElementById('bg').closest('label'),transparencyLabel,effectLabel);
    const borderGroup=panelGroup('الإطار');borderGroup.grid.append(...Array.from(borderControls.querySelectorAll('label')));borderControls.remove();
    const mediaGroupPanel=panelGroup('طريقة عرض الميديا');mediaGroupPanel.grid.append(fitLabel);const mediaExplanation=document.createElement('small');mediaExplanation.textContent='ملء الإطار قد يقص الأطراف. عرض الصورة كاملة قد يترك فراغًا. تعديل الارتفاع يجعل الإطار يتناسب مع الصورة.';mediaGroupPanel.grid.append(mediaExplanation);
    const sampleBox=document.createElement('div');sampleBox.className='sample';const sampleCaption=document.createElement('small');sampleCaption.textContent='معاينة تنسيق فقط، لا تغيّر العنصر قبل الضغط على تطبيق';const sample=document.createElement('span');sample.textContent='معاينة النص';sampleBox.append(sampleCaption,sample);formatPanel.append(sampleBox);
    const actions=document.createElement('div');actions.className='panelActions';actions.append(document.getElementById('apply'));const closeButton=Array.from(formatPanel.querySelectorAll('button')).find(b=>b.textContent==='إغلاق');if(closeButton)actions.append(closeButton);formatPanel.append(actions);
    const colorValues=new Map();[document.getElementById('color'),document.getElementById('bg'),borderColor].forEach(input=>{const row=document.createElement('div');row.className='colorRow';input.before(row);row.append(input);const value=document.createElement('span');value.className='colorValue';row.append(value);colorValues.set(input,value);});
    function updatePanelPreview(){colorValues.forEach((value,input)=>{value.textContent=input.value.toUpperCase();value.style.borderBottom='4px solid '+input.value;});const i=(typeof liveMode!=='undefined'&&liveMode&&selectedLive)?{text:selectedLive.text}:state.items.find(i=>i.id===formatTargetId);sample.textContent=i?.text?.trim().slice(0,80)||'معاينة النص';sample.style.fontFamily=document.getElementById('font').value;sample.style.fontSize=Math.min(42,Number(document.getElementById('size').value)||24)+'px';sample.style.color=document.getElementById('color').value;sample.style.backgroundColor=transparencyInput.checked?'transparent':document.getElementById('bg').value;sample.style.border='2px solid '+(borderTransparent.checked?'transparent':borderColor.value);sample.style.borderRadius=borderShape.value==='circle'?'50%':'0';sample.style.boxShadow=borderDepth.checked&&!borderTransparent.checked?'inset 1px 1px 2px #fff,inset -2px -2px 3px #0004,0 5px 10px #0003':'none';sample.style.textShadow=effectSelect.value==='none'?'none':'0 1px 0 #fff,1px 2px 2px #0004';sample.style.textAlign=document.getElementById('align').value;}
    formatPanel.querySelectorAll('input,select').forEach(input=>{input.addEventListener('input',updatePanelPreview);input.addEventListener('change',updatePanelPreview);});
    const organizedFormat=openFormat;openFormat=function(){organizedFormat();const i=state.items.find(i=>i.id===formatTargetId);const hasMedia=!!i&&(!!i.mediaSrc||['image','video'].includes(i.type));mediaGroupPanel.fieldset.hidden=!hasMedia;textGroup.fieldset.hidden=!!i&&['image','video'].includes(i.type);updatePanelPreview();};
    document.querySelector('header strong').textContent='Élan Scents · النسخة 7 — البانر ولوحة التنسيق';
    // Compact formatting panel and expanded Arabic/English font choices.
    const fontDefinitions=[['عربي',['Cairo','Tajawal','Almarai','Amiri','Changa','El Messiri','Noto Kufi Arabic','Noto Naskh Arabic','Noto Sans Arabic','Reem Kufi','IBM Plex Sans Arabic']],['إنجليزي',['Inter','Roboto','Open Sans','Lato','Montserrat','Poppins','Playfair Display','Cormorant Garamond','Libre Baskerville','Merriweather']],['خطوط الجهاز',['Tahoma','Arial','Georgia','Times New Roman','Verdana','Trebuchet MS','Courier New','system-ui']]];
    const fontControl=document.getElementById('font');fontControl.replaceChildren();fontDefinitions.forEach(([group,names])=>{const optgroup=document.createElement('optgroup');optgroup.label=group;names.forEach(name=>{const o=document.createElement('option');o.value=name;o.textContent=name;optgroup.append(o);});fontControl.append(optgroup);});
    const fontCSS=document.createElement('link');fontCSS.rel='stylesheet';const families=fontDefinitions.slice(0,2).flatMap(g=>g[1]).map(name=>'family='+name.replace(/ /g,'+')+':wght@400;700').join('&');fontCSS.href='https://fonts.googleapis.com/css2?'+families+'&display=swap';document.head.append(fontCSS);
    const compactStyle=document.createElement('style');compactStyle.textContent='#format{width:580px!important;padding:16px}#format .fieldGrid{gap:10px}#format fieldset{margin:9px 0;padding:10px}#format label{font-size:12px;gap:5px}#format select,#format input[type=number]{min-height:34px;padding:6px}#format .textRow{grid-template-columns:minmax(0,1.7fr) minmax(0,1fr) minmax(0,1fr)}#format .colorRow{direction:rtl;background:white;border:1px solid #ddcfb2;border-radius:8px;padding:6px;gap:7px}#format .colorChip{width:36px;height:30px;border-radius:6px;border:1px solid #c9bb9b;box-shadow:inset 0 0 0 2px #ffffff99;display:block;flex-shrink:0}#format .colorLabel{font-family:Tahoma;font-size:12px;color:#514737}#format .colorHex{font-family:Arial;font-size:11px;color:#777;direction:ltr}#format .borderToggles{grid-column:1/-1;display:flex;gap:20px;align-items:center;flex-wrap:nowrap;padding:7px 0}#format .borderToggles label{display:flex;flex-direction:row;gap:7px;white-space:nowrap}#format .sample{padding:8px;margin:8px 0}#format .sample span{padding:10px}@media(max-width:420px){#format{padding:10px}#format .textRow{grid-template-columns:minmax(0,1.3fr) minmax(0,1fr) minmax(0,1fr)}#format .borderToggles{gap:8px;font-size:11px}}';document.head.append(compactStyle);
    textGroup.grid.classList.add('textRow');
    const toggles=document.createElement('div');toggles.className='borderToggles';toggles.append(borderDepth.closest('label'),borderTransparent.closest('label'));borderGroup.grid.append(toggles);
    function colorName(hex){const r=parseInt(hex.slice(1,3),16),g=parseInt(hex.slice(3,5),16),b=parseInt(hex.slice(5,7),16);if(Math.max(r,g,b)-Math.min(r,g,b)<25){if(r>235)return 'أبيض';if(r<35)return 'أسود';return 'رمادي';}if(r>180&&g>150&&b<140)return 'ذهبي';if(r>210&&g>190&&b>155)return 'عاجي';if(r>g*1.2&&r>b*1.2)return 'أحمر';if(g>r*1.2&&g>b*1.2)return 'أخضر';if(b>r*1.2&&b>g*1.2)return 'أزرق';return 'لون مخصص';}
    const chips=new Map();colorValues.forEach((value,input)=>{value.remove();const row=input.parentElement;const control=document.createElement('button');control.type='button';control.style.cssText='display:flex;align-items:center;gap:8px;background:none;border:0;padding:0;width:100%;text-align:right';const chip=document.createElement('span');chip.className='colorChip';const info=document.createElement('span');const name=document.createElement('span');name.className='colorLabel';const code=document.createElement('span');code.className='colorHex';code.style.display='block';info.append(name,code);control.append(chip,info);row.append(control);input.style.cssText='position:absolute;opacity:0;width:1px;height:1px;padding:0;border:0;pointer-events:none';input.tabIndex=-1;control.onclick=()=>{if(typeof input.showPicker==='function'){try{input.showPicker();}catch(e){input.click();}}else input.click();};chips.set(input,{chip,name,code});});
    const updateBeforeChips=updatePanelPreview;updatePanelPreview=function(){updateBeforeChips();chips.forEach((parts,input)=>{parts.chip.style.backgroundColor=input.value;parts.name.textContent=colorName(input.value);parts.code.textContent=input.value.toUpperCase();});};
    chips.forEach((parts,input)=>{input.addEventListener('input',()=>updatePanelPreview());input.addEventListener('change',()=>updatePanelPreview());});
    const fontNotice=document.createElement('small');fontNotice.textContent='الخطوط الإضافية تُحمّل من Google Fonts وتحتاج الإنترنت؛ عند تعذر التحميل يُستخدم خط بديل.';textGroup.fieldset.append(fontNotice);
    document.querySelector('header strong').textContent='Élan Scents · النسخة 8 — لوحة مختصرة وخطوط';
    // Focused visual and library improvements.
    fontNotice.remove();document.getElementById('hint').remove();
    const textEffectsRow=document.createElement('div');textEffectsRow.className='borderToggles';textEffectsRow.append(transparencyLabel,effectLabel);colorsGroup.grid.append(textEffectsRow);effectLabel.style.flexDirection='row';effectSelect.style.width='145px';
    const paletteColors=[['ذهبي','#D4AF37'],['ذهبي داكن','#B8860B'],['ذهبي فاتح','#E6C76A'],['أسود','#000000'],['أبيض','#FFFFFF'],['عاجي','#FFFFF0'],['أوف وايت','#FAF9F6'],['رمادي','#808080'],['رمادي داكن','#444444'],['بيج','#E8DCC4'],['أحمر','#C62828'],['أزرق','#1565C0'],['أخضر','#2E7D32'],['بنفسجي','#7B1FA2']];
    const paletteDialog=document.createElement('dialog');paletteDialog.style.width='430px';document.body.append(paletteDialog);let paletteTarget=null;function openPalette(input){paletteTarget=input;paletteDialog.replaceChildren();const h=document.createElement('h3');h.textContent='اختيار لون صريح';paletteDialog.append(h);const grid=document.createElement('div');grid.style.cssText='display:grid;grid-template-columns:repeat(3,1fr);gap:8px';paletteColors.forEach(([label,color])=>{const b=document.createElement('button');b.style.cssText='display:flex;align-items:center;gap:7px;font-size:12px;padding:8px';const sw=document.createElement('span');sw.style.cssText='width:24px;height:24px;border:1px solid #aaa;border-radius:4px;background:'+color;b.append(sw,label);b.onclick=()=>{input.value=color;input.dispatchEvent(new Event('input',{bubbles:true}));input.dispatchEvent(new Event('change',{bubbles:true}));paletteDialog.close();};grid.append(b);});paletteDialog.append(grid);const label=document.createElement('label');label.textContent='أو أدخل كود اللون بدقة';const hex=document.createElement('input');hex.value=input.value.toUpperCase();hex.dir='ltr';hex.placeholder='#D4AF37';label.append(hex);paletteDialog.append(label);const apply=document.createElement('button');apply.textContent='اعتماد اللون';apply.onclick=()=>{const value=hex.value.trim();if(!/^#[0-9a-f]{6}$/i.test(value)){alert('اكتب # وبعده ستة أحرف أو أرقام، مثال #D4AF37');return;}input.value=value;input.dispatchEvent(new Event('input',{bubbles:true}));input.dispatchEvent(new Event('change',{bubbles:true}));paletteDialog.close();};const close=document.createElement('button');close.textContent='إغلاق';close.onclick=()=>paletteDialog.close();paletteDialog.append(apply,close);paletteDialog.showModal();}
    chips.forEach((parts,input)=>{input.parentElement.querySelector('button').onclick=()=>openPalette(input);});
    state.items.forEach(i=>{if(i.mediaSrc)i.fit='contain';});
    const safeMediaRender=render;render=function(){safeMediaRender();state.items.forEach(i=>{const el=Array.from(canvas.children).find(e=>e.dataset.id===i.id);if(!el)return;el.querySelectorAll('img,video').forEach(media=>{media.style.objectFit='contain';media.style.width='100%';media.style.height='100%';});const c=el.querySelector('.content');c.style.backgroundImage='none';c.style.color=i.color||'#222222';if(i.effect==='gold')c.style.textShadow='0 1px 0 rgba(255,255,255,.6),1px 2px 2px rgba(0,0,0,.25)';});};
    mediaGroupPanel.fieldset.hidden=true;const openBeforeMediaHide=openFormat;openFormat=function(){openBeforeMediaHide();mediaGroupPanel.fieldset.hidden=true;};
    const categoryDefinitions=[['section','سيكشن'],['brand','براند'],['store','متجر'],['perfume','عطر'],['banner','بانر'],['text','نص'],['hero','هيرو'],['image','صورة'],['video','فيديو']];
    function itemCategory(item){if(['brand','store','perfume','banner','hero'].includes(item.kind))return item.kind;if(item.type==='card')return 'perfume';if(item.type==='section')return 'section';return ['text','image','video'].includes(item.type)?item.type:'banner';}
    if(!Array.isArray(state.savedElements))state.savedElements=[];
    let libraryTab='archive',libraryCategory='section',uploadOnlyCategory=null;
    const libraryDialog=document.getElementById('libraryDialog');libraryDialog.style.width='720px';
    function libraryButton(text,fn){const b=document.createElement('button');b.textContent=text;b.onclick=fn;return b;}
    library=function(){libraryDialog.replaceChildren();const title=document.createElement('h3');title.textContent='مكتبة إيلان المحلية';libraryDialog.append(title);const tabs=document.createElement('div');tabs.style.cssText='display:flex;gap:8px;margin-bottom:12px';[['archive','العناصر المحذوفة'],['saved','الميديا والعناصر المحفوظة']].forEach(([value,text])=>{const b=libraryButton(text,()=>{libraryTab=value;library();});if(libraryTab===value)b.style.background='#e8d6ad';tabs.append(b);});libraryDialog.append(tabs);const folders=document.createElement('div');folders.style.cssText='display:grid;grid-template-columns:repeat(3,1fr);gap:8px';categoryDefinitions.forEach(([key,label])=>{const count=libraryTab==='archive'?state.archive.filter(i=>itemCategory(i)===key).length:(state.savedElements||[]).filter(i=>itemCategory(i)===key).length+state.media.filter(m=>(m.category||m.type)===key).length;const b=libraryButton(label+' ('+count+')',()=>{libraryCategory=key;library();});if(libraryCategory===key)b.style.background='#e8d6ad';folders.append(b);});libraryDialog.append(folders);const heading=document.createElement('h4');heading.textContent=categoryDefinitions.find(c=>c[0]===libraryCategory)?.[1]||'';libraryDialog.append(heading);const list=document.createElement('div');list.style.cssText='display:grid;gap:10px';libraryDialog.append(list);
    function row(item,label,callback){const box=document.createElement('div');box.style.cssText='display:flex;align-items:center;gap:10px;padding:10px;border:1px solid #dfd0b3;border-radius:10px';if(item.type==='image'||item.mediaType==='image'){const img=document.createElement('img');img.src=item.src||item.mediaSrc;img.style.cssText='width:60px;height:50px;object-fit:contain';box.append(img);}const text=document.createElement('span');text.textContent=item.name||item.text?.slice(0,35)||heading.textContent;text.style.flex='1';box.append(text,libraryButton(label,callback));list.append(box);}
    if(libraryTab==='archive'){state.archive.forEach((item,index)=>{if(itemCategory(item)!==libraryCategory)return;row(item,'استرجاع',()=>{checkpoint();const copy=clone(item);if(state.items.some(i=>i.id===copy.id))copy.id=uid();state.items.push(copy);state.archive.splice(index,1);selected=copy.id;changed();render();library();});});}else{state.savedElements.forEach(item=>{if(itemCategory(item)!==libraryCategory)return;row(item,'إضافة نسخة',()=>{checkpoint();const copy=clone(item);copy.id=uid();copy.x=80;copy.y=300;state.items.push(copy);selected=copy.id;changed();render();libraryDialog.close();});});state.media.forEach(m=>{if((m.category||m.type)!==libraryCategory)return;row(m,'استخدام',()=>{const i=current();if(i&&['card','section'].includes(i.type)){checkpoint();i.mediaSrc=m.src;i.mediaType=m.type;i.fit='contain';changed();render();}else{add(m.type,m.src);}libraryDialog.close();});});const uploadButton=libraryButton('رفع ملف وحفظه في '+heading.textContent,()=>{uploadOnlyCategory=libraryCategory;replaceId=null;document.getElementById('upload').click();});libraryDialog.append(uploadButton);const note=document.createElement('small');note.textContent='صور وفيديوهات صغيرة، أو ملف عنصر JSON صادر من هذا المحرر. الملفات تُحفظ محليًا، ولا تُضاف للصفحة عند الرفع للمكتبة.';libraryDialog.append(note);}
    if(!list.children.length){const empty=document.createElement('p');empty.textContent='لا توجد عناصر في هذا القسم بعد.';list.append(empty);}libraryDialog.append(libraryButton('إغلاق',()=>libraryDialog.close()));if(!libraryDialog.open)libraryDialog.showModal();};document.getElementById('library').onclick=()=>library();
    document.getElementById('upload').accept='image/*,video/*,.json';document.getElementById('upload').onchange=async e=>{const f=e.target.files[0];if(!f)return;e.target.value='';const category=uploadOnlyCategory;uploadOnlyCategory=null;if(f.size>1024*1024){alert('النسخة المحلية تقبل ملفًا أقل من 1 ميجابايت.');return;}if(f.name.toLowerCase().endsWith('.json')){if(!category){alert('استيراد العناصر من داخل المكتبة فقط.');return;}try{const obj=JSON.parse(await f.text());if(obj.format!=='elan-element-v1'||!obj.element||!['card','section','text','image','video'].includes(obj.element.type))throw new Error();checkpoint();const item=clone(obj.element);item.id=uid();if(['brand','store','perfume','banner','hero'].includes(category))item.kind=category;else item.type=category;state.savedElements.push(item);changed();library();}catch(err){alert('الملف ليس عنصرًا متوافقًا صادرًا من المحرر.');}return;}if(!f.type.startsWith('image/')&&!f.type.startsWith('video/')){alert('اختر صورة أو فيديو أو ملف عنصر متوافق.');return;}const target=replaceId||(current()&&['card','section'].includes(current().type)?selected:null);replaceId=null;const reader=new FileReader();reader.onload=()=>{checkpoint();const type=f.type.startsWith('image/')?'image':'video';const i=state.items.find(i=>i.id===target);const m={name:f.name,src:reader.result,type,category:category||(i?itemCategory(i):type)};state.media.push(m);if(!category){if(i&&['card','section'].includes(i.type)){i.mediaSrc=m.src;i.mediaType=type;i.fit='contain';}else if(i&&['image','video'].includes(i.type)){i.src=m.src;i.type=type;}else{add(type,m.src);}}changed();render();if(libraryDialog.open)library();};reader.readAsDataURL(f);};
    function downloadElement(item){const url=URL.createObjectURL(new Blob([JSON.stringify({format:'elan-element-v1',element:item},null,2)],{type:'application/json'}));const a=document.createElement('a');a.href=url;a.download='elan-element.json';a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);}
    const cleanMenu=showMenu;showMenu=function(e){cleanMenu(e);Array.from(menu.children).forEach(b=>{if(b.textContent==='استبدال الصورة أو الفيديو')b.remove();if(b.textContent==='حذف إلى الأرشيف')b.textContent='حذف العنصر إلى الأرشيف';});action('حفظ العنصر في المكتبة',()=>{const i=current();if(!i)return;checkpoint();if(!Array.isArray(state.savedElements))state.savedElements=[];state.savedElements.push(clone(i));changed();},!!current());action('تنزيل العنصر للمكتبة كملف',()=>{if(current())downloadElement(current());},!!current());const r=menu.getBoundingClientRect();menu.style.top=Math.max(4,Math.min(e.clientY,innerHeight-r.height-8))+'px';};
    // Sections participate in the same flow as cards instead of floating on top.
    cardOrder=function(){return state.items.filter(i=>['card','section'].includes(i.type)).sort((a,b)=>a.y-b.y||a.x-b.x);};
    packCards=function(){const elements=cardOrder();const moving=elements.find(i=>i.id===selected);if(moving&&dropTarget){const without=elements.filter(i=>i.id!==moving.id);const index=without.findIndex(i=>i.id===dropTarget.id);if(index>=0){without.splice(index+(dropTarget.after?1:0),0,moving);elements.splice(0,elements.length,...without);}}let x=40,y=340,rowHeight=0;elements.forEach(i=>{const oldX=i.x,oldY=i.y;if(i.type==='section'){if(x!==40){y+=rowHeight+24;x=40;rowHeight=0;}i.w=Math.min(i.w,1020);i.x=40;i.y=y;y+=i.h+24;}else{if(x+i.w>1060){x=40;y+=rowHeight+24;rowHeight=0;}i.x=x;i.y=y;x+=i.w+24;rowHeight=Math.max(rowHeight,i.h);}state.items.filter(t=>t.overlayOf===i.id).forEach(t=>{t.x+=i.x-oldX;t.y+=i.y-oldY;});});canvas.style.height=Math.max(900,y+rowHeight+60)+'px';dropTarget=null;};
    canvas.addEventListener('pointerdown',e=>{const el=e.target.closest('.item');if(el&&state.items.find(i=>i.id===el.dataset.id)?.type==='section'&&!e.target.classList.contains('handle'))dragWasCard=true;},true);
    canvas.addEventListener('pointermove',e=>{if(!gesture||gesture.mode!=='move')return;const i=state.items.find(i=>i.id===gesture.id);if(i?.type!=='section')return;const rect=canvas.getBoundingClientRect();const target=nearestCard(e.clientX-rect.left,e.clientY-rect.top,i.id);dropTarget=target?{id:target.id,after:e.clientY-rect.top>target.y+target.h/2}:null;});
    const createKindBeforeFlow=addKind;addKind=function(kind){createKindBeforeFlow(kind);if(kind==='section'&&autoFlow){packCards();render();}};
    const migrateSavedRender=render;render=function(){if(!Array.isArray(state.savedElements))state.savedElements=[];migrateSavedRender();};
    document.querySelector('header strong').textContent='Élan Scents · النسخة 9 — الألوان والمكتبة';
    // Place elements where requested; flow only on deliberate dragging.
    let requestedFlow=false;cardOrder=function(){return state.items.filter(i=>['card','section','image','video'].includes(i.type)).sort((a,b)=>a.y-b.y||a.x-b.x);};
    packCards=function(){if(!requestedFlow)return;const elements=cardOrder();const moving=elements.find(i=>i.id===selected);if(moving&&dropTarget){const rest=elements.filter(i=>i.id!==moving.id);const index=rest.findIndex(i=>i.id===dropTarget.id);if(index>=0){rest.splice(index+(dropTarget.after?1:0),0,moving);elements.splice(0,elements.length,...rest);}}let startY=Math.max(30,Math.min(...elements.map(i=>i.y)));let x=40,y=Number.isFinite(startY)?startY:340,rowHeight=0;elements.forEach(i=>{const oldX=i.x,oldY=i.y;i.w=Math.min(i.w,1020);if(x+i.w>1060){x=40;y+=rowHeight+24;rowHeight=0;}i.x=x;i.y=y;x+=i.w+24;rowHeight=Math.max(rowHeight,i.h);state.items.filter(t=>t.overlayOf===i.id).forEach(t=>{t.x+=i.x-oldX;t.y+=i.y-oldY;});});canvas.style.height=Math.max(900,y+rowHeight+50)+'px';dropTarget=null;requestedFlow=false;};
    const kindAtPosition=addKind;addKind=function(kind){kindAtPosition(kind);const i=current();if(!i)return;i.x=Math.max(0,Math.min(1100-i.w,contextPoint.x));i.y=Math.max(0,contextPoint.y);if(kind==='section'){i.w=450;i.h=220;i.x=Math.max(0,Math.min(1100-i.w,contextPoint.x));}canvas.style.height=Math.max(canvas.offsetHeight,i.y+i.h+50)+'px';render();};
    const lastMenu=showMenu;showMenu=function(e){lastMenu(e);Array.from(menu.children).forEach(b=>{if(['مسح الاسم أو النص التلقائي','كتابة أو تعديل نص العنصر'].includes(b.textContent))b.remove();});};
    let flowPointerStart=null;canvas.addEventListener('pointerdown',e=>{flowPointerStart={x:e.clientX,y:e.clientY};},true);canvas.addEventListener('pointerup',e=>{const g=gesture;if(!g||g.mode!=='move'||!flowPointerStart)return;const moved=Math.hypot(e.clientX-flowPointerStart.x,e.clientY-flowPointerStart.y)>4;const item=state.items.find(i=>i.id===g.id);if(moved&&item&&['card','section','image','video'].includes(item.type)){const rect=canvas.getBoundingClientRect();const x=e.clientX-rect.left,y=e.clientY-rect.top;const target=nearestCard(x,y,item.id);dropTarget=target?{id:target.id,after:y>target.y+target.h*.7||(Math.abs(y-(target.y+target.h/2))<target.h*.4&&x>target.x+target.w/2)}:null;requestedFlow=!!target;dragWasCard=true;}flowPointerStart=null;},true);
    // Clicking saved media inserts a new element, never silently overwrites the selection.
    const libraryBeforeFix=library;library=function(){libraryBeforeFix();const list=Array.from(libraryDialog.children).find(el=>el.tagName==='DIV'&&el.style.display==='grid'&&!el.textContent.includes('سيكشن ('));if(!list)return;const entries=libraryTab==='archive'?state.archive.filter(i=>itemCategory(i)===libraryCategory):[...state.savedElements.filter(i=>itemCategory(i)===libraryCategory),...state.media.filter(m=>(m.category||m.type)===libraryCategory)];Array.from(list.children).forEach((row,index)=>{const source=entries[index];if(!source||row.tagName!=='DIV')return;const use=row.querySelector('button');if(libraryTab==='saved'&&use){use.onclick=()=>{checkpoint();let copy;if(state.media.includes(source)){if(['section','brand','store','perfume','banner','hero'].includes(libraryCategory)){copy={id:uid(),type:libraryCategory==='section'?'section':'card',kind:libraryCategory,mediaSrc:source.src,mediaType:source.type,fit:'contain',text:'',w:300,h:240,font:'Tahoma',size:24,color:'#222222',bg:'#fffdf9',align:'right'};}else copy={id:uid(),type:source.type,src:source.src,w:300,h:240,text:'',fit:'contain'};}else{copy=clone(source);copy.id=uid();}copy.x=Math.max(0,Math.min(1100-copy.w,contextPoint.x));copy.y=Math.max(0,contextPoint.y);state.items.push(copy);selected=copy.id;if(autoFlow){const near=nearestCard(copy.x,copy.y,copy.id);if(near){dropTarget={id:near.id,after:true};requestedFlow=true;packCards();}}canvas.style.height=Math.max(canvas.offsetHeight,copy.y+copy.h+50)+'px';changed();render();libraryDialog.close();};}const del=document.createElement('button');del.textContent='حذف نهائي';del.style.color='#a02222';del.onclick=()=>{if(!confirm('حذف هذا العنصر نهائيًا من المكتبة؟ النسخ الموجودة في الصفحة لن تُحذف. يمكن التراجع أثناء هذه الجلسة فقط.'))return;checkpoint();const collection=libraryTab==='archive'?state.archive:state.savedElements.includes(source)?state.savedElements:state.media;const idx=collection.indexOf(source);if(idx>=0)collection.splice(idx,1);changed();library();};row.append(del);});};document.getElementById('library').onclick=()=>library();
    document.querySelector('header strong').textContent='Élan Scents · النسخة 10 — المواضع والمكتبة';
    // Two scoped fixes: automatic insertion/flow and media filling its frame.
    let insertPending=false;
    function isFlowElement(i){return ['card','section','image','video'].includes(i.type);}
    function reflowAt(id,point){const moving=state.items.find(i=>i.id===id);if(!moving||!isFlowElement(moving))return;const others=state.items.filter(i=>isFlowElement(i)&&i.id!==id).sort((a,b)=>a.y-b.y||a.x-b.x);let index=others.filter(i=>i.y<moving.y||(i.y===moving.y&&i.x<moving.x)).length;if(point&&others.length){let best=Infinity,nearestIndex=0;others.forEach((i,n)=>{const distance=Math.hypot(point.x-(i.x+i.w/2),point.y-(i.y+i.h/2));if(distance<best){best=distance;nearestIndex=n;}});const target=others[nearestIndex];index=nearestIndex+((point.y>target.y+target.h*.75)||(point.y>=target.y&&point.x>target.x+target.w/2)?1:0);}const top=others.length?Math.max(0,Math.min(...others.map(i=>i.y))):Math.max(0,moving.y);others.splice(index,0,moving);let x=40,y=top,rowH=0;others.forEach(i=>{const oldX=i.x,oldY=i.y;i.w=Math.max(40,Math.min(1020,i.w));if(x+i.w>1060){x=40;y+=rowH+24;rowH=0;}i.x=x;i.y=y;state.items.filter(t=>t.overlayOf===i.id).forEach(t=>{t.x+=i.x-oldX;t.y+=i.y-oldY;});x+=i.w+24;rowH=Math.max(rowH,i.h);});canvas.style.height=Math.max(900,y+rowH+60)+'px';dropTarget=null;requestedFlow=false;changed();render();}
    function scheduleInsertion(){if(insertPending)return;insertPending=true;queueMicrotask(()=>{insertPending=false;const i=current();if(i&&isFlowElement(i))reflowAt(i.id,{...contextPoint});});}
    const insertionAdd=add;add=function(type,src){insertionAdd(type,src);if(isFlowElement(current()||{}))scheduleInsertion();};const insertionKind=addKind;addKind=function(kind){insertionKind(kind);scheduleInsertion();};
    let lastDrag=null;canvas.addEventListener('pointerdown',e=>{const el=e.target.closest('.item');if(!el)return;const i=state.items.find(i=>i.id===el.dataset.id);if(i&&isFlowElement(i)){lastDrag={id:i.id,x:e.clientX,y:e.clientY,resize:e.target.classList.contains('handle')};}},true);canvas.addEventListener('pointerup',e=>{if(!lastDrag)return;const drag=lastDrag;lastDrag=null;const distance=Math.hypot(e.clientX-drag.x,e.clientY-drag.y);if(distance<4)return;const rect=canvas.getBoundingClientRect();const point={x:e.clientX-rect.left,y:e.clientY-rect.top};queueMicrotask(()=>{if(state.items.some(i=>i.id===drag.id)){selected=drag.id;reflowAt(drag.id,drag.resize?null:point);}});},true);canvas.addEventListener('pointercancel',()=>lastDrag=null,true);
    const fillRender=render;render=function(){fillRender();state.items.forEach(i=>{const el=Array.from(canvas.children).find(e=>e.dataset.id===i.id);if(!el)return;el.querySelectorAll('img,video').forEach(media=>{media.style.objectFit='cover';media.style.objectPosition='center';media.style.width='100%';media.style.height='100%';media.style.display='block';});});};
    document.querySelector('header strong').textContent='Élan Scents · النسخة 11 — الإزاحة وملء الميديا';
    // Menu-only cleanup; automatic arrangement remains enabled.
    autoFlow=true;
    const menuBeforeFinalCleanup=showMenu;
    showMenu=function(e){autoFlow=true;menuBeforeFinalCleanup(e);Array.from(menu.children).forEach(b=>{const label=b.textContent.trim();if(label==='تكبير الخط +'||label==='تصغير الخط −'||label.startsWith('الترتيب التلقائي:'))b.remove();});const r=menu.getBoundingClientRect();menu.style.top=Math.max(4,Math.min(e.clientY,innerHeight-r.height-8))+'px';};
    document.querySelector('header strong').textContent='Élan Scents · النسخة 12';
    // Fit the complete media without cropping or distorting it.
    const completeMediaRender=render;
    render=function(){completeMediaRender();state.items.forEach(i=>{const el=Array.from(canvas.children).find(e=>e.dataset.id===i.id);if(!el)return;el.querySelectorAll('img,video').forEach(media=>{media.style.objectFit='contain';media.style.objectPosition='center';media.style.width='100%';media.style.height='100%';media.style.display='block';});});};
    const headerStyle=document.createElement('style');headerStyle.textContent='header{height:auto;min-height:82px;background:linear-gradient(110deg,#151515,#24211c);border-bottom:1px solid #b99755;box-shadow:0 4px 18px rgba(0,0,0,.16);padding:13px 26px;gap:10px;flex-wrap:wrap}header strong{display:flex;flex-direction:column;min-width:160px;margin-left:auto;line-height:1.15}header .brandName{font-family:Georgia,serif;font-size:30px;letter-spacing:.4px;color:#e7c779;text-shadow:0 1px 0 #6b4d16,0 2px 5px #0005}header .brandName .scents{font-size:23px;color:#f3ead9;font-weight:400}header .brandCaption{font:10px Arial,sans-serif;letter-spacing:2px;color:#c6b796;margin-top:7px}header button{background:#302b23;border:1px solid #685b41;color:#efe4cc;border-radius:10px;min-height:42px;padding:10px 15px;display:flex;align-items:center;gap:8px;box-shadow:inset 0 1px 0 #ffffff0d;transition:background .15s,border-color .15s}header button:hover:not(:disabled){background:#463a27;border-color:#c7a663}header button:disabled{opacity:.35}header #save{background:#d4b76e;color:#211d15;border-color:#dfc88e;font-weight:bold}header #save:hover{background:#e2c983}header #status{font-size:11px;color:#cabfa9;border-right:1px solid #65583f;padding-right:12px;max-width:190px;line-height:1.7}#viewport{height:calc(100vh - 100px)}@media(max-width:600px){header{padding:10px;gap:6px}header strong{width:100%;align-items:center;margin-bottom:5px}header button{padding:8px 10px;flex:1;justify-content:center}header #status{max-width:none;width:100%;text-align:center;border:0}#viewport{height:calc(100vh - 170px)}}';document.head.append(headerStyle);
    const logo=document.querySelector('header strong');logo.replaceChildren();const brand=document.createElement('span');brand.className='brandName';brand.dir='ltr';brand.append('Élan ');const scents=document.createElement('span');scents.className='scents';scents.textContent='Scents';brand.append(scents);const caption=document.createElement('span');caption.className='brandCaption';caption.dir='ltr';caption.textContent='VISUAL EDITOR · 13';logo.append(brand,caption);
    [['undo','↶','تراجع'],['redo','↷','إعادة'],['save','✓','حفظ'],['library','▦','المكتبة']].forEach(([id,icon,label])=>{const button=document.getElementById(id);button.replaceChildren();const mark=document.createElement('span');mark.textContent=icon;mark.style.fontSize='19px';mark.setAttribute('aria-hidden','true');const text=document.createElement('span');text.textContent=label;button.append(mark,text);button.title=label;});
    // Stretch media to exactly match the element's width and height.
    const exactFillStyle=document.createElement('style');exactFillStyle.textContent='#status{display:none!important}.item img,.item video{object-fit:fill!important;object-position:center!important;width:100%!important;height:100%!important;max-width:none!important;max-height:none!important}.item.image .content,.item.video .content{padding:0!important}';document.head.append(exactFillStyle);
    const beforeExactFill=render;render=function(){beforeExactFill();state.items.forEach(i=>{const el=Array.from(canvas.children).find(e=>e.dataset.id===i.id);if(!el)return;el.querySelectorAll('img,video').forEach(media=>{media.style.setProperty('object-fit','fill','important');media.style.setProperty('width','100%','important');media.style.setProperty('height','100%','important');if(i.borderShape!=='circle')media.style.clipPath='none';});});};
    caption.textContent='VISUAL EDITOR · 14';
    // Enable keyboard text editing for sections without synthetic double-clicks.
    const beforeSectionTextMenu=showMenu;
    showMenu=function(e){beforeSectionTextMenu(e);const item=current();const button=Array.from(menu.children).find(b=>b.textContent==='تعديل النص بالكيبورد');if(button){button.disabled=!item||!['text','card','section'].includes(item.type);button.onclick=()=>{menu.style.display='none';const target=current();if(!target||!['text','card','section'].includes(target.type))return;const el=Array.from(canvas.children).find(node=>node.dataset.id===target.id);const content=el?.querySelector('.content');if(!content)return;checkpoint();editing=true;el.classList.add('editing');content.contentEditable='plaintext-only';content.focus();const range=document.createRange();range.selectNodeContents(content);range.collapse(false);const selection=window.getSelection();selection.removeAllRanges();selection.addRange(range);};}};
    caption.textContent='VISUAL EDITOR · 15';
    // Elan domain definitions: declarative bindings, not a live database connection.
    const elanElementDefinitions={
    version:1,
    rules:{priceSource:'store_catalog',availabilitySource:'store_catalog',officialBrandContentOnly:true,neverUseBrandPrice:true,externalBrandStoreLinksVisible:false,oneCardPerProductSize:true,compareSameSizeConcentrationEditionPackaging:true,requireVerifiedAvailableOffer:true,priceOrder:['price ASC','commission_rate DESC','priority_rank ASC'],unknownQuantityIsNotZero:true,noAutomaticSplit:true,noVendorSwitchForInsufficientRequestedQuantity:true,comingSoonNotPurchasable:true},
    initialBrands:['AMOUAGE','ARMAF','AFNAN','ASAF','RASASI','FRENCH AVENUE','ARABIYAT PRESTIGE','LATTAFA','Maison Alhambra'],
    elements:{
    section:{label:'سيكشن',source:['public_products','cheapest_offers'],fields:['name','purpose','filter','preview_limit'],behavior:'Dynamic query by approved purpose; display only matching available perfumes with unified cards; coming soon is a separately labeled exception.'},
    perfume:{label:'كارت عطر',source:['products','product_sizes','cheapest_offers'],fields:['product_id','product_size_id','name','image','brand','store','category','price','short_description','occasions','notes','availability','quantity','last_synced_at'],behavior:'One card per exact product variant and size. Verified lowest eligible store offer. Details and cart actions use bound IDs; unavailable data stays empty, not fabricated.'},
    brand:{label:'كارت براند',source:['brands','public_products','cheapest_offers'],fields:['brand_id','name','official_logo_url'],behavior:'Original official logo without cropping; only this brand perfumes available at participating stores.'},
    store:{label:'كارت متجر',source:['stores','store_products'],fields:['store_id','name','logo_url','image_url','short_description','status'],behavior:'Separate seller catalogue restricted to approved brands. Show this seller actual price and stock, never attribute another seller price. New seller remains pending integration.'},
    occasion:{label:'كارت مناسبة',source:['occasions','product_occasions','public_products','cheapest_offers'],fields:['occasion_id','name','image_url'],behavior:'Only verified linked products. A new name does not imply automatic fragrance classification.'},
    note:{label:'كارت نوتة عطرية',source:['aromatic_notes','product_notes','public_products','cheapest_offers'],fields:['note_id','name','image_url'],behavior:'Only matching verified product-note relations; preserve official content provenance.'},
    banner:{label:'بانر',source:['editor_content'],fields:['name','media','alt_text','optional_internal_target'],behavior:'Editorial image/video; no invented commercial data.'},
    text:{label:'نص',source:['editor_content','marketing_phrases'],fields:['text','font','color','background','size'],behavior:'Overlay text; only assigned marketing wording, no unsupported claims.'},
    text_block:{label:'كتلة نصية',source:['editor_content','marketing_phrases'],fields:['text','font','color','background','size'],behavior:'Flow block, not overlay; occupies layout space and displaces neighbouring elements.'}
    }};
    function definitionKind(item){if(item.kind==='text_block')return 'text_block';if(['brand','store','perfume','occasion','note','banner'].includes(item.kind))return item.kind;if(item.type==='section')return 'section';if(item.type==='text')return 'text';if(item.type==='card')return 'perfume';return null;}
    function attachDefinition(item){const kind=definitionKind(item);if(!kind)return;item.definitionKey=kind;item.definitionVersion=1;if(!item.binding)item.binding={status:['text','text_block','banner'].includes(kind)?'editorial':'not_connected',entityId:null,productSizeId:null,name:'',purpose:null};}
    state.elementDefinitions=clone(elanElementDefinitions);state.items.forEach(attachDefinition);
    const definitionDialog=document.createElement('dialog');definitionDialog.style.width='470px';document.body.append(definitionDialog);
    function configureDefinition(){const item=current();if(!item)return;attachDefinition(item);const def=elanElementDefinitions.elements[item.definitionKey];if(!def)return;definitionDialog.replaceChildren();const h=document.createElement('h3');h.textContent='تعريف '+def.label;definitionDialog.append(h);const fields={};function input(label,key,value){const l=document.createElement('label');l.textContent=label;const i=document.createElement('input');i.value=value||'';i.style.cssText='display:block;width:100%;margin-top:6px';l.append(i);definitionDialog.append(l);fields[key]=i;}
    input('اسم العنصر أو السجل المطلوب','name',item.binding.name);if(!['text','text_block','banner','section'].includes(item.definitionKey)){input('معرّف السجل في سابابيس، اختياري الآن','entityId',item.binding.entityId);fields.entityId.dir='ltr';}if(item.definitionKey==='perfume'){input('معرّف حجم العطر، اختياري الآن','productSizeId',item.binding.productSizeId);fields.productSizeId.dir='ltr';}
    let purpose=null;if(item.definitionKey==='section'){const l=document.createElement('label');l.textContent='غرض السيكشن';purpose=document.createElement('select');[['available','سحر الخليج، العطور المتاحة'],['brands','البراندات'],['offers','العروض والخصومات'],['new_arrivals','وصل حديثًا وفق إعلان المتجر'],['masterpieces','المختارات بمؤشرات موثقة'],['categories','الفئات'],['occasions','المناسبات'],['notes','النوتات'],['coming_soon','مرتقب وصولها، غير قابلة للشراء'],['stores','المتاجر'],['about','عن إيلان'],['contact','التواصل'],['custom','غرض مخصص يحتاج قاعدة بيانات معتمدة']].forEach(([value,label])=>{const o=document.createElement('option');o.value=value;o.textContent=label;purpose.append(o);});purpose.value=item.binding.purpose||'available';l.append(purpose);definitionDialog.append(l);}
    const note=document.createElement('small');note.textContent='تعريف محفوظ داخل التصميم لتجهيز الربط. لا يتم جلب بيانات أو إنشاء سجل في سابابيس من هذه النسخة. ربط الاسم وحده لا يكفي، ويحتاج معرّفًا وقاعدة عرض.';definitionDialog.append(note);const save=document.createElement('button');save.textContent='حفظ التعريف';save.onclick=()=>{const uuid=/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;for(const key of ['entityId','productSizeId'])if(fields[key]?.value.trim()&&!uuid.test(fields[key].value.trim())){alert('معرّف السجل يجب أن يكون UUID صحيحًا، أو اتركه فارغًا.');return;}checkpoint();Object.entries(fields).forEach(([key,value])=>item.binding[key]=value.value.trim()||null);if(purpose)item.binding.purpose=purpose.value;if(item.binding.name&&!['text','text_block'].includes(item.definitionKey))item.text=item.binding.name;changed();render();definitionDialog.close();};const close=document.createElement('button');close.textContent='إغلاق';close.onclick=()=>definitionDialog.close();definitionDialog.append(save,close);definitionDialog.showModal();}
    const kindsBeforeDefinition=addKind;addKind=function(kind){kindsBeforeDefinition(kind);const item=current();if(!item)return;if(kind==='occasion'){item.text='اسم المناسبة';item.kind='occasion';}if(kind==='note'){item.text='اسم النوتة العطرية';item.kind='note';}attachDefinition(item);render();};
    function createTextBlock(){add('text');const item=current();item.kind='text_block';item.z=1;item.transparent=false;delete item.overlayOf;item.w=450;item.h=150;item.text='كتلة نصية جديدة';attachDefinition(item);changed();render();scheduleInsertion();}
    isFlowElement=function(item){return ['card','section','image','video'].includes(item.type)||item.kind==='text_block';};cardOrder=function(){return state.items.filter(isFlowElement).sort((a,b)=>a.y-b.y||a.x-b.x);};
    const renderWithDefinitions=render;render=function(){state.elementDefinitions=clone(elanElementDefinitions);state.items.forEach(attachDefinition);renderWithDefinitions();state.items.filter(i=>i.kind==='text_block').forEach(i=>{const el=Array.from(canvas.children).find(el=>el.dataset.id===i.id);if(el){el.style.zIndex='1';el.dataset.layout='flow';}});};
    const menuWithDefinitions=showMenu;showMenu=function(e){menuWithDefinitions(e);const added=[];function extra(label,fn){action(label,fn);added.push(menu.lastElementChild);}extra('إنشاء مناسبة',()=>addKind('occasion'));extra('إنشاء نوتة عطر',()=>addKind('note'));extra('إنشاء كتلة نصية',createTextBlock);const anchor=Array.from(menu.children).find(b=>b.textContent==='إنشاء كارت عطر');if(anchor){let after=anchor;added.forEach(b=>{after.after(b);after=b;});}action('تعريف العنصر ومصدر بياناته',configureDefinition,!!current()&&!!definitionKind(current()));const r=menu.getBoundingClientRect();menu.style.top=Math.max(4,Math.min(e.clientY,innerHeight-r.height-8))+'px';};
    const categoryBeforeDefinition=itemCategory;itemCategory=function(item){if(['occasion','note','text_block'].includes(item.kind))return item.kind;return categoryBeforeDefinition(item);};categoryDefinitions.push(['occasion','مناسبة'],['note','نوتة عطرية'],['text_block','كتلة نصية']);
    caption.textContent='VISUAL EDITOR · 17';
    // Final element data contract: only names, fields, relations and rules supplied by the merchant.
    const suppliedSchema={
    tables:{
    brands:['id','name','slug','official_logo_url','description','official_website_url','is_active','created_at','updated_at'],
    stores:['id','name','slug','logo_url','image_url','short_description','website_url','status','commission_rate','priority_rank','created_at','updated_at'],
    store_accounts:['id','store_id','user_id','role','created_at'],
    aromatic_notes:['id','name','image_url','created_at','updated_at'],categories:['id','name','image_url','created_at','updated_at'],occasions:['id','name','image_url','created_at','updated_at'],
    products:['id','brand_id','name','slug','short_description','official_description','composition','gender','notes_source','content_source','status','meta_title','meta_description','is_active','created_at','updated_at'],
    product_sizes:['id','product_id','size_ml','size_label','sku','created_at','updated_at'],
    product_images:['id','product_id','product_size_id','image_url','alt_text','sort_order','is_primary','created_at'],
    product_notes:['product_id','note_id'],product_categories:['product_id','category_id'],product_occasions:['product_id','occasion_id'],
    store_products:['id','store_id','product_size_id','price','original_price','discount_percentage','stock_quantity','is_available','is_new_arrival','is_coming_soon','price_includes_tax','price_includes_shipping','currency','data_source','sync_status','last_synced_at','created_at','updated_at'],
    offers:['id','store_id','product_size_id','title','description','discount_type','discount_value','start_date','end_date','is_active','created_at','updated_at'],
    product_stats:['product_id','views_count','sales_count','search_count','request_count','average_rating','reviews_count','updated_at'],
    reviews:['id','user_id','product_id','rating','comment','is_approved','created_at','updated_at'],
    profiles:['id','full_name','phone','avatar_url','role','created_at','updated_at'],
    favorites:['id','user_id','product_id','created_at'],cart_items:['id','user_id','store_product_id','quantity','created_at','updated_at'],
    orders:['id','user_id','status','subtotal','tax_amount','shipping_amount','total_amount','created_at','updated_at'],order_items:['id','order_id','store_product_id','quantity','price_at_time','created_at'],
    commissions:['id','store_id','order_item_id','rate','amount','status','created_at','updated_at'],contact_messages:['id','name','email','phone','message','is_read','created_at'],notifications:['id','user_id','title','body','is_read','created_at'],
    marketing_phrases:['id','phrase_ar','phrase_en','category','is_public','usage_scope','created_at'],media_library:['id','file_url','file_type','source','alt_text','linked_entity_type','linked_entity_id','is_approved','created_at'],analytics_events:['id','event_type','product_id','product_size_id','user_id','metadata','created_at'],site_settings:['key','value','updated_at'],sync_logs:['id','store_id','status','message','records_count','created_at']},
    relations:{'products.brand_id':'brands.id','product_sizes.product_id':'products.id','product_images.product_id':'products.id','product_images.product_size_id':'product_sizes.id','product_notes.product_id':'products.id','product_notes.note_id':'aromatic_notes.id','product_categories.product_id':'products.id','product_categories.category_id':'categories.id','product_occasions.product_id':'products.id','product_occasions.occasion_id':'occasions.id','store_products.store_id':'stores.id','store_products.product_size_id':'product_sizes.id','offers.store_id':'stores.id','offers.product_size_id':'product_sizes.id','product_stats.product_id':'products.id','store_accounts.store_id':'stores.id','store_accounts.user_id':'auth.users.id','profiles.id':'auth.users.id','reviews.user_id':'profiles.id','reviews.product_id':'products.id','favorites.user_id':'profiles.id','favorites.product_id':'products.id','cart_items.user_id':'profiles.id','cart_items.store_product_id':'store_products.id','orders.user_id':'profiles.id','order_items.order_id':'orders.id','order_items.store_product_id':'store_products.id','commissions.store_id':'stores.id','commissions.order_item_id':'order_items.id','notifications.user_id':'profiles.id'},
    views:{cheapest_offers:{per:'product_size_id',conditions:['is_available = true','stock_quantity > 0','sync_status = synced'],order:['price ASC','commission_rate DESC','priority_rank ASC'],columns:['product_size_id','product_id','brand_id','store_id','store_name','price','stock_quantity','currency','price_includes_tax','price_includes_shipping','last_synced_at']},public_products:{conditions:['published products','at least one offer in cheapest_offers'],usage:'The only product visibility rule for cards, sections and search',columns:'not specified in supplied schema'}},
    rules:{priceAvailabilityQuantityOffersNewArrivalBestSellingSource:'store_catalog',descriptionCompositionNotesOfficialContentSupplementSource:'brand_official',brandWebsitePriceProhibited:true,brandStoreWebsiteLinksHidden:true,atLeastOneAvailableStoreRequired:true,eachSizeIndependent:true,compareDifferentSizesProhibited:true,oneCardPerProductAndSize:true,tieBreak:['commission_rate DESC','priority_rank ASC']},
    initial:{brands:['AMOUAGE','ARMAF','AFNAN','ASAF','RASASI','FRENCH AVENUE','ARABIYAT PRESTIGE','LATTAFA','Maison Alhambra'],stores:[{name:'Afnan Egypt',website_url:'egypt.afnan.com'},{name:'Emarati Scents',website_url:'emaratiscents.com'}],notes:['عنبري','حمضي','خشبي','عود','هيل'],categories:['رجالي','نسائي','عطر يجمعنا'],occasions:['نهاري','ليلي','عمل','موعد','هدية'],site_settings:['contact_email','instagram_url','tiktok_url','pinterest_url','footer_tagline','developer_credit','whatsapp_number']},
    security:{rlsAllTables:true,publicRead:'available products, brands, stores, offers and prices only',ownUserWrites:['favorites','cart_items','orders','reviews','contact_messages'],storeAccounts:'own store catalogue only',platform_admin:'full access'},
    connection:'not_connected',origin:'merchant supplied schema specification, not live database inspection'};
    function schemaElement(label,table,related,extra){return {label,table,fields:table?clone(suppliedSchema.tables[table]):[],relatedTables:related||[],...extra};}
    elanElementDefinitions.version=3;elanElementDefinitions.rules=clone(suppliedSchema.rules);elanElementDefinitions.schema=clone(suppliedSchema);
    elanElementDefinitions.elements={
    section:schemaElement('سيكشن',null,[],{schemaDefinition:'No independent section table or layout fields specified.',productVisibilityView:'public_products'}),
    perfume:schemaElement('كارت عطر','products',['product_sizes','product_images','brands','stores','store_products','product_notes','aromatic_notes','product_categories','categories','product_occasions','occasions'],{sizeKey:'product_sizes.id',offerView:'cheapest_offers',productVisibilityView:'public_products',cardUniqueness:'same product and same size'}),
    brand:schemaElement('كارت براند','brands',['products','product_sizes','store_products','stores'],{hiddenFields:['official_website_url'],productVisibilityView:'public_products',offerView:'cheapest_offers'}),
    store:schemaElement('كارت متجر','stores',['store_products','product_sizes','products','brands'],{hiddenFields:['website_url'],productVisibilityView:'public_products',offerView:'cheapest_offers'}),
    occasion:schemaElement('كارت مناسبة','occasions',['product_occasions','products','product_sizes'],{relation:'product_occasions.occasion_id -> occasions.id; product_occasions.product_id -> products.id',productVisibilityView:'public_products',offerView:'cheapest_offers'}),
    note:schemaElement('كارت نوتة عطرية','aromatic_notes',['product_notes','products','product_sizes'],{relation:'product_notes.note_id -> aromatic_notes.id; product_notes.product_id -> products.id',productVisibilityView:'public_products',offerView:'cheapest_offers'}),
    banner:schemaElement('بانر',null,['media_library'],{schemaDefinition:'No independent banner table or behavior specified.'}),
    text:schemaElement('نص',null,['marketing_phrases'],{schemaDefinition:'No independent editor text table specified.'}),
    text_block:schemaElement('كتلة نصية',null,['marketing_phrases'],{schemaDefinition:'No independent text-block table specified.',editorLayout:'flow as requested by merchant'})};
    const beforeExactDefinition=attachDefinition;attachDefinition=function(item){beforeExactDefinition(item);if(!item.definitionKey)return;const def=elanElementDefinitions.elements[item.definitionKey];item.definitionVersion=3;item.dataDefinition={kind:item.definitionKey,table:def.table,fields:clone(def.fields),relatedTables:clone(def.relatedTables),contract:clone(def),rules:clone(suppliedSchema.rules)};};
    state.items.forEach(attachDefinition);
    // No purpose/filter implementation is inferred from the schema.
    configureDefinition=function(){const item=current();if(!item)return;attachDefinition(item);definitionDialog.replaceChildren();const def=elanElementDefinitions.elements[item.definitionKey];const h=document.createElement('h3');h.textContent='تعريف '+def.label;definitionDialog.append(h);const l=document.createElement('label');l.textContent='اسم العنصر';const name=document.createElement('input');name.value=item.binding.name||'';l.append(name);definitionDialog.append(l);const identity=document.createElement('input');if(def.table){const label=document.createElement('label');label.textContent='معرّف السجل، يحدد عند الربط';identity.value=item.binding.entityId||'';identity.dir='ltr';label.append(identity);definitionDialog.append(label);}const note=document.createElement('p');note.textContent=def.table?'مصدر التعريف: '+def.table:'الشّيما لا تحدد جدولًا مستقلًا لهذا العنصر؛ لا يتم افتراض جدول جديد.';definitionDialog.append(note);const save=document.createElement('button');save.textContent='حفظ';save.onclick=()=>{if(identity.value.trim()&&!/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(identity.value.trim())){alert('اكتب UUID أو اترك المعرّف فارغًا.');return;}checkpoint();item.binding.name=name.value.trim()||null;if(def.table)item.binding.entityId=identity.value.trim()||null;if(item.binding.name&&!['text','text_block'].includes(item.definitionKey))item.text=item.binding.name;attachDefinition(item);changed();render();definitionDialog.close();};const close=document.createElement('button');close.textContent='إغلاق';close.onclick=()=>definitionDialog.close();definitionDialog.append(save,close);definitionDialog.showModal();};
    const exactSchemaSave=document.getElementById('save').onclick;document.getElementById('save').onclick=()=>{state.elementDefinitions=clone(elanElementDefinitions);state.items.forEach(attachDefinition);exactSchemaSave();};
    caption.textContent='VISUAL EDITOR · SCHEMA FINAL';
    render();
    
    </script><script>
    // Section campaign extension. No remote connection or fake catalogue.
    const sectionPanel=document.createElement('dialog');sectionPanel.style.cssText='width:650px;max-height:90vh';document.body.append(sectionPanel);
    function localCairo(iso){if(!iso)return '';const p=Object.fromEntries(new Intl.DateTimeFormat('en-GB',{timeZone:'Africa/Cairo',year:'numeric',month:'2-digit',day:'2-digit',hour:'2-digit',minute:'2-digit',hourCycle:'h23'}).formatToParts(new Date(iso)).filter(p=>p.type!=='literal').map(p=>[p.type,p.value]));return `${p.year}-${p.month}-${p.day}T${p.hour}:${p.minute}`;}
    function cairoUTC(s){if(!s)return null;let t=Date.parse(s+'Z'),g=t;if(!Number.isFinite(t))throw Error('موعد غير صحيح');for(let n=0;n<4;n++){const shown=Date.parse(localCairo(new Date(g).toISOString())+'Z');g+=t-shown;}return new Date(g).toISOString();}
    function editSection(item){const old=item?.sectionConfig||{};sectionPanel.replaceChildren();const h=document.createElement('h3');h.textContent=item?'إعدادات السيكشن':'إنشاء سيكشن';sectionPanel.append(h);function field(title,type,value){const l=document.createElement('label');l.textContent=title;const i=document.createElement('input');i.type=type;i.value=value??'';i.style.cssText='display:block;width:100%;margin-top:5px';l.append(i);sectionPanel.append(l);return i;}function select(title,choices,value){const l=document.createElement('label');l.textContent=title;const s=document.createElement('select');choices.forEach(([v,t])=>{const o=document.createElement('option');o.value=v;o.textContent=t;s.append(o);});s.value=value;l.append(s);sectionPanel.append(l);return s;}
    const name=field('اسم السيكشن','text',old.name||item?.text||''),purpose=field('الغرض من السيكشن','text',old.purpose||'');const mode=select('اختيار العطور',[['manual','يدوي'],['automatic','تلقائي بالفلاتر']],old.selectionMode||'manual');const filters={};[['brand_id','البراند'],['store_id','المتجر'],['category_id','الفئة'],['occasion_id','المناسبة'],['note_id','النوتة'],['size_ml','الحجم بالمل'],['price_min','أقل سعر'],['price_max','أعلى سعر']].forEach(([key,title])=>{const number=['size_ml','price_min','price_max'].includes(key);filters[key]=field(title,number?'number':'text',old.filters?.[key]);if(!number)filters[key].placeholder='معرّف السجل؛ قائمة الأسماء بعد ربط سابابيس';else filters[key].min='0';});
    let picks=clone(old.manualProducts||[]);const add=document.createElement('button');add.textContent='إضافة عطر';const results=document.createElement('div'),chosen=document.createElement('div');function paint(){chosen.replaceChildren();picks.forEach((p,n)=>{const line=document.createElement('div');line.textContent=p.name+' — '+p.productSizeId;const b=document.createElement('button');b.textContent='إزالة';b.onclick=()=>{picks.splice(n,1);paint();};line.append(b);chosen.append(line);});}paint();add.onclick=()=>{results.replaceChildren();const available=state.items.filter(i=>i.kind==='perfume'&&i.binding?.entityId&&i.binding?.productSizeId);if(!available.length){results.textContent='لا يوجد كتالوج متصل. اختيار العطور بأسمائها وتطبيق الفلاتر على نتائج حقيقية يحتاج ربط سابابيس. لا نعرض بيانات وهمية.';return;}available.forEach(i=>{const b=document.createElement('button');b.textContent=i.binding.name||i.text;b.onclick=()=>{if(!picks.some(p=>p.productSizeId===i.binding.productSizeId))picks.push({productId:i.binding.entityId,productSizeId:i.binding.productSizeId,name:i.binding.name||i.text});paint();};results.append(b);});};sectionPanel.append(add,results,chosen);mode.onchange=()=>{add.hidden=mode.value!=='manual';chosen.hidden=mode.value!=='manual';results.replaceChildren();};mode.onchange();
    const label=document.createElement('label'),enabled=document.createElement('input');enabled.type='checkbox';enabled.checked=!!old.timer?.enabled;label.append(enabled,' تشغيل التوقيت');sectionPanel.append(label);const timing=select('طريقة التوقيت',[['dates','بداية ونهاية'],['duration','ساعات أو أيام من أول حفظ']],old.timer?.mode||'dates');const start=field('البداية، توقيت مصر','datetime-local',localCairo(old.timer?.startsAt)),end=field('النهاية، توقيت مصر','datetime-local',localCairo(old.timer?.endsAt)),count=field('عدد الساعات أو الأيام','number',old.timer?.durationValue||1);count.min='1';const unit=select('الوحدة',[['hours','ساعات'],['days','أيام']],old.timer?.durationUnit||'hours');function timingUI(){timing.closest('label').hidden=!enabled.checked;start.closest('label').hidden=end.closest('label').hidden=!enabled.checked||timing.value!=='dates';count.closest('label').hidden=unit.closest('label').hidden=!enabled.checked||timing.value!=='duration';}enabled.onchange=timingUI;timing.onchange=timingUI;timingUI();
    const note=document.createElement('small');note.textContent='هذه نسخة محلية: التعريفات جاهزة للربط، والتوقيت يعمل أثناء فتح المحرر وعند إعادة فتحه. البداية المستقبلية تظهر باهتة للمعاينة فقط.';sectionPanel.append(note);const save=document.createElement('button');save.textContent='حفظ السيكشن';save.onclick=()=>{try{if(!name.value.trim()||!purpose.value.trim())throw Error('اكتب الاسم والغرض.');const values={};Object.entries(filters).forEach(([key,i])=>{if(!i.value.trim())return;if(i.type==='number'){if(!Number.isFinite(Number(i.value))||Number(i.value)<0)throw Error('قيمة فلتر غير صحيحة');values[key]=Number(i.value);}else{if(!/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(i.value.trim()))throw Error('استخدم معرّف سجل صحيحًا أو اترك الفلتر فارغًا.');values[key]=i.value.trim();}});if(values.price_min!==undefined&&values.price_max!==undefined&&values.price_min>values.price_max)throw Error('أقل سعر أكبر من أعلى سعر.');const createdAt=old.createdAt||new Date().toISOString();const timer={enabled:enabled.checked,mode:timing.value,timeZone:'Africa/Cairo',durationValue:Number(count.value),durationUnit:unit.value,startsAt:null,endsAt:null};if(timer.enabled){if(timer.mode==='dates'){timer.startsAt=cairoUTC(start.value);timer.endsAt=cairoUTC(end.value);if(!timer.startsAt||!timer.endsAt||Date.parse(timer.endsAt)<=Date.parse(timer.startsAt))throw Error('حدد مواعيد صحيحة.');}else{if(!Number.isFinite(timer.durationValue)||timer.durationValue<=0)throw Error('حدد مدة أكبر من صفر');timer.startsAt=createdAt;timer.endsAt=new Date(Date.parse(createdAt)+timer.durationValue*(unit.value==='days'?86400000:3600000)).toISOString();}}checkpoint();let target=item;if(!target){windowSectionAdd();target=current();}target.text=name.value.trim();target.sectionConfig={name:name.value.trim(),purpose:purpose.value.trim(),selectionMode:mode.value,filters:values,manualProducts:picks,createdAt,timer,dataSource:{products:'public_products',offers:'cheapest_offers',connection:'not_connected'}};attachDefinition(target);target.binding.name=target.sectionConfig.name;target.binding.purpose=target.sectionConfig.purpose;selected=target.id;reflowAt(target.id,{...contextPoint});changed();document.getElementById('save').click();sectionPanel.close();checkSections();}catch(e){alert(e.message);}};const close=document.createElement('button');close.textContent='إلغاء';close.onclick=()=>sectionPanel.close();sectionPanel.append(save,close);sectionPanel.showModal();}
    function windowSectionAdd(){add('section');const i=current();i.w=450;i.h=220;i.z=1;}
    const sectionMenuBase=showMenu;showMenu=function(e){sectionMenuBase(e);const b=Array.from(menu.children).find(b=>b.textContent==='إنشاء سيكشن');if(b)b.onclick=()=>{menu.style.display='none';editSection(null);};action('إعدادات السيكشن',()=>editSection(current()),current()?.type==='section');};
    function checkSections(){const now=Date.now();const expired=state.items.filter(i=>i.sectionConfig?.timer?.enabled&&i.sectionConfig.timer.endsAt&&Date.parse(i.sectionConfig.timer.endsAt)<=now);if(expired.length){checkpoint();expired.forEach(i=>{const copy=clone(i);copy.sectionConfig.lastTimer=clone(copy.sectionConfig.timer);copy.sectionConfig.timer.enabled=false;copy.sectionConfig.archivedAt=new Date().toISOString();state.archive.push(copy);});const ids=new Set(expired.map(i=>i.id));state.items=state.items.filter(i=>!ids.has(i.id));const first=state.items.find(isFlowElement);if(first)reflowAt(first.id,null);changed();render();document.getElementById('save').click();}canvas.querySelectorAll('.item').forEach(el=>{const timer=state.items.find(i=>i.id===el.dataset.id)?.sectionConfig?.timer;el.style.opacity=timer?.enabled&&timer.startsAt&&Date.parse(timer.startsAt)>now?'0.45':'';});}
    setInterval(checkSections,1000);caption.textContent='VISUAL EDITOR · SECTION CAMPAIGN';checkSections();
    
    
    </script><script>
    // Clean section panel. Integration supplies a real, authenticated data provider.
    // window.elanSectionDataProvider.getOptions() -> {brands,stores,categories,occasions,notes,sizes}
    // Each option: {id,name}; sizes: {size_ml,name}.
    // getPerfumes(filters) -> [{product_id,product_size_id,name,size_label}]
    // Provider must apply public_products/cheapest_offers and all supplied schema restrictions.
    const cleanSectionStyle=document.createElement('style');cleanSectionStyle.textContent='.sectionPanelClean{width:760px;max-width:95vw;background:#fffdf8;color:#28251e;padding:22px}.sectionPanelClean h3{margin:0 0 18px;color:#866329}.sectionPanelClean .sectionGrid{display:grid;grid-template-columns:1fr 1fr;gap:12px}.sectionPanelClean .filterGrid{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:10px}.sectionPanelClean label{margin:0;display:flex;flex-direction:column;gap:6px;font-size:13px}.sectionPanelClean input,.sectionPanelClean select{width:100%;min-width:0;background:white;min-height:38px}.sectionPanelClean fieldset{margin:15px 0;padding:14px;border:1px solid #e0d0af;border-radius:12px}.sectionPanelClean legend{font-weight:bold;color:#8c6830;padding:0 7px}.sectionPanelClean .perfumeRow{display:grid;grid-template-columns:1fr auto;gap:10px;align-items:end;margin:12px 0}.sectionPanelClean .selectionList{display:grid;gap:7px;margin-top:12px}.sectionPanelClean .chosenPerfume{display:flex;align-items:center;gap:10px;border:1px solid #e4d7be;background:white;border-radius:8px;padding:9px;font-size:13px}.sectionPanelClean .chosenPerfume span{flex:1}.sectionPanelClean .notice{font-size:12px;color:#716344;line-height:1.7;padding:9px 0;background:none}.sectionPanelClean .actions{display:flex;gap:10px;margin-top:16px}.sectionPanelClean .actions button{flex:1}.sectionPanelClean .primary{background:#28241e;color:#efdeb8}.sectionPanelClean .toggle{display:flex;flex-direction:row;align-items:center;gap:8px}.sectionPanelClean .toggle input{width:auto;min-height:0}@media(max-width:560px){.sectionPanelClean .filterGrid{grid-template-columns:1fr 1fr}.sectionPanelClean{padding:14px}.sectionPanelClean .sectionGrid{grid-template-columns:1fr}}';document.head.append(cleanSectionStyle);
    editSection=function(item){const old=item?.sectionConfig||{};sectionPanel.replaceChildren();sectionPanel.className='sectionPanelClean';sectionPanel.style.width='760px';const heading=document.createElement('h3');heading.textContent=item?'إعدادات السيكشن':'إنشاء سيكشن';sectionPanel.append(heading);function inputField(parent,label,type,value){const l=document.createElement('label');l.textContent=label;const i=document.createElement('input');i.type=type;i.value=value??'';l.append(i);parent.append(l);return i;}function selectField(parent,label,options,value){const l=document.createElement('label');l.textContent=label;const s=document.createElement('select');options.forEach(([v,t])=>{const o=document.createElement('option');o.value=v;o.textContent=t;s.append(o);});s.value=value??'';l.append(s);parent.append(l);return s;}function fieldset(title){const f=document.createElement('fieldset');const l=document.createElement('legend');l.textContent=title;f.append(l);sectionPanel.append(f);return f;}
    const basics=document.createElement('div');basics.className='sectionGrid';sectionPanel.append(basics);const name=inputField(basics,'اسم السيكشن','text',old.name||item?.text||''),purpose=inputField(basics,'الغرض من السيكشن','text',old.purpose||'');const content=fieldset('اختيار العطور');const mode=selectField(content,'طريقة الاختيار',[['manual','اختيار عطور محددة'],['automatic','تلقائي حسب الفلاتر']],old.selectionMode||'manual');const grid=document.createElement('div');grid.className='filterGrid';content.append(grid);const controls={};const optionSpec=[['brand_id','البراند','brands'],['store_id','المتجر','stores'],['category_id','الفئة','categories'],['occasion_id','المناسبة','occasions'],['note_id','النوتة العطرية','notes'],['size_ml','الحجم','sizes']];optionSpec.forEach(([key,label])=>{const s=selectField(grid,label,[['','الكل']], '');s.disabled=true;controls[key]=s;});const min=inputField(grid,'السعر من','number',old.filters?.price_min),max=inputField(grid,'السعر إلى','number',old.filters?.price_max);min.min=max.min='0';const message=document.createElement('div');message.className='notice';content.append(message);const row=document.createElement('div');row.className='perfumeRow';content.append(row);const perfume=selectField(row,'العطر والحجم',[['','اختر العطر من نتائج الفلترة']], '');perfume.disabled=true;const addButton=document.createElement('button');addButton.textContent='إضافة';addButton.disabled=true;row.append(addButton);const selectedBox=document.createElement('div');selectedBox.className='selectionList';content.append(selectedBox);let picks=clone(old.manualProducts||[]),results=[],requestSerial=0;
    function paintPicks(){selectedBox.replaceChildren();picks.forEach((p,n)=>{const box=document.createElement('div');box.className='chosenPerfume';const span=document.createElement('span');span.textContent=p.name+(p.sizeLabel?' — '+p.sizeLabel:'');const b=document.createElement('button');b.textContent='إزالة';b.onclick=()=>{picks.splice(n,1);paintPicks();};box.append(span,b);selectedBox.append(box);});}paintPicks();
    function filters(){const result={};Object.entries(controls).forEach(([key,s])=>{if(s.value)result[key]=key==='size_ml'?Number(s.value):s.value;});if(min.value!=='')result.price_min=Number(min.value);if(max.value!=='')result.price_max=Number(max.value);return result;}
    async function refreshPerfumes(){const seq=++requestSerial;results=[];perfume.replaceChildren();const p=document.createElement('option');p.value='';p.textContent='جارٍ قراءة نتائج الفلترة…';perfume.append(p);perfume.disabled=true;addButton.disabled=true;const provider=window.elanSectionDataProvider;if(!provider?.getPerfumes){p.textContent='العطور متاحة بعد ربط سابابيس';message.textContent='القوائم مجهزة للاختيار بالأسماء. اتصال سابابيس غير منفّذ في هذا الملف، لذلك لا نعرض أسماء أو عطورًا وهمية.';return;}try{const f=filters();if((f.price_min!==undefined&&!Number.isFinite(f.price_min))||(f.price_max!==undefined&&!Number.isFinite(f.price_max))||(f.price_min!==undefined&&f.price_max!==undefined&&f.price_min>f.price_max))throw Error('راجع حدود السعر');const data=await provider.getPerfumes(f);if(seq!==requestSerial)return;if(!Array.isArray(data)||data.some(p=>!p.product_id||!p.product_size_id||!p.name))throw Error('بيانات نتائج غير متوافقة');results=data;perfume.replaceChildren();const empty=document.createElement('option');empty.value='';empty.textContent=results.length?'اختر العطر والحجم':'لا توجد عطور متاحة تطابق الفلاتر';perfume.append(empty);results.forEach((p,n)=>{const o=document.createElement('option');o.value=String(n);o.textContent=p.name+(p.size_label?' — '+p.size_label:'');perfume.append(o);});perfume.disabled=!results.length;message.textContent='عدد النتائج المتاحة: '+results.length;}catch(err){if(seq!==requestSerial)return;perfume.replaceChildren();const o=document.createElement('option');o.value='';o.textContent='تعذر تحميل العطور';perfume.append(o);message.textContent='تعذر قراءة النتائج؛ لم تُضف بيانات بديلة.';}}
    async function loadOptions(){const provider=window.elanSectionDataProvider;if(!provider?.getOptions){refreshPerfumes();return;}message.textContent='جارٍ تحميل قوائم سابابيس…';try{const data=await provider.getOptions();for(const [key,label,list]of optionSpec){if(!Array.isArray(data[list]))throw Error('قائمة ناقصة');const s=controls[key];s.replaceChildren();const all=document.createElement('option');all.value='';all.textContent='كل '+label;s.append(all);data[list].forEach(record=>{const id=key==='size_ml'?record.size_ml:record.id;if(id===undefined||id===null||!record.name)return;const o=document.createElement('option');o.value=String(id);o.textContent=record.name;s.append(o);});if(old.filters?.[key]!==undefined)s.value=String(old.filters[key]);s.disabled=false;s.onchange=refreshPerfumes;}refreshPerfumes();}catch(e){message.textContent='تعذر تحميل قوائم سابابيس. لن يتم تعويضها بقيم وهمية.';}}
    min.onchange=max.onchange=refreshPerfumes;perfume.onchange=()=>addButton.disabled=mode.value!=='manual'||perfume.value==='';addButton.onclick=()=>{const p=results[Number(perfume.value)];if(perfume.value===''||!p)return;if(!picks.some(i=>i.productSizeId===p.product_size_id)){picks.push({productId:p.product_id,productSizeId:p.product_size_id,name:p.name,sizeLabel:p.size_label||null});paintPicks();}};mode.onchange=()=>{row.hidden=mode.value==='automatic';selectedBox.hidden=mode.value==='automatic';addButton.disabled=mode.value!=='manual'||perfume.value==='';};mode.onchange();
    const timerBox=fieldset('توقيت السيكشن');const toggle=document.createElement('label');toggle.className='toggle';const enabled=document.createElement('input');enabled.type='checkbox';enabled.checked=!!old.timer?.enabled;toggle.append(enabled,'تشغيل التوقيت');timerBox.append(toggle);const timing=selectField(timerBox,'طريقة التوقيت',[['dates','بداية ونهاية محددتان'],['duration','مدة من أول حفظ للسيكشن']],old.timer?.mode||'dates');const dateGrid=document.createElement('div');dateGrid.className='sectionGrid';timerBox.append(dateGrid);const start=inputField(dateGrid,'البداية، توقيت مصر','datetime-local',localCairo(old.timer?.startsAt)),end=inputField(dateGrid,'النهاية، توقيت مصر','datetime-local',localCairo(old.timer?.endsAt));const durationGrid=document.createElement('div');durationGrid.className='sectionGrid';timerBox.append(durationGrid);const count=inputField(durationGrid,'المدة','number',old.timer?.durationValue||1);count.min='1';const unit=selectField(durationGrid,'الوحدة',[['hours','ساعات'],['days','أيام']],old.timer?.durationUnit||'hours');function timingUI(){timing.closest('label').hidden=!enabled.checked;dateGrid.hidden=!enabled.checked||timing.value!=='dates';durationGrid.hidden=!enabled.checked||timing.value!=='duration';}enabled.onchange=timingUI;timing.onchange=timingUI;timingUI();
    const actions=document.createElement('div');actions.className='actions';const save=document.createElement('button');save.className='primary';save.textContent='حفظ السيكشن';const close=document.createElement('button');close.textContent='إلغاء';close.onclick=()=>sectionPanel.close();actions.append(save,close);sectionPanel.append(actions);
    save.onclick=()=>{try{if(!name.value.trim()||!purpose.value.trim())throw Error('اكتب الاسم والغرض.');const providerReady=!!window.elanSectionDataProvider?.getOptions;const f=providerReady?filters():clone(old.filters||{});if((f.price_min!==undefined&&f.price_min<0)||(f.price_max!==undefined&&f.price_max<0)||(f.price_min!==undefined&&f.price_max!==undefined&&f.price_min>f.price_max))throw Error('راجع حدود السعر.');const createdAt=old.createdAt||new Date().toISOString();const timer={enabled:enabled.checked,mode:timing.value,timeZone:'Africa/Cairo',durationValue:Number(count.value),durationUnit:unit.value,startsAt:null,endsAt:null};if(timer.enabled){if(timer.mode==='dates'){timer.startsAt=cairoUTC(start.value);timer.endsAt=cairoUTC(end.value);if(!timer.startsAt||!timer.endsAt||Date.parse(timer.endsAt)<=Date.parse(timer.startsAt))throw Error('حدد مواعيد صحيحة.');}else{if(!Number.isFinite(timer.durationValue)||timer.durationValue<=0)throw Error('حدد مدة أكبر من صفر');timer.startsAt=createdAt;timer.endsAt=new Date(Date.parse(createdAt)+timer.durationValue*(unit.value==='days'?86400000:3600000)).toISOString();}}checkpoint();let target=item;if(!target){windowSectionAdd();target=current();}target.text=name.value.trim();target.sectionConfig={name:name.value.trim(),purpose:purpose.value.trim(),selectionMode:mode.value,filters:f,manualProducts:picks,createdAt,timer,dataSource:{products:'public_products',offers:'cheapest_offers',connection:providerReady?'provider_configured':'not_connected'}};attachDefinition(target);target.binding.name=target.sectionConfig.name;target.binding.purpose=target.sectionConfig.purpose;selected=target.id;reflowAt(target.id,{...contextPoint});changed();document.getElementById('save').click();sectionPanel.close();checkSections();}catch(e){alert(e.message);}};sectionPanel.showModal();loadOptions();};
    
    cleanSectionStyle.textContent += ".sectionPanelClean [hidden]{display:none!important}";
    
    </script><script>
    // Manual sidebar mirrors the real provider results; automatic mode retains all matching results.
    const selectionRepairStyle=document.createElement('style');selectionRepairStyle.textContent='.sectionPanelClean{width:1000px!important}.sectionPanelClean .manualLayout{display:grid;grid-template-columns:minmax(0,1fr) 270px;gap:14px}.sectionPanelClean .manualResults{border:1px solid #d7c29c;border-radius:12px;padding:12px;background:#fffaf0;max-height:420px;overflow:auto}.sectionPanelClean .manualResults h4{margin-top:0}.sectionPanelClean .manualResults label{display:flex;flex-direction:row;align-items:center;gap:8px;padding:9px 0;border-bottom:1px solid #e7ddc8}.sectionPanelClean .manualResults input{width:auto;min-height:0}.sectionPanelClean .modeHelp{font-size:12px;line-height:1.8;color:#756443;margin:8px 0}@media(max-width:700px){.sectionPanelClean .manualLayout{grid-template-columns:1fr}}';document.head.append(selectionRepairStyle);
    const sectionBeforeSelectionFix=editSection;
    editSection=function(item){sectionBeforeSelectionFix(item);const panel=sectionPanel;const content=Array.from(panel.querySelectorAll('fieldset')).find(f=>f.querySelector('legend')?.textContent==='اختيار العطور');if(!content)return;const mode=content.querySelector('select');const row=content.querySelector('.perfumeRow');const select=row.querySelector('select');const add=row.querySelector('button');const chosen=content.querySelector('.selectionList');const notice=content.querySelector('.notice');const grid=content.querySelector('.filterGrid');grid.querySelectorAll('select').forEach(s=>{s.disabled=false;s.title='قائمة الأسماء تأتي من سابابيس عند الربط';});
    const layout=document.createElement('div');layout.className='manualLayout';const main=document.createElement('div');const sidebar=document.createElement('div');sidebar.className='manualResults';content.append(layout);layout.append(main,sidebar);main.append(grid,notice,chosen);row.hidden=true;row.style.display='none';main.append(row);const explanation=document.createElement('div');explanation.className='modeHelp';content.insertBefore(explanation,layout);
    let marked=new Set();function drawSidebar(){sidebar.replaceChildren();const h=document.createElement('h4');h.textContent='العطور الناتجة عن الفلترة';sidebar.append(h);const options=Array.from(select.options).filter(o=>o.value!=='');if(!options.length){const p=document.createElement('p');p.textContent=window.elanSectionDataProvider?'لا توجد نتائج جاهزة، أو جارٍ تحميلها.':'قائمة النتائج تحتاج اتصال سابابيس؛ لا توجد بيانات فعلية في الملف.';sidebar.append(p);return;}options.forEach(o=>{const label=document.createElement('label');const box=document.createElement('input');box.type='checkbox';box.checked=marked.has(o.value);box.onchange=()=>box.checked?marked.add(o.value):marked.delete(o.value);label.append(box,o.textContent);sidebar.append(label);});const addSelected=document.createElement('button');addSelected.textContent='إضافة العطور المحددة';addSelected.onclick=()=>{for(const value of marked){select.value=value;select.dispatchEvent(new Event('change'));if(!add.disabled)add.click();}marked.clear();drawSidebar();};sidebar.append(addSelected);}
    const modeHandler=mode.onchange;mode.onchange=()=>{modeHandler();row.hidden=true;row.style.display='none';sidebar.hidden=mode.value!=='manual';layout.style.gridTemplateColumns=mode.value==='manual'?'minmax(0,1fr) 270px':'1fr';explanation.textContent=mode.value==='manual'?'اختر الفلاتر، ثم حدّد عطورًا من القائمة الجانبية واضغط إضافة.':'كل العطور المطابقة للفلاتر تدخل في السيكشن تلقائيًا بعد الربط، بدون تحديد عطر فردي أو حد مختارات.';drawSidebar();};mode.onchange();const observer=new MutationObserver(()=>{marked.clear();drawSidebar();});observer.observe(select,{childList:true});panel.addEventListener('close',()=>observer.disconnect(),{once:true});
    const save=panel.querySelector('.actions .primary');const oldSave=save.onclick;save.onclick=()=>{oldSave();if(panel.open)return;const target=current();if(target?.sectionConfig){target.sectionConfig.includeAllMatching=mode.value==='automatic';target.sectionConfig.selectionStrategy=mode.value==='automatic'?'all_filtered_products':'explicit_product_size_ids';target.sectionConfig.resultSource={products:'public_products',offers:'cheapest_offers',filters:clone(target.sectionConfig.filters),manualSelectionUses:'manualProducts.productSizeId'};document.getElementById('save').click();}};
    };caption.textContent='VISUAL EDITOR · SECTION SELECTION';
    
    
    </script><script>
    // Always-visible explicit add actions for both selection modes.
    const sectionBeforeAddActions=editSection;
    editSection=function(item){sectionBeforeAddActions(item);const panel=sectionPanel;const content=Array.from(panel.querySelectorAll('fieldset')).find(f=>f.querySelector('legend')?.textContent==='اختيار العطور');if(!content)return;const mode=content.querySelector('select');const sidebar=content.querySelector('.manualResults');const bar=document.createElement('div');bar.style.cssText='display:flex;align-items:center;gap:10px;margin-top:12px;flex-wrap:wrap';const manualButton=document.createElement('button');manualButton.textContent='إضافة العطور المحددة';manualButton.className='primary';const automaticButton=document.createElement('button');automaticButton.textContent='إضافة العناصر';automaticButton.className='primary';const feedback=document.createElement('span');feedback.style.cssText='font-size:12px;color:#79643f';bar.append(manualButton,automaticButton,feedback);content.append(bar);let automaticMatches=null;
    function updateAddActions(){manualButton.hidden=mode.value!=='manual';automaticButton.hidden=mode.value!=='automatic';if(mode.value==='manual')feedback.textContent='حدّد العطور في القائمة الجانبية، ثم اضغط إضافة.';else feedback.textContent='إضافة كل نتائج الفلاتر الحالية، بدون اختيار عطر فردي.';}
    const modeBeforeButtons=mode.onchange;mode.onchange=()=>{modeBeforeButtons();automaticMatches=null;updateAddActions();};updateAddActions();
    manualButton.onclick=()=>{const checks=sidebar?Array.from(sidebar.querySelectorAll('input[type=checkbox]:checked')):[];if(!checks.length){feedback.textContent='اختر عطرًا أو أكثر من نتائج الفلترة أولًا.';return;}const button=Array.from(sidebar.querySelectorAll('button')).find(b=>b.textContent==='إضافة العطور المحددة');if(button){button.click();feedback.textContent='أضيفت العطور إلى اختيارات السيكشن. اضغط حفظ السيكشن لاعتمادها.';}else feedback.textContent='تعذر إضافة الاختيارات، أعد تحميل النتائج.';};
    // Sidebar's own button can remain; main action is always present.
    automaticButton.onclick=async()=>{const provider=window.elanSectionDataProvider;if(!provider?.getPerfumes){feedback.textContent='إضافة العناصر الفعلية تتطلب ربط سابابيس. لم تتم إضافة عطور وهمية.';return;}const grid=content.querySelector('.filterGrid');const selects=Array.from(grid.querySelectorAll('select'));const keys=['brand_id','store_id','category_id','occasion_id','note_id','size_ml'];const filters={};selects.forEach((s,n)=>{if(s.value)filters[keys[n]]=keys[n]==='size_ml'?Number(s.value):s.value;});const numbers=Array.from(grid.querySelectorAll('input[type=number]'));if(numbers[0]?.value!=='')filters.price_min=Number(numbers[0].value);if(numbers[1]?.value!=='')filters.price_max=Number(numbers[1].value);automaticButton.disabled=true;feedback.textContent='جارٍ إضافة نتائج الفلترة…';try{const rows=await provider.getPerfumes(filters);if(!Array.isArray(rows)||rows.some(p=>!p.product_id||!p.product_size_id||!p.name))throw Error();automaticMatches=rows.map(p=>({productId:p.product_id,productSizeId:p.product_size_id,name:p.name,sizeLabel:p.size_label||null}));feedback.textContent='أضيفت '+automaticMatches.length+' نتيجة إلى إعداد السيكشن. اضغط حفظ السيكشن لاعتمادها.';}catch(e){feedback.textContent='تعذر تحميل العناصر؛ لم تُعتمد نتائج بديلة.';}finally{automaticButton.disabled=false;}};
    content.querySelector('.filterGrid').addEventListener('change',()=>{automaticMatches=null;});const save=panel.querySelector('.actions .primary');const saveBeforeMatches=save.onclick;save.onclick=()=>{saveBeforeMatches();if(panel.open)return;const target=current();if(target?.sectionConfig&&mode.value==='automatic'){target.sectionConfig.automaticSelectionPreview=automaticMatches||[];target.sectionConfig.includeAllMatching=true;target.sectionConfig.automaticRefreshFromFilters=true;document.getElementById('save').click();}};
    };caption.textContent='VISUAL EDITOR · SECTION ADD ACTIONS';
    
    
    </script><script>
    // Per-perfume manual addition; one add-all action for automatic selection.
    const sectionBeforeRowActions=editSection;
    editSection=function(item){sectionBeforeRowActions(item);const content=Array.from(sectionPanel.querySelectorAll('fieldset')).find(f=>f.querySelector('legend')?.textContent==='اختيار العطور');if(!content)return;const mode=content.querySelector('select'),sidebar=content.querySelector('.manualResults'),chosen=content.querySelector('.selectionList');if(!sidebar)return;
    const primaryManual=Array.from(content.querySelectorAll('button')).find(b=>b.textContent==='إضافة العطور المحددة'&&b.parentElement!==sidebar);if(primaryManual){primaryManual.style.display='none';const feedback=primaryManual.parentElement.querySelector('span');if(feedback)feedback.style.display='none';}
    function selectedNames(){return new Set(Array.from(chosen.querySelectorAll('.chosenPerfume span')).map(s=>s.textContent.trim()));}
    function updateRows(){const saved=selectedNames();Array.from(sidebar.querySelectorAll('label')).forEach(label=>{const checkbox=label.querySelector('input[type=checkbox]');if(!checkbox)return;if(!label.dataset.perPerfume){const name=Array.from(label.childNodes).filter(n=>n.nodeType===Node.TEXT_NODE).map(n=>n.textContent).join('').trim();label.dataset.perPerfume='true';label.dataset.perfumeName=name;checkbox.style.display='none';label.style.display='flex';const title=document.createElement('span');title.textContent=name;title.style.flex='1';Array.from(label.childNodes).filter(n=>n.nodeType===Node.TEXT_NODE).forEach(n=>n.remove());label.append(title);const b=document.createElement('button');b.type='button';b.dataset.singleAdd='true';b.style.cssText='white-space:nowrap;padding:7px 10px';b.onclick=e=>{e.preventDefault();e.stopPropagation();if(b.disabled)return;sidebar.querySelectorAll('input[type=checkbox]').forEach(c=>{c.checked=c===checkbox;c.onchange?.();});const bulk=Array.from(sidebar.children).find(n=>n.tagName==='BUTTON'&&n.textContent==='إضافة العطور المحددة');if(bulk){bulk.click();updateRows();}};label.append(b);}const button=label.querySelector('button[data-single-add]');const isAdded=saved.has(label.dataset.perfumeName);if(button.disabled!==isAdded)button.disabled=isAdded;const text=isAdded?'✓ تمت الإضافة':'إضافة';if(button.textContent!==text)button.textContent=text;button.style.background=isAdded?'#e3efe2':'#fffaf0';});Array.from(sidebar.children).filter(n=>n.tagName==='BUTTON'&&n.textContent==='إضافة العطور المحددة').forEach(b=>b.style.display='none');}
    const previousMode=mode.onchange;mode.onchange=()=>{previousMode();if(primaryManual)primaryManual.style.display='none';updateRows();};
    const observer=new MutationObserver(updateRows);observer.observe(sidebar,{childList:true,subtree:true});observer.observe(chosen,{childList:true,subtree:true});sectionPanel.addEventListener('close',()=>observer.disconnect(),{once:true});updateRows();};caption.textContent='VISUAL EDITOR · INDIVIDUAL PERFUME ADD';
    
    
    </script><script>
    // Approved brand creation panel: one name input, Create and Cancel.
    const brandPanel=document.createElement('dialog');brandPanel.style.cssText='width:380px;max-width:92vw;padding:22px;background:#fffdf8;border:1px solid #c6aa70;border-radius:14px';document.body.append(brandPanel);
    function openBrandPanel(){brandPanel.replaceChildren();const title=document.createElement('h3');title.textContent='إنشاء كارت براند';title.style.cssText='margin:0 0 18px;color:#87652d';const label=document.createElement('label');label.textContent='اسم البراند';const name=document.createElement('input');name.type='text';name.autocomplete='off';name.style.cssText='display:block;width:100%;margin-top:8px;padding:10px;background:white';label.append(name);const actions=document.createElement('div');actions.style.cssText='display:flex;gap:10px;margin-top:18px';const create=document.createElement('button');create.textContent='إنشاء';create.style.cssText='flex:1;background:#29251e;color:#f0dfb9';const cancel=document.createElement('button');cancel.textContent='إلغاء';cancel.style.flex='1';cancel.onclick=()=>brandPanel.close();create.onclick=()=>{const value=name.value.trim();if(!value){name.focus();name.setCustomValidity('اكتب اسم البراند');name.reportValidity();return;}name.setCustomValidity('');addKind('brand');const item=current();if(!item)return;item.text=value;attachDefinition(item);item.binding.name=value;item.binding.entityId=null;item.binding.status='pending_connection';item.brandCreationRequest={version:1,name:value,status:'pending_connection',table:'brands',reuseExistingIfMatched:true,createIfNew:true,matchSource:'connected_store_catalogues',populateOfficialDataOnlyWhenVerified:true,includeOnlyMatchingBrandProducts:true,productVisibility:'public_products',offerSource:'cheapest_offers',noFabricatedProducts:true,unverifiedMatchRequiresReview:true};changed();render();document.getElementById('save').click();brandPanel.close();};name.oninput=()=>name.setCustomValidity('');name.onkeydown=e=>{if(e.key==='Enter'){e.preventDefault();create.click();}};actions.append(create,cancel);brandPanel.append(title,label,actions);brandPanel.showModal();name.focus();}
    const menuBeforeBrandPanel=showMenu;showMenu=function(e){menuBeforeBrandPanel(e);const button=Array.from(menu.children).find(b=>b.textContent==='إنشاء كارت براند');if(button)button.onclick=()=>{menu.style.display='none';openBrandPanel();};};caption.textContent='VISUAL EDITOR · BRAND PANEL';
    
    
    </script><script>
    // Vertical text position, independent from horizontal alignment.
    const positionLabel=document.createElement('label');positionLabel.textContent='الوضعية';const positionSelect=document.createElement('select');[['top','أعلى'],['middle','وسط'],['bottom','أسفل']].forEach(([value,label])=>{const o=document.createElement('option');o.value=value;o.textContent=label;positionSelect.append(o);});positionLabel.append(positionSelect);textGroup.grid.append(positionLabel);
    const textPositionStyle=document.createElement('style');textPositionStyle.textContent='#format .textRow{grid-template-columns:minmax(0,1.5fr) repeat(3,minmax(0,1fr))}';document.head.append(textPositionStyle);
    const openBeforeTextPosition=openFormat;openFormat=function(){openBeforeTextPosition();const item=state.items.find(i=>i.id===formatTargetId);positionSelect.value=item?.textPosition||'top';};
    const applyBeforeTextPosition=document.getElementById('apply').onclick;document.getElementById('apply').onclick=()=>{const item=state.items.find(i=>i.id===formatTargetId);const value=positionSelect.value;applyBeforeTextPosition();if(item){item.textPosition=value;changed();render();}};
    const renderBeforeTextPosition=render;render=function(){renderBeforeTextPosition();state.items.forEach(item=>{if(!['text','card','section'].includes(item.type))return;const el=Array.from(canvas.children).find(el=>el.dataset.id===item.id);const content=el?.querySelector('.content');if(!content)return;content.style.display='flex';content.style.flexDirection='column';content.style.justifyContent=item.textPosition==='middle'?'center':item.textPosition==='bottom'?'flex-end':'flex-start';});};
    positionSelect.addEventListener('change',()=>{sample.style.display='flex';sample.style.flexDirection='column';sample.style.minHeight='100px';sample.style.justifyContent=positionSelect.value==='middle'?'center':positionSelect.value==='bottom'?'flex-end':'flex-start';});caption.textContent='VISUAL EDITOR · TEXT POSITION';render();
    
    
    </script><script>
    // Reuse the approved section panel without section name/purpose.
    function openPerfumePanel(){const point={...contextPoint};const origin=selected;const anchor=state.items.find(i=>i.id===origin);const stage={id:uid(),type:'section',text:'',binding:{},sectionConfig:{name:'اختيار عطور',purpose:'إضافة كروت عطور',selectionMode:'manual',manualProducts:[],filters:{},timer:{enabled:false,mode:'dates'}}};editSection(stage);sectionPanel.querySelector('h3').textContent='إنشاء كارت عطر';const basics=sectionPanel.querySelector('.sectionGrid');if(basics){basics.style.display='none';basics.querySelectorAll('input').forEach((input,n)=>input.value=n===0?'اختيار عطور':'إضافة كروت عطور');}const commit=sectionPanel.querySelector('.actions .primary');commit.textContent='حفظ كروت العطور';const panelSave=commit.onclick;commit.onclick=async()=>{const originalSelected=selected;selected=null;panelSave();if(sectionPanel.open){selected=originalSelected;return;}const cfg=stage.sectionConfig;const provider=window.elanSectionDataProvider;let choices=cfg.manualProducts||[];if(cfg.selectionMode==='automatic'){if(!provider?.getPerfumes){alert('لا توجد بيانات عطور متصلة. إضافة كل النتائج تحتاج ربط سابابيس، ولن ننشئ كروتًا وهمية.');selected=originalSelected;sectionPanel.showModal();return;}try{const rows=await provider.getPerfumes(cfg.filters);if(!Array.isArray(rows)||rows.some(p=>!p.product_id||!p.product_size_id||!p.name))throw Error();choices=rows.map(p=>({productId:p.product_id,productSizeId:p.product_size_id,name:p.name,sizeLabel:p.size_label||null}));}catch(e){alert('تعذر تحميل نتائج الفلترة؛ لم تُنشأ كروت بديلة.');selected=originalSelected;sectionPanel.showModal();return;}}if(!choices.length){alert('أضف عطرًا من القائمة أولًا، أو اختر فلاتر لها نتائج في الوضع التلقائي.');selected=originalSelected;sectionPanel.showModal();return;}checkpoint();const ids=new Set();const added=[];choices.forEach((p,n)=>{if(ids.has(p.productSizeId))return;ids.add(p.productSizeId);const id=uid();const i={id,type:'card',kind:'perfume',text:p.name+(p.sizeLabel?'\n'+p.sizeLabel:''),x:Math.max(0,Math.min(800,point.x)),y:Math.max(0,point.y)+n*264,w:300,h:240,font:'Tahoma',size:22,color:'#222222',bg:'#fffdf9',align:'right',binding:{name:p.name,entityId:p.productId,productSizeId:p.productSizeId,status:'catalogue_selected'},parentSectionId:anchor?.type==='section'?anchor.id:null,sectionConfig:clone(cfg)};i.sectionConfig.manualProducts=[clone(p)];i.sectionConfig.selectionStrategy=cfg.selectionMode==='automatic'?'all_filtered_products':'explicit_product_size_ids';i.sectionConfig.includeAllMatching=cfg.selectionMode==='automatic';attachDefinition(i);state.items.push(i);added.push(i);});if(anchor?.type==='section'){if(!anchor.sectionConfig)anchor.sectionConfig={manualProducts:[]};if(!Array.isArray(anchor.sectionConfig.manualProducts))anchor.sectionConfig.manualProducts=[];choices.forEach(p=>{if(!anchor.sectionConfig.manualProducts.some(x=>x.productSizeId===p.productSizeId))anchor.sectionConfig.manualProducts.push(clone(p));});}if(added.length){selected=added[0].id;reflowAt(selected,point);}else selected=originalSelected;changed();render();document.getElementById('save').click();checkSections();};}
    const menuBeforePerfumePanel=showMenu;showMenu=function(e){menuBeforePerfumePanel(e);const button=Array.from(menu.children).find(b=>b.textContent==='إنشاء كارت عطر');if(button)button.onclick=()=>{menu.style.display='none';openPerfumePanel();};};caption.textContent='VISUAL EDITOR · PERFUME PANEL';
    
    
    </script><script>
    // Compact styling for section/perfume panels only.
    const compactCampaignStyle=document.createElement('style');compactCampaignStyle.textContent='.sectionPanelClean{width:min(960px,96vw)!important;max-height:96dvh!important;padding:12px 16px!important}.sectionPanelClean h3{font-size:17px;margin:0 0 8px!important}.sectionPanelClean label{font-size:11px;gap:3px}.sectionPanelClean input,.sectionPanelClean select{font-size:11px;min-height:29px!important;padding:5px 7px}.sectionPanelClean button{font-size:11px;padding:6px 9px}.sectionPanelClean fieldset{margin:7px 0;padding:8px 10px}.sectionPanelClean legend{font-size:12px}.sectionPanelClean .sectionGrid{gap:8px}.sectionPanelClean .filterGrid{grid-template-columns:repeat(4,minmax(0,1fr));gap:6px}.sectionPanelClean .manualLayout{gap:9px}.sectionPanelClean .manualResults{padding:8px;max-height:190px!important;overflow:auto}.sectionPanelClean .manualResults h4{font-size:12px;margin:0 0 5px}.sectionPanelClean .manualResults label{padding:5px 0;font-size:11px}.sectionPanelClean .selectionList{margin-top:5px;gap:4px;max-height:76px;overflow:auto}.sectionPanelClean .chosenPerfume{font-size:11px;padding:5px 7px}.sectionPanelClean .notice,.sectionPanelClean .modeHelp{font-size:10px;line-height:1.5;margin:4px 0;padding:3px 0}.sectionPanelClean .actions{margin-top:8px;gap:8px}.sectionPanelClean .toggle{font-size:11px;margin-bottom:4px}.sectionPanelClean .perfumeRow{margin:6px 0}.sectionPanelClean fieldset:last-of-type>.sectionGrid{display:grid;grid-template-columns:1fr 1fr}.sectionPanelClean fieldset:last-of-type>label:not(.toggle){max-width:100%}@media(min-width:700px) and (min-height:700px){.sectionPanelClean{max-height:94dvh}}@media(max-width:600px){.sectionPanelClean{padding:10px!important}.sectionPanelClean .filterGrid{grid-template-columns:repeat(2,minmax(0,1fr))}.sectionPanelClean .manualResults{max-height:140px!important}}';document.head.append(compactCampaignStyle);caption.textContent='VISUAL EDITOR · COMPACT PANELS';
    
    
    </script><script>
    // Replace the overcompressed panel styling; behavior stays unchanged.
    compactCampaignStyle.remove();
    const balancedPanelStyle=document.createElement('style');balancedPanelStyle.textContent=`
    .sectionPanelClean{width:min(790px,94vw)!important;max-height:92dvh!important;padding:20px!important;background:#fffdf9;color:#302b23;border:1px solid #c8ae79;border-radius:18px;box-shadow:0 24px 80px #0003;overflow:auto}
    .sectionPanelClean::backdrop{background:rgba(21,19,15,.45)}
    .sectionPanelClean h3{font-size:19px;font-weight:700;line-height:1.4;color:#86642e;margin:0 0 15px!important;padding-bottom:12px;border-bottom:1px solid #e9dec8}
    .sectionPanelClean label{font-size:12px;line-height:1.5;font-weight:500;gap:5px;min-width:0}
    .sectionPanelClean input,.sectionPanelClean select{width:100%;min-width:0;font:12px Tahoma,Arial;min-height:35px!important;height:35px;padding:7px 9px;border:1px solid #dccfb6;border-radius:7px;background:#fff;box-shadow:none;color:#302b23}
    .sectionPanelClean input:focus,.sectionPanelClean select:focus{outline:2px solid #cfb57966;outline-offset:1px;border-color:#ae8d4e}
    .sectionPanelClean input:disabled,.sectionPanelClean select:disabled{background:#f1eee7;color:#938977}
    .sectionPanelClean button{font:12px Tahoma,Arial;padding:8px 12px;border-radius:8px;min-height:34px}
    .sectionPanelClean fieldset{margin:12px 0;padding:12px;border:1px solid #e2d6bd;border-radius:12px;background:#faf7f0;min-width:0}
    .sectionPanelClean legend{font-size:13px;font-weight:700;color:#86642e;padding:0 7px}
    .sectionPanelClean .sectionGrid{display:grid;grid-template-columns:1fr 1fr;gap:10px}
    .sectionPanelClean .filterGrid{grid-template-columns:repeat(3,minmax(0,1fr))!important;gap:9px}
    .sectionPanelClean .manualLayout{grid-template-columns:minmax(0,1fr) 225px;gap:12px;align-items:start}
    .sectionPanelClean .manualResults{padding:10px;max-height:255px!important;min-height:110px;border:1px solid #ddcba7;background:#fffdf8;border-radius:10px;overflow:auto}
    .sectionPanelClean .manualResults h4{font-size:13px;color:#76582a;margin:0 0 9px;padding-bottom:7px;border-bottom:1px solid #ece2cf}
    .sectionPanelClean .manualResults label{font-size:12px;padding:7px 0;gap:6px}
    .sectionPanelClean .manualResults p{font-size:12px;line-height:1.8;color:#827459;margin:6px 0}
    .sectionPanelClean .manualResults input[type=checkbox],.sectionPanelClean .toggle input{width:16px;height:16px;min-height:16px!important;padding:0;flex-shrink:0}
    .sectionPanelClean .selectionList{gap:6px;margin-top:9px;max-height:110px;overflow:auto}
    .sectionPanelClean .chosenPerfume{font-size:12px;padding:7px 9px;background:#fff;border-color:#e2d7c3}
    .sectionPanelClean .notice,.sectionPanelClean .modeHelp{font-size:11px;line-height:1.7;color:#827358;padding:5px 0;margin:5px 0}
    .sectionPanelClean .toggle{font-size:12px;margin-bottom:9px;gap:8px}
    .sectionPanelClean .actions{margin-top:14px;padding-top:12px;border-top:1px solid #e9dec8;gap:10px}
    .sectionPanelClean .actions button{min-height:39px;font-size:13px}
    .sectionPanelClean .primary{background:#30291f;color:#f1dfb7;border-color:#30291f}
    .sectionPanelClean [hidden]{display:none!important}
    @media(max-width:650px){.sectionPanelClean{width:94vw!important;padding:14px!important}.sectionPanelClean .manualLayout{grid-template-columns:1fr!important}.sectionPanelClean .filterGrid{grid-template-columns:repeat(2,minmax(0,1fr))!important}.sectionPanelClean .manualResults{max-height:190px!important}}
    `;document.head.append(balancedPanelStyle);
    // Keep the automatic-mode single column, and balanced manual-mode proportions.
    const panelBeforeBalanced=editSection;editSection=function(item){panelBeforeBalanced(item);const content=Array.from(sectionPanel.querySelectorAll('fieldset')).find(f=>f.querySelector('legend')?.textContent==='اختيار العطور');const mode=content?.querySelector('select'),layout=content?.querySelector('.manualLayout');if(mode&&layout){const old=mode.onchange;mode.onchange=()=>{old();layout.style.gridTemplateColumns=mode.value==='manual'?'minmax(0,1fr) 225px':'1fr';};layout.style.gridTemplateColumns=mode.value==='manual'?'minmax(0,1fr) 225px':'1fr';}};
    caption.textContent='VISUAL EDITOR · BALANCED PANELS';
    
    
    </script><script>
    // Remove exactly the two requested explanatory messages.
    const removedPanelTexts=new Set(['اختر الفلاتر، ثم حدّد عطورًا من القائمة الجانبية واضغط إضافة.','القوائم مجهزة للاختيار بالأسماء. اتصال سابابيس غير منفّذ في هذا الملف، لذلك لا نعرض أسماء أو عطورًا وهمية.']);
    function cleanRequestedPanelCopy(){sectionPanel.querySelectorAll('.modeHelp,.notice').forEach(el=>{if(removedPanelTexts.has(el.textContent.trim())){el.textContent='';el.hidden=true;}else if(el.textContent.trim()){el.hidden=false;}});}
    const panelBeforeCopyRemoval=editSection;editSection=function(item){panelBeforeCopyRemoval(item);cleanRequestedPanelCopy();const watch=new MutationObserver(cleanRequestedPanelCopy);watch.observe(sectionPanel,{childList:true,subtree:true,characterData:true});sectionPanel.addEventListener('close',()=>watch.disconnect(),{once:true});};
    
    
    </script><script>
    // Requested sidebar height and context-menu cleanup only.
    const tallerPerfumeSidebar=document.createElement('style');tallerPerfumeSidebar.textContent='.sectionPanelClean .manualResults{min-height:300px!important;max-height:420px!important}@media(max-width:650px){.sectionPanelClean .manualResults{min-height:220px!important;max-height:330px!important}}';document.head.append(tallerPerfumeSidebar);
    const menuBeforeTwoRemovals=showMenu;showMenu=function(e){menuBeforeTwoRemovals(e);Array.from(menu.children).forEach(button=>{if(['تعريف العنصر ومصدر بياناته','إعدادات السيكشن'].includes(button.textContent.trim()))button.remove();});const rect=menu.getBoundingClientRect();menu.style.top=Math.max(4,Math.min(e.clientY,innerHeight-rect.height-8))+'px';};
    
    
    </script><script>
    // Remove only the requested label text; retain the selection-mode control.
    const panelBeforeModeLabelRemoval=editSection;
    editSection=function(item){panelBeforeModeLabelRemoval(item);sectionPanel.querySelectorAll('label').forEach(label=>{if(!label.querySelector('select'))return;Array.from(label.childNodes).forEach(node=>{if(node.nodeType===Node.TEXT_NODE&&node.textContent.trim()==='طريقة الاختيار')node.remove();});});};
    
    
    </script><script>
    // Name-only occasion and aromatic-note panels; no fabricated product matching.
    const taxonomyPanel=document.createElement('dialog');taxonomyPanel.style.cssText='width:380px;max-width:92vw;padding:22px;background:#fffdf8;border:1px solid #c6aa70;border-radius:14px';document.body.append(taxonomyPanel);
    function openTaxonomyPanel(kind){const occasion=kind==='occasion';const table=occasion?'occasions':'aromatic_notes',relationTable=occasion?'product_occasions':'product_notes',relationId=occasion?'occasion_id':'note_id';taxonomyPanel.replaceChildren();const title=document.createElement('h3');title.textContent=occasion?'إنشاء كارت مناسبة':'إنشاء كارت نوتة عطرية';title.style.cssText='margin:0 0 18px;color:#87652d';const label=document.createElement('label');label.textContent=occasion?'اسم المناسبة':'اسم النوتة العطرية';const name=document.createElement('input');name.type='text';name.autocomplete='off';name.style.cssText='display:block;width:100%;margin-top:8px;padding:10px;background:white';label.append(name);const actions=document.createElement('div');actions.style.cssText='display:flex;gap:10px;margin-top:18px';const create=document.createElement('button');create.textContent='إنشاء';create.style.cssText='flex:1;background:#29251e;color:#f0dfb9';const cancel=document.createElement('button');cancel.textContent='إلغاء';cancel.style.flex='1';cancel.onclick=()=>taxonomyPanel.close();name.oninput=()=>name.setCustomValidity('');create.onclick=()=>{const value=name.value.trim();if(!value){name.focus();name.setCustomValidity('اكتب الاسم');name.reportValidity();return;}name.setCustomValidity('');addKind(kind);const item=current();if(!item)return;item.text=value;attachDefinition(item);item.binding.name=value;item.binding.entityId=null;item.binding.status='pending_connection';item.taxonomyCreationRequest={version:1,kind,name:value,status:'pending_connection',table,relationTable,relationId,productIdField:'product_id',reuseExistingIfMatched:true,createIfNew:true,automaticProductAssignment:true,manualProductSelectionRequired:false,matchSource:'available_verified_database_and_catalogue_data',preferExistingRelations:true,createRelationsOnlyWithVerifiedEvidence:true,noUnsupportedInference:true,emptyWhenEvidenceInsufficient:true,productVisibility:'public_products',offerSource:'cheapest_offers',noFabricatedProducts:true};changed();render();document.getElementById('save').click();taxonomyPanel.close();};name.onkeydown=e=>{if(e.key==='Enter'){e.preventDefault();create.click();}};actions.append(create,cancel);taxonomyPanel.append(title,label,actions);taxonomyPanel.showModal();name.focus();}
    const menuBeforeTaxonomyPanels=showMenu;showMenu=function(e){menuBeforeTaxonomyPanels(e);Array.from(menu.children).forEach(button=>{if(button.textContent==='إنشاء مناسبة')button.onclick=()=>{menu.style.display='none';openTaxonomyPanel('occasion');};if(button.textContent==='إنشاء نوتة عطر')button.onclick=()=>{menu.style.display='none';openTaxonomyPanel('note');};});};caption.textContent='VISUAL EDITOR · OCCASION & NOTE';
    
    
    </script><script>
    // Name-only store creation panel with the supplied schema and pricing rules.
    const storePanel=document.createElement('dialog');storePanel.style.cssText='width:380px;max-width:92vw;padding:22px;background:#fffdf8;border:1px solid #c6aa70;border-radius:14px';document.body.append(storePanel);
    function openStorePanel(){storePanel.replaceChildren();const title=document.createElement('h3');title.textContent='إنشاء كارت متجر';title.style.cssText='margin:0 0 18px;color:#87652d';const label=document.createElement('label');label.textContent='اسم المتجر';const name=document.createElement('input');name.type='text';name.autocomplete='off';name.style.cssText='display:block;width:100%;margin-top:8px;padding:10px;background:white';label.append(name);const actions=document.createElement('div');actions.style.cssText='display:flex;gap:10px;margin-top:18px';const create=document.createElement('button');create.textContent='إنشاء';create.style.cssText='flex:1;background:#29251e;color:#f0dfb9';const cancel=document.createElement('button');cancel.textContent='إلغاء';cancel.style.flex='1';cancel.onclick=()=>storePanel.close();name.oninput=()=>name.setCustomValidity('');create.onclick=()=>{const value=name.value.trim();if(!value){name.focus();name.setCustomValidity('اكتب اسم المتجر');name.reportValidity();return;}name.setCustomValidity('');addKind('store');const item=current();if(!item)return;item.text=value;attachDefinition(item);item.binding.name=value;item.binding.entityId=null;item.binding.status='pending_connection';item.storeCreationRequest={version:1,name:value,status:'pending_connection',table:'stores',fields:clone(suppliedSchema.tables.stores),relations:{'store_products.store_id':'stores.id','store_products.product_size_id':'product_sizes.id','product_sizes.product_id':'products.id','products.brand_id':'brands.id'},reuseExistingIfMatched:true,createIfNew:true,integrationCompleted:false,separateStoreCatalogue:true,approvedBrands:clone(suppliedSchema.initial.brands),hiddenPublicFields:['website_url'],dataSources:{price:'store_catalog',availability:'store_catalog',quantity:'store_catalog',offers:'store_catalog'},rules:clone(suppliedSchema.rules),visibilityView:'public_products',cheapestOfferDefinition:clone(suppliedSchema.views.cheapest_offers),storeCataloguePrices:'Use this store actual offers; never attribute another store price or stock to this store.',credentialsRequiredInThisPanel:false};changed();render();document.getElementById('save').click();storePanel.close();};name.onkeydown=e=>{if(e.key==='Enter'){e.preventDefault();create.click();}};actions.append(create,cancel);storePanel.append(title,label,actions);storePanel.showModal();name.focus();}
    const menuBeforeStorePanel=showMenu;showMenu=function(e){menuBeforeStorePanel(e);const button=Array.from(menu.children).find(b=>b.textContent==='إنشاء كارت متجر');if(button)button.onclick=()=>{menu.style.display='none';openStorePanel();};};caption.textContent='VISUAL EDITOR · STORE PANEL';
    
    
    </script><script>
    // Store definition completed from the supplied schema, without database changes.
    const exactStoreSchema={table:'stores',columns:{id:{type:'uuid',primaryKey:true},name:{type:'not specified'},slug:{type:'not specified',unique:true},logo_url:{type:'not specified'},image_url:{type:'not specified'},short_description:{type:'not specified'},website_url:{type:'not specified',hiddenFromCustomer:true},status:{type:'not specified',allowedValues:['active','inactive']},commission_rate:{type:'numeric',default:0},priority_rank:{type:'integer',default:100},created_at:{type:'not specified',automatic:true},updated_at:{type:'not specified',automatic:true}},rowLevelSecurity:true,publicRead:'Available products, brands, stores, offers and prices only, as stated in the supplied schema.',storeAccountWrite:'Store accounts modify their own store catalogue only.',platform_admin:'Full access.',relatedTables:['store_accounts','store_products','offers','commissions','sync_logs','product_sizes','products','brands'],relations:{'store_accounts.store_id':'stores.id','store_accounts.user_id':'auth.users.id','store_products.store_id':'stores.id','store_products.product_size_id':'product_sizes.id','product_sizes.product_id':'products.id','products.brand_id':'brands.id','offers.store_id':'stores.id','offers.product_size_id':'product_sizes.id','commissions.store_id':'stores.id','commissions.order_item_id':'order_items.id','sync_logs.store_id':'stores.id'},uniqueConstraints:{store_accounts:['store_id','user_id'],store_products:['store_id','product_size_id']},requestedIndexes:['brand_id','store_id','product_id','product_size_id','price','is_available','commission_rate'],storeProductFields:clone(suppliedSchema.tables.store_products),storeProductDefaults:{stock_quantity:0,is_available:false,is_new_arrival:false,is_coming_soon:false,currency:'EGP',data_source:'store_catalog',sync_status:'unavailable'},storeProductRequired:{price:'numeric not null'},storeProductSyncValues:['synced','stale','unavailable'],storeProductTimestamps:'created_at and updated_at automatic',views:clone(suppliedSchema.views),dataRules:clone(suppliedSchema.rules),initialStores:clone(suppliedSchema.initial.stores),approvedBrands:clone(suppliedSchema.initial.brands),source:'merchant supplied schema, not a verification of deployed SQL'};
    const attachBeforeStoreCompletion=attachDefinition;attachDefinition=function(item){attachBeforeStoreCompletion(item);if(item.kind!=='store')return;item.storeSchemaDefinition=clone(exactStoreSchema);if(item.storeCreationRequest){item.storeCreationRequest.schemaDefinition=clone(exactStoreSchema);item.storeCreationRequest.suppliedSchemaReference=clone(suppliedSchema);}};
    const saveBeforeStoreCompletion=document.getElementById('save').onclick;document.getElementById('save').onclick=()=>{state.items.forEach(attachDefinition);state.archive.forEach(attachDefinition);if(Array.isArray(state.savedElements))state.savedElements.forEach(attachDefinition);saveBeforeStoreCompletion();};state.items.forEach(attachDefinition);state.archive.forEach(attachDefinition);if(Array.isArray(state.savedElements))state.savedElements.forEach(attachDefinition);
    
    
    </script><script>
    // Canonical table clauses transcribed from the supplied schema, including its exceptions.
    const canonicalTableSpecs={
    brands:'id, name, slug unique, official_logo_url, description, official_website_url, is_active default true, created_at, updated_at',
    stores:'id, name, slug unique, logo_url, image_url, short_description, website_url; status (active / inactive); commission_rate numeric default 0; priority_rank integer default 100; created_at, updated_at',
    store_accounts:'id, store_id references stores, user_id references auth.users, role text default store_admin, created_at; unique (store_id, user_id)',
    aromatic_notes:'id, name unique, image_url, created_at, updated_at',categories:'id, name unique, image_url, created_at, updated_at',occasions:'id, name unique, image_url, created_at, updated_at',
    products:'id, brand_id references brands, name, slug unique; short_description, official_description, composition; gender (men / women / unisex); notes_source (brand_official / store_catalog / mixed); content_source text; status (draft / published / archived) default draft; meta_title, meta_description; is_active default true; created_at, updated_at',
    product_sizes:'id, product_id references products, size_ml integer, size_label text, sku text; unique (product_id, size_label); created_at, updated_at',
    product_images:'id, product_id references products, product_size_id nullable references product_sizes; image_url, alt_text, sort_order integer default 0, is_primary default false; created_at',
    product_notes:'product_id references products, note_id references aromatic_notes; primary key (product_id, note_id)',
    product_categories:'product_id references products, category_id references categories; primary key (product_id, category_id)',
    product_occasions:'product_id references products, occasion_id references occasions; primary key (product_id, occasion_id)',
    store_products:'id; store_id references stores; product_size_id references product_sizes; price numeric not null; original_price numeric; discount_percentage numeric; stock_quantity integer default 0; is_available boolean default false; is_new_arrival boolean default false; is_coming_soon boolean default false; price_includes_tax boolean; price_includes_shipping boolean; currency text default EGP; data_source text default store_catalog; sync_status (synced / stale / unavailable) default unavailable; last_synced_at timestamptz; created_at, updated_at; unique (store_id, product_size_id)',
    offers:'id, store_id references stores, product_size_id nullable references product_sizes; title, description; discount_type (percentage / fixed / package); discount_value numeric; start_date, end_date; is_active default true; created_at, updated_at',
    product_stats:'product_id primary key references products; views_count integer default 0; sales_count integer default 0; search_count integer default 0; request_count integer default 0; average_rating numeric; reviews_count integer default 0; updated_at',
    reviews:'id, user_id references profiles, product_id references products; rating integer check 1-5, comment text, is_approved default false; created_at, updated_at; unique (user_id, product_id)',
    profiles:'id primary key references auth.users; full_name, phone, avatar_url; role (customer / store_admin / platform_admin) default customer; created_at, updated_at',
    favorites:'id, user_id references profiles, product_id references products; created_at; unique (user_id, product_id)',
    cart_items:'id, user_id references profiles, store_product_id references store_products; quantity integer default 1 check > 0; created_at, updated_at; unique (user_id, store_product_id)',
    orders:'id, user_id references profiles; status (pending / confirmed / shipped / delivered / cancelled); subtotal numeric, tax_amount numeric default 0, shipping_amount numeric default 0, total_amount numeric; created_at, updated_at',
    order_items:'id, order_id references orders, store_product_id references store_products; quantity integer, price_at_time numeric; created_at',
    commissions:'id, store_id references stores, order_item_id references order_items; rate numeric, amount numeric; status (pending / payable / paid) default pending; created_at, updated_at',
    contact_messages:'id, name, email, phone, message, is_read default false, created_at',
    notifications:'id, user_id references profiles, title, body, is_read default false, created_at',
    marketing_phrases:'id, phrase_ar, phrase_en nullable; category (slogan / section / internal_reference); is_public boolean default false; usage_scope text; created_at',
    media_library:'id, file_url, file_type (image / video); source (device_upload / ai_generated / store_catalog / brand_official); alt_text, linked_entity_type, linked_entity_id; is_approved default false; created_at',
    analytics_events:'id, event_type (view / search / add_to_cart / request); product_id nullable, product_size_id nullable, user_id nullable; metadata jsonb; created_at',
    site_settings:'key text primary key, value text, updated_at',
    sync_logs:'id, store_id references stores, status text, message text, records_count integer, created_at'
    };
    const canonicalGeneralRules={primaryKeyInstruction:'UUID as primary key for all tables',timestampsInstruction:'created_at and updated_at automatic on every table',preserveExplicitTableExceptions:true,rowLevelSecurity:'Enable on every table',publicRead:'Only available products, brands, stores, offers and prices',userWrite:'Authenticated users may write only their own favorites, cart, orders, reviews and messages',storeWrite:'Store accounts modify their own store catalogue only',platform_admin:'Full access',indexes:['brand_id','store_id','product_id','product_size_id','price','is_available','commission_rate']};
    const canonicalForbiddenData=[
    'Price, availability, quantity, offers, new arrivals and best sellers come only from store catalogues.',
    'Description, composition, notes and official content may be supplemented only from the official brand website.',
    'Never store or display official brand website price as the displayed price.',
    'brands.official_website_url is stored but never displayed to customers.',
    'No store or brand website link is displayed to customers.',
    'Do not display a perfume unless available for sale at at least one platform store.',
    'Each size has independent price, availability, quantity and comparison; no comparison across sizes.',
    'One card for the same perfume and size: cheapest available store; tie: highest commission_rate then priority_rank.'
    ];
    const canonicalViews={cheapest_offers:{per:'product_size_id',eligibility:['is_available = true','stock_quantity > 0','sync_status = synced'],selection:'Cheapest store_products row',tieOrder:['commission_rate DESC','priority_rank ASC'],columns:['product_size_id','product_id','brand_id','store_id','store_name','price','stock_quantity','currency','price_includes_tax','price_includes_shipping','last_synced_at']},public_products:{eligibility:'Published products with at least one offer in cheapest_offers',usage:'The only product-display rule for cards, sections and search',columns:'Not listed in the supplied schema'}};
    const elementSchemaTables={
    section:Object.keys(canonicalTableSpecs),
    perfume:['products','product_sizes','product_images','brands','stores','store_products','aromatic_notes','product_notes','categories','product_categories','occasions','product_occasions','offers','product_stats','reviews','profiles','favorites','cart_items','orders','order_items','commissions','media_library','analytics_events','sync_logs'],
    brand:['brands','products','product_sizes','product_images','stores','store_products','offers','product_stats','media_library','sync_logs'],
    store:['stores','store_accounts','profiles','products','brands','product_sizes','product_images','store_products','offers','product_stats','reviews','order_items','commissions','media_library','sync_logs'],
    occasion:['occasions','product_occasions','products','product_sizes','product_images','brands','stores','store_products','media_library'],
    note:['aromatic_notes','product_notes','products','product_sizes','product_images','brands','stores','store_products','media_library'],
    banner:['media_library'],text:['marketing_phrases'],text_block:['marketing_phrases']};
    const canonicalSchemaReference={id:'elan-merchant-schema-v1',tables:canonicalTableSpecs,generalRules:canonicalGeneralRules,dataRestrictions:canonicalForbiddenData,relations:clone(suppliedSchema.relations),views:canonicalViews,initialData:clone(suppliedSchema.initial),marketingPhraseSeedRule:'Identity phrases are is_public=false except phrases explicitly assigned to each section.',verification:'Matched to supplied specification; no live database verification.'};
    function canonicalElementDefinition(item){const kind=definitionKind(item);if(!kind)return null;const tables=elementSchemaTables[kind]||[];const clauses={};tables.forEach(name=>clauses[name]=canonicalTableSpecs[name]);const tableSet=new Set(tables);const relations=Object.fromEntries(Object.entries(suppliedSchema.relations).filter(([left,right])=>tableSet.has(left.split('.')[0])||tableSet.has(right.split('.')[0])));return {kind,schemaReferenceId:canonicalSchemaReference.id,entityTable:elanElementDefinitions.elements[kind]?.table||null,tableSpecifications:clauses,relations,generalRules:clone(canonicalGeneralRules),dataRestrictions:clone(canonicalForbiddenData),views:['banner','text','text_block'].includes(kind)?null:clone(canonicalViews),initialData:clone(suppliedSchema.initial),independentLayoutTableSpecified:!['section','banner','text','text_block'].includes(kind),connectionStatus:'not_connected'};}
    const attachBeforeCanonicalAudit=attachDefinition;attachDefinition=function(item){attachBeforeCanonicalAudit(item);if(!definitionKind(item))return;item.schemaDefinition=canonicalElementDefinition(item);item.schemaReferenceId=canonicalSchemaReference.id;};
    Object.entries(elanElementDefinitions.elements).forEach(([kind,def])=>{def.schemaReferenceId=canonicalSchemaReference.id;def.tableSpecifications={};(elementSchemaTables[kind]||[]).forEach(name=>def.tableSpecifications[name]=canonicalTableSpecs[name]);});
    elanElementDefinitions.canonicalSchema=canonicalSchemaReference;
    const saveBeforeCanonicalAudit=document.getElementById('save').onclick;document.getElementById('save').onclick=()=>{state.canonicalSchemaReference=clone(canonicalSchemaReference);state.items.forEach(attachDefinition);state.archive.forEach(attachDefinition);if(Array.isArray(state.savedElements))state.savedElements.forEach(attachDefinition);saveBeforeCanonicalAudit();};
    state.canonicalSchemaReference=clone(canonicalSchemaReference);state.items.forEach(attachDefinition);state.archive.forEach(attachDefinition);if(Array.isArray(state.savedElements))state.savedElements.forEach(attachDefinition);
    const audit={expectedTables:29,actualTables:Object.keys(canonicalTableSpecs).length,missingTables:Object.keys(suppliedSchema.tables).filter(t=>!canonicalTableSpecs[t]),elementKinds:Object.keys(elementSchemaTables),requiredPriceColumnsMissing:suppliedSchema.views.cheapest_offers.columns.filter(c=>!canonicalViews.cheapest_offers.columns.includes(c))};
    state.schemaDefinitionAudit=audit;
    if(audit.actualTables!==29||audit.missingTables.length||audit.requiredPriceColumnsMissing.length)console.error('Schema definition mismatch',audit);
    caption.textContent='VISUAL EDITOR · FINAL SCHEMA REVIEW';
    
    
    </script><script>
    // Cloud library integration boundary. No credentials and no invented Supabase tables.
    // Provider contract: getLibrary() -> {archive,media,savedElements,revision};
    // saveLibrary({archive,media,savedElements}, expectedRevision) -> {revision};
    // uploadMedia(file,{category}) -> {id,name,src,type,category};
    // generateMedia({prompt,category}) -> stored cloud media record, only after external service configuration.
    let cloudLibraryReady=false,cloudLibraryRevision=null,cloudLibraryTimer=null,cloudLibrarySaving=false,cloudLibraryPending=false;
    function librarySnapshot(){return clone({archive:state.archive,media:state.media,savedElements:state.savedElements||[]});}
    function cloudProvider(){return window.elanLibraryDataProvider;}
    function showLibraryCloudMessage(text){let msg=libraryDialog.querySelector('[data-cloud-message]');if(!msg){msg=document.createElement('p');msg.dataset.cloudMessage='true';msg.style.cssText='font-size:12px;line-height:1.8;color:#846631';libraryDialog.append(msg);}msg.textContent=text;}
    function validLibrary(data){return data&&Array.isArray(data.archive)&&Array.isArray(data.media)&&Array.isArray(data.savedElements)&&data.revision!==undefined;}
    async function loadCloudLibrary(){const provider=cloudProvider();if(!provider?.getLibrary){showLibraryCloudMessage('المكتبة المركزية غير متصلة. الموجود حاليًا نسخة محلية، ولا يوجد حفظ مؤكد في سابابيس.');return false;}if(cloudLibraryPending){showLibraryCloudMessage('توجد تغييرات غير محفوظة مركزيًا. لا نستبدلها قبل المزامنة.');return false;}try{const data=await provider.getLibrary();if(!validLibrary(data))throw Error('Invalid cloud response');state.archive=clone(data.archive);state.media=clone(data.media);state.savedElements=clone(data.savedElements);cloudLibraryRevision=data.revision;cloudLibraryReady=true;document.getElementById('save').click();library();showLibraryCloudMessage('المكتبة محمّلة من المصدر المركزي.');return true;}catch(e){cloudLibraryReady=false;showLibraryCloudMessage('تعذر قراءة المكتبة المركزية. لم تُستبدل بياناتك المحلية.');return false;}}
    async function persistCloudLibrary(){if(!cloudLibraryReady||!cloudProvider()?.saveLibrary)return;if(cloudLibrarySaving)return;cloudLibrarySaving=true;const snapshot=librarySnapshot();cloudLibraryPending=false;try{const result=await cloudProvider().saveLibrary(snapshot,cloudLibraryRevision);if(result?.revision===undefined)throw Error('Missing revision');cloudLibraryRevision=result.revision;if(libraryDialog.open)showLibraryCloudMessage('تم تأكيد حفظ المكتبة والأرشيف مركزيًا.');}catch(e){cloudLibraryPending=true;if(libraryDialog.open)showLibraryCloudMessage('لم يتم تأكيد الحفظ المركزي، أو تعارض مع نسخة أحدث. بياناتك المحلية لم تُحذف؛ لا تُعتبر هذه التغييرات محفوظة على الخادم.');}finally{cloudLibrarySaving=false;}}
    let lastLibrarySignature=JSON.stringify(librarySnapshot());const changedBeforeCloudLibrary=changed;changed=function(){changedBeforeCloudLibrary();const signature=JSON.stringify(librarySnapshot());if(signature===lastLibrarySignature)return;lastLibrarySignature=signature;cloudLibraryPending=true;if(cloudLibraryReady){clearTimeout(cloudLibraryTimer);cloudLibraryTimer=setTimeout(persistCloudLibrary,350);}};
    window.connectElanLibrary=async function(provider){if(!provider||typeof provider.getLibrary!=='function'||typeof provider.saveLibrary!=='function')throw Error('Library provider requires authenticated load/save methods');window.elanLibraryDataProvider=provider;cloudLibraryPending=false;return loadCloudLibrary();};
    const libraryBeforeCloudSources=library;library=function(){libraryBeforeCloudSources();const controls=document.createElement('div');controls.style.cssText='display:flex;gap:8px;flex-wrap:wrap;margin-top:12px';const cloud=document.createElement('button');cloud.textContent='تحميل المكتبة من سابابيس';cloud.onclick=loadCloudLibrary;const sync=document.createElement('button');sync.textContent='مزامنة التغييرات';sync.onclick=()=>{if(!cloudLibraryReady){showLibraryCloudMessage('أكمل الاتصال أولًا. لا يتم رفع الأرشيف المحلي تلقائيًا إلى قاعدة البيانات.');return;}persistCloudLibrary();};controls.append(cloud,sync);if(libraryTab==='saved'){const ai=document.createElement('button');ai.textContent='إضافة من الذكاء الاصطناعي';ai.onclick=async()=>{const provider=cloudProvider();if(!cloudLibraryReady||!provider?.generateMedia){showLibraryCloudMessage('مولّد الميديا غير متصل. يلزم إعداد خدمة توليد وربط الحفظ المركزي أولًا.');return;}const promptText=prompt('وصف الصورة أو الفيديو المطلوب');if(!promptText?.trim())return;if(!confirm('إرسال طلب التوليد للخدمة المرتبطة؟ قد تُحتسب تكلفة وفق حسابك لديها.'))return;ai.disabled=true;try{const record=await provider.generateMedia({prompt:promptText.trim(),category:libraryCategory});if(!record?.id||!record.src||!['image','video'].includes(record.type))throw Error();checkpoint();state.media.push({...record,category:libraryCategory});changed();await persistCloudLibrary();library();}catch(e){showLibraryCloudMessage('لم يتم تأكيد توليد الميديا وحفظها مركزيًا.');}finally{ai.disabled=false;}};controls.append(ai);}libraryDialog.append(controls);showLibraryCloudMessage(cloudLibraryReady?(cloudLibraryPending?'تغييرات تنتظر تأكيد الحفظ المركزي.':'المكتبة متصلة بالمصدر المركزي.'):'الربط المركزي غير منفّذ؛ لا تزال المكتبة المحلية هي المعروضة.');};document.getElementById('library').onclick=()=>library();
    const localUploadBeforeCloud=document.getElementById('upload').onchange;document.getElementById('upload').onchange=async e=>{const file=e.target.files[0];if(!file)return;if(!cloudLibraryReady||!cloudProvider()?.uploadMedia||file.name.toLowerCase().endsWith('.json')){localUploadBeforeCloud(e);return;}if(!file.type.startsWith('image/')&&!file.type.startsWith('video/')){alert('اختر صورة أو فيديو');e.target.value='';return;}const category=uploadOnlyCategory;uploadOnlyCategory=null;const targetId=replaceId||(current()&&['card','section'].includes(current().type)?selected:null);replaceId=null;e.target.value='';try{const target=state.items.find(i=>i.id===targetId);const record=await cloudProvider().uploadMedia(file,{category:category||(target?itemCategory(target):file.type.startsWith('image/')?'image':'video')});if(!record?.id||!record.src||!['image','video'].includes(record.type))throw Error();checkpoint();state.media.push(record);if(!category){if(target&&['card','section'].includes(target.type)){target.mediaSrc=record.src;target.mediaType=record.type;}else if(target&&['image','video'].includes(target.type)){target.src=record.src;target.type=record.type;}else add(record.type,record.src);}changed();render();await persistCloudLibrary();if(libraryDialog.open)library();}catch(e){alert('لم يتم تأكيد رفع الملف للمكتبة المركزية. لم نعرضه كملف محفوظ بنجاح.');}};
    state.libraryStorageDefinition={target:'supabase',mediaMetadataTable:'media_library',mediaBinaryStorage:'Configured private Supabase Storage with authenticated access',archive:'Full element payload including layout, data definitions, bindings, timers and content; storage location chosen only after inspecting existing backend',savedElements:'Full reusable element payload',sources:['central_library','device_upload','configured_ai_generator'],secretKeysInBrowser:false,liveConnection:false};
    caption.textContent='VISUAL EDITOR · CENTRAL LIBRARY READY';
    
    
    </script><script>
    // Media source chooser for the selected element, with explicit connection status.
    const mediaSourceDialog=document.createElement('dialog');mediaSourceDialog.style.cssText='width:420px;max-width:94vw;padding:22px;background:#fffdf8;border:1px solid #c6aa70;border-radius:14px';document.body.append(mediaSourceDialog);
    function applyChosenMedia(targetId,record){const target=state.items.find(i=>i.id===targetId);if(!target){alert('العنصر المطلوب غير موجود.');return;}checkpoint();if(['card','section'].includes(target.type)){target.mediaSrc=record.src;target.mediaType=record.type;}else if(['image','video'].includes(target.type)){target.src=record.src;target.type=record.type;}else{alert('هذا العنصر لا يدعم الميديا.');return;}changed();render();document.getElementById('save').click();}
    function chooseMediaSource(){const target=current();if(!target||!['card','section','image','video'].includes(target.type))return;const targetId=target.id;mediaSourceDialog.replaceChildren();const title=document.createElement('h3');title.textContent='مصدر الصورة أو الفيديو';title.style.color='#87652d';const statusText=document.createElement('p');statusText.style.cssText='font-size:12px;line-height:1.7;color:#7d6a49';function sourceButton(label,fn){const b=document.createElement('button');b.textContent=label;b.style.cssText='display:block;width:100%;margin:9px 0';b.onclick=fn;mediaSourceDialog.append(b);return b;}mediaSourceDialog.append(title);
    sourceButton('من مكتبة سابابيس',async()=>{const provider=cloudProvider();if(!provider?.getLibrary){statusText.textContent='مكتبة سابابيس غير متصلة بعد. لم نعرض المكتبة المحلية باعتبارها مكتبة سحابية.';return;}try{const data=await provider.getLibrary();if(!validLibrary(data))throw Error();const list=document.createElement('div');const heading=document.createElement('h4');heading.textContent='اختر الميديا';list.append(heading);const media=data.media.filter(m=>m.src&&['image','video'].includes(m.type));if(!media.length){const empty=document.createElement('p');empty.textContent='لا توجد صور أو فيديوهات محفوظة في المكتبة المركزية.';list.append(empty);}media.forEach(record=>{const b=document.createElement('button');b.textContent=record.name||record.type;b.style.cssText='display:block;width:100%;margin:6px 0';b.onclick=()=>{applyChosenMedia(targetId,record);mediaSourceDialog.close();};list.append(b);});mediaSourceDialog.querySelector('[data-media-list]')?.remove();list.dataset.mediaList='true';mediaSourceDialog.append(list);}catch(e){statusText.textContent='تعذر تحميل المكتبة المركزية، ولم تُعرض بيانات بديلة.';}});
    sourceButton('من الجهاز',()=>{selected=targetId;replaceId=targetId;uploadOnlyCategory=null;mediaSourceDialog.close();document.getElementById('upload').accept='image/*,video/*';document.getElementById('upload').click();});
    const aiButton=sourceButton('من الذكاء الاصطناعي',async()=>{const provider=cloudProvider();if(!cloudLibraryReady||!provider?.generateMedia){statusText.textContent='خدمة التوليد والحفظ المركزي غير متصلة بعد.';return;}const description=prompt('وصف الصورة أو الفيديو المطلوب');if(!description?.trim())return;if(!confirm('إرسال طلب التوليد للخدمة المرتبطة؟ قد تكون هناك تكلفة حسب حسابك.'))return;aiButton.disabled=true;try{const record=await provider.generateMedia({prompt:description.trim(),category:itemCategory(target)});if(!record?.id||!record.src||!['image','video'].includes(record.type))throw Error();state.media.push(record);applyChosenMedia(targetId,record);await persistCloudLibrary();mediaSourceDialog.close();}catch(e){statusText.textContent='لم يتم تأكيد توليد الميديا وحفظها.';}finally{aiButton.disabled=false;}});mediaSourceDialog.append(statusText);sourceButton('إلغاء',()=>mediaSourceDialog.close());mediaSourceDialog.showModal();}
    const menuBeforeMediaSources=showMenu;showMenu=function(e){menuBeforeMediaSources(e);const button=Array.from(menu.children).find(b=>b.textContent==='رفع صورة أو فيديو داخل العناصر أو الهيرو');if(button){button.disabled=!current()||!['card','section','image','video'].includes(current().type);button.onclick=()=>{menu.style.display='none';chooseMediaSource();};}};caption.textContent='VISUAL EDITOR · MEDIA SOURCES';
    
    
    </script><script>
    // Integration shell: existing standalone editing remains separate and unchanged.
    const bridgeProtocol='elan-editor-bridge/v1';let liveMode=false,bridgeReady=false,bridgeSession='',bridgeOrigin='',bridgeRevision=null,bridgeDirty=false;const bridgePending=new Map();let bridgeTimeout=null;
    const livePanel=document.createElement('section');livePanel.style.cssText='padding:10px 20px;background:#fffaf0;border-bottom:1px solid #c2a66a';const address=document.createElement('input');address.type='url';address.value=location.origin+'/';address.style.cssText='width:min(480px,70vw);direction:ltr';const openLive=document.createElement('button');openLive.textContent='فتح المنصة داخل الإديتور';const localButton=document.createElement('button');localButton.textContent='المحرر المستقل';const bridgeStatus=document.createElement('span');bridgeStatus.style.cssText='display:block;font-size:12px;margin-top:8px';bridgeStatus.textContent='الموقع لا يصبح قابلًا للتعديل قبل تثبيت الربط داخل إيلان سنتس.';livePanel.append(address,openLive,localButton,bridgeStatus);document.querySelector('header').after(livePanel);
    const liveArea=document.createElement('section');liveArea.hidden=true;const liveTools=document.createElement('div');liveTools.style.cssText='display:flex;gap:6px;flex-wrap:wrap;padding:10px;background:#fffdf8';const liveFrame=document.createElement('iframe');liveFrame.title='إيلان سنتس، وضع التحرير';liveFrame.referrerPolicy='strict-origin-when-cross-origin';liveFrame.style.cssText='display:block;width:100%;height:calc(100vh - 230px);border:0;background:white';liveArea.append(liveTools,liveFrame);livePanel.after(liveArea);const originalHeaderButtons=Array.from(document.querySelectorAll('header button'));const localViewport=document.getElementById('viewport');const localHint=document.getElementById('hint');let selectedLive=null;
    function markBridge(text){bridgeStatus.textContent=text;status.textContent=text;liveTools.querySelectorAll('button').forEach(b=>b.disabled=!bridgeReady);}
    function requestLive(action,payload={}){if(!bridgeReady)return Promise.reject(Error('المنصة غير متصلة بوضع التحرير'));const id=crypto.randomUUID();return new Promise((resolve,reject)=>{const timer=setTimeout(()=>{bridgePending.delete(id);reject(Error('لم يصل تأكيد التنفيذ. لا نفترض نجاح الحفظ؛ تحقّق من الإصدار قبل إعادة المحاولة.'));},20000);bridgePending.set(id,{resolve,reject,timer});liveFrame.contentWindow.postMessage({protocol:bridgeProtocol,type:'request',session:bridgeSession,id,action,payload,expectedRevision:bridgeRevision},bridgeOrigin);});}
    async function runLive(action,payload={}){try{const result=await requestLive(action,payload);if(action==='page.save'){if(result?.revision===undefined||result?.published!==true)throw Error('لم يصل تأكيد نشر الإصدار');bridgeRevision=result.revision;bridgeDirty=false;markBridge('تم تأكيد الحفظ والنشر، الإصدار '+bridgeRevision);}return result;}catch(e){markBridge(e.message);return null;}}
    function tool(label,action,payload){const b=document.createElement('button');b.textContent=label;b.disabled=true;b.onclick=()=>runLive(action,typeof payload==='function'?payload():payload||{});liveTools.append(b);}
    tool('↶ تراجع','history.undo');tool('↷ إعادة','history.redo');const saveBtn=document.createElement('button');saveBtn.textContent='حفظ';saveBtn.disabled=true;saveBtn.onclick=()=>saveLive();liveTools.append(saveBtn);tool('المكتبة','library.open');tool('تنسيق العنصر','ui.openFormatPanel',()=>({elementId:selectedLive?.id}));tool('مصدر الصورة أو الفيديو','ui.openMediaPanel',()=>({elementId:selectedLive?.id,sources:['central_library','device_upload','configured_ai_generator']}));['section','perfume','brand','store','occasion','note','banner','text_block'].forEach((kind,n)=>tool(['إنشاء سيكشن','إنشاء كارت عطر','إنشاء براند','إنشاء متجر','إنشاء مناسبة','إنشاء نوتة','إنشاء بانر','إنشاء كتلة نصية'][n],'ui.openCreatePanel',{kind,schemaReferenceId:'elan-merchant-schema-v1'}));tool('حذف إلى الأرشيف','element.archive',()=>({elementId:selectedLive?.id}));
    tool('استعادة من الأرشيف','archive.restore',null);
    liveTools.lastChild.onclick=async()=>{const st=await runLive('page.getState');if(!st)return;if(!st.archive.length){markBridge('الأرشيف فاضي.');return;}const pick=prompt('اكتبي رقم العنصر لاستعادته:\n'+st.archive.map((a,i)=>(i+1)+'. '+a.name).join('\n'));const n=parseInt(pick,10);if(n>=1&&n<=st.archive.length)runLive('archive.restore',{elementId:st.archive[n-1].id});};
    const deviceBox=document.createElement('span');deviceBox.style.cssText='margin-inline-start:auto;display:flex;gap:6px';[['لاب','100%'],['تابلت','820px'],['موبايل','390px']].forEach(([label,w])=>{const b=document.createElement('button');b.textContent=label;b.onclick=()=>{liveFrame.style.width=w;liveFrame.style.margin='0 auto';liveFrame.style.borderInline=w==='100%'?'0':'1px solid #c2a66a';};deviceBox.append(b);});liveTools.append(deviceBox);
    const refreshBtn=document.createElement('button');refreshBtn.textContent='تحديث';refreshBtn.title='يتأكد إن النشر خلص ويعيد تحميل الصفحة على آخر نسخة';refreshBtn.onclick=()=>refreshLive();liveTools.append(refreshBtn);
    
    
    const SAVE_ERR={conflict:'حد غيّر الصفحة وإنتي بتعدّلي. دوسي تحديث وجرّبي تاني.',unauthorized:'انتهت الجلسة، سجّلي الدخول من جديد.',editor_not_configured:'إعدادات الإديتور ناقصة على Railway.',main_not_allowed:'الحفظ على main مقفول.',github_auth_failed:'مفتاح GitHub مش شغال أو صلاحيته ناقصة.',invalid_design:'في تعديل مش مسموح (راجعي الألوان والروابط).',branch_not_found:'الفرع المطلوب مش موجود على GitHub.'};
    
    const stageBox=document.createElement('span');stageBox.style.cssText='display:flex;gap:6px;margin-inline-start:8px';
    const stage=(txt)=>{const c=document.createElement('span');c.textContent=txt;c.style.cssText='font-size:12px;padding:3px 9px;border-radius:99px;border:1px solid #685b41;color:#8c8068';return c;};
    const chipUp=stage('رفع على GitHub'),chipPub=stage('نشر على Railway'),chipLoad=stage('تحميل النسخة الجديدة');stageBox.append(chipUp,chipPub,chipLoad);
    function setStages(n){[chipUp,chipPub,chipLoad].forEach((c,i)=>{const on=i<n;c.style.color=on?'#d7f2c4':'#8c8068';c.style.borderColor=on?'#7ab35b':'#685b41';c.textContent=(on?'✔ ':'')+['رفع على GitHub','نشر على Railway','تحميل النسخة الجديدة'][i];});}
    status.after(stageBox);
    const logoutBtn=document.createElement('button');logoutBtn.textContent='خروج';logoutBtn.style.cssText='background:#302b23;border:1px solid #685b41;color:#efe4cc;border-radius:8px;padding:6px 12px';logoutBtn.onclick=async()=>{if(bridgeDirty&&!confirm('في تعديلات لسه ما اتحفظتش. تخرجي برضه؟'))return;try{await fetch('/api/editor-logout',{method:'POST'});}catch(_){}document.body.textContent='';location.replace('/editor');};
    status.after(logoutBtn);
    let publishWatch=null,pendingLoadStage=false;
    async function waitPublished(revision){for(let i=0;i<60;i++){await new Promise(r=>setTimeout(r,5000));try{const r=await fetch('/api/editor',{method:'POST',headers:{'Content-Type':'application/json'},credentials:'same-origin',body:JSON.stringify({action:'status',revision})});if(r.status===401)throw Error(SAVE_ERR.unauthorized);const j=await r.json();if(j.ok&&j.published)return true;}catch(e){if(e.message===SAVE_ERR.unauthorized)throw e;}}return false;}
    async function saveLive(){if(!bridgeReady)return markBridge('المنصة غير متصلة بوضع التحرير');setStages(0);markBridge('جاري الحفظ...');try{const st=await requestLive('page.getState');const rid=crypto.randomUUID().replace(/-/g,'');const r=await fetch('/api/editor',{method:'POST',headers:{'Content-Type':'application/json'},credentials:'same-origin',body:JSON.stringify({action:'save',design:st.design,expectedRevision:st.revision==='initial'?null:st.revision,requestId:rid})});const j=await r.json().catch(()=>({}));if(!r.ok||!j.ok)throw Error(SAVE_ERR[j.error]||('تعذّر الحفظ ('+(j.error||r.status)+')'));await requestLive('page.markSaved',{revision:j.revision});bridgeRevision=j.revision;bridgeDirty=false;if(!j.committed){markBridge('مفيش تغيير جديد للحفظ.');return;}setStages(1);markBridge('تم الرفع على GitHub ✔ بستنى النشر على Railway...');const my=publishWatch=Symbol();const ok=await waitPublished(j.revision);if(publishWatch!==my)return;if(ok)setStages(2);markBridge(ok?'تم النشر على Railway ✔ دوسي تحديث لتحميل النسخة الجديدة.':'اتحفظ على GitHub بس النشر لسه ماتأكدش. دوسي تحديث بعد شوية.');}catch(e){markBridge(e.message);if(/GitHub/.test(e.message))explainGithub();}}
    async function explainGithub(){try{markBridge('بفحص سبب رفض GitHub...');const r=await fetch('/api/editor?action=diagnose',{credentials:'same-origin',cache:'no-store'});const j=await r.json();if(!j.ok)return markBridge('تعذّر الفحص ('+(j.error||r.status)+').');let eb=document.getElementById('liveError');if(!eb){eb=document.createElement('div');eb.id='liveError';eb.style.cssText='position:fixed;top:78px;left:50%;transform:translateX(-50%);z-index:60;background:#fbe9e7;color:#8a1c12;border:1px solid #d9a199;border-radius:10px;padding:12px 18px;max-width:80vw;font:15px Tahoma;box-shadow:0 8px 24px #0003;cursor:pointer';eb.title='اضغطي لإغلاق الرسالة';eb.onclick=()=>eb.remove();document.body.appendChild(eb);}eb.textContent='سبب رفض GitHub: '+j.verdict;markBridge(j.verdict);}catch(e){markBridge('تعذّر فحص GitHub.');}}
    async function refreshLive(){if(bridgeDirty&&!confirm('في تعديلات لسه ما اتحفظتش. التحديث هيمسحها. تكملي؟'))return;markBridge('بتأكد من النشر...');try{const ok=await waitPublished(bridgeRevision);if(!ok&&!confirm('النشر لسه ماتأكدش. أعيد التحميل برضه؟'))return;}catch(e){return markBridge(e.message);}pendingLoadStage=true;openLive.onclick();}
    
    /* The original right-click menu, shown over the platform page. Same entries, same look, same behaviour. */
    function showLiveMenu(info){const el=info&&info.element;selectedLive=el||null;const r=liveFrame.getBoundingClientRect();menu.replaceChildren();const at={x:info.x,y:info.y};
    (info.tools||[]).forEach(t=>action(t.label,()=>{if(t.ui==='format')openLiveFormat();else if(t.ui==='media'&&window.elanLiveMedia)window.elanLiveMedia(el);else if(t.ui==='media_new'&&window.elanLiveMediaNew)window.elanLiveMediaNew(t,at);else runLive('tool.run',{id:t.id,elementId:el&&el.id,at});},t.enabled));
    menu.style.display='block';const mr=menu.getBoundingClientRect();menu.style.left=Math.max(4,Math.min(r.left+info.x,innerWidth-mr.width-8))+'px';menu.style.top=Math.max(4,Math.min(r.top+info.y,innerHeight-mr.height-8))+'px';}
    function openLiveFormat(){const s=selectedLive&&selectedLive.style;if(!s)return;const hex=v=>/^#[0-9a-f]{6}$/i.test(v||'')?v:null;const fontSel=document.getElementById('font');const fam=(s.fontFamily||'Tahoma').replace(/["']/g,'');if(![...fontSel.options].some(o=>o.value===fam)){const o=document.createElement('option');o.value=fam;o.textContent=fam;fontSel.append(o);}fontSel.value=fam;document.getElementById('size').value=s.fontSize||24;document.getElementById('color').value=hex(s.color)||'#222222';document.getElementById('bg').value=hex(s.background)||'#fffdf9';document.getElementById('align').value=s.align||'right';try{effectSelect.value=s.effect||'none';}catch(_){}window.liveFormatInitial={color:document.getElementById('color').value,bg:document.getElementById('bg').value};document.getElementById('format').showModal();try{updatePanelPreview();}catch(_){}}
    document.getElementById('apply').addEventListener('click',e=>{if(!liveMode)return;e.stopImmediatePropagation();e.preventDefault();if(!selectedLive)return;const fonts=fontDefinitions.flatMap(g=>g[1]);const init=window.liveFormatInitial||{};const style={fontSize:Math.max(8,Math.min(120,Math.round(Number(document.getElementById('size').value)||24))),align:document.getElementById('align').value};if(document.getElementById('color').value!==init.color)style.color=document.getElementById('color').value;if(document.getElementById('bg').value!==init.bg)style.background=document.getElementById('bg').value;const f=document.getElementById('font').value;if(fonts.includes(f))style.fontFamily=f;try{style.effect=effectSelect.value;}catch(_){}document.getElementById('format').close();runLive('element.format',{elementId:selectedLive.id,style});},true);
    [['undo',()=>runLive('history.undo')],['redo',()=>runLive('history.redo')],['save',()=>saveLive()],['library',()=>runLive('library.open')]].forEach(([id,fn])=>document.getElementById(id).addEventListener('click',e=>{if(!liveMode)return;e.stopImmediatePropagation();e.preventDefault();fn();},true));
    window.addEventListener('blur',()=>{if(liveMode)menu.style.display='none';});
    Array.from(liveTools.children).forEach(c=>{if(c!==deviceBox&&c!==refreshBtn)c.hidden=true;});
    function abandonBridge(){bridgeReady=false;try{clearInterval(helloTimer);}catch(_){}clearTimeout(bridgeTimeout);bridgePending.forEach(p=>{clearTimeout(p.timer);p.reject(Error('تم إغلاق الاتصال'));});bridgePending.clear();}
    openLive.onclick=()=>{if(bridgeDirty&&!confirm('توجد تعديلات لم يُؤكد حفظها. إعادة فتح الصفحة قد تفقدها. المتابعة؟'))return;let url;try{url=new URL(address.value);if(url.protocol!=='https:'&&!(url.protocol==='http:'&&/^(127\.0\.0\.1|localhost)$/.test(url.hostname)))throw Error();}catch(e){alert('أدخل رابط HTTPS صحيحًا للمنصة');return;}abandonBridge();bridgeSession=crypto.randomUUID();bridgeOrigin=url.origin;bridgeDirty=false;selectedLive=null;liveMode=true;liveArea.hidden=false;localViewport.hidden=true;if(localHint)localHint.hidden=true;originalHeaderButtons.forEach(b=>{b.hidden=false;b.disabled=false;});menu.style.display='none';url.searchParams.set('elan_editor','1');liveFrame.src=url.href;markBridge('جارٍ فتح الموقع. العرض داخل النافذة لا يعني أن الربط أو الحفظ يعمل.');};
    let helloTimer=null;liveFrame.onload=()=>{if(!liveMode)return;const hello=()=>{try{liveFrame.contentWindow.postMessage({protocol:bridgeProtocol,type:'hello',session:bridgeSession},bridgeOrigin);}catch(_){}};hello();clearInterval(helloTimer);helloTimer=setInterval(()=>{if(bridgeReady||!liveMode){clearInterval(helloTimer);return;}hello();},700);clearTimeout(bridgeTimeout);bridgeTimeout=setTimeout(()=>{if(!bridgeReady)markBridge('لم يصل تأكيد اتصال: قد يحتاج الموقع تفعيل الربط وتسجيل دخول الإدارة أو السماح بعرضه داخل الإديتور. أدوات التعديل متوقفة.');},12000);};
    window.addEventListener('message',e=>{const m=e.data;if(!liveMode||e.source!==liveFrame.contentWindow||e.origin!==bridgeOrigin||m?.protocol!==bridgeProtocol||m.session!==bridgeSession)return;if(m.type==='ready'&&m.authorized===true&&m.page?.revision!==undefined){clearTimeout(bridgeTimeout);bridgeReady=true;bridgeRevision=m.page.revision;markBridge('متصل بوضع التحرير، الإصدار المنشور '+bridgeRevision);{const eb=document.getElementById('liveError');if(eb)eb.remove();}if(pendingLoadStage){pendingLoadStage=false;setStages(3);markBridge('تم تحميل صفحة جديدة من النسخة المحدثة ✔');}}else if(m.type==='denied'){abandonBridge();const why=(typeof m.message==='string'&&/[\u0600-\u06FF]/.test(m.message)&&m.message.length<300)?m.message:'وضع التحرير غير جاهز أو حساب الإدارة غير مصرح له.';markBridge(why);let eb=document.getElementById('liveError');if(!eb){eb=document.createElement('div');eb.id='liveError';eb.style.cssText='position:fixed;top:78px;left:50%;transform:translateX(-50%);z-index:60;background:#fbe9e7;color:#8a1c12;border:1px solid #d9a199;border-radius:10px;padding:12px 18px;max-width:80vw;font:15px Tahoma;box-shadow:0 8px 24px #0003';document.body.appendChild(eb);}eb.textContent='أدوات التحرير لسه مش شغالة: '+why;}else if(bridgeReady&&m.type==='selection'){selectedLive=m.element;bridgeStatus.textContent='العنصر المحدد: '+(selectedLive?.name||selectedLive?.id||'لا يوجد');menu.style.display='none';}else if(bridgeReady&&m.type==='context'){showLiveMenu(m.info);}else if(bridgeReady&&m.type==='dirty'){bridgeDirty=!!m.dirty;bridgeStatus.textContent=bridgeDirty?'تعديلات غير محفوظة على المنصة.':'لا توجد تعديلات معلقة.';status.textContent=bridgeDirty?'تعديلات غير محفوظة':'محفوظ';}else if(bridgeReady&&m.type==='revision'){bridgeRevision=m.revision;}else if(m.type==='response'){const p=bridgePending.get(m.id);if(!p)return;clearTimeout(p.timer);bridgePending.delete(m.id);m.ok?p.resolve(m.result):p.reject(Error(m.error||'فشل التنفيذ'));}});
    localButton.onclick=()=>{if(bridgeDirty&&!confirm('تعديلات المنصة لم يُؤكد حفظها. الخروج؟'))return;abandonBridge();liveMode=false;liveArea.hidden=true;liveFrame.src='about:blank';localViewport.hidden=false;if(localHint)localHint.hidden=false;originalHeaderButtons.forEach(b=>b.hidden=false);markBridge('المحرر المستقل، ليس صفحة المنصة الحقيقية ولا دليلًا على الحفظ المركزي.');};
    window.addEventListener('beforeunload',e=>{if(bridgeDirty||bridgePending.size){e.preventDefault();e.returnValue='';}});
    address.hidden=true;openLive.hidden=true;localButton.hidden=true;bridgeStatus.textContent='جاري فتح الموقع...';setTimeout(()=>openLive.onclick(),0);
    window.elanLiveEditorBridge={request:requestLive,getState:()=>({connected:bridgeReady,revision:bridgeRevision,dirty:bridgeDirty})};
    caption.textContent='VISUAL EDITOR · LIVE PLATFORM BRIDGE';
    
    </script></body></html>
    
  operator: 'match'
  stack: |-
    TestContext.<anonymous> (/home/ubuntu/elan-scents/tests/editor-format-panel.test.js:22:10)
    Test.runInAsyncScope (node:async_hooks:211:14)
    Test.run (node:internal/test_runner/test:931:25)
    Test.processPendingSubtests (node:internal/test_runner/test:629:18)
    Test.postRun (node:internal/test_runner/test:1042:19)
    Test.run (node:internal/test_runner/test:970:12)
    async startSubtestAfterBootstrap (node:internal/test_runner/harness:296:3)
  ...
# Subtest: the storefront loads an extra web font only when a saved design uses it
not ok 60 - the storefront loads an extra web font only when a saved design uses it
  ---
  duration_ms: 10.631073
  location: '/home/ubuntu/elan-scents/tests/editor-format-panel.test.js:28:1'
  failureType: 'testCodeFailure'
  error: |-
    The input did not match the regular expression /function ensureFont\(name\)/. Input:
    
    '/* Élan Scents — storefront design layer.\n' +
      '   Reads /design/home.json and applies it on top of the existing page after every render().\n' +
      '   Safe by construction: if the file is missing, invalid or empty, the page is left exactly as it is. */\n' +
      '(function () {\n' +
      "  'use strict';\n" +
      '  var ED = window.ElanDesign;\n' +
      '  if (!ED) return;\n' +
      '\n' +
      '  var design = null;\n' +
      '  var editing = false;\n' +
      '  var touched = [];\n' +
      '  var lastDevice = null;\n' +
      "  var SEC_NAMES = { brands: 'الماركات', offers: 'العروض', new: 'وصل حديثًا', cats: 'الأقسام', master: 'الأعلى مبيعًا', occ: 'المناسبات', notes: 'النوتات العطرية', soon: 'قريبًا', stores: 'المتاجر' };\n" +
      "  var STYLE_ID = 'elan-design-style';\n" +
      '  var CSS = [\n' +
      "    '.elan-block{max-width:900px;margin:18px auto;padding:0 16px;box-sizing:border-box}',\n" +
      "    '.elan-align-start{text-align:start}.elan-align-center{text-align:center}.elan-align-end{text-align:end}',\n" +
      "    '.elan-text p{margin:0;line-height:1.9;white-space:pre-line}',\n" +
      "    '.elan-size-sm p,.elan-size-sm h3{font-size:14px}.elan-size-md p,.elan-size-md h3{font-size:17px}',\n" +
      "    '.elan-size-lg p,.elan-size-lg h3{font-size:22px}.elan-size-xl p,.elan-size-xl h3{font-size:30px}',\n" +
      "    '.elan-banner{position:relative;overflow:hidden;border-radius:14px;padding:36px 20px;background-size:cover;background-position:center}',\n" +
      `    '.elan-banner:before{content:"";position:absolute;inset:0;background:rgba(20,12,4,.35)}',\n` +
      "    '.elan-banner>*{position:relative}.elan-banner h3,.elan-banner p{margin:6px 0;color:#fff}',\n" +
      "    '.elan-image img{max-width:100%;height:auto;display:block;margin:0 auto;border-radius:12px}',\n" +
      "    '.elan-block a{color:inherit;text-decoration:none;display:block}',\n" +
      "    '.elan-smart{max-width:1200px}.elan-smart h3{margin:0 0 12px;text-align:start}'\n" +
      "  ].join('\\n');\n" +
      '\n' +
      "  function lang() { return document.documentElement.lang === 'en' ? 'en' : 'ar'; }\n" +
      "  function pick(o) { return o ? (o[lang()] || o.ar || o.en || '') : ''; }\n" +
      '\n' +
      '  function ensureStyle() {\n' +
      '    if (document.getElementById(STYLE_ID)) return;\n' +
      "    var s = document.createElement('style');\n" +
      '    s.id = STYLE_ID;\n' +
      '    s.textContent = CSS;\n' +
      '    document.head.appendChild(s);\n' +
      '  }\n' +
      '\n' +
      '  function el(tag, cls) {\n' +
      '    var e = document.createElement(tag);\n' +
      '    if (cls) e.className = cls;\n' +
      '    return e;\n' +
      '  }\n' +
      '\n' +
      '\n' +
      '  // ----- smart sections: definition + items live in Supabase (public read; RLS hides archived/expired ones) -----\n' +
      '  var smartCache = {};\n' +
      '  window.ElanPendingSections = window.ElanPendingSections || {};   // edit mode only: drafts not saved yet\n' +
      '  function perfumeBy(id) { try { return PERFUMES.filter(function (x) { return String(x.id) === String(id); })[0] || null; } catch (e) { return null; } }\n' +
      '  function autoList(f) {\n' +
      '    f = f || {};\n' +
      '    var l = [];\n' +
      '    try { l = PERFUMES.map(function (p) { return { p: p, b: best(p) }; }).filter(function (x) { return x.b; }); } catch (e) { return []; }\n' +
      '    l = l.filter(function (x) {\n' +
      '      var p = x.p;\n' +
      '      if (f.brand && p.brand !== f.brand) return false;\n' +
      "      if (f.cat && !(p.cats || []).some(function (i) { return nmOf('cats', i) === f.cat; })) return false;\n" +
      "      if (f.occ && !(p.occs || []).some(function (i) { return nmOf('occ', i) === f.occ; })) return false;\n" +
      "      if (f.note && !(p.notes || []).some(function (i) { return nmOf('notes', i) === f.note; })) return false;\n" +
      '      if (f.store && !p.offers.some(function (o) { return o.store === f.store; })) return false;\n' +
      '      if (f.flag && !p.offers.some(function (o) { return (o.flags || []).indexOf(f.flag) > -1; })) return false;\n' +
      "      if (f.min !== undefined && f.min !== '' && x.b.price < +f.min) return false;\n" +
      "      if (f.max !== undefined && f.max !== '' && x.b.price > +f.max) return false;\n" +
      '      return true;\n' +
      '    });\n' +
      "    if (f.sort === 'price_asc') l.sort(function (a, b) { return a.b.price - b.b.price; });\n" +
      "    else if (f.sort === 'price_desc') l.sort(function (a, b) { return b.b.price - a.b.price; });\n" +
      '    else l.sort(function (a, b) { return (b.p.rel || 0) - (a.p.rel || 0); });\n' +
      '    return l.slice(0, Math.max(1, Math.min(24, +f.limit || 12)));\n' +
      '  }\n' +
      '  function manualList(ids) {\n' +
      '    return ids.map(perfumeBy).filter(Boolean).map(function (p) { return { p: p, b: best(p) }; });\n' +
      '  }\n' +
      '  function paint(root, name, list) {\n' +
      "    root.textContent = '';\n" +
      "    if (name) { var h = el('h3'); h.textContent = name; root.appendChild(h); }\n" +
      "    var g = el('div', 'grid section-perfume-grid');\n" +
      "    g.innerHTML = list.map(function (x) { return pc(x); }).join('');   // pc() output is built from the storefront's own escaped data\n" +
      '    root.appendChild(g);\n' +
      '  }\n' +
      '  function fillSmart(root, ref) {\n' +
      '    var pend = window.ElanPendingSections[ref];\n' +
      "    if (pend) { paint(root, pend.name, pend.mode === 'auto' ? autoList(pend.filters) : manualList(pend.items || [])); return; }\n" +
      "    if (typeof SB === 'undefined' || !SB || !SB.url) { root.remove(); return; }\n" +
      '    var hit = smartCache[ref];\n' +
      '    if (hit && Date.now() - hit.t < 60000) { if (hit.def) paint(root, hit.def.name, hit.list()); else root.remove(); return; }\n' +
      "    var H = { apikey: SB.key, Authorization: 'Bearer ' + SB.key };\n" +
      "    fetch(SB.url + '/rest/v1/editor_sections?element_id=eq.' + encodeURIComponent(ref) + '&select=id,name,selection_mode,filters&limit=1', { headers: H })\n" +
      '      .then(function (r) { return r.ok ? r.json() : []; })\n' +
      '      .then(function (rows) {\n' +
      '        if (!rows.length) { smartCache[ref] = { t: Date.now(), def: null }; root.remove(); return null; }\n' +
      '        var def = rows[0];\n' +
      "        if (def.selection_mode === 'auto') { smartCache[ref] = { t: Date.now(), def: def, list: function () { return autoList(def.filters); } }; paint(root, def.name, autoList(def.filters)); return null; }\n" +
      "        return fetch(SB.url + '/rest/v1/editor_section_items?section_id=eq.' + def.id + '&select=product_size_id&order=sort_order', { headers: H })\n" +
      '          .then(function (r) { return r.ok ? r.json() : []; })\n' +
      '          .then(function (items) { var ids = items.map(function (i) { return i.product_size_id; }); smartCache[ref] = { t: Date.now(), def: def, list: function () { return manualList(ids); } }; paint(root, def.name, manualList(ids)); });\n' +
      '      })\n' +
      '      .catch(function () { root.remove(); });\n' +
      '  }\n' +
      '\n' +
      '  function buildBlock(b) {\n' +
      '    var st = b.style || {};\n' +
      "    var root = el('div', 'elan-block elan-' + b.type + ' elan-size-' + (st.size || 'md') + ' elan-align-' + (st.align || 'center'));\n" +
      "    root.setAttribute('data-elan-id', b.id);\n" +
      "    root.setAttribute('data-elan-custom', '1');\n" +
      '    if (st.color) root.style.color = st.color;\n' +
      '    if (st.background) root.style.backgroundColor = st.background;\n' +
      '    var inner = root;\n' +
      "    if (b.href && b.type !== 'smart') {\n" +
      "      var a = el('a');\n" +
      "      a.setAttribute('href', b.href);\n" +
      '      root.appendChild(a);\n' +
      '      inner = a;\n' +
      '    }\n' +
      "    if (b.type === 'smart') {\n" +
      "      root.classList.add('elan-smart');\n" +
      '      fillSmart(root, b.ref);\n' +
      "    } else if (b.type === 'text') {\n" +
      "      var p = el('p');\n" +
      '      p.textContent = pick(b.text);\n' +
      '      inner.appendChild(p);\n' +
      "    } else if (b.type === 'banner') {\n" +
      `      if (b.image) root.style.backgroundImage = 'url("' + b.image + '")';\n` +
      '      var t = pick(b.title);\n' +
      '      var s = pick(b.subtitle);\n' +
      "      if (t) { var h = el('h3'); h.textContent = t; inner.appendChild(h); }\n" +
      "      if (s) { var sp = el('p'); sp.textContent = s; inner.appendChild(sp); }\n" +
      "    } else if (b.type === 'image') {\n" +
      "      var img = el('img');\n" +
      "      img.setAttribute('src', b.src);\n" +
      "      img.setAttribute('alt', pick(b.alt));\n" +
      "      img.setAttribute('loading', 'lazy');\n" +
      '      inner.appendChild(img);\n' +
      '    }\n' +
      '    return root;\n' +
      '  }\n' +
      '\n' +
      '  function hash(str) { var h = 5381, i; for (i = 0; i < str.length; i++) h = ((h << 5) + h + str.charCodeAt(i)) >>> 0; return h.toString(36); }\n' +
      '\n' +
      '  /* Every element the editor can touch, with a stable id that does not change between renders. */\n' +
      "  var SERIF = { 'Amiri': 1, 'Noto Naskh Arabic': 1, 'Playfair Display': 1, 'Cormorant Garamond': 1, 'Libre Baskerville': 1, 'Merriweather': 1, 'Georgia': 1, 'Times New Roman': 1 };\n" +
      '  var loadedFonts = {};\n' +
      '  function loadFont(name) {                       // adds one Google Fonts stylesheet per web font that is actually used\n' +
      '    if (loadedFonts[name] || ED.WEB_FONTS.indexOf(name) === -1) return;\n' +
      '    loadedFonts[name] = 1;\n' +
      "    var l = document.createElement('link'); l.rel = 'stylesheet';\n" +
      "    l.href = 'https://fonts.googleapis.com/css2?family=' + name.replace(/ /g, '+') + ':wght@400;700&display=swap';\n" +
      '    document.head.appendChild(l);\n' +
      '  }\n' +
      '  function elements() {\n' +
      '    var out = [], seen = {};\n' +
      '    function add(id, el, kind, name) { if (!el || seen[id]) return; seen[id] = 1; out.push({ id: id, el: el, kind: kind, name: name }); }\n' +
      "    var hero = document.getElementById('hero');\n" +
      '    if (hero) {\n' +
      "      add('hero', hero, 'hero', 'الواجهة الرئيسية');\n" +
      "      add('hero:magic', hero.querySelector('.magic'), 'hero-text', 'نص الواجهة');\n" +
      "      add('hero:counters', hero.querySelector('.counters'), 'hero-counters', 'العدّادات');\n" +
      '    }\n' +
      "    var V = document.getElementById('view');\n" +
      "    if (V && document.body.classList.contains('inner')) {\n" +
      "      var pk = hash(pageKey() || 'page'), vn = 0;\n" +
      "      var vt = V.querySelector('h3'); if (vt) add('pg:' + pk + ':title', vt, 'title', 'عنوان الصفحة');\n" +
      "      Array.prototype.slice.call(V.querySelectorAll('[data-elan-custom]')).forEach(function (b) { add(b.getAttribute('data-elan-id'), b, 'block', 'بلوك إضافي'); });\n" +
      "      Array.prototype.slice.call(V.querySelectorAll('.card')).forEach(function (card, i) {\n" +
      "        var base = 'pcard:' + pk + hash(card.getAttribute('data-go') || 'i' + i), id = base;\n" +
      "        while (seen[id]) id = base + '-' + (++vn);\n" +
      "        var h4 = card.querySelector('h4');\n" +
      "        add(id, card, 'card', 'كارت ' + ((h4 && h4.textContent.trim().slice(0, 24)) || (i + 1)));\n" +
      '      });\n' +
      '    }\n' +
      "    var main = document.getElementById('main');\n" +
      '    if (!main) return out;\n' +
      '    Array.prototype.slice.call(main.children).forEach(function (c) {\n' +
      "      if (c.hasAttribute('data-elan-custom')) { add(c.getAttribute('data-elan-id'), c, 'block', 'بلوك إضافي'); return; }\n" +
      "      if (c.tagName !== 'SECTION' || !c.id || ED.BUILTIN.indexOf(c.id) === -1) return;\n" +
      '      add('... 10270 more characters
    
  code: 'ERR_ASSERTION'
  name: 'AssertionError'
  expected:
  actual: |-
    /* Élan Scents — storefront design layer.
       Reads /design/home.json and applies it on top of the existing page after every render().
       Safe by construction: if the file is missing, invalid or empty, the page is left exactly as it is. */
    (function () {
      'use strict';
      var ED = window.ElanDesign;
      if (!ED) return;
    
      var design = null;
      var editing = false;
      var touched = [];
      var lastDevice = null;
      var SEC_NAMES = { brands: 'الماركات', offers: 'العروض', new: 'وصل حديثًا', cats: 'الأقسام', master: 'الأعلى مبيعًا', occ: 'المناسبات', notes: 'النوتات العطرية', soon: 'قريبًا', stores: 'المتاجر' };
      var STYLE_ID = 'elan-design-style';
      var CSS = [
        '.elan-block{max-width:900px;margin:18px auto;padding:0 16px;box-sizing:border-box}',
        '.elan-align-start{text-align:start}.elan-align-center{text-align:center}.elan-align-end{text-align:end}',
        '.elan-text p{margin:0;line-height:1.9;white-space:pre-line}',
        '.elan-size-sm p,.elan-size-sm h3{font-size:14px}.elan-size-md p,.elan-size-md h3{font-size:17px}',
        '.elan-size-lg p,.elan-size-lg h3{font-size:22px}.elan-size-xl p,.elan-size-xl h3{font-size:30px}',
        '.elan-banner{position:relative;overflow:hidden;border-radius:14px;padding:36px 20px;background-size:cover;background-position:center}',
        '.elan-banner:before{content:"";position:absolute;inset:0;background:rgba(20,12,4,.35)}',
        '.elan-banner>*{position:relative}.elan-banner h3,.elan-banner p{margin:6px 0;color:#fff}',
        '.elan-image img{max-width:100%;height:auto;display:block;margin:0 auto;border-radius:12px}',
        '.elan-block a{color:inherit;text-decoration:none;display:block}',
        '.elan-smart{max-width:1200px}.elan-smart h3{margin:0 0 12px;text-align:start}'
      ].join('\n');
    
      function lang() { return document.documentElement.lang === 'en' ? 'en' : 'ar'; }
      function pick(o) { return o ? (o[lang()] || o.ar || o.en || '') : ''; }
    
      function ensureStyle() {
        if (document.getElementById(STYLE_ID)) return;
        var s = document.createElement('style');
        s.id = STYLE_ID;
        s.textContent = CSS;
        document.head.appendChild(s);
      }
    
      function el(tag, cls) {
        var e = document.createElement(tag);
        if (cls) e.className = cls;
        return e;
      }
    
    
      // ----- smart sections: definition + items live in Supabase (public read; RLS hides archived/expired ones) -----
      var smartCache = {};
      window.ElanPendingSections = window.ElanPendingSections || {};   // edit mode only: drafts not saved yet
      function perfumeBy(id) { try { return PERFUMES.filter(function (x) { return String(x.id) === String(id); })[0] || null; } catch (e) { return null; } }
      function autoList(f) {
        f = f || {};
        var l = [];
        try { l = PERFUMES.map(function (p) { return { p: p, b: best(p) }; }).filter(function (x) { return x.b; }); } catch (e) { return []; }
        l = l.filter(function (x) {
          var p = x.p;
          if (f.brand && p.brand !== f.brand) return false;
          if (f.cat && !(p.cats || []).some(function (i) { return nmOf('cats', i) === f.cat; })) return false;
          if (f.occ && !(p.occs || []).some(function (i) { return nmOf('occ', i) === f.occ; })) return false;
          if (f.note && !(p.notes || []).some(function (i) { return nmOf('notes', i) === f.note; })) return false;
          if (f.store && !p.offers.some(function (o) { return o.store === f.store; })) return false;
          if (f.flag && !p.offers.some(function (o) { return (o.flags || []).indexOf(f.flag) > -1; })) return false;
          if (f.min !== undefined && f.min !== '' && x.b.price < +f.min) return false;
          if (f.max !== undefined && f.max !== '' && x.b.price > +f.max) return false;
          return true;
        });
        if (f.sort === 'price_asc') l.sort(function (a, b) { return a.b.price - b.b.price; });
        else if (f.sort === 'price_desc') l.sort(function (a, b) { return b.b.price - a.b.price; });
        else l.sort(function (a, b) { return (b.p.rel || 0) - (a.p.rel || 0); });
        return l.slice(0, Math.max(1, Math.min(24, +f.limit || 12)));
      }
      function manualList(ids) {
        return ids.map(perfumeBy).filter(Boolean).map(function (p) { return { p: p, b: best(p) }; });
      }
      function paint(root, name, list) {
        root.textContent = '';
        if (name) { var h = el('h3'); h.textContent = name; root.appendChild(h); }
        var g = el('div', 'grid section-perfume-grid');
        g.innerHTML = list.map(function (x) { return pc(x); }).join('');   // pc() output is built from the storefront's own escaped data
        root.appendChild(g);
      }
      function fillSmart(root, ref) {
        var pend = window.ElanPendingSections[ref];
        if (pend) { paint(root, pend.name, pend.mode === 'auto' ? autoList(pend.filters) : manualList(pend.items || [])); return; }
        if (typeof SB === 'undefined' || !SB || !SB.url) { root.remove(); return; }
        var hit = smartCache[ref];
        if (hit && Date.now() - hit.t < 60000) { if (hit.def) paint(root, hit.def.name, hit.list()); else root.remove(); return; }
        var H = { apikey: SB.key, Authorization: 'Bearer ' + SB.key };
        fetch(SB.url + '/rest/v1/editor_sections?element_id=eq.' + encodeURIComponent(ref) + '&select=id,name,selection_mode,filters&limit=1', { headers: H })
          .then(function (r) { return r.ok ? r.json() : []; })
          .then(function (rows) {
            if (!rows.length) { smartCache[ref] = { t: Date.now(), def: null }; root.remove(); return null; }
            var def = rows[0];
            if (def.selection_mode === 'auto') { smartCache[ref] = { t: Date.now(), def: def, list: function () { return autoList(def.filters); } }; paint(root, def.name, autoList(def.filters)); return null; }
            return fetch(SB.url + '/rest/v1/editor_section_items?section_id=eq.' + def.id + '&select=product_size_id&order=sort_order', { headers: H })
              .then(function (r) { return r.ok ? r.json() : []; })
              .then(function (items) { var ids = items.map(function (i) { return i.product_size_id; }); smartCache[ref] = { t: Date.now(), def: def, list: function () { return manualList(ids); } }; paint(root, def.name, manualList(ids)); });
          })
          .catch(function () { root.remove(); });
      }
    
      function buildBlock(b) {
        var st = b.style || {};
        var root = el('div', 'elan-block elan-' + b.type + ' elan-size-' + (st.size || 'md') + ' elan-align-' + (st.align || 'center'));
        root.setAttribute('data-elan-id', b.id);
        root.setAttribute('data-elan-custom', '1');
        if (st.color) root.style.color = st.color;
        if (st.background) root.style.backgroundColor = st.background;
        var inner = root;
        if (b.href && b.type !== 'smart') {
          var a = el('a');
          a.setAttribute('href', b.href);
          root.appendChild(a);
          inner = a;
        }
        if (b.type === 'smart') {
          root.classList.add('elan-smart');
          fillSmart(root, b.ref);
        } else if (b.type === 'text') {
          var p = el('p');
          p.textContent = pick(b.text);
          inner.appendChild(p);
        } else if (b.type === 'banner') {
          if (b.image) root.style.backgroundImage = 'url("' + b.image + '")';
          var t = pick(b.title);
          var s = pick(b.subtitle);
          if (t) { var h = el('h3'); h.textContent = t; inner.appendChild(h); }
          if (s) { var sp = el('p'); sp.textContent = s; inner.appendChild(sp); }
        } else if (b.type === 'image') {
          var img = el('img');
          img.setAttribute('src', b.src);
          img.setAttribute('alt', pick(b.alt));
          img.setAttribute('loading', 'lazy');
          inner.appendChild(img);
        }
        return root;
      }
    
      function hash(str) { var h = 5381, i; for (i = 0; i < str.length; i++) h = ((h << 5) + h + str.charCodeAt(i)) >>> 0; return h.toString(36); }
    
      /* Every element the editor can touch, with a stable id that does not change between renders. */
      var SERIF = { 'Amiri': 1, 'Noto Naskh Arabic': 1, 'Playfair Display': 1, 'Cormorant Garamond': 1, 'Libre Baskerville': 1, 'Merriweather': 1, 'Georgia': 1, 'Times New Roman': 1 };
      var loadedFonts = {};
      function loadFont(name) {                       // adds one Google Fonts stylesheet per web font that is actually used
        if (loadedFonts[name] || ED.WEB_FONTS.indexOf(name) === -1) return;
        loadedFonts[name] = 1;
        var l = document.createElement('link'); l.rel = 'stylesheet';
        l.href = 'https://fonts.googleapis.com/css2?family=' + name.replace(/ /g, '+') + ':wght@400;700&display=swap';
        document.head.appendChild(l);
      }
      function elements() {
        var out = [], seen = {};
        function add(id, el, kind, name) { if (!el || seen[id]) return; seen[id] = 1; out.push({ id: id, el: el, kind: kind, name: name }); }
        var hero = document.getElementById('hero');
        if (hero) {
          add('hero', hero, 'hero', 'الواجهة الرئيسية');
          add('hero:magic', hero.querySelector('.magic'), 'hero-text', 'نص الواجهة');
          add('hero:counters', hero.querySelector('.counters'), 'hero-counters', 'العدّادات');
        }
        var V = document.getElementById('view');
        if (V && document.body.classList.contains('inner')) {
          var pk = hash(pageKey() || 'page'), vn = 0;
          var vt = V.querySelector('h3'); if (vt) add('pg:' + pk + ':title', vt, 'title', 'عنوان الصفحة');
          Array.prototype.slice.call(V.querySelectorAll('[data-elan-custom]')).forEach(function (b) { add(b.getAttribute('data-elan-id'), b, 'block', 'بلوك إضافي'); });
          Array.prototype.slice.call(V.querySelectorAll('.card')).forEach(function (card, i) {
            var base = 'pcard:' + pk + hash(card.getAttribute('data-go') || 'i' + i), id = base;
            while (seen[id]) id = base + '-' + (++vn);
            var h4 = card.querySelector('h4');
            add(id, card, 'card', 'كارت ' + ((h4 && h4.textContent.trim().slice(0, 24)) || (i + 1)));
          });
        }
        var main = document.getElementById('main');
        if (!main) return out;
        Array.prototype.slice.call(main.children).forEach(function (c) {
          if (c.hasAttribute('data-elan-custom')) { add(c.getAttribute('data-elan-id'), c, 'block', 'بلوك إضافي'); return; }
          if (c.tagName !== 'SECTION' || !c.id || ED.BUILTIN.indexOf(c.id) === -1) return;
          add('sec:' + c.id, c, 'section', 'سيكشن ' + (SEC_NAMES[c.id] || c.id));
          add('sec:' + c.id + ':title', c.querySelector('h3'), 'title', 'عنوان ' + (SEC_NAMES[c.id] || c.id));
          var n = 0;
          Array.prototype.slice.call(c.querySelectorAll('.card')).forEach(function (card, i) {
            var base = 'card:' + hash(c.id + '|' + (card.getAttribute('data-go') || 'i' + i)), id = base;
            while (seen[id]) id = base + '-' + (++n);
            var h4 = card.querySelector('h4');
            add(id, card, 'card', 'كارت ' + ((h4 && h4.textContent.trim().slice(0, 24)) || (i + 1)));
          });
        });
        return out;
      }
    
      function textTarget(e) {
        if (e.kind === 'title') return e.el;
        if (e.kind === 'hero-text') return e.el.querySelector('h2');
        if (e.kind === 'card') return e.el.querySelector('h4');
        if (e.kind === 'block') return e.el.querySelector('p, h3');
        return null;
      }
    
      function unpaint(el) {
        if (el.__elanBase !== undefined) {
          if (el.__elanBase) el.setAttribute('style', el.__elanBase); else el.removeAttribute('style');
          delete el.__elanBase; el.removeAttribute('data-elan-edited');
        }
        if (el.__elanText) { el.__elanText.node.textContent = el.__elanText.value; delete el.__elanText; }
        if (el.__elanStrip) { var st = el.__elanStrip; if (st.base) st.node.setAttribute('style', st.base); else st.node.removeAttribute('style'); delete el.__elanStrip; }
      }
    
      function paint(entry, ed) {
        var el = entry.el, st = ed.style || {};
        el.__elanBase = el.getAttribute('style') || '';
        el.setAttribute('data-elan-edited', '1');
        if (ed.hidden || ed.archived) { el.style.display = 'none'; return; }
        if (ed.dx || ed.dy) {
          el.style.transform = 'translate(' + (ed.dx || 0) + 'px,' + (ed.dy || 0) + 'px)';
          el.style.position = el.style.position || 'relative';
          el.style.zIndex = '3';
          var strip = entry.kind === 'card' && el.closest('.strip');
          if (strip && !el.__elanStrip) { el.__elanStrip = { node: strip, base: strip.getAttribute('style') || '' }; strip.style.overflow = 'visible'; }
        }
        if (ed.w) { el.style.width = ed.w + 'px'; el.style.maxWidth = 'none'; el.style.flex = '0 0 auto'; }
        if (ed.h) { el.style.height = ed.h + 'px'; }
        if (st.color) el.style.color = st.color;
        if (st.background) el.style.backgroundColor = st.background;
        if (st.media) {
          el.style.backgroundImage = 'url("' + st.media.replace(/([\\"'])/g, '\\$1') + '")';
          el.style.backgroundSize = st.fit === 'contain' ? 'contain' : 'cover';
          el.style.backgroundPosition = 'center';
          el.style.backgroundRepeat = 'no-repeat';
        }
        if (st.fontSize) el.style.fontSize = st.fontSize + 'px';
        if (st.weight) el.style.fontWeight = String(st.weight);
        if (st.radius !== undefined) el.style.borderRadius = st.radius + 'px';
        if (st.align) el.style.textAlign = ({ start: 'start', end: 'end', center: 'center', left: 'left', right: 'right' })[st.align] || 'center';
        if (st.fontFamily) { loadFont(st.fontFamily); el.style.fontFamily = '"' + st.fontFamily + '", ' + (SERIF[st.fontFamily] ? 'serif' : 'sans-serif'); }
        if (st.effect === 'soft') { el.style.textShadow = '0 1px 0 #fff,0 3px 4px rgba(0,0,0,.22)'; el.style.boxShadow = '0 7px 18px rgba(0,0,0,.14)'; }
        if (st.effect === 'gold') { el.style.color = st.color || '#ae852e'; el.style.textShadow = '0 1px 0 #fceab1,0 2px 0 #77541e,0 4px 6px rgba(80,52,0,.3)'; el.style.boxShadow = '0 2px 0 #d6bc79,0 9px 22px rgba(101,72,18,.22)'; }
        if (st.effect === 'deep') { el.style.textShadow = '1px 1px 0 rgba(255,255,255,.6),2px 3px 3px rgba(0,0,0,.3)'; el.style.boxShadow = '0 4px 0 rgba(0,0,0,.13),0 14px 26px rgba(0,0,0,.2)'; }
        if (st.opacity !== undefined) el.style.opacity = String(st.opacity);
        if (ed.text) {
          var node = textTarget(entry), t = ed.text[lang()] || ed.text.ar || ed.text.en;
          if (node && t) { el.__elanText = { node: node, value: node.textContent }; node.textContent = t; }
        }
      }
    
      /* Free-form edits for the current screen size. Idempotent: always undo the last paint first. */
      function applyEdits() {
        touched.forEach(unpaint);
        touched = [];
        if (!design || !design.edits) return;
        var dev = ED.deviceOf(window.innerWidth);
        elements().forEach(function (entry) {
          var ed = ED.editFor(design, dev, entry.id);
          if (!ed) return;
          paint(entry, ed);
          touched.push(entry.el);
        });
      }
    
      function apply() {
        var main = document.getElementById('main');
        if (!main || !design) return;
        if (ED.isEmpty(design)) { applyEdits(); return; }
    
        // Idempotent: drop what we added before, then re-apply on the freshly rendered page.
        Array.prototype.slice.call(main.querySelectorAll('[data-elan-custom]')).forEach(function (n) { n.remove(); });
    
        var nodes = {};
        var present = [];
        Array.prototype.slice.call(main.children).forEach(function (c) {
          if (c.tagName === 'SECTION' && c.id && ED.BUILTIN.indexOf(c.id) !== -1) { nodes[c.id] = c; present.push(c.id); }
        });
    
        var plan = ED.plan(design, present, lang());
    
        plan.hide.forEach(function (id) {
          nodes[id].setAttribute('data-elan-hidden', '1');
          if (editing) nodes[id].style.opacity = '.4'; else nodes[id].style.display = 'none';
        });
        Object.keys(plan.titles).forEach(function (id) {
          var h = nodes[id].querySelector('h3');
          if (h) h.textContent = plan.titles[id];
        });
        plan.blocks.forEach(function (b) { nodes[b.id] = buildBlock(b); });
    
        // Only touch the order when the design asks for it or adds blocks.
        plan.order.forEach(function (id) { if (nodes[id]) main.appendChild(nodes[id]); });
        applyEdits(); // free-form edits from the visual editor, for the current screen size
      }
    
    
      // Inner pages (brands, stores, categories, occasions, notes, collections): blocks go at the top or bottom of #view.
      function pageKey() {
        if (!document.body.classList.contains('inner')) return 'home';
        try {
          var x = P[P.length - 1];
          if (!x) return null;
          if (x.k === 'sec') return 'sec:' + x.id;
          if (x.k === 'col') return 'col:' + x.id + ':' + x.i;
          if (x.k === 'brand') return 'brand:' + x.n;
          if (x.k === 'store') return 'store:' + x.n;
        } catch (e) { /* no page stack yet */ }
        return null;
      }
    
      function applyPage() {
        var V = document.getElementById('view');
        if (!V || !design) return;
        Array.prototype.slice.call(V.querySelectorAll('[data-elan-custom]')).forEach(function (n) { n.remove(); });
        var key = pageKey(), pg = design.pages && key && design.pages[key];
        if (!pg) return;
        var top = pg.blocks.filter(function (b) { return b.slot !== 'bottom'; });
        var bottom = pg.blocks.filter(function (b) { return b.slot === 'bottom'; });
        var h = V.querySelector('h3'), ref = h || null;
        top.forEach(function (b) {
          var n = buildBlock(b);
          if (ref) { ref.parentNode.insertBefore(n, ref.nextSibling); ref = n; } else { V.insertBefore(n, V.firstChild); ref = n; }
        });
        bottom.forEach(function (b) { V.appendChild(buildBlock(b)); });
      }
    
      /* An element that opens another page when a visitor clicks it (cards, lists): its go-target, or null. */
      function goTargetOf(el) {
        var n = el && el.closest ? el.closest('[data-go]') : null;
        return n ? n.getAttribute('data-go') : null;
      }
    
      function wrapView() {
        var orig = window.view;
        if (typeof orig !== 'function' || orig.__elanDesign) return;
        var wrapped = function () {
          var r = orig.apply(this, arguments);
          try { applyPage(); applyEdits(); } catch (e) { console.error('design layer', e); }
          return r;
        };
        wrapped.__elanDesign = true;
        window.view = wrapped;
      }
    
      function waitFor(test, cb, timeoutMs) {
        var t0 = Date.now();
        (function tick() {
          if (test()) return cb();
          if (Date.now() - t0 > timeoutMs) return;
          setTimeout(tick, 60);
        })();
      }
    
      function wrapRender() {
        var orig = window.render;
        if (typeof orig !== 'function' || orig.__elanDesign) return;
        var wrapped = function () {
          var r = orig.apply(this, arguments);
          try { apply(); } catch (e) { console.error('design layer', e); }
          return r;
        };
        wrapped.__elanDesign = true;
        window.render = wrapped;
      }
    
      function start(json) {
        var n = ED.normalize(json, { strict: false });
        if (!n.ok || ED.isEmpty(n.design)) return; // nothing to do: page stays untouched
        design = n.design;
        ensureStyle();
        if (typeof D === 'object' && D) ED.applyTexts(D, design);
        wrapRender(); wrapView();
        if (typeof window.render === 'function') window.render();
        if (document.body.classList.contains('inner') && typeof window.view === 'function') window.view();
      }
    
      // Used only by the editor's edit mode: swap in a draft design and redraw. Customers never call this.
      function set(json, opts) {
        var n = ED.normalize(json, { strict: false });
        if (!n.ok) return false;
        editing = !!(opts && opts.editing);
        design = n.design;
        ensureStyle();
        if (typeof D === 'object' && D) ED.applyTexts(D, design);
        wrapRender(); wrapView();
        if (typeof window.render === 'function') window.render();
        if (document.body.classList.contains('inner') && typeof window.view === 'function') window.view();
        return true;
      }
    
      window.ElanDesignLayer = { apply: apply, set: set, pageKey: pageKey, current: function () { return design; }, applyEdits: applyEdits, elements: elements, textTarget: textTarget, goTargetOf: goTargetOf };
    
      // A different screen size means a different set of free-form edits.
      window.addEventListener('resize', function () {
        if (!design || !design.edits) return;
        var d = ED.deviceOf(window.innerWidth);
        if (d !== lastDevice) { lastDevice = d; try { applyEdits(); } catch (e) { /* keep the page usable */ } }
      });
      lastDevice = ED.deviceOf(window.innerWidth);
    
      fetch('/design/home.json', { cache: 'no-store' })
        .then(function (r) { return r.ok ? r.json() : null; })
        .then(function (json) {
          if (!json) return;
          waitFor(function () { return typeof window.render === 'function' && document.getElementById('main'); },
            function () { start(json); }, 15000);
        })
        .catch(function () { /* design is optional */ });
    })();
    
  operator: 'match'
  stack: |-
    TestContext.<anonymous> (/home/ubuntu/elan-scents/tests/editor-format-panel.test.js:30:10)
    Test.runInAsyncScope (node:async_hooks:211:14)
    Test.run (node:internal/test_runner/test:931:25)
    Test.processPendingSubtests (node:internal/test_runner/test:629:18)
    Test.postRun (node:internal/test_runner/test:1042:19)
    Test.run (node:internal/test_runner/test:970:12)
    async Test.processPendingSubtests (node:internal/test_runner/test:629:7)
  ...
# Subtest: the library button opens the archive and image library in live mode
not ok 61 - the library button opens the archive and image library in live mode
  ---
  duration_ms: 3.287047
  location: '/home/ubuntu/elan-scents/tests/editor-format-panel.test.js:34:1'
  failureType: 'testCodeFailure'
  error: |-
    The input did not match the regular expression /\['library',\(\)=>openLiveLibrary\(\)\]/. Input:
    
    `<!doctype html><html lang="ar" dir="rtl"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>محرر إيلان — بداية جديدة</title><style>*{box-sizing:border-box}body{margin:0;font-family:Tahoma,Arial;background:#eae7e1;color:#222}header{height:68px;background:#191919;color:#eeddb8;display:flex;align-items:center;gap:10px;padding:12px 20px;position:sticky;top:0;z-index:5}button,input,select{font:inherit}button{cursor:pointer;border:1px solid #c2a66a;border-radius:7px;padding:9px 13px;background:#fffaf0;color:#29251c}header strong{margin-left:auto}#status{font-size:12px;color:#ddd}#hint{padding:12px;text-align:center;font-size:13px;line-height:1.7}#viewport{overflow:auto;padding:20px;height:calc(100vh - 125px)}#canvas{width:1100px;height:900px;position:relative;background:#fffdf9;box-shadow:0 8px 40px #0001;margin:0 auto;direction:rtl}.item{position:absolute;touch-action:none;outline:none;overflow:hidden}.item.selected{outline:2px solid #a88032;overflow:visible}.content{width:100%;height:100%;overflow:hidden}.text .content{white-space:pre-wrap;line-height:1.4;cursor:move}.editing .content{cursor:text;user-select:text;overflow:auto}.image img{width:100%;height:100%;object-fit:cover;pointer-events:none}.card .content{padding:22px;border:1px solid #bd9c57;border-radius:16px;box-shadow:0 8px 20px #0001;background:#fffdf8}.handle{position:absolute;width:13px;height:13px;background:#fff;border:2px solid #a88032;right:-7px;bottom:-7px;cursor:nwse-resize;z-index:3;display:none;touch-action:none}.selected .handle{display:block}#menu{display:none;position:fixed;z-index:20;width:220px;max-height:80vh;overflow:auto;padding:8px;border:1px solid #b59655;border-radius:12px;background:#fff;box-shadow:0 10px 35px #0003}#menu button{display:block;width:100%;text-align:right;margin:4px 0}dialog{border:1px solid #c0a064;border-radius:14px;padding:24px;max-width:95vw;max-height:90vh;overflow:auto}dialog::backdrop{background:#0005}label{display:block;margin:12px 0}input,select,textarea{padding:8px;border:1px solid #ccb98d;border-radius:6px;max-width:100%}#archiveList button{display:block;margin:8px 0}small{display:block;line-height:1.7;color:#666}button:disabled{opacity:.4;cursor:default}</style></head><body><header><strong>Élan Scents · محرر تجريبي جديد</strong><button id="undo">↶ تراجع</button><button id="redo">↷ إعادة</button><button id="save">حفظ</button><button id="library">المكتبة</button><span id="status">حفظ محلي فقط</span></header><div id="hint">كليك شمال للتحديد والسحب. اسحب المقبض لتغيير الحجم. كليك يمين للأدوات. اضغط مرتين على النص واكتب بالكيبورد. هذه مساحة اختبار ثابتة، وليست منصة متصلة.</div><div id="viewport"><div id="canvas"></div></div><div id="menu"></div><input id="upload" type="file" accept="image/*,video/*" hidden><dialog id="format"><h3>تنسيق العنصر</h3><label>الخط <select id="font"><option>Tahoma</option><option>Arial</option><option>Georgia</option><option>Times New Roman</option><option>Verdana</option></select></label><label>حجم الخط <input id="size" type="number" min="8" max="160"></label><label>لون النص <input id="color" type="color"></label><label>لون الخلفية <input id="bg" type="color"></label><label>المحاذاة <select id="align"><option value="right">يمين</option><option value="center">وسط</option><option value="left">يسار</option></select></label><button id="apply">تطبيق</button> <button onclick="this.closest('dialog').close()">إغلاق</button></dialog><dialog id="libraryDialog"><h3>المكتبة والأرشيف المحلي</h3><button id="addMedia">رفع صورة أو فيديو</button><h4>الميديا المحفوظة</h4><div id="mediaList"></div><h4>العناصر المحذوفة</h4><div id="archiveList"></div><small>للملفات الصغيرة فقط، حد الملف 1 ميجابايت. ليست مكتبة سحابية.</small><button onclick="this.closest('dialog').close()">إغلاق</button></dialog><script src="/editor/editor-data-bridge.js?v=20261014-01"></script><script>\n` +
      "const canvas=document.getElementById('canvas'),menu=document.getElementById('menu'),status=document.getElementById('status');const storageKey='elan-fresh-editor-v1';let state={items:[{id:'title',type:'text',x:280,y:90,w:540,h:110,text:'Élan Scents',font:'Georgia',size:64,color:'#a17b35',bg:'#fffdf9',align:'center'},{id:'subtitle',type:'text',x:280,y:220,w:540,h:65,text:'سحر الخليج بين يديك',font:'Tahoma',size:30,color:'#282828',bg:'#fffdf9',align:'center'},{id:'card',type:'card',x:390,y:360,w:300,h:200,text:'كارت عطر تجريبي\\nليست بيانات متجر حقيقية',font:'Tahoma',size:22,color:'#282828',bg:'#fffdf9',align:'center'}],archive:[],media:[]};let selected=null,history=[],future=[],dirty=false,editing=false,gesture=null,replaceId=null;\n" +
      "try{const s=JSON.parse(localStorage.getItem(storageKey));if(s&&Array.isArray(s.items)&&Array.isArray(s.archive)&&Array.isArray(s.media))state=s;}catch(e){status.textContent='تعذر قراءة الحفظ السابق.';}\n" +
      "const clone=x=>JSON.parse(JSON.stringify(x));function checkpoint(){history.push(clone(state));if(history.length>30)history.shift();future=[];}function changed(){dirty=true;status.textContent='تعديلات غير محفوظة';document.getElementById('undo').disabled=!history.length;document.getElementById('redo').disabled=!future.length;}function current(){return state.items.find(i=>i.id===selected);}function uid(){return 'item-'+Date.now()+'-'+Math.random().toString(16).slice(2,8);}function select(id){selected=id;canvas.querySelectorAll('.item').forEach(el=>el.classList.toggle('selected',el.dataset.id===id));}\n" +
      "function render(){canvas.replaceChildren();state.items.forEach(item=>{const el=document.createElement('div');el.className='item '+item.type;el.dataset.id=item.id;Object.assign(el.style,{left:item.x+'px',top:item.y+'px',width:item.w+'px',height:item.h+'px',zIndex:String(item.z||1)});const content=document.createElement('div');content.className='content';Object.assign(content.style,{fontFamily:item.font||'Tahoma',fontSize:(item.size||24)+'px',color:item.color||'#222',backgroundColor:item.bg||'#fffdf9',textAlign:item.align||'right',whiteSpace:'pre-wrap'});if(item.type==='image'){const img=document.createElement('img');img.src=item.src;img.alt='صورة في التصميم';content.append(img);}else if(item.type==='video'){const v=document.createElement('video');v.src=item.src;v.controls=true;v.style.cssText='width:100%;height:100%;object-fit:contain';content.append(v);}else content.textContent=item.text||'';el.append(content);const handle=document.createElement('div');handle.className='handle';el.append(handle);canvas.append(el);\n" +
      "el.addEventListener('pointerdown',e=>{if(e.button!==0||editing||e.target.closest('video'))return;e.preventDefault();select(item.id);menu.style.display='none';checkpoint();gesture={id:item.id,mode:e.target===handle?'resize':'move',sx:e.clientX,sy:e.clientY,x:item.x,y:item.y,w:item.w,h:item.h};el.setPointerCapture(e.pointerId);});el.addEventListener('pointermove',e=>{if(!gesture||gesture.id!==item.id)return;const dx=e.clientX-gesture.sx,dy=e.clientY-gesture.sy;if(gesture.mode==='resize'){item.w=Math.max(40,Math.min(1100-item.x,gesture.w+dx));item.h=Math.max(30,Math.min(900-item.y,gesture.h+dy));}else{item.x=Math.max(0,Math.min(1100-item.w,gesture.x+dx));item.y=Math.max(0,Math.min(900-item.h,gesture.y+dy));}Object.assign(el.style,{left:item.x+'px',top:item.y+'px',width:item.w+'px',height:item.h+'px'});changed();});function finish(){gesture=null;}el.addEventListener('pointerup',finish);el.addEventListener('pointercancel',finish);\n" +
      "el.addEventListener('dblclick',e=>{if(!['text','card'].includes(item.type))return;select(item.id);checkpoint();editing=true;el.classList.add('editing');content.contentEditable='plaintext-only';content.focus();});content.addEventListener('input',()=>{if(editing){item.text=content.innerText;changed();}});content.addEventListener('blur',()=>{content.contentEditable='false';el.classList.remove('editing');editing=false;});el.addEventListener('contextmenu',e=>{e.preventDefault();e.stopPropagation();select(item.id);showMenu(e);});});select(selected);document.getElementById('undo').disabled=!history.length;document.getElementById('redo').disabled=!future.length;}\n" +
      "function add(type,src){checkpoint();const item={id:uid(),type,x:350,y:300,w:320,h:type==='text'?90:220,text:type==='text'?'اكتب نصك هنا':'كارت جديد',font:'Tahoma',size:26,color:'#252525',bg:'#fffdf9',align:'right',src};state.items.push(item);selected=item.id;changed();render();}\n" +
      "function action(label,callback,enabled=true){const b=document.createElement('button');b.textContent=label;b.disabled=!enabled;b.onclick=()=>{menu.style.display='none';callback();};menu.append(b);}\n" +
      `function showMenu(e){menu.replaceChildren();const item=current();action('إضافة نص',()=>add('text'));action('إضافة كارت',()=>add('card'));action('إضافة صورة أو فيديو',()=>{replaceId=null;document.getElementById('upload').click();});action('تعديل النص بالكيبورد',()=>{const el=canvas.querySelector('[data-id="'+selected+'"]');el?.dispatchEvent(new MouseEvent('dblclick',{bubbles:true}));},!!item&&['text','card'].includes(item.type));action('الخط واللون والحجم',openFormat,!!item);action('تكبير الخط +',()=>resizeText(2),!!item&&['text','card'].includes(item.type));action('تصغير الخط −',()=>resizeText(-2),!!item&&['text','card'].includes(item.type));action('استبدال الصورة أو الفيديو',()=>{replaceId=selected;document.getElementById('upload').click();},!!item&&['image','video'].includes(item.type));action('نسخ العنصر',()=>{checkpoint();const copy=clone(current());copy.id=uid();copy.x=Math.min(1100-copy.w,copy.x+20);copy.y=Math.min(900-copy.h,copy.y+20);state.items.push(copy);selected=copy.id;changed();render();},!!item);action('حذف إلى الأرشيف',()=>{checkpoint();state.archive.push(clone(current()));state.items=state.items.filter(i=>i.id!==selected);selected=null;changed();render();},!!item);menu.style.display='block';const r=menu.getBoundingClientRect();menu.style.left=Math.max(4,Math.min(e.clientX,innerWidth-r.width-8))+'px';menu.style.top=Math.max(4,Math.min(e.clientY,innerHeight-r.height-8))+'px';}\n` +
      'function resizeText(d){const '... 182017 more characters
    
  code: 'ERR_ASSERTION'
  name: 'AssertionError'
  expected:
  actual: |-
    <!doctype html><html lang="ar" dir="rtl"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>محرر إيلان — بداية جديدة</title><style>*{box-sizing:border-box}body{margin:0;font-family:Tahoma,Arial;background:#eae7e1;color:#222}header{height:68px;background:#191919;color:#eeddb8;display:flex;align-items:center;gap:10px;padding:12px 20px;position:sticky;top:0;z-index:5}button,input,select{font:inherit}button{cursor:pointer;border:1px solid #c2a66a;border-radius:7px;padding:9px 13px;background:#fffaf0;color:#29251c}header strong{margin-left:auto}#status{font-size:12px;color:#ddd}#hint{padding:12px;text-align:center;font-size:13px;line-height:1.7}#viewport{overflow:auto;padding:20px;height:calc(100vh - 125px)}#canvas{width:1100px;height:900px;position:relative;background:#fffdf9;box-shadow:0 8px 40px #0001;margin:0 auto;direction:rtl}.item{position:absolute;touch-action:none;outline:none;overflow:hidden}.item.selected{outline:2px solid #a88032;overflow:visible}.content{width:100%;height:100%;overflow:hidden}.text .content{white-space:pre-wrap;line-height:1.4;cursor:move}.editing .content{cursor:text;user-select:text;overflow:auto}.image img{width:100%;height:100%;object-fit:cover;pointer-events:none}.card .content{padding:22px;border:1px solid #bd9c57;border-radius:16px;box-shadow:0 8px 20px #0001;background:#fffdf8}.handle{position:absolute;width:13px;height:13px;background:#fff;border:2px solid #a88032;right:-7px;bottom:-7px;cursor:nwse-resize;z-index:3;display:none;touch-action:none}.selected .handle{display:block}#menu{display:none;position:fixed;z-index:20;width:220px;max-height:80vh;overflow:auto;padding:8px;border:1px solid #b59655;border-radius:12px;background:#fff;box-shadow:0 10px 35px #0003}#menu button{display:block;width:100%;text-align:right;margin:4px 0}dialog{border:1px solid #c0a064;border-radius:14px;padding:24px;max-width:95vw;max-height:90vh;overflow:auto}dialog::backdrop{background:#0005}label{display:block;margin:12px 0}input,select,textarea{padding:8px;border:1px solid #ccb98d;border-radius:6px;max-width:100%}#archiveList button{display:block;margin:8px 0}small{display:block;line-height:1.7;color:#666}button:disabled{opacity:.4;cursor:default}</style></head><body><header><strong>Élan Scents · محرر تجريبي جديد</strong><button id="undo">↶ تراجع</button><button id="redo">↷ إعادة</button><button id="save">حفظ</button><button id="library">المكتبة</button><span id="status">حفظ محلي فقط</span></header><div id="hint">كليك شمال للتحديد والسحب. اسحب المقبض لتغيير الحجم. كليك يمين للأدوات. اضغط مرتين على النص واكتب بالكيبورد. هذه مساحة اختبار ثابتة، وليست منصة متصلة.</div><div id="viewport"><div id="canvas"></div></div><div id="menu"></div><input id="upload" type="file" accept="image/*,video/*" hidden><dialog id="format"><h3>تنسيق العنصر</h3><label>الخط <select id="font"><option>Tahoma</option><option>Arial</option><option>Georgia</option><option>Times New Roman</option><option>Verdana</option></select></label><label>حجم الخط <input id="size" type="number" min="8" max="160"></label><label>لون النص <input id="color" type="color"></label><label>لون الخلفية <input id="bg" type="color"></label><label>المحاذاة <select id="align"><option value="right">يمين</option><option value="center">وسط</option><option value="left">يسار</option></select></label><button id="apply">تطبيق</button> <button onclick="this.closest('dialog').close()">إغلاق</button></dialog><dialog id="libraryDialog"><h3>المكتبة والأرشيف المحلي</h3><button id="addMedia">رفع صورة أو فيديو</button><h4>الميديا المحفوظة</h4><div id="mediaList"></div><h4>العناصر المحذوفة</h4><div id="archiveList"></div><small>للملفات الصغيرة فقط، حد الملف 1 ميجابايت. ليست مكتبة سحابية.</small><button onclick="this.closest('dialog').close()">إغلاق</button></dialog><script src="/editor/editor-data-bridge.js?v=20261014-01"></script><script>
    const canvas=document.getElementById('canvas'),menu=document.getElementById('menu'),status=document.getElementById('status');const storageKey='elan-fresh-editor-v1';let state={items:[{id:'title',type:'text',x:280,y:90,w:540,h:110,text:'Élan Scents',font:'Georgia',size:64,color:'#a17b35',bg:'#fffdf9',align:'center'},{id:'subtitle',type:'text',x:280,y:220,w:540,h:65,text:'سحر الخليج بين يديك',font:'Tahoma',size:30,color:'#282828',bg:'#fffdf9',align:'center'},{id:'card',type:'card',x:390,y:360,w:300,h:200,text:'كارت عطر تجريبي\nليست بيانات متجر حقيقية',font:'Tahoma',size:22,color:'#282828',bg:'#fffdf9',align:'center'}],archive:[],media:[]};let selected=null,history=[],future=[],dirty=false,editing=false,gesture=null,replaceId=null;
    try{const s=JSON.parse(localStorage.getItem(storageKey));if(s&&Array.isArray(s.items)&&Array.isArray(s.archive)&&Array.isArray(s.media))state=s;}catch(e){status.textContent='تعذر قراءة الحفظ السابق.';}
    const clone=x=>JSON.parse(JSON.stringify(x));function checkpoint(){history.push(clone(state));if(history.length>30)history.shift();future=[];}function changed(){dirty=true;status.textContent='تعديلات غير محفوظة';document.getElementById('undo').disabled=!history.length;document.getElementById('redo').disabled=!future.length;}function current(){return state.items.find(i=>i.id===selected);}function uid(){return 'item-'+Date.now()+'-'+Math.random().toString(16).slice(2,8);}function select(id){selected=id;canvas.querySelectorAll('.item').forEach(el=>el.classList.toggle('selected',el.dataset.id===id));}
    function render(){canvas.replaceChildren();state.items.forEach(item=>{const el=document.createElement('div');el.className='item '+item.type;el.dataset.id=item.id;Object.assign(el.style,{left:item.x+'px',top:item.y+'px',width:item.w+'px',height:item.h+'px',zIndex:String(item.z||1)});const content=document.createElement('div');content.className='content';Object.assign(content.style,{fontFamily:item.font||'Tahoma',fontSize:(item.size||24)+'px',color:item.color||'#222',backgroundColor:item.bg||'#fffdf9',textAlign:item.align||'right',whiteSpace:'pre-wrap'});if(item.type==='image'){const img=document.createElement('img');img.src=item.src;img.alt='صورة في التصميم';content.append(img);}else if(item.type==='video'){const v=document.createElement('video');v.src=item.src;v.controls=true;v.style.cssText='width:100%;height:100%;object-fit:contain';content.append(v);}else content.textContent=item.text||'';el.append(content);const handle=document.createElement('div');handle.className='handle';el.append(handle);canvas.append(el);
    el.addEventListener('pointerdown',e=>{if(e.button!==0||editing||e.target.closest('video'))return;e.preventDefault();select(item.id);menu.style.display='none';checkpoint();gesture={id:item.id,mode:e.target===handle?'resize':'move',sx:e.clientX,sy:e.clientY,x:item.x,y:item.y,w:item.w,h:item.h};el.setPointerCapture(e.pointerId);});el.addEventListener('pointermove',e=>{if(!gesture||gesture.id!==item.id)return;const dx=e.clientX-gesture.sx,dy=e.clientY-gesture.sy;if(gesture.mode==='resize'){item.w=Math.max(40,Math.min(1100-item.x,gesture.w+dx));item.h=Math.max(30,Math.min(900-item.y,gesture.h+dy));}else{item.x=Math.max(0,Math.min(1100-item.w,gesture.x+dx));item.y=Math.max(0,Math.min(900-item.h,gesture.y+dy));}Object.assign(el.style,{left:item.x+'px',top:item.y+'px',width:item.w+'px',height:item.h+'px'});changed();});function finish(){gesture=null;}el.addEventListener('pointerup',finish);el.addEventListener('pointercancel',finish);
    el.addEventListener('dblclick',e=>{if(!['text','card'].includes(item.type))return;select(item.id);checkpoint();editing=true;el.classList.add('editing');content.contentEditable='plaintext-only';content.focus();});content.addEventListener('input',()=>{if(editing){item.text=content.innerText;changed();}});content.addEventListener('blur',()=>{content.contentEditable='false';el.classList.remove('editing');editing=false;});el.addEventListener('contextmenu',e=>{e.preventDefault();e.stopPropagation();select(item.id);showMenu(e);});});select(selected);document.getElementById('undo').disabled=!history.length;document.getElementById('redo').disabled=!future.length;}
    function add(type,src){checkpoint();const item={id:uid(),type,x:350,y:300,w:320,h:type==='text'?90:220,text:type==='text'?'اكتب نصك هنا':'كارت جديد',font:'Tahoma',size:26,color:'#252525',bg:'#fffdf9',align:'right',src};state.items.push(item);selected=item.id;changed();render();}
    function action(label,callback,enabled=true){const b=document.createElement('button');b.textContent=label;b.disabled=!enabled;b.onclick=()=>{menu.style.display='none';callback();};menu.append(b);}
    function showMenu(e){menu.replaceChildren();const item=current();action('إضافة نص',()=>add('text'));action('إضافة كارت',()=>add('card'));action('إضافة صورة أو فيديو',()=>{replaceId=null;document.getElementById('upload').click();});action('تعديل النص بالكيبورد',()=>{const el=canvas.querySelector('[data-id="'+selected+'"]');el?.dispatchEvent(new MouseEvent('dblclick',{bubbles:true}));},!!item&&['text','card'].includes(item.type));action('الخط واللون والحجم',openFormat,!!item);action('تكبير الخط +',()=>resizeText(2),!!item&&['text','card'].includes(item.type));action('تصغير الخط −',()=>resizeText(-2),!!item&&['text','card'].includes(item.type));action('استبدال الصورة أو الفيديو',()=>{replaceId=selected;document.getElementById('upload').click();},!!item&&['image','video'].includes(item.type));action('نسخ العنصر',()=>{checkpoint();const copy=clone(current());copy.id=uid();copy.x=Math.min(1100-copy.w,copy.x+20);copy.y=Math.min(900-copy.h,copy.y+20);state.items.push(copy);selected=copy.id;changed();render();},!!item);action('حذف إلى الأرشيف',()=>{checkpoint();state.archive.push(clone(current()));state.items=state.items.filter(i=>i.id!==selected);selected=null;changed();render();},!!item);menu.style.display='block';const r=menu.getBoundingClientRect();menu.style.left=Math.max(4,Math.min(e.clientX,innerWidth-r.width-8))+'px';menu.style.top=Math.max(4,Math.min(e.clientY,innerHeight-r.height-8))+'px';}
    function resizeText(d){const i=current();if(!i)return;checkpoint();i.size=Math.max(8,Math.min(160,(i.size||24)+d));changed();render();}
    function openFormat(){const i=current();if(!i)return;document.getElementById('font').value=i.font||'Tahoma';document.getElementById('size').value=i.size||24;document.getElementById('color').value=i.color||'#222222';document.getElementById('bg').value=i.bg||'#fffdf9';document.getElementById('align').value=i.align||'right';document.getElementById('format').showModal();}
    document.getElementById('apply').onclick=()=>{const i=current();if(!i)return;checkpoint();i.font=document.getElementById('font').value;i.size=Math.max(8,Math.min(160,Number(document.getElementById('size').value)||24));i.color=document.getElementById('color').value;i.bg=document.getElementById('bg').value;i.align=document.getElementById('align').value;changed();render();document.getElementById('format').close();};
    canvas.addEventListener('contextmenu',e=>{e.preventDefault();select(null);showMenu(e);});canvas.addEventListener('pointerdown',e=>{if(e.target===canvas){select(null);menu.style.display='none';}});document.addEventListener('pointerdown',e=>{if(!menu.contains(e.target))menu.style.display='none';});document.addEventListener('keydown',e=>{if(e.key==='Escape')menu.style.display='none';});
    document.getElementById('undo').onclick=()=>{if(!history.length)return;future.push(clone(state));state=history.pop();changed();render();};document.getElementById('redo').onclick=()=>{if(!future.length)return;history.push(clone(state));state=future.pop();changed();render();};document.getElementById('save').onclick=()=>{try{localStorage.setItem(storageKey,JSON.stringify(state));dirty=false;status.textContent='تم الحفظ في هذا المتصفح فقط';}catch(e){status.textContent='فشل الحفظ: مساحة المتصفح غير كافية';}};
    function library(){const media=document.getElementById('mediaList'),archive=document.getElementById('archiveList');media.replaceChildren();archive.replaceChildren();if(!state.media.length)media.textContent='لم تُرفع ميديا بعد.';state.media.forEach(m=>{const b=document.createElement('button');b.textContent='إضافة: '+m.name;b.onclick=()=>{add(m.type,m.src);document.getElementById('libraryDialog').close();};media.append(b);});if(!state.archive.length)archive.textContent='الأرشيف فارغ.';state.archive.forEach((i,index)=>{const b=document.createElement('button');b.textContent='استرجاع: '+(i.text?.slice(0,25)||i.type);b.onclick=()=>{checkpoint();const copy=clone(i);if(state.items.some(x=>x.id===copy.id))copy.id=uid();state.items.push(copy);state.archive.splice(index,1);selected=copy.id;changed();render();library();};archive.append(b);});if(!document.getElementById('libraryDialog').open)document.getElementById('libraryDialog').showModal();}
    document.getElementById('library').onclick=library;document.getElementById('addMedia').onclick=()=>{replaceId=null;document.getElementById('upload').click();};document.getElementById('upload').onchange=e=>{const f=e.target.files[0];if(!f)return;if(f.size>1024*1024){alert('هذه نسخة محلية: استخدم ملفًا أقل من 1 ميجابايت.');return;}if(!f.type.startsWith('image/')&&!f.type.startsWith('video/'))return;const target=replaceId;const reader=new FileReader();reader.onload=()=>{checkpoint();const type=f.type.startsWith('image/')?'image':'video';state.media.push({name:f.name,src:reader.result,type});const i=state.items.find(i=>i.id===target);if(i){i.src=reader.result;i.type=type;changed();render();}else{add(type,reader.result);}if(document.getElementById('libraryDialog').open)library();};reader.readAsDataURL(f);e.target.value='';};window.addEventListener('beforeunload',e=>{if(dirty){e.preventDefault();e.returnValue='';}});// Keep the simple editor, extend cards and visual effects.
    const extraStyle=document.createElement('style');extraStyle.textContent='.card .content{position:relative;z-index:2;background:transparent}.card .cardMedia{position:absolute;inset:0;width:100%;height:100%;object-fit:cover;border-radius:16px;z-index:1}.item.card{border-radius:16px}.item.card:not(.selected){overflow:hidden}.section .content{border-radius:16px;border:1px solid #c2a66a}.item.text{z-index:100}.item.selected{z-index:200!important}';document.head.appendChild(extraStyle);
    const effectLabel=document.createElement('label');effectLabel.textContent='تأثير ثلاثي الأبعاد ';const effectSelect=document.createElement('select');[['none','بدون تأثير'],['soft','بروز ناعم'],['gold','ذهبي بارز'],['deep','عمق واضح']].forEach(([value,label])=>{const o=document.createElement('option');o.value=value;o.textContent=label;effectSelect.append(o);});effectLabel.append(effectSelect);document.getElementById('apply').before(effectLabel);
    const fitLabel=document.createElement('label');fitLabel.textContent='عرض الصورة داخل الكارت ';const fitSelect=document.createElement('select');[['cover','ملء الكارت، مع قص الأطراف عند الحاجة'],['contain','الصورة كاملة، بدون قص']].forEach(([value,label])=>{const o=document.createElement('option');o.value=value;o.textContent=label;fitSelect.append(o);});fitLabel.append(fitSelect);document.getElementById('apply').before(fitLabel);
    const originalFormat=openFormat;openFormat=function(){originalFormat();const i=current();if(i){effectSelect.value=i.effect||'none';fitSelect.value=i.fit||'cover';}};
    const previousApply=document.getElementById('apply').onclick;document.getElementById('apply').onclick=()=>{const i=current();if(!i)return;const effect=effectSelect.value,fit=fitSelect.value;previousApply();i.effect=effect;i.fit=fit;changed();render();};
    const baseRender=render;render=function(){baseRender();state.items.forEach(i=>{const el=Array.from(canvas.children).find(e=>e.dataset.id===i.id);if(!el)return;const content=el.querySelector('.content');if(i.type==='text')el.style.zIndex=String(i.z||100);if(['card','section'].includes(i.type)){content.style.backgroundColor=i.mediaSrc?'transparent':(i.bg||'#fffdf9');if(i.mediaSrc){const media=document.createElement(i.mediaType==='video'?'video':'img');media.className='cardMedia';media.src=i.mediaSrc;if(i.mediaType==='video'){media.muted=true;media.loop=true;media.autoplay=true;media.playsInline=true;}else media.alt='ميديا الكارت';media.style.objectFit=i.fit||'contain';el.prepend(media);}}if(i.effect==='soft'){content.style.textShadow='0 1px 0 #fff,0 3px 4px rgba(0,0,0,.22)';el.style.boxShadow='0 7px 18px rgba(0,0,0,.14)';}if(i.effect==='gold'){content.style.color='#ae852e';content.style.textShadow='0 1px 0 #fceab1,0 2px 0 #77541e,0 4px 6px rgba(80,52,0,.3)';el.style.boxShadow='0 2px 0 #d6bc79,0 9px 22px rgba(101,72,18,.22)';}if(i.effect==='deep'){content.style.textShadow='1px 1px 0 rgba(255,255,255,.6),2px 3px 3px rgba(0,0,0,.3)';el.style.boxShadow='0 4px 0 rgba(0,0,0,.13),0 14px 26px rgba(0,0,0,.22)';}});};
    function addKind(kind){if(kind==='section'){add('section');const i=current();i.text='سيكشن جديد';i.w=1000;i.h=240;i.x=50;i.y=420;i.z=0;changed();render();return;}add('card');const i=current();i.kind=kind;i.text=kind==='brand'?'اسم البراند':kind==='store'?'اسم المتجر':'اسم العطر\nبيانات تجريبية';i.w=300;i.h=240;changed();render();}
    const originalShowMenu=showMenu;showMenu=function(e){originalShowMenu(e);const i=current();action('إنشاء سيكشن',()=>addKind('section'));action('إنشاء كارت براند',()=>addKind('brand'));action('إنشاء كارت متجر',()=>addKind('store'));action('إنشاء كارت عطر',()=>addKind('perfume'));action('رفع ميديا داخل الكارت',()=>{replaceId=selected;document.getElementById('upload').click();},!!i&&i.type==='card');action('نص فوق العنصر',()=>{const anchor=current();add('text');const t=current();if(anchor){t.x=anchor.x+15;t.y=anchor.y+15;t.w=Math.max(40,anchor.w-30);t.h=Math.min(90,anchor.h);}t.z=100;t.bg='#fffdf9';t.transparent=true;t.overlayOf=anchor?.id||null;changed();render();});action('خلفية نص شفافة',()=>{checkpoint();current().transparent=true;changed();render();},!!i&&i.type==='text');action('حذف ميديا الكارت',()=>{checkpoint();delete current().mediaSrc;delete current().mediaType;changed();render();},!!i&&!!i.mediaSrc);const r=menu.getBoundingClientRect();menu.style.left=Math.max(4,Math.min(e.clientX,innerWidth-r.width-8))+'px';menu.style.top=Math.max(4,Math.min(e.clientY,innerHeight-r.height-8))+'px';};
    const mediaRender=render;render=function(){mediaRender();state.items.forEach(i=>{if(i.transparent){const el=Array.from(canvas.children).find(e=>e.dataset.id===i.id);if(el)el.querySelector('.content').style.backgroundColor='transparent';}});};
    document.getElementById('upload').onchange=e=>{const f=e.target.files[0];if(!f)return;if(f.size>1024*1024){alert('حد الملف المحلي 1 ميجابايت. الفيديوهات الكبيرة تحتاج تخزينًا خارجيًا لاحقًا.');e.target.value='';return;}if(!f.type.startsWith('image/')&&!f.type.startsWith('video/'))return;const selectedItem=current();const target=replaceId||(selectedItem?.type==='card'?selectedItem.id:null);const reader=new FileReader();reader.onload=()=>{checkpoint();const type=f.type.startsWith('image/')?'image':'video';state.media.push({name:f.name,src:reader.result,type});const i=state.items.find(i=>i.id===target);if(i&&['card','section'].includes(i.type)){i.mediaSrc=reader.result;i.mediaType=type;i.fit=i.fit||'contain';changed();render();}else if(i&&['image','video'].includes(i.type)){i.src=reader.result;i.type=type;changed();render();}else add(type,reader.result);replaceId=null;if(document.getElementById('libraryDialog').open)library();};reader.readAsDataURL(f);e.target.value='';};
    const flowButton=document.createElement('button');flowButton.textContent='ترتيب تلقائي: مفعّل';let autoFlow=true;document.querySelector('header').append(flowButton);flowButton.onclick=()=>{autoFlow=!autoFlow;flowButton.textContent='ترتيب تلقائي: '+(autoFlow?'مفعّل':'متوقف');};
    function packCards(){const cards=state.items.filter(i=>i.type==='card').sort((a,b)=>a.y-b.y||a.x-b.x);if(!cards.length)return;let x=40,y=340,rowHeight=0;cards.forEach(i=>{const oldX=i.x,oldY=i.y;if(x+i.w>1060){x=40;y+=rowHeight+24;rowHeight=0;}i.x=x;i.y=y;state.items.filter(t=>t.overlayOf===i.id).forEach(t=>{t.x+=i.x-oldX;t.y+=i.y-oldY;});x+=i.w+24;rowHeight=Math.max(rowHeight,i.h);});canvas.style.height=Math.max(900,y+rowHeight+60)+'px';}
    let dragWasCard=false;let dragStartPoint=null;canvas.addEventListener('pointerdown',e=>{dragStartPoint={x:e.clientX,y:e.clientY};},true);canvas.addEventListener('pointerup',e=>{if(dragStartPoint&&Math.hypot(e.clientX-dragStartPoint.x,e.clientY-dragStartPoint.y)<4)dragWasCard=false;dragStartPoint=null;},true);canvas.addEventListener('pointerdown',e=>{const el=e.target.closest('.item');dragWasCard=!!el&&state.items.find(i=>i.id===el.dataset.id)?.type==='card'&&!e.target.classList.contains('handle');},true);canvas.addEventListener('pointerup',()=>{if(autoFlow&&dragWasCard&&!editing){packCards();changed();render();}dragWasCard=false;});
    const kindDblClick=canvas.addEventListener('dblclick',e=>{const el=e.target.closest('.item');const i=state.items.find(i=>i.id===el?.dataset.id);if(i?.type==='section'){checkpoint();editing=true;el.classList.add('editing');const c=el.querySelector('.content');c.contentEditable='plaintext-only';c.focus();}});
    document.getElementById('hint').textContent='حدد الكارت ثم كليك يمين لرفع الميديا داخله. النص طبقة مستقلة فوق العناصر. ترتيب تلقائي يرص الكروت بعد سحبها، ويمكن إيقافه. الحفظ محلي، مساحة اختبار ثابتة.';
    // Visible version marker and direct access to the requested functions.
    document.querySelector('header strong').textContent='Élan Scents · النسخة 3 — ميديا داخل الكارت';
    const quick=document.createElement('div');quick.style.cssText='display:flex;gap:8px;flex-wrap:wrap;justify-content:center;padding:10px;background:#f6f0e4';document.getElementById('hint').after(quick);function quickButton(label,callback){const b=document.createElement('button');b.textContent=label;b.onclick=callback;quick.append(b);}quickButton('+ سيكشن',()=>addKind('section'));quickButton('+ كارت براند',()=>addKind('brand'));quickButton('+ كارت متجر',()=>addKind('store'));quickButton('+ كارت عطر',()=>addKind('perfume'));quickButton('ميديا داخل الكارت المحدد',()=>{const i=current();if(!i||i.type!=='card'){alert('حدد كارتًا أولًا بكليك شمال، ثم اضغط هذا الزر.');return;}replaceId=i.id;document.getElementById('upload').click();});quickButton('تنسيق وتأثير 3D',()=>{if(!current()){alert('حدد عنصرًا أولًا.');return;}openFormat();});quickButton('نص فوق العنصر',()=>{const anchor=current();add('text');const t=current();t.transparent=true;t.z=100;t.overlayOf=anchor?.id||null;if(anchor){t.x=anchor.x+15;t.y=anchor.y+15;t.w=Math.max(40,anchor.w-30);}changed();render();});
    const menuWithAdditions=showMenu;showMenu=function(e){menuWithAdditions(e);const buttons=Array.from(menu.children);const additions=buttons.slice(-8);additions.reverse().forEach(b=>menu.prepend(b));};
    const originalLibrary=library;library=function(){originalLibrary();const holder=document.getElementById('mediaList');Array.from(holder.children).forEach((b,index)=>{const m=state.media[index];if(!m)return;b.textContent='استخدام: '+m.name;b.onclick=()=>{const i=current();if(i&&['card','section'].includes(i.type)){checkpoint();i.mediaSrc=m.src;i.mediaType=m.type;i.fit=i.fit||'contain';changed();render();}else add(m.type,m.src);document.getElementById('libraryDialog').close();};});};document.getElementById('library').onclick=()=>library();
    const correctedRender=render;render=function(){correctedRender();state.items.forEach(i=>{const el=Array.from(canvas.children).find(e=>e.dataset.id===i.id);if(!el)return;const content=el.querySelector('.content');if(i.mediaSrc&&i.type==='card'){el.style.backgroundColor=i.bg||'#fffdf9';const media=el.querySelector('.cardMedia');if(media){media.style.pointerEvents='none';media.style.clipPath='inset(0 round 16px)';}content.style.backgroundColor='transparent';}if(i.effect==='gold'&&!i.mediaSrc&&!i.transparent)content.style.backgroundImage='linear-gradient(145deg,'+(i.bg||'#fffdf9')+' 0%,#e9dbba 55%,'+(i.bg||'#fffdf9')+' 100%)';if(i.effect==='soft'&&!i.mediaSrc&&!i.transparent)content.style.backgroundImage='linear-gradient(145deg,#ffffff,'+(i.bg||'#fffdf9')+')';});};
    document.getElementById('hint').textContent='نسخة 3: حدّد كارتًا وارفع الميديا داخله. الأدوات الجديدة ظاهرة في الشريط المختصر وكليك يمين. الترتيب التلقائي للكروت فقط، والسيكشن ليس حاوية متكاملة بعد. الحفظ محلي.';
    // Repair interaction layering and keep all creation tools in the context menu.
    quick.remove();flowButton.remove();document.querySelector('header strong').textContent='Élan Scents · النسخة 4 — إصلاح التفاعل';
    const repairs=document.createElement('style');repairs.textContent='#menu{z-index:2147483000!important;direction:rtl}.item{user-select:none}.editing .content{user-select:text}.card .cardMedia{object-fit:contain}#format{min-width:320px}';document.head.appendChild(repairs);
    state.items.forEach(i=>{if(i.type==='card')i.fit='contain';});
    let contextPoint={x:350,y:300};let pendingInsertIndex=null;let dropTarget=null;
    function cardOrder(){return state.items.filter(i=>i.type==='card').sort((a,b)=>a.y-b.y||a.x-b.x);}
    function nearestCard(x,y,exclude){const cards=cardOrder().filter(c=>c.id!==exclude);let nearest=null,best=Infinity;cards.forEach(c=>{const distance=Math.hypot(x-(c.x+c.w/2),y-(c.y+c.h/2));if(distance<best){best=distance;nearest=c;}});return nearest;}
    packCards=function(){const cards=cardOrder();if(!cards.length)return;const moving=cards.find(c=>c.id===selected);if(moving&&dropTarget){const target=cards.find(c=>c.id===dropTarget.id);if(target){const without=cards.filter(c=>c.id!==moving.id);let idx=without.findIndex(c=>c.id===target.id)+(dropTarget.after?1:0);without.splice(Math.max(0,idx),0,moving);cards.splice(0,cards.length,...without);}}let x=40,y=340,rowHeight=0;cards.forEach(i=>{const oldX=i.x,oldY=i.y;if(x+i.w>1060){x=40;y+=rowHeight+24;rowHeight=0;}i.x=x;i.y=y;state.items.filter(t=>t.overlayOf===i.id).forEach(t=>{t.x+=i.x-oldX;t.y+=i.y-oldY;});x+=i.w+24;rowHeight=Math.max(rowHeight,i.h);});canvas.style.height=Math.max(900,y+rowHeight+60)+'px';dropTarget=null;};
    canvas.addEventListener('pointermove',e=>{if(!gesture||gesture.mode!=='move')return;const moving=state.items.find(i=>i.id===gesture.id);if(!moving||moving.type!=='card')return;const rect=canvas.getBoundingClientRect();const x=e.clientX-rect.left,y=e.clientY-rect.top;const target=nearestCard(x,y,moving.id);dropTarget=target?{id:target.id,after:x>target.x+target.w/2}:null;canvas.querySelectorAll('.item').forEach(el=>{el.style.borderLeft='';el.style.borderRight='';if(dropTarget&&el.dataset.id===dropTarget.id)el.style[dropTarget.after?'borderRight':'borderLeft']='4px solid #b48b38';});});
    const menuRepair=showMenu;showMenu=function(e){const rect=canvas.getBoundingClientRect();contextPoint={x:Math.max(0,Math.min(1000,e.clientX-rect.left)),y:Math.max(0,e.clientY-rect.top)};menuRepair(e);const formatButton=Array.from(menu.children).find(b=>b.textContent==='الخط واللون والحجم');if(formatButton){formatButton.disabled=!current();formatButton.textContent='تنسيق النص: الخط • اللون • الحجم • 3D';formatButton.onclick=()=>{menu.style.display='none';if(current())openFormat();};menu.prepend(formatButton);}action('الترتيب التلقائي: '+(autoFlow?'مفعّل':'متوقف'),()=>{autoFlow=!autoFlow;status.textContent=autoFlow?'الترتيب التلقائي للكروت مفعّل':'التحريك الحر مفعّل؛ العناصر الأخرى لن تتحرك';});const r=menu.getBoundingClientRect();menu.style.left=Math.max(4,Math.min(e.clientX,innerWidth-r.width-8))+'px';menu.style.top=Math.max(4,Math.min(e.clientY,innerHeight-r.height-8))+'px';};
    const addAtClick=add;add=function(type,src){addAtClick(type,src);const i=current();if(!i)return;i.x=Math.min(1100-i.w,contextPoint.x);i.y=contextPoint.y;if(type==='text'){i.transparent=true;i.z=100;}if(type==='card'&&autoFlow){const t=nearestCard(contextPoint.x,contextPoint.y,i.id);dropTarget=t?{id:t.id,after:contextPoint.x>t.x+t.w/2}:null;packCards();}render();};
    const oldKind=addKind;addKind=function(kind){oldKind(kind);if(kind!=='section'&&autoFlow){packCards();render();}};
    const interactionRender=render;render=function(){interactionRender();canvas.querySelectorAll('.item').forEach(el=>{const content=el.querySelector('.content');content.addEventListener('dblclick',()=>{const i=state.items.find(i=>i.id===el.dataset.id);if(i&&['text','card','section'].includes(i.type)){select(i.id);content.contentEditable='plaintext-only';content.focus();}});});};
    // Expand movement bounds to the current canvas height.
    canvas.addEventListener('pointermove',e=>{if(!gesture)return;const i=state.items.find(i=>i.id===gesture.id);const el=Array.from(canvas.children).find(el=>el.dataset.id===gesture.id);if(!i||!el)return;const height=Math.max(900,canvas.offsetHeight);if(gesture.mode==='move'){i.y=Math.max(0,Math.min(height-i.h,gesture.y+e.clientY-gesture.sy));el.style.top=i.y+'px';}else{i.h=Math.max(30,Math.min(height-i.y,gesture.h+e.clientY-gesture.sy));el.style.height=i.h+'px';}});
    document.getElementById('hint').textContent='كليك يمين لإنشاء العناصر أو تنسيق النص. الصور كاملة داخل الكارت بدون قص افتراضيًا؛ اختلاف النسب قد يترك فراغًا. عند سحب كارت يظهر خط ذهبي لتحديد موضع إدراجه. النصوص تتحرك بحرية. لا يوجد ربط أو نشر.';
    // Repair text editing and make media behavior explicit for all visual containers.
    const mediaCSS=document.createElement('style');mediaCSS.textContent='.section .content{position:relative;z-index:2}.section .cardMedia{position:absolute;inset:0;width:100%;height:100%;z-index:1;border-radius:16px;pointer-events:none}.item .cardMedia{pointer-events:none}';document.head.appendChild(mediaCSS);
    const adaptOption=document.createElement('option');adaptOption.value='adapt';adaptOption.textContent='الصورة كاملة: تعديل ارتفاع الإطار ليناسب أبعادها';fitSelect.append(adaptOption);
    const transparencyLabel=document.createElement('label');const transparencyInput=document.createElement('input');transparencyInput.type='checkbox';transparencyLabel.append(transparencyInput,' خلفية النص شفافة');document.getElementById('apply').before(transparencyLabel);
    let formatTargetId=null;openFormat=function(){const i=current();if(!i)return;formatTargetId=i.id;document.getElementById('font').value=i.font||'Tahoma';document.getElementById('size').value=i.size||24;document.getElementById('color').value=/^#[0-9a-f]{6}$/i.test(i.color||'')?i.color:'#222222';document.getElementById('bg').value=/^#[0-9a-f]{6}$/i.test(i.bg||'')?i.bg:'#fffdf9';document.getElementById('align').value=i.align||'right';effectSelect.value=i.effect||'none';fitSelect.value=i.fit||'cover';transparencyInput.checked=!!i.transparent;document.getElementById('format').showModal();};
    document.getElementById('bg').oninput=()=>transparencyInput.checked=false;
    function applyMediaAspect(i){if(!i.mediaSrc||i.fit!=='adapt')return;const probe=document.createElement(i.mediaType==='video'?'video':'img');const update=()=>{const width=probe.naturalWidth||probe.videoWidth;const height=probe.naturalHeight||probe.videoHeight;if(width&&height){i.h=Math.max(30,Math.round(i.w*height/width));canvas.style.height=Math.max(canvas.offsetHeight,i.y+i.h+50)+'px';render();}};if(i.mediaType==='video')probe.onloadedmetadata=update;else probe.onload=update;probe.src=i.mediaSrc;}
    document.getElementById('apply').onclick=()=>{const i=state.items.find(i=>i.id===formatTargetId);if(!i)return;checkpoint();i.font=document.getElementById('font').value;i.size=Math.max(8,Math.min(160,Number(document.getElementById('size').value)||24));i.color=document.getElementById('color').value;i.bg=document.getElementById('bg').value;i.align=document.getElementById('align').value;i.effect=effectSelect.value;i.fit=fitSelect.value;i.transparent=transparencyInput.checked;selected=i.id;changed();render();applyMediaAspect(i);document.getElementById('format').close();};
    const finalMediaRender=render;render=function(){finalMediaRender();state.items.forEach(i=>{const el=Array.from(canvas.children).find(e=>e.dataset.id===i.id);if(!el)return;const media=el.querySelector('.cardMedia');if(media){media.style.objectFit=i.fit==='contain'?'contain':'cover';media.style.width='100%';media.style.height='100%';el.querySelector('.content').style.backgroundColor='transparent';}if(i.type==='text'&&!i.transparent)el.querySelector('.content').style.backgroundColor=i.bg||'#fffdf9';});};
    let explicitUploadTarget=null;const previousUpload=document.getElementById('upload').onchange;document.getElementById('upload').onchange=e=>{const i=state.items.find(i=>i.id===replaceId)||current();if(i&&['card','section'].includes(i.type)){replaceId=i.id;i.fit='cover';}previousUpload(e);};
    const fixedMenu=showMenu;showMenu=function(e){fixedMenu(e);const i=current();Array.from(menu.children).forEach(b=>{if(b.textContent==='إضافة كارت'){b.textContent='إضافة بانر';b.onclick=()=>{menu.style.display='none';addKind('section');const item=current();item.text='';item.kind='banner';render();};}if(b.textContent.startsWith('تنسيق النص:')||b.textContent==='الخط واللون والحجم'){b.disabled=!i;b.onclick=()=>{menu.style.display='none';openFormat();};}if(b.textContent==='رفع ميديا داخل الكارت'){b.textContent='رفع صورة أو فيديو داخل العنصر';b.disabled=!i||!['card','section'].includes(i.type);b.onclick=()=>{menu.style.display='none';replaceId=selected;document.getElementById('upload').click();};}});action('مسح الاسم أو النص التلقائي',()=>{const target=current();if(!target)return;checkpoint();target.text='';changed();render();},!!i&&['text','card','section'].includes(i.type));action('كتابة أو تعديل نص العنصر',()=>{const target=current();if(!target)return;const value=prompt('اكتب النص أو اتركه فارغًا لمسحه',target.text||'');if(value===null)return;checkpoint();target.text=value;changed();render();},!!i&&['text','card','section'].includes(i.type));const r=menu.getBoundingClientRect();menu.style.top=Math.max(4,Math.min(e.clientY,innerHeight-r.height-8))+'px';};
    document.querySelector('header strong').textContent='Élan Scents · النسخة 5 — النصوص والبانر';document.getElementById('hint').textContent='كليك يمين: تنسيق الخط واللون والحجم والخلفية، أو مسح النص التلقائي. الميديا تملأ الإطار مع قص عند اختلاف النسب؛ اختر تعديل ارتفاع الإطار من التنسيق لعرضها كاملة بدون قص. حفظ محلي فقط.';
    // Requested border controls and a consolidated context menu.
    const borderControls=document.createElement('fieldset');borderControls.style.cssText='border:1px solid #d6c49d;border-radius:10px;margin:16px 0;padding:12px';const borderLegend=document.createElement('legend');borderLegend.textContent='إطار مربع النص أو العنصر';borderControls.append(borderLegend);
    function borderField(label,input){const l=document.createElement('label');l.append(label,input);borderControls.append(l);}
    const borderColor=document.createElement('input');borderColor.type='color';borderField(' لون الإطار ',borderColor);
    const borderTransparent=document.createElement('input');borderTransparent.type='checkbox';borderField(' إطار شفاف ',borderTransparent);borderColor.oninput=()=>borderTransparent.checked=false;
    const borderDepth=document.createElement('input');borderDepth.type='checkbox';borderField(' تفعيل تأثير 3D للإطار ',borderDepth);
    const borderShape=document.createElement('select');[['rectangle','مستطيل'],['circle','دائرة']].forEach(([value,text])=>{const o=document.createElement('option');o.value=value;o.textContent=text;borderShape.append(o);});borderField(' شكل مربع النص ',borderShape);document.getElementById('apply').before(borderControls);
    const formatBeforeBorder=openFormat;openFormat=function(){formatBeforeBorder();const i=state.items.find(i=>i.id===formatTargetId);if(!i)return;borderColor.value=i.borderColor||'#b99755';borderTransparent.checked=i.borderTransparent!==false;borderDepth.checked=!!i.borderDepth;borderShape.value=i.borderShape||'rectangle';};
    const applyBeforeBorder=document.getElementById('apply').onclick;document.getElementById('apply').onclick=()=>{const i=state.items.find(i=>i.id===formatTargetId);if(!i)return;const values={borderColor:borderColor.value,borderTransparent:borderTransparent.checked,borderDepth:borderDepth.checked,borderShape:borderShape.value};applyBeforeBorder();Object.assign(i,values);if(i.borderShape==='circle')i.h=i.w;changed();render();};
    const renderBeforeBorder=render;render=function(){renderBeforeBorder();state.items.forEach(i=>{const el=Array.from(canvas.children).find(e=>e.dataset.id===i.id);if(!el)return;const content=el.querySelector('.content');if(i.borderShape){const radius=i.borderShape==='circle'?'50%':'0px';content.style.borderRadius=radius;content.style.border='2px solid '+(i.borderTransparent?'transparent':(i.borderColor||'#b99755'));content.style.boxShadow=i.borderDepth&&!i.borderTransparent?'inset 1px 1px 2px rgba(255,255,255,.85),inset -2px -2px 3px rgba(0,0,0,.25),0 5px 10px rgba(0,0,0,.2)':'none';el.style.borderRadius=radius;const media=el.querySelector('.cardMedia');if(media){media.style.borderRadius=radius;media.style.clipPath=i.borderShape==='circle'?'circle(50%)':'inset(0)';}}});};
    const menuBeforeCleanup=showMenu;showMenu=function(e){menuBeforeCleanup(e);const elements=Array.from(menu.children);let createText=null,banner=null,perfume=null;elements.forEach(b=>{const text=b.textContent;if(text==='إضافة نص'||text==='نص فوق العنصر'){if(!createText){createText=b;b.textContent='إنشاء نص';b.disabled=false;b.onclick=()=>{menu.style.display='none';const anchor=current();add('text');const t=current();t.transparent=true;t.z=100;t.overlayOf=anchor?.id||null;if(anchor){t.x=anchor.x+15;t.y=anchor.y+15;t.w=Math.max(40,anchor.w-30);}changed();render();};}else b.remove();}else if(text==='خلفية نص شفافة'||text==='إضافة صورة أو فيديو'){b.remove();}else if(text==='إضافة بانر'){banner=b;b.textContent='إنشاء بانر صورة أو فيديو';}else if(text==='إنشاء كارت عطر'){perfume=b;}else if(text==='رفع صورة أو فيديو داخل العنصر'){b.textContent='رفع صورة أو فيديو داخل العناصر أو الهيرو';b.disabled=!current()||!['card','section','image','video'].includes(current().type);}else if(text==='حذف ميديا الكارت'){b.textContent='حذف ميديا الكارت أو الهيرو إلى الأرشيف';const i=current();b.disabled=!i||!(i.mediaSrc||(['image','video'].includes(i.type)&&i.src));b.onclick=()=>{menu.style.display='none';const target=current();if(!target)return;checkpoint();if(target.mediaSrc){state.archive.push({id:uid(),type:target.mediaType==='video'?'video':'image',src:target.mediaSrc,x:target.x,y:target.y,w:target.w,h:target.h,text:'',font:'Tahoma',size:24,color:'#222222',bg:'#fffdf9',align:'right'});delete target.mediaSrc;delete target.mediaType;}else if(['image','video'].includes(target.type)&&target.src){state.archive.push(clone(target));state.items=state.items.filter(i=>i.id!==target.id);selected=null;}changed();render();};}});if(perfume){let after=perfume;if(banner){after.after(banner);after=banner;}if(createText)after.after(createText);}const r=menu.getBoundingClientRect();menu.style.top=Math.max(4,Math.min(e.clientY,innerHeight-r.height-8))+'px';};
    canvas.addEventListener('pointerup',()=>{const i=current();if(i?.borderShape==='circle'){i.h=i.w;render();}});
    document.querySelector('header strong').textContent='Élan Scents · النسخة 6 — الإطار والقائمة';
    // Working empty banner and a clearer, contextual formatting panel.
    const bannerMenu=showMenu;showMenu=function(e){bannerMenu(e);const b=Array.from(menu.children).find(b=>b.textContent==='إنشاء بانر صورة أو فيديو');if(b){b.disabled=false;b.onclick=()=>{menu.style.display='none';add('card');const i=current();i.kind='banner';i.text='';i.w=300;i.h=240;i.borderColor='#b99755';i.borderTransparent=false;i.borderShape='rectangle';if(autoFlow)packCards();changed();render();};}};
    const formatPanel=document.getElementById('format');formatPanel.style.width='540px';formatPanel.querySelector('h3').textContent='تنسيق العنصر';
    const panelStyle=document.createElement('style');panelStyle.textContent='#format{background:#fffdf8;color:#28251e;padding:20px}#format h3{margin:0 0 18px;color:#86632b}#format fieldset{border:1px solid #e0d1b0;border-radius:12px;padding:12px;margin:12px 0}#format legend{font-weight:bold;color:#87642e;padding:0 8px}#format .fieldGrid{display:grid;grid-template-columns:1fr 1fr;gap:12px}#format label{margin:0;display:flex;flex-direction:column;gap:7px;font-size:13px}#format label:has(input[type=checkbox]){flex-direction:row;align-items:center;grid-column:1/-1}#format select,#format input[type=number]{width:100%;background:white;min-height:38px}#format .colorRow{display:flex;align-items:center;gap:8px;direction:ltr}#format input[type=color]{width:55px;height:40px;padding:3px;cursor:pointer}#format .colorValue{font-family:Arial;font-size:12px;border:1px solid #d8c69f;background:white;padding:8px;border-radius:7px}#format .sample{padding:18px;border:1px solid #e0d1b0;border-radius:12px;margin:12px 0;background:#f1eee7}#format .sample span{display:block;padding:14px;text-align:center}#format .panelActions{display:flex;gap:10px;padding-top:10px}#format .panelActions button{flex:1}#format .panelActions #apply{background:#26231d;color:#efddaf}@media(max-width:480px){#format .fieldGrid{grid-template-columns:1fr}}';document.head.append(panelStyle);
    function panelGroup(title){const f=document.createElement('fieldset');const l=document.createElement('legend');l.textContent=title;const grid=document.createElement('div');grid.className='fieldGrid';f.append(l,grid);formatPanel.append(f);return {fieldset:f,grid};}
    const textGroup=panelGroup('الكتابة');textGroup.grid.append(document.getElementById('font').closest('label'),document.getElementById('size').closest('label'),document.getElementById('align').closest('label'));
    const colorsGroup=panelGroup('ألوان النص والخلفية');colorsGroup.grid.append(document.getElementById('color').closest('label'),document.getElementById('bg').closest('label'),transparencyLabel,effectLabel);
    const borderGroup=panelGroup('الإطار');borderGroup.grid.append(...Array.from(borderControls.querySelectorAll('label')));borderControls.remove();
    const mediaGroupPanel=panelGroup('طريقة عرض الميديا');mediaGroupPanel.grid.append(fitLabel);const mediaExplanation=document.createElement('small');mediaExplanation.textContent='ملء الإطار قد يقص الأطراف. عرض الصورة كاملة قد يترك فراغًا. تعديل الارتفاع يجعل الإطار يتناسب مع الصورة.';mediaGroupPanel.grid.append(mediaExplanation);
    const sampleBox=document.createElement('div');sampleBox.className='sample';const sampleCaption=document.createElement('small');sampleCaption.textContent='معاينة تنسيق فقط، لا تغيّر العنصر قبل الضغط على تطبيق';const sample=document.createElement('span');sample.textContent='معاينة النص';sampleBox.append(sampleCaption,sample);formatPanel.append(sampleBox);
    const actions=document.createElement('div');actions.className='panelActions';actions.append(document.getElementById('apply'));const closeButton=Array.from(formatPanel.querySelectorAll('button')).find(b=>b.textContent==='إغلاق');if(closeButton)actions.append(closeButton);formatPanel.append(actions);
    const colorValues=new Map();[document.getElementById('color'),document.getElementById('bg'),borderColor].forEach(input=>{const row=document.createElement('div');row.className='colorRow';input.before(row);row.append(input);const value=document.createElement('span');value.className='colorValue';row.append(value);colorValues.set(input,value);});
    function updatePanelPreview(){colorValues.forEach((value,input)=>{value.textContent=input.value.toUpperCase();value.style.borderBottom='4px solid '+input.value;});const i=(typeof liveMode!=='undefined'&&liveMode&&selectedLive)?{text:selectedLive.text}:state.items.find(i=>i.id===formatTargetId);sample.textContent=i?.text?.trim().slice(0,80)||'معاينة النص';sample.style.fontFamily=document.getElementById('font').value;sample.style.fontSize=Math.min(42,Number(document.getElementById('size').value)||24)+'px';sample.style.color=document.getElementById('color').value;sample.style.backgroundColor=transparencyInput.checked?'transparent':document.getElementById('bg').value;sample.style.border='2px solid '+(borderTransparent.checked?'transparent':borderColor.value);sample.style.borderRadius=borderShape.value==='circle'?'50%':'0';sample.style.boxShadow=borderDepth.checked&&!borderTransparent.checked?'inset 1px 1px 2px #fff,inset -2px -2px 3px #0004,0 5px 10px #0003':'none';sample.style.textShadow=effectSelect.value==='none'?'none':'0 1px 0 #fff,1px 2px 2px #0004';sample.style.textAlign=document.getElementById('align').value;}
    formatPanel.querySelectorAll('input,select').forEach(input=>{input.addEventListener('input',updatePanelPreview);input.addEventListener('change',updatePanelPreview);});
    const organizedFormat=openFormat;openFormat=function(){organizedFormat();const i=state.items.find(i=>i.id===formatTargetId);const hasMedia=!!i&&(!!i.mediaSrc||['image','video'].includes(i.type));mediaGroupPanel.fieldset.hidden=!hasMedia;textGroup.fieldset.hidden=!!i&&['image','video'].includes(i.type);updatePanelPreview();};
    document.querySelector('header strong').textContent='Élan Scents · النسخة 7 — البانر ولوحة التنسيق';
    // Compact formatting panel and expanded Arabic/English font choices.
    const fontDefinitions=[['عربي',['Cairo','Tajawal','Almarai','Amiri','Changa','El Messiri','Noto Kufi Arabic','Noto Naskh Arabic','Noto Sans Arabic','Reem Kufi','IBM Plex Sans Arabic']],['إنجليزي',['Inter','Roboto','Open Sans','Lato','Montserrat','Poppins','Playfair Display','Cormorant Garamond','Libre Baskerville','Merriweather']],['خطوط الجهاز',['Tahoma','Arial','Georgia','Times New Roman','Verdana','Trebuchet MS','Courier New','system-ui']]];
    const fontControl=document.getElementById('font');fontControl.replaceChildren();fontDefinitions.forEach(([group,names])=>{const optgroup=document.createElement('optgroup');optgroup.label=group;names.forEach(name=>{const o=document.createElement('option');o.value=name;o.textContent=name;optgroup.append(o);});fontControl.append(optgroup);});
    const fontCSS=document.createElement('link');fontCSS.rel='stylesheet';const families=fontDefinitions.slice(0,2).flatMap(g=>g[1]).map(name=>'family='+name.replace(/ /g,'+')+':wght@400;700').join('&');fontCSS.href='https://fonts.googleapis.com/css2?'+families+'&display=swap';document.head.append(fontCSS);
    const compactStyle=document.createElement('style');compactStyle.textContent='#format{width:580px!important;padding:16px}#format .fieldGrid{gap:10px}#format fieldset{margin:9px 0;padding:10px}#format label{font-size:12px;gap:5px}#format select,#format input[type=number]{min-height:34px;padding:6px}#format .textRow{grid-template-columns:minmax(0,1.7fr) minmax(0,1fr) minmax(0,1fr)}#format .colorRow{direction:rtl;background:white;border:1px solid #ddcfb2;border-radius:8px;padding:6px;gap:7px}#format .colorChip{width:36px;height:30px;border-radius:6px;border:1px solid #c9bb9b;box-shadow:inset 0 0 0 2px #ffffff99;display:block;flex-shrink:0}#format .colorLabel{font-family:Tahoma;font-size:12px;color:#514737}#format .colorHex{font-family:Arial;font-size:11px;color:#777;direction:ltr}#format .borderToggles{grid-column:1/-1;display:flex;gap:20px;align-items:center;flex-wrap:nowrap;padding:7px 0}#format .borderToggles label{display:flex;flex-direction:row;gap:7px;white-space:nowrap}#format .sample{padding:8px;margin:8px 0}#format .sample span{padding:10px}@media(max-width:420px){#format{padding:10px}#format .textRow{grid-template-columns:minmax(0,1.3fr) minmax(0,1fr) minmax(0,1fr)}#format .borderToggles{gap:8px;font-size:11px}}';document.head.append(compactStyle);
    textGroup.grid.classList.add('textRow');
    const toggles=document.createElement('div');toggles.className='borderToggles';toggles.append(borderDepth.closest('label'),borderTransparent.closest('label'));borderGroup.grid.append(toggles);
    function colorName(hex){const r=parseInt(hex.slice(1,3),16),g=parseInt(hex.slice(3,5),16),b=parseInt(hex.slice(5,7),16);if(Math.max(r,g,b)-Math.min(r,g,b)<25){if(r>235)return 'أبيض';if(r<35)return 'أسود';return 'رمادي';}if(r>180&&g>150&&b<140)return 'ذهبي';if(r>210&&g>190&&b>155)return 'عاجي';if(r>g*1.2&&r>b*1.2)return 'أحمر';if(g>r*1.2&&g>b*1.2)return 'أخضر';if(b>r*1.2&&b>g*1.2)return 'أزرق';return 'لون مخصص';}
    const chips=new Map();colorValues.forEach((value,input)=>{value.remove();const row=input.parentElement;const control=document.createElement('button');control.type='button';control.style.cssText='display:flex;align-items:center;gap:8px;background:none;border:0;padding:0;width:100%;text-align:right';const chip=document.createElement('span');chip.className='colorChip';const info=document.createElement('span');const name=document.createElement('span');name.className='colorLabel';const code=document.createElement('span');code.className='colorHex';code.style.display='block';info.append(name,code);control.append(chip,info);row.append(control);input.style.cssText='position:absolute;opacity:0;width:1px;height:1px;padding:0;border:0;pointer-events:none';input.tabIndex=-1;control.onclick=()=>{if(typeof input.showPicker==='function'){try{input.showPicker();}catch(e){input.click();}}else input.click();};chips.set(input,{chip,name,code});});
    const updateBeforeChips=updatePanelPreview;updatePanelPreview=function(){updateBeforeChips();chips.forEach((parts,input)=>{parts.chip.style.backgroundColor=input.value;parts.name.textContent=colorName(input.value);parts.code.textContent=input.value.toUpperCase();});};
    chips.forEach((parts,input)=>{input.addEventListener('input',()=>updatePanelPreview());input.addEventListener('change',()=>updatePanelPreview());});
    const fontNotice=document.createElement('small');fontNotice.textContent='الخطوط الإضافية تُحمّل من Google Fonts وتحتاج الإنترنت؛ عند تعذر التحميل يُستخدم خط بديل.';textGroup.fieldset.append(fontNotice);
    document.querySelector('header strong').textContent='Élan Scents · النسخة 8 — لوحة مختصرة وخطوط';
    // Focused visual and library improvements.
    fontNotice.remove();document.getElementById('hint').remove();
    const textEffectsRow=document.createElement('div');textEffectsRow.className='borderToggles';textEffectsRow.append(transparencyLabel,effectLabel);colorsGroup.grid.append(textEffectsRow);effectLabel.style.flexDirection='row';effectSelect.style.width='145px';
    const paletteColors=[['ذهبي','#D4AF37'],['ذهبي داكن','#B8860B'],['ذهبي فاتح','#E6C76A'],['أسود','#000000'],['أبيض','#FFFFFF'],['عاجي','#FFFFF0'],['أوف وايت','#FAF9F6'],['رمادي','#808080'],['رمادي داكن','#444444'],['بيج','#E8DCC4'],['أحمر','#C62828'],['أزرق','#1565C0'],['أخضر','#2E7D32'],['بنفسجي','#7B1FA2']];
    const paletteDialog=document.createElement('dialog');paletteDialog.style.width='430px';document.body.append(paletteDialog);let paletteTarget=null;function openPalette(input){paletteTarget=input;paletteDialog.replaceChildren();const h=document.createElement('h3');h.textContent='اختيار لون صريح';paletteDialog.append(h);const grid=document.createElement('div');grid.style.cssText='display:grid;grid-template-columns:repeat(3,1fr);gap:8px';paletteColors.forEach(([label,color])=>{const b=document.createElement('button');b.style.cssText='display:flex;align-items:center;gap:7px;font-size:12px;padding:8px';const sw=document.createElement('span');sw.style.cssText='width:24px;height:24px;border:1px solid #aaa;border-radius:4px;background:'+color;b.append(sw,label);b.onclick=()=>{input.value=color;input.dispatchEvent(new Event('input',{bubbles:true}));input.dispatchEvent(new Event('change',{bubbles:true}));paletteDialog.close();};grid.append(b);});paletteDialog.append(grid);const label=document.createElement('label');label.textContent='أو أدخل كود اللون بدقة';const hex=document.createElement('input');hex.value=input.value.toUpperCase();hex.dir='ltr';hex.placeholder='#D4AF37';label.append(hex);paletteDialog.append(label);const apply=document.createElement('button');apply.textContent='اعتماد اللون';apply.onclick=()=>{const value=hex.value.trim();if(!/^#[0-9a-f]{6}$/i.test(value)){alert('اكتب # وبعده ستة أحرف أو أرقام، مثال #D4AF37');return;}input.value=value;input.dispatchEvent(new Event('input',{bubbles:true}));input.dispatchEvent(new Event('change',{bubbles:true}));paletteDialog.close();};const close=document.createElement('button');close.textContent='إغلاق';close.onclick=()=>paletteDialog.close();paletteDialog.append(apply,close);paletteDialog.showModal();}
    chips.forEach((parts,input)=>{input.parentElement.querySelector('button').onclick=()=>openPalette(input);});
    state.items.forEach(i=>{if(i.mediaSrc)i.fit='contain';});
    const safeMediaRender=render;render=function(){safeMediaRender();state.items.forEach(i=>{const el=Array.from(canvas.children).find(e=>e.dataset.id===i.id);if(!el)return;el.querySelectorAll('img,video').forEach(media=>{media.style.objectFit='contain';media.style.width='100%';media.style.height='100%';});const c=el.querySelector('.content');c.style.backgroundImage='none';c.style.color=i.color||'#222222';if(i.effect==='gold')c.style.textShadow='0 1px 0 rgba(255,255,255,.6),1px 2px 2px rgba(0,0,0,.25)';});};
    mediaGroupPanel.fieldset.hidden=true;const openBeforeMediaHide=openFormat;openFormat=function(){openBeforeMediaHide();mediaGroupPanel.fieldset.hidden=true;};
    const categoryDefinitions=[['section','سيكشن'],['brand','براند'],['store','متجر'],['perfume','عطر'],['banner','بانر'],['text','نص'],['hero','هيرو'],['image','صورة'],['video','فيديو']];
    function itemCategory(item){if(['brand','store','perfume','banner','hero'].includes(item.kind))return item.kind;if(item.type==='card')return 'perfume';if(item.type==='section')return 'section';return ['text','image','video'].includes(item.type)?item.type:'banner';}
    if(!Array.isArray(state.savedElements))state.savedElements=[];
    let libraryTab='archive',libraryCategory='section',uploadOnlyCategory=null;
    const libraryDialog=document.getElementById('libraryDialog');libraryDialog.style.width='720px';
    function libraryButton(text,fn){const b=document.createElement('button');b.textContent=text;b.onclick=fn;return b;}
    library=function(){libraryDialog.replaceChildren();const title=document.createElement('h3');title.textContent='مكتبة إيلان المحلية';libraryDialog.append(title);const tabs=document.createElement('div');tabs.style.cssText='display:flex;gap:8px;margin-bottom:12px';[['archive','العناصر المحذوفة'],['saved','الميديا والعناصر المحفوظة']].forEach(([value,text])=>{const b=libraryButton(text,()=>{libraryTab=value;library();});if(libraryTab===value)b.style.background='#e8d6ad';tabs.append(b);});libraryDialog.append(tabs);const folders=document.createElement('div');folders.style.cssText='display:grid;grid-template-columns:repeat(3,1fr);gap:8px';categoryDefinitions.forEach(([key,label])=>{const count=libraryTab==='archive'?state.archive.filter(i=>itemCategory(i)===key).length:(state.savedElements||[]).filter(i=>itemCategory(i)===key).length+state.media.filter(m=>(m.category||m.type)===key).length;const b=libraryButton(label+' ('+count+')',()=>{libraryCategory=key;library();});if(libraryCategory===key)b.style.background='#e8d6ad';folders.append(b);});libraryDialog.append(folders);const heading=document.createElement('h4');heading.textContent=categoryDefinitions.find(c=>c[0]===libraryCategory)?.[1]||'';libraryDialog.append(heading);const list=document.createElement('div');list.style.cssText='display:grid;gap:10px';libraryDialog.append(list);
    function row(item,label,callback){const box=document.createElement('div');box.style.cssText='display:flex;align-items:center;gap:10px;padding:10px;border:1px solid #dfd0b3;border-radius:10px';if(item.type==='image'||item.mediaType==='image'){const img=document.createElement('img');img.src=item.src||item.mediaSrc;img.style.cssText='width:60px;height:50px;object-fit:contain';box.append(img);}const text=document.createElement('span');text.textContent=item.name||item.text?.slice(0,35)||heading.textContent;text.style.flex='1';box.append(text,libraryButton(label,callback));list.append(box);}
    if(libraryTab==='archive'){state.archive.forEach((item,index)=>{if(itemCategory(item)!==libraryCategory)return;row(item,'استرجاع',()=>{checkpoint();const copy=clone(item);if(state.items.some(i=>i.id===copy.id))copy.id=uid();state.items.push(copy);state.archive.splice(index,1);selected=copy.id;changed();render();library();});});}else{state.savedElements.forEach(item=>{if(itemCategory(item)!==libraryCategory)return;row(item,'إضافة نسخة',()=>{checkpoint();const copy=clone(item);copy.id=uid();copy.x=80;copy.y=300;state.items.push(copy);selected=copy.id;changed();render();libraryDialog.close();});});state.media.forEach(m=>{if((m.category||m.type)!==libraryCategory)return;row(m,'استخدام',()=>{const i=current();if(i&&['card','section'].includes(i.type)){checkpoint();i.mediaSrc=m.src;i.mediaType=m.type;i.fit='contain';changed();render();}else{add(m.type,m.src);}libraryDialog.close();});});const uploadButton=libraryButton('رفع ملف وحفظه في '+heading.textContent,()=>{uploadOnlyCategory=libraryCategory;replaceId=null;document.getElementById('upload').click();});libraryDialog.append(uploadButton);const note=document.createElement('small');note.textContent='صور وفيديوهات صغيرة، أو ملف عنصر JSON صادر من هذا المحرر. الملفات تُحفظ محليًا، ولا تُضاف للصفحة عند الرفع للمكتبة.';libraryDialog.append(note);}
    if(!list.children.length){const empty=document.createElement('p');empty.textContent='لا توجد عناصر في هذا القسم بعد.';list.append(empty);}libraryDialog.append(libraryButton('إغلاق',()=>libraryDialog.close()));if(!libraryDialog.open)libraryDialog.showModal();};document.getElementById('library').onclick=()=>library();
    document.getElementById('upload').accept='image/*,video/*,.json';document.getElementById('upload').onchange=async e=>{const f=e.target.files[0];if(!f)return;e.target.value='';const category=uploadOnlyCategory;uploadOnlyCategory=null;if(f.size>1024*1024){alert('النسخة المحلية تقبل ملفًا أقل من 1 ميجابايت.');return;}if(f.name.toLowerCase().endsWith('.json')){if(!category){alert('استيراد العناصر من داخل المكتبة فقط.');return;}try{const obj=JSON.parse(await f.text());if(obj.format!=='elan-element-v1'||!obj.element||!['card','section','text','image','video'].includes(obj.element.type))throw new Error();checkpoint();const item=clone(obj.element);item.id=uid();if(['brand','store','perfume','banner','hero'].includes(category))item.kind=category;else item.type=category;state.savedElements.push(item);changed();library();}catch(err){alert('الملف ليس عنصرًا متوافقًا صادرًا من المحرر.');}return;}if(!f.type.startsWith('image/')&&!f.type.startsWith('video/')){alert('اختر صورة أو فيديو أو ملف عنصر متوافق.');return;}const target=replaceId||(current()&&['card','section'].includes(current().type)?selected:null);replaceId=null;const reader=new FileReader();reader.onload=()=>{checkpoint();const type=f.type.startsWith('image/')?'image':'video';const i=state.items.find(i=>i.id===target);const m={name:f.name,src:reader.result,type,category:category||(i?itemCategory(i):type)};state.media.push(m);if(!category){if(i&&['card','section'].includes(i.type)){i.mediaSrc=m.src;i.mediaType=type;i.fit='contain';}else if(i&&['image','video'].includes(i.type)){i.src=m.src;i.type=type;}else{add(type,m.src);}}changed();render();if(libraryDialog.open)library();};reader.readAsDataURL(f);};
    function downloadElement(item){const url=URL.createObjectURL(new Blob([JSON.stringify({format:'elan-element-v1',element:item},null,2)],{type:'application/json'}));const a=document.createElement('a');a.href=url;a.download='elan-element.json';a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);}
    const cleanMenu=showMenu;showMenu=function(e){cleanMenu(e);Array.from(menu.children).forEach(b=>{if(b.textContent==='استبدال الصورة أو الفيديو')b.remove();if(b.textContent==='حذف إلى الأرشيف')b.textContent='حذف العنصر إلى الأرشيف';});action('حفظ العنصر في المكتبة',()=>{const i=current();if(!i)return;checkpoint();if(!Array.isArray(state.savedElements))state.savedElements=[];state.savedElements.push(clone(i));changed();},!!current());action('تنزيل العنصر للمكتبة كملف',()=>{if(current())downloadElement(current());},!!current());const r=menu.getBoundingClientRect();menu.style.top=Math.max(4,Math.min(e.clientY,innerHeight-r.height-8))+'px';};
    // Sections participate in the same flow as cards instead of floating on top.
    cardOrder=function(){return state.items.filter(i=>['card','section'].includes(i.type)).sort((a,b)=>a.y-b.y||a.x-b.x);};
    packCards=function(){const elements=cardOrder();const moving=elements.find(i=>i.id===selected);if(moving&&dropTarget){const without=elements.filter(i=>i.id!==moving.id);const index=without.findIndex(i=>i.id===dropTarget.id);if(index>=0){without.splice(index+(dropTarget.after?1:0),0,moving);elements.splice(0,elements.length,...without);}}let x=40,y=340,rowHeight=0;elements.forEach(i=>{const oldX=i.x,oldY=i.y;if(i.type==='section'){if(x!==40){y+=rowHeight+24;x=40;rowHeight=0;}i.w=Math.min(i.w,1020);i.x=40;i.y=y;y+=i.h+24;}else{if(x+i.w>1060){x=40;y+=rowHeight+24;rowHeight=0;}i.x=x;i.y=y;x+=i.w+24;rowHeight=Math.max(rowHeight,i.h);}state.items.filter(t=>t.overlayOf===i.id).forEach(t=>{t.x+=i.x-oldX;t.y+=i.y-oldY;});});canvas.style.height=Math.max(900,y+rowHeight+60)+'px';dropTarget=null;};
    canvas.addEventListener('pointerdown',e=>{const el=e.target.closest('.item');if(el&&state.items.find(i=>i.id===el.dataset.id)?.type==='section'&&!e.target.classList.contains('handle'))dragWasCard=true;},true);
    canvas.addEventListener('pointermove',e=>{if(!gesture||gesture.mode!=='move')return;const i=state.items.find(i=>i.id===gesture.id);if(i?.type!=='section')return;const rect=canvas.getBoundingClientRect();const target=nearestCard(e.clientX-rect.left,e.clientY-rect.top,i.id);dropTarget=target?{id:target.id,after:e.clientY-rect.top>target.y+target.h/2}:null;});
    const createKindBeforeFlow=addKind;addKind=function(kind){createKindBeforeFlow(kind);if(kind==='section'&&autoFlow){packCards();render();}};
    const migrateSavedRender=render;render=function(){if(!Array.isArray(state.savedElements))state.savedElements=[];migrateSavedRender();};
    document.querySelector('header strong').textContent='Élan Scents · النسخة 9 — الألوان والمكتبة';
    // Place elements where requested; flow only on deliberate dragging.
    let requestedFlow=false;cardOrder=function(){return state.items.filter(i=>['card','section','image','video'].includes(i.type)).sort((a,b)=>a.y-b.y||a.x-b.x);};
    packCards=function(){if(!requestedFlow)return;const elements=cardOrder();const moving=elements.find(i=>i.id===selected);if(moving&&dropTarget){const rest=elements.filter(i=>i.id!==moving.id);const index=rest.findIndex(i=>i.id===dropTarget.id);if(index>=0){rest.splice(index+(dropTarget.after?1:0),0,moving);elements.splice(0,elements.length,...rest);}}let startY=Math.max(30,Math.min(...elements.map(i=>i.y)));let x=40,y=Number.isFinite(startY)?startY:340,rowHeight=0;elements.forEach(i=>{const oldX=i.x,oldY=i.y;i.w=Math.min(i.w,1020);if(x+i.w>1060){x=40;y+=rowHeight+24;rowHeight=0;}i.x=x;i.y=y;x+=i.w+24;rowHeight=Math.max(rowHeight,i.h);state.items.filter(t=>t.overlayOf===i.id).forEach(t=>{t.x+=i.x-oldX;t.y+=i.y-oldY;});});canvas.style.height=Math.max(900,y+rowHeight+50)+'px';dropTarget=null;requestedFlow=false;};
    const kindAtPosition=addKind;addKind=function(kind){kindAtPosition(kind);const i=current();if(!i)return;i.x=Math.max(0,Math.min(1100-i.w,contextPoint.x));i.y=Math.max(0,contextPoint.y);if(kind==='section'){i.w=450;i.h=220;i.x=Math.max(0,Math.min(1100-i.w,contextPoint.x));}canvas.style.height=Math.max(canvas.offsetHeight,i.y+i.h+50)+'px';render();};
    const lastMenu=showMenu;showMenu=function(e){lastMenu(e);Array.from(menu.children).forEach(b=>{if(['مسح الاسم أو النص التلقائي','كتابة أو تعديل نص العنصر'].includes(b.textContent))b.remove();});};
    let flowPointerStart=null;canvas.addEventListener('pointerdown',e=>{flowPointerStart={x:e.clientX,y:e.clientY};},true);canvas.addEventListener('pointerup',e=>{const g=gesture;if(!g||g.mode!=='move'||!flowPointerStart)return;const moved=Math.hypot(e.clientX-flowPointerStart.x,e.clientY-flowPointerStart.y)>4;const item=state.items.find(i=>i.id===g.id);if(moved&&item&&['card','section','image','video'].includes(item.type)){const rect=canvas.getBoundingClientRect();const x=e.clientX-rect.left,y=e.clientY-rect.top;const target=nearestCard(x,y,item.id);dropTarget=target?{id:target.id,after:y>target.y+target.h*.7||(Math.abs(y-(target.y+target.h/2))<target.h*.4&&x>target.x+target.w/2)}:null;requestedFlow=!!target;dragWasCard=true;}flowPointerStart=null;},true);
    // Clicking saved media inserts a new element, never silently overwrites the selection.
    const libraryBeforeFix=library;library=function(){libraryBeforeFix();const list=Array.from(libraryDialog.children).find(el=>el.tagName==='DIV'&&el.style.display==='grid'&&!el.textContent.includes('سيكشن ('));if(!list)return;const entries=libraryTab==='archive'?state.archive.filter(i=>itemCategory(i)===libraryCategory):[...state.savedElements.filter(i=>itemCategory(i)===libraryCategory),...state.media.filter(m=>(m.category||m.type)===libraryCategory)];Array.from(list.children).forEach((row,index)=>{const source=entries[index];if(!source||row.tagName!=='DIV')return;const use=row.querySelector('button');if(libraryTab==='saved'&&use){use.onclick=()=>{checkpoint();let copy;if(state.media.includes(source)){if(['section','brand','store','perfume','banner','hero'].includes(libraryCategory)){copy={id:uid(),type:libraryCategory==='section'?'section':'card',kind:libraryCategory,mediaSrc:source.src,mediaType:source.type,fit:'contain',text:'',w:300,h:240,font:'Tahoma',size:24,color:'#222222',bg:'#fffdf9',align:'right'};}else copy={id:uid(),type:source.type,src:source.src,w:300,h:240,text:'',fit:'contain'};}else{copy=clone(source);copy.id=uid();}copy.x=Math.max(0,Math.min(1100-copy.w,contextPoint.x));copy.y=Math.max(0,contextPoint.y);state.items.push(copy);selected=copy.id;if(autoFlow){const near=nearestCard(copy.x,copy.y,copy.id);if(near){dropTarget={id:near.id,after:true};requestedFlow=true;packCards();}}canvas.style.height=Math.max(canvas.offsetHeight,copy.y+copy.h+50)+'px';changed();render();libraryDialog.close();};}const del=document.createElement('button');del.textContent='حذف نهائي';del.style.color='#a02222';del.onclick=()=>{if(!confirm('حذف هذا العنصر نهائيًا من المكتبة؟ النسخ الموجودة في الصفحة لن تُحذف. يمكن التراجع أثناء هذه الجلسة فقط.'))return;checkpoint();const collection=libraryTab==='archive'?state.archive:state.savedElements.includes(source)?state.savedElements:state.media;const idx=collection.indexOf(source);if(idx>=0)collection.splice(idx,1);changed();library();};row.append(del);});};document.getElementById('library').onclick=()=>library();
    document.querySelector('header strong').textContent='Élan Scents · النسخة 10 — المواضع والمكتبة';
    // Two scoped fixes: automatic insertion/flow and media filling its frame.
    let insertPending=false;
    function isFlowElement(i){return ['card','section','image','video'].includes(i.type);}
    function reflowAt(id,point){const moving=state.items.find(i=>i.id===id);if(!moving||!isFlowElement(moving))return;const others=state.items.filter(i=>isFlowElement(i)&&i.id!==id).sort((a,b)=>a.y-b.y||a.x-b.x);let index=others.filter(i=>i.y<moving.y||(i.y===moving.y&&i.x<moving.x)).length;if(point&&others.length){let best=Infinity,nearestIndex=0;others.forEach((i,n)=>{const distance=Math.hypot(point.x-(i.x+i.w/2),point.y-(i.y+i.h/2));if(distance<best){best=distance;nearestIndex=n;}});const target=others[nearestIndex];index=nearestIndex+((point.y>target.y+target.h*.75)||(point.y>=target.y&&point.x>target.x+target.w/2)?1:0);}const top=others.length?Math.max(0,Math.min(...others.map(i=>i.y))):Math.max(0,moving.y);others.splice(index,0,moving);let x=40,y=top,rowH=0;others.forEach(i=>{const oldX=i.x,oldY=i.y;i.w=Math.max(40,Math.min(1020,i.w));if(x+i.w>1060){x=40;y+=rowH+24;rowH=0;}i.x=x;i.y=y;state.items.filter(t=>t.overlayOf===i.id).forEach(t=>{t.x+=i.x-oldX;t.y+=i.y-oldY;});x+=i.w+24;rowH=Math.max(rowH,i.h);});canvas.style.height=Math.max(900,y+rowH+60)+'px';dropTarget=null;requestedFlow=false;changed();render();}
    function scheduleInsertion(){if(insertPending)return;insertPending=true;queueMicrotask(()=>{insertPending=false;const i=current();if(i&&isFlowElement(i))reflowAt(i.id,{...contextPoint});});}
    const insertionAdd=add;add=function(type,src){insertionAdd(type,src);if(isFlowElement(current()||{}))scheduleInsertion();};const insertionKind=addKind;addKind=function(kind){insertionKind(kind);scheduleInsertion();};
    let lastDrag=null;canvas.addEventListener('pointerdown',e=>{const el=e.target.closest('.item');if(!el)return;const i=state.items.find(i=>i.id===el.dataset.id);if(i&&isFlowElement(i)){lastDrag={id:i.id,x:e.clientX,y:e.clientY,resize:e.target.classList.contains('handle')};}},true);canvas.addEventListener('pointerup',e=>{if(!lastDrag)return;const drag=lastDrag;lastDrag=null;const distance=Math.hypot(e.clientX-drag.x,e.clientY-drag.y);if(distance<4)return;const rect=canvas.getBoundingClientRect();const point={x:e.clientX-rect.left,y:e.clientY-rect.top};queueMicrotask(()=>{if(state.items.some(i=>i.id===drag.id)){selected=drag.id;reflowAt(drag.id,drag.resize?null:point);}});},true);canvas.addEventListener('pointercancel',()=>lastDrag=null,true);
    const fillRender=render;render=function(){fillRender();state.items.forEach(i=>{const el=Array.from(canvas.children).find(e=>e.dataset.id===i.id);if(!el)return;el.querySelectorAll('img,video').forEach(media=>{media.style.objectFit='cover';media.style.objectPosition='center';media.style.width='100%';media.style.height='100%';media.style.display='block';});});};
    document.querySelector('header strong').textContent='Élan Scents · النسخة 11 — الإزاحة وملء الميديا';
    // Menu-only cleanup; automatic arrangement remains enabled.
    autoFlow=true;
    const menuBeforeFinalCleanup=showMenu;
    showMenu=function(e){autoFlow=true;menuBeforeFinalCleanup(e);Array.from(menu.children).forEach(b=>{const label=b.textContent.trim();if(label==='تكبير الخط +'||label==='تصغير الخط −'||label.startsWith('الترتيب التلقائي:'))b.remove();});const r=menu.getBoundingClientRect();menu.style.top=Math.max(4,Math.min(e.clientY,innerHeight-r.height-8))+'px';};
    document.querySelector('header strong').textContent='Élan Scents · النسخة 12';
    // Fit the complete media without cropping or distorting it.
    const completeMediaRender=render;
    render=function(){completeMediaRender();state.items.forEach(i=>{const el=Array.from(canvas.children).find(e=>e.dataset.id===i.id);if(!el)return;el.querySelectorAll('img,video').forEach(media=>{media.style.objectFit='contain';media.style.objectPosition='center';media.style.width='100%';media.style.height='100%';media.style.display='block';});});};
    const headerStyle=document.createElement('style');headerStyle.textContent='header{height:auto;min-height:82px;background:linear-gradient(110deg,#151515,#24211c);border-bottom:1px solid #b99755;box-shadow:0 4px 18px rgba(0,0,0,.16);padding:13px 26px;gap:10px;flex-wrap:wrap}header strong{display:flex;flex-direction:column;min-width:160px;margin-left:auto;line-height:1.15}header .brandName{font-family:Georgia,serif;font-size:30px;letter-spacing:.4px;color:#e7c779;text-shadow:0 1px 0 #6b4d16,0 2px 5px #0005}header .brandName .scents{font-size:23px;color:#f3ead9;font-weight:400}header .brandCaption{font:10px Arial,sans-serif;letter-spacing:2px;color:#c6b796;margin-top:7px}header button{background:#302b23;border:1px solid #685b41;color:#efe4cc;border-radius:10px;min-height:42px;padding:10px 15px;display:flex;align-items:center;gap:8px;box-shadow:inset 0 1px 0 #ffffff0d;transition:background .15s,border-color .15s}header button:hover:not(:disabled){background:#463a27;border-color:#c7a663}header button:disabled{opacity:.35}header #save{background:#d4b76e;color:#211d15;border-color:#dfc88e;font-weight:bold}header #save:hover{background:#e2c983}header #status{font-size:11px;color:#cabfa9;border-right:1px solid #65583f;padding-right:12px;max-width:190px;line-height:1.7}#viewport{height:calc(100vh - 100px)}@media(max-width:600px){header{padding:10px;gap:6px}header strong{width:100%;align-items:center;margin-bottom:5px}header button{padding:8px 10px;flex:1;justify-content:center}header #status{max-width:none;width:100%;text-align:center;border:0}#viewport{height:calc(100vh - 170px)}}';document.head.append(headerStyle);
    const logo=document.querySelector('header strong');logo.replaceChildren();const brand=document.createElement('span');brand.className='brandName';brand.dir='ltr';brand.append('Élan ');const scents=document.createElement('span');scents.className='scents';scents.textContent='Scents';brand.append(scents);const caption=document.createElement('span');caption.className='brandCaption';caption.dir='ltr';caption.textContent='VISUAL EDITOR · 13';logo.append(brand,caption);
    [['undo','↶','تراجع'],['redo','↷','إعادة'],['save','✓','حفظ'],['library','▦','المكتبة']].forEach(([id,icon,label])=>{const button=document.getElementById(id);button.replaceChildren();const mark=document.createElement('span');mark.textContent=icon;mark.style.fontSize='19px';mark.setAttribute('aria-hidden','true');const text=document.createElement('span');text.textContent=label;button.append(mark,text);button.title=label;});
    // Stretch media to exactly match the element's width and height.
    const exactFillStyle=document.createElement('style');exactFillStyle.textContent='#status{display:none!important}.item img,.item video{object-fit:fill!important;object-position:center!important;width:100%!important;height:100%!important;max-width:none!important;max-height:none!important}.item.image .content,.item.video .content{padding:0!important}';document.head.append(exactFillStyle);
    const beforeExactFill=render;render=function(){beforeExactFill();state.items.forEach(i=>{const el=Array.from(canvas.children).find(e=>e.dataset.id===i.id);if(!el)return;el.querySelectorAll('img,video').forEach(media=>{media.style.setProperty('object-fit','fill','important');media.style.setProperty('width','100%','important');media.style.setProperty('height','100%','important');if(i.borderShape!=='circle')media.style.clipPath='none';});});};
    caption.textContent='VISUAL EDITOR · 14';
    // Enable keyboard text editing for sections without synthetic double-clicks.
    const beforeSectionTextMenu=showMenu;
    showMenu=function(e){beforeSectionTextMenu(e);const item=current();const button=Array.from(menu.children).find(b=>b.textContent==='تعديل النص بالكيبورد');if(button){button.disabled=!item||!['text','card','section'].includes(item.type);button.onclick=()=>{menu.style.display='none';const target=current();if(!target||!['text','card','section'].includes(target.type))return;const el=Array.from(canvas.children).find(node=>node.dataset.id===target.id);const content=el?.querySelector('.content');if(!content)return;checkpoint();editing=true;el.classList.add('editing');content.contentEditable='plaintext-only';content.focus();const range=document.createRange();range.selectNodeContents(content);range.collapse(false);const selection=window.getSelection();selection.removeAllRanges();selection.addRange(range);};}};
    caption.textContent='VISUAL EDITOR · 15';
    // Elan domain definitions: declarative bindings, not a live database connection.
    const elanElementDefinitions={
    version:1,
    rules:{priceSource:'store_catalog',availabilitySource:'store_catalog',officialBrandContentOnly:true,neverUseBrandPrice:true,externalBrandStoreLinksVisible:false,oneCardPerProductSize:true,compareSameSizeConcentrationEditionPackaging:true,requireVerifiedAvailableOffer:true,priceOrder:['price ASC','commission_rate DESC','priority_rank ASC'],unknownQuantityIsNotZero:true,noAutomaticSplit:true,noVendorSwitchForInsufficientRequestedQuantity:true,comingSoonNotPurchasable:true},
    initialBrands:['AMOUAGE','ARMAF','AFNAN','ASAF','RASASI','FRENCH AVENUE','ARABIYAT PRESTIGE','LATTAFA','Maison Alhambra'],
    elements:{
    section:{label:'سيكشن',source:['public_products','cheapest_offers'],fields:['name','purpose','filter','preview_limit'],behavior:'Dynamic query by approved purpose; display only matching available perfumes with unified cards; coming soon is a separately labeled exception.'},
    perfume:{label:'كارت عطر',source:['products','product_sizes','cheapest_offers'],fields:['product_id','product_size_id','name','image','brand','store','category','price','short_description','occasions','notes','availability','quantity','last_synced_at'],behavior:'One card per exact product variant and size. Verified lowest eligible store offer. Details and cart actions use bound IDs; unavailable data stays empty, not fabricated.'},
    brand:{label:'كارت براند',source:['brands','public_products','cheapest_offers'],fields:['brand_id','name','official_logo_url'],behavior:'Original official logo without cropping; only this brand perfumes available at participating stores.'},
    store:{label:'كارت متجر',source:['stores','store_products'],fields:['store_id','name','logo_url','image_url','short_description','status'],behavior:'Separate seller catalogue restricted to approved brands. Show this seller actual price and stock, never attribute another seller price. New seller remains pending integration.'},
    occasion:{label:'كارت مناسبة',source:['occasions','product_occasions','public_products','cheapest_offers'],fields:['occasion_id','name','image_url'],behavior:'Only verified linked products. A new name does not imply automatic fragrance classification.'},
    note:{label:'كارت نوتة عطرية',source:['aromatic_notes','product_notes','public_products','cheapest_offers'],fields:['note_id','name','image_url'],behavior:'Only matching verified product-note relations; preserve official content provenance.'},
    banner:{label:'بانر',source:['editor_content'],fields:['name','media','alt_text','optional_internal_target'],behavior:'Editorial image/video; no invented commercial data.'},
    text:{label:'نص',source:['editor_content','marketing_phrases'],fields:['text','font','color','background','size'],behavior:'Overlay text; only assigned marketing wording, no unsupported claims.'},
    text_block:{label:'كتلة نصية',source:['editor_content','marketing_phrases'],fields:['text','font','color','background','size'],behavior:'Flow block, not overlay; occupies layout space and displaces neighbouring elements.'}
    }};
    function definitionKind(item){if(item.kind==='text_block')return 'text_block';if(['brand','store','perfume','occasion','note','banner'].includes(item.kind))return item.kind;if(item.type==='section')return 'section';if(item.type==='text')return 'text';if(item.type==='card')return 'perfume';return null;}
    function attachDefinition(item){const kind=definitionKind(item);if(!kind)return;item.definitionKey=kind;item.definitionVersion=1;if(!item.binding)item.binding={status:['text','text_block','banner'].includes(kind)?'editorial':'not_connected',entityId:null,productSizeId:null,name:'',purpose:null};}
    state.elementDefinitions=clone(elanElementDefinitions);state.items.forEach(attachDefinition);
    const definitionDialog=document.createElement('dialog');definitionDialog.style.width='470px';document.body.append(definitionDialog);
    function configureDefinition(){const item=current();if(!item)return;attachDefinition(item);const def=elanElementDefinitions.elements[item.definitionKey];if(!def)return;definitionDialog.replaceChildren();const h=document.createElement('h3');h.textContent='تعريف '+def.label;definitionDialog.append(h);const fields={};function input(label,key,value){const l=document.createElement('label');l.textContent=label;const i=document.createElement('input');i.value=value||'';i.style.cssText='display:block;width:100%;margin-top:6px';l.append(i);definitionDialog.append(l);fields[key]=i;}
    input('اسم العنصر أو السجل المطلوب','name',item.binding.name);if(!['text','text_block','banner','section'].includes(item.definitionKey)){input('معرّف السجل في سابابيس، اختياري الآن','entityId',item.binding.entityId);fields.entityId.dir='ltr';}if(item.definitionKey==='perfume'){input('معرّف حجم العطر، اختياري الآن','productSizeId',item.binding.productSizeId);fields.productSizeId.dir='ltr';}
    let purpose=null;if(item.definitionKey==='section'){const l=document.createElement('label');l.textContent='غرض السيكشن';purpose=document.createElement('select');[['available','سحر الخليج، العطور المتاحة'],['brands','البراندات'],['offers','العروض والخصومات'],['new_arrivals','وصل حديثًا وفق إعلان المتجر'],['masterpieces','المختارات بمؤشرات موثقة'],['categories','الفئات'],['occasions','المناسبات'],['notes','النوتات'],['coming_soon','مرتقب وصولها، غير قابلة للشراء'],['stores','المتاجر'],['about','عن إيلان'],['contact','التواصل'],['custom','غرض مخصص يحتاج قاعدة بيانات معتمدة']].forEach(([value,label])=>{const o=document.createElement('option');o.value=value;o.textContent=label;purpose.append(o);});purpose.value=item.binding.purpose||'available';l.append(purpose);definitionDialog.append(l);}
    const note=document.createElement('small');note.textContent='تعريف محفوظ داخل التصميم لتجهيز الربط. لا يتم جلب بيانات أو إنشاء سجل في سابابيس من هذه النسخة. ربط الاسم وحده لا يكفي، ويحتاج معرّفًا وقاعدة عرض.';definitionDialog.append(note);const save=document.createElement('button');save.textContent='حفظ التعريف';save.onclick=()=>{const uuid=/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;for(const key of ['entityId','productSizeId'])if(fields[key]?.value.trim()&&!uuid.test(fields[key].value.trim())){alert('معرّف السجل يجب أن يكون UUID صحيحًا، أو اتركه فارغًا.');return;}checkpoint();Object.entries(fields).forEach(([key,value])=>item.binding[key]=value.value.trim()||null);if(purpose)item.binding.purpose=purpose.value;if(item.binding.name&&!['text','text_block'].includes(item.definitionKey))item.text=item.binding.name;changed();render();definitionDialog.close();};const close=document.createElement('button');close.textContent='إغلاق';close.onclick=()=>definitionDialog.close();definitionDialog.append(save,close);definitionDialog.showModal();}
    const kindsBeforeDefinition=addKind;addKind=function(kind){kindsBeforeDefinition(kind);const item=current();if(!item)return;if(kind==='occasion'){item.text='اسم المناسبة';item.kind='occasion';}if(kind==='note'){item.text='اسم النوتة العطرية';item.kind='note';}attachDefinition(item);render();};
    function createTextBlock(){add('text');const item=current();item.kind='text_block';item.z=1;item.transparent=false;delete item.overlayOf;item.w=450;item.h=150;item.text='كتلة نصية جديدة';attachDefinition(item);changed();render();scheduleInsertion();}
    isFlowElement=function(item){return ['card','section','image','video'].includes(item.type)||item.kind==='text_block';};cardOrder=function(){return state.items.filter(isFlowElement).sort((a,b)=>a.y-b.y||a.x-b.x);};
    const renderWithDefinitions=render;render=function(){state.elementDefinitions=clone(elanElementDefinitions);state.items.forEach(attachDefinition);renderWithDefinitions();state.items.filter(i=>i.kind==='text_block').forEach(i=>{const el=Array.from(canvas.children).find(el=>el.dataset.id===i.id);if(el){el.style.zIndex='1';el.dataset.layout='flow';}});};
    const menuWithDefinitions=showMenu;showMenu=function(e){menuWithDefinitions(e);const added=[];function extra(label,fn){action(label,fn);added.push(menu.lastElementChild);}extra('إنشاء مناسبة',()=>addKind('occasion'));extra('إنشاء نوتة عطر',()=>addKind('note'));extra('إنشاء كتلة نصية',createTextBlock);const anchor=Array.from(menu.children).find(b=>b.textContent==='إنشاء كارت عطر');if(anchor){let after=anchor;added.forEach(b=>{after.after(b);after=b;});}action('تعريف العنصر ومصدر بياناته',configureDefinition,!!current()&&!!definitionKind(current()));const r=menu.getBoundingClientRect();menu.style.top=Math.max(4,Math.min(e.clientY,innerHeight-r.height-8))+'px';};
    const categoryBeforeDefinition=itemCategory;itemCategory=function(item){if(['occasion','note','text_block'].includes(item.kind))return item.kind;return categoryBeforeDefinition(item);};categoryDefinitions.push(['occasion','مناسبة'],['note','نوتة عطرية'],['text_block','كتلة نصية']);
    caption.textContent='VISUAL EDITOR · 17';
    // Final element data contract: only names, fields, relations and rules supplied by the merchant.
    const suppliedSchema={
    tables:{
    brands:['id','name','slug','official_logo_url','description','official_website_url','is_active','created_at','updated_at'],
    stores:['id','name','slug','logo_url','image_url','short_description','website_url','status','commission_rate','priority_rank','created_at','updated_at'],
    store_accounts:['id','store_id','user_id','role','created_at'],
    aromatic_notes:['id','name','image_url','created_at','updated_at'],categories:['id','name','image_url','created_at','updated_at'],occasions:['id','name','image_url','created_at','updated_at'],
    products:['id','brand_id','name','slug','short_description','official_description','composition','gender','notes_source','content_source','status','meta_title','meta_description','is_active','created_at','updated_at'],
    product_sizes:['id','product_id','size_ml','size_label','sku','created_at','updated_at'],
    product_images:['id','product_id','product_size_id','image_url','alt_text','sort_order','is_primary','created_at'],
    product_notes:['product_id','note_id'],product_categories:['product_id','category_id'],product_occasions:['product_id','occasion_id'],
    store_products:['id','store_id','product_size_id','price','original_price','discount_percentage','stock_quantity','is_available','is_new_arrival','is_coming_soon','price_includes_tax','price_includes_shipping','currency','data_source','sync_status','last_synced_at','created_at','updated_at'],
    offers:['id','store_id','product_size_id','title','description','discount_type','discount_value','start_date','end_date','is_active','created_at','updated_at'],
    product_stats:['product_id','views_count','sales_count','search_count','request_count','average_rating','reviews_count','updated_at'],
    reviews:['id','user_id','product_id','rating','comment','is_approved','created_at','updated_at'],
    profiles:['id','full_name','phone','avatar_url','role','created_at','updated_at'],
    favorites:['id','user_id','product_id','created_at'],cart_items:['id','user_id','store_product_id','quantity','created_at','updated_at'],
    orders:['id','user_id','status','subtotal','tax_amount','shipping_amount','total_amount','created_at','updated_at'],order_items:['id','order_id','store_product_id','quantity','price_at_time','created_at'],
    commissions:['id','store_id','order_item_id','rate','amount','status','created_at','updated_at'],contact_messages:['id','name','email','phone','message','is_read','created_at'],notifications:['id','user_id','title','body','is_read','created_at'],
    marketing_phrases:['id','phrase_ar','phrase_en','category','is_public','usage_scope','created_at'],media_library:['id','file_url','file_type','source','alt_text','linked_entity_type','linked_entity_id','is_approved','created_at'],analytics_events:['id','event_type','product_id','product_size_id','user_id','metadata','created_at'],site_settings:['key','value','updated_at'],sync_logs:['id','store_id','status','message','records_count','created_at']},
    relations:{'products.brand_id':'brands.id','product_sizes.product_id':'products.id','product_images.product_id':'products.id','product_images.product_size_id':'product_sizes.id','product_notes.product_id':'products.id','product_notes.note_id':'aromatic_notes.id','product_categories.product_id':'products.id','product_categories.category_id':'categories.id','product_occasions.product_id':'products.id','product_occasions.occasion_id':'occasions.id','store_products.store_id':'stores.id','store_products.product_size_id':'product_sizes.id','offers.store_id':'stores.id','offers.product_size_id':'product_sizes.id','product_stats.product_id':'products.id','store_accounts.store_id':'stores.id','store_accounts.user_id':'auth.users.id','profiles.id':'auth.users.id','reviews.user_id':'profiles.id','reviews.product_id':'products.id','favorites.user_id':'profiles.id','favorites.product_id':'products.id','cart_items.user_id':'profiles.id','cart_items.store_product_id':'store_products.id','orders.user_id':'profiles.id','order_items.order_id':'orders.id','order_items.store_product_id':'store_products.id','commissions.store_id':'stores.id','commissions.order_item_id':'order_items.id','notifications.user_id':'profiles.id'},
    views:{cheapest_offers:{per:'product_size_id',conditions:['is_available = true','stock_quantity > 0','sync_status = synced'],order:['price ASC','commission_rate DESC','priority_rank ASC'],columns:['product_size_id','product_id','brand_id','store_id','store_name','price','stock_quantity','currency','price_includes_tax','price_includes_shipping','last_synced_at']},public_products:{conditions:['published products','at least one offer in cheapest_offers'],usage:'The only product visibility rule for cards, sections and search',columns:'not specified in supplied schema'}},
    rules:{priceAvailabilityQuantityOffersNewArrivalBestSellingSource:'store_catalog',descriptionCompositionNotesOfficialContentSupplementSource:'brand_official',brandWebsitePriceProhibited:true,brandStoreWebsiteLinksHidden:true,atLeastOneAvailableStoreRequired:true,eachSizeIndependent:true,compareDifferentSizesProhibited:true,oneCardPerProductAndSize:true,tieBreak:['commission_rate DESC','priority_rank ASC']},
    initial:{brands:['AMOUAGE','ARMAF','AFNAN','ASAF','RASASI','FRENCH AVENUE','ARABIYAT PRESTIGE','LATTAFA','Maison Alhambra'],stores:[{name:'Afnan Egypt',website_url:'egypt.afnan.com'},{name:'Emarati Scents',website_url:'emaratiscents.com'}],notes:['عنبري','حمضي','خشبي','عود','هيل'],categories:['رجالي','نسائي','عطر يجمعنا'],occasions:['نهاري','ليلي','عمل','موعد','هدية'],site_settings:['contact_email','instagram_url','tiktok_url','pinterest_url','footer_tagline','developer_credit','whatsapp_number']},
    security:{rlsAllTables:true,publicRead:'available products, brands, stores, offers and prices only',ownUserWrites:['favorites','cart_items','orders','reviews','contact_messages'],storeAccounts:'own store catalogue only',platform_admin:'full access'},
    connection:'not_connected',origin:'merchant supplied schema specification, not live database inspection'};
    function schemaElement(label,table,related,extra){return {label,table,fields:table?clone(suppliedSchema.tables[table]):[],relatedTables:related||[],...extra};}
    elanElementDefinitions.version=3;elanElementDefinitions.rules=clone(suppliedSchema.rules);elanElementDefinitions.schema=clone(suppliedSchema);
    elanElementDefinitions.elements={
    section:schemaElement('سيكشن',null,[],{schemaDefinition:'No independent section table or layout fields specified.',productVisibilityView:'public_products'}),
    perfume:schemaElement('كارت عطر','products',['product_sizes','product_images','brands','stores','store_products','product_notes','aromatic_notes','product_categories','categories','product_occasions','occasions'],{sizeKey:'product_sizes.id',offerView:'cheapest_offers',productVisibilityView:'public_products',cardUniqueness:'same product and same size'}),
    brand:schemaElement('كارت براند','brands',['products','product_sizes','store_products','stores'],{hiddenFields:['official_website_url'],productVisibilityView:'public_products',offerView:'cheapest_offers'}),
    store:schemaElement('كارت متجر','stores',['store_products','product_sizes','products','brands'],{hiddenFields:['website_url'],productVisibilityView:'public_products',offerView:'cheapest_offers'}),
    occasion:schemaElement('كارت مناسبة','occasions',['product_occasions','products','product_sizes'],{relation:'product_occasions.occasion_id -> occasions.id; product_occasions.product_id -> products.id',productVisibilityView:'public_products',offerView:'cheapest_offers'}),
    note:schemaElement('كارت نوتة عطرية','aromatic_notes',['product_notes','products','product_sizes'],{relation:'product_notes.note_id -> aromatic_notes.id; product_notes.product_id -> products.id',productVisibilityView:'public_products',offerView:'cheapest_offers'}),
    banner:schemaElement('بانر',null,['media_library'],{schemaDefinition:'No independent banner table or behavior specified.'}),
    text:schemaElement('نص',null,['marketing_phrases'],{schemaDefinition:'No independent editor text table specified.'}),
    text_block:schemaElement('كتلة نصية',null,['marketing_phrases'],{schemaDefinition:'No independent text-block table specified.',editorLayout:'flow as requested by merchant'})};
    const beforeExactDefinition=attachDefinition;attachDefinition=function(item){beforeExactDefinition(item);if(!item.definitionKey)return;const def=elanElementDefinitions.elements[item.definitionKey];item.definitionVersion=3;item.dataDefinition={kind:item.definitionKey,table:def.table,fields:clone(def.fields),relatedTables:clone(def.relatedTables),contract:clone(def),rules:clone(suppliedSchema.rules)};};
    state.items.forEach(attachDefinition);
    // No purpose/filter implementation is inferred from the schema.
    configureDefinition=function(){const item=current();if(!item)return;attachDefinition(item);definitionDialog.replaceChildren();const def=elanElementDefinitions.elements[item.definitionKey];const h=document.createElement('h3');h.textContent='تعريف '+def.label;definitionDialog.append(h);const l=document.createElement('label');l.textContent='اسم العنصر';const name=document.createElement('input');name.value=item.binding.name||'';l.append(name);definitionDialog.append(l);const identity=document.createElement('input');if(def.table){const label=document.createElement('label');label.textContent='معرّف السجل، يحدد عند الربط';identity.value=item.binding.entityId||'';identity.dir='ltr';label.append(identity);definitionDialog.append(label);}const note=document.createElement('p');note.textContent=def.table?'مصدر التعريف: '+def.table:'الشّيما لا تحدد جدولًا مستقلًا لهذا العنصر؛ لا يتم افتراض جدول جديد.';definitionDialog.append(note);const save=document.createElement('button');save.textContent='حفظ';save.onclick=()=>{if(identity.value.trim()&&!/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(identity.value.trim())){alert('اكتب UUID أو اترك المعرّف فارغًا.');return;}checkpoint();item.binding.name=name.value.trim()||null;if(def.table)item.binding.entityId=identity.value.trim()||null;if(item.binding.name&&!['text','text_block'].includes(item.definitionKey))item.text=item.binding.name;attachDefinition(item);changed();render();definitionDialog.close();};const close=document.createElement('button');close.textContent='إغلاق';close.onclick=()=>definitionDialog.close();definitionDialog.append(save,close);definitionDialog.showModal();};
    const exactSchemaSave=document.getElementById('save').onclick;document.getElementById('save').onclick=()=>{state.elementDefinitions=clone(elanElementDefinitions);state.items.forEach(attachDefinition);exactSchemaSave();};
    caption.textContent='VISUAL EDITOR · SCHEMA FINAL';
    render();
    
    </script><script>
    // Section campaign extension. No remote connection or fake catalogue.
    const sectionPanel=document.createElement('dialog');sectionPanel.style.cssText='width:650px;max-height:90vh';document.body.append(sectionPanel);
    function localCairo(iso){if(!iso)return '';const p=Object.fromEntries(new Intl.DateTimeFormat('en-GB',{timeZone:'Africa/Cairo',year:'numeric',month:'2-digit',day:'2-digit',hour:'2-digit',minute:'2-digit',hourCycle:'h23'}).formatToParts(new Date(iso)).filter(p=>p.type!=='literal').map(p=>[p.type,p.value]));return `${p.year}-${p.month}-${p.day}T${p.hour}:${p.minute}`;}
    function cairoUTC(s){if(!s)return null;let t=Date.parse(s+'Z'),g=t;if(!Number.isFinite(t))throw Error('موعد غير صحيح');for(let n=0;n<4;n++){const shown=Date.parse(localCairo(new Date(g).toISOString())+'Z');g+=t-shown;}return new Date(g).toISOString();}
    function editSection(item){const old=item?.sectionConfig||{};sectionPanel.replaceChildren();const h=document.createElement('h3');h.textContent=item?'إعدادات السيكشن':'إنشاء سيكشن';sectionPanel.append(h);function field(title,type,value){const l=document.createElement('label');l.textContent=title;const i=document.createElement('input');i.type=type;i.value=value??'';i.style.cssText='display:block;width:100%;margin-top:5px';l.append(i);sectionPanel.append(l);return i;}function select(title,choices,value){const l=document.createElement('label');l.textContent=title;const s=document.createElement('select');choices.forEach(([v,t])=>{const o=document.createElement('option');o.value=v;o.textContent=t;s.append(o);});s.value=value;l.append(s);sectionPanel.append(l);return s;}
    const name=field('اسم السيكشن','text',old.name||item?.text||''),purpose=field('الغرض من السيكشن','text',old.purpose||'');const mode=select('اختيار العطور',[['manual','يدوي'],['automatic','تلقائي بالفلاتر']],old.selectionMode||'manual');const filters={};[['brand_id','البراند'],['store_id','المتجر'],['category_id','الفئة'],['occasion_id','المناسبة'],['note_id','النوتة'],['size_ml','الحجم بالمل'],['price_min','أقل سعر'],['price_max','أعلى سعر']].forEach(([key,title])=>{const number=['size_ml','price_min','price_max'].includes(key);filters[key]=field(title,number?'number':'text',old.filters?.[key]);if(!number)filters[key].placeholder='معرّف السجل؛ قائمة الأسماء بعد ربط سابابيس';else filters[key].min='0';});
    let picks=clone(old.manualProducts||[]);const add=document.createElement('button');add.textContent='إضافة عطر';const results=document.createElement('div'),chosen=document.createElement('div');function paint(){chosen.replaceChildren();picks.forEach((p,n)=>{const line=document.createElement('div');line.textContent=p.name+' — '+p.productSizeId;const b=document.createElement('button');b.textContent='إزالة';b.onclick=()=>{picks.splice(n,1);paint();};line.append(b);chosen.append(line);});}paint();add.onclick=()=>{results.replaceChildren();const available=state.items.filter(i=>i.kind==='perfume'&&i.binding?.entityId&&i.binding?.productSizeId);if(!available.length){results.textContent='لا يوجد كتالوج متصل. اختيار العطور بأسمائها وتطبيق الفلاتر على نتائج حقيقية يحتاج ربط سابابيس. لا نعرض بيانات وهمية.';return;}available.forEach(i=>{const b=document.createElement('button');b.textContent=i.binding.name||i.text;b.onclick=()=>{if(!picks.some(p=>p.productSizeId===i.binding.productSizeId))picks.push({productId:i.binding.entityId,productSizeId:i.binding.productSizeId,name:i.binding.name||i.text});paint();};results.append(b);});};sectionPanel.append(add,results,chosen);mode.onchange=()=>{add.hidden=mode.value!=='manual';chosen.hidden=mode.value!=='manual';results.replaceChildren();};mode.onchange();
    const label=document.createElement('label'),enabled=document.createElement('input');enabled.type='checkbox';enabled.checked=!!old.timer?.enabled;label.append(enabled,' تشغيل التوقيت');sectionPanel.append(label);const timing=select('طريقة التوقيت',[['dates','بداية ونهاية'],['duration','ساعات أو أيام من أول حفظ']],old.timer?.mode||'dates');const start=field('البداية، توقيت مصر','datetime-local',localCairo(old.timer?.startsAt)),end=field('النهاية، توقيت مصر','datetime-local',localCairo(old.timer?.endsAt)),count=field('عدد الساعات أو الأيام','number',old.timer?.durationValue||1);count.min='1';const unit=select('الوحدة',[['hours','ساعات'],['days','أيام']],old.timer?.durationUnit||'hours');function timingUI(){timing.closest('label').hidden=!enabled.checked;start.closest('label').hidden=end.closest('label').hidden=!enabled.checked||timing.value!=='dates';count.closest('label').hidden=unit.closest('label').hidden=!enabled.checked||timing.value!=='duration';}enabled.onchange=timingUI;timing.onchange=timingUI;timingUI();
    const note=document.createElement('small');note.textContent='هذه نسخة محلية: التعريفات جاهزة للربط، والتوقيت يعمل أثناء فتح المحرر وعند إعادة فتحه. البداية المستقبلية تظهر باهتة للمعاينة فقط.';sectionPanel.append(note);const save=document.createElement('button');save.textContent='حفظ السيكشن';save.onclick=()=>{try{if(!name.value.trim()||!purpose.value.trim())throw Error('اكتب الاسم والغرض.');const values={};Object.entries(filters).forEach(([key,i])=>{if(!i.value.trim())return;if(i.type==='number'){if(!Number.isFinite(Number(i.value))||Number(i.value)<0)throw Error('قيمة فلتر غير صحيحة');values[key]=Number(i.value);}else{if(!/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(i.value.trim()))throw Error('استخدم معرّف سجل صحيحًا أو اترك الفلتر فارغًا.');values[key]=i.value.trim();}});if(values.price_min!==undefined&&values.price_max!==undefined&&values.price_min>values.price_max)throw Error('أقل سعر أكبر من أعلى سعر.');const createdAt=old.createdAt||new Date().toISOString();const timer={enabled:enabled.checked,mode:timing.value,timeZone:'Africa/Cairo',durationValue:Number(count.value),durationUnit:unit.value,startsAt:null,endsAt:null};if(timer.enabled){if(timer.mode==='dates'){timer.startsAt=cairoUTC(start.value);timer.endsAt=cairoUTC(end.value);if(!timer.startsAt||!timer.endsAt||Date.parse(timer.endsAt)<=Date.parse(timer.startsAt))throw Error('حدد مواعيد صحيحة.');}else{if(!Number.isFinite(timer.durationValue)||timer.durationValue<=0)throw Error('حدد مدة أكبر من صفر');timer.startsAt=createdAt;timer.endsAt=new Date(Date.parse(createdAt)+timer.durationValue*(unit.value==='days'?86400000:3600000)).toISOString();}}checkpoint();let target=item;if(!target){windowSectionAdd();target=current();}target.text=name.value.trim();target.sectionConfig={name:name.value.trim(),purpose:purpose.value.trim(),selectionMode:mode.value,filters:values,manualProducts:picks,createdAt,timer,dataSource:{products:'public_products',offers:'cheapest_offers',connection:'not_connected'}};attachDefinition(target);target.binding.name=target.sectionConfig.name;target.binding.purpose=target.sectionConfig.purpose;selected=target.id;reflowAt(target.id,{...contextPoint});changed();document.getElementById('save').click();sectionPanel.close();checkSections();}catch(e){alert(e.message);}};const close=document.createElement('button');close.textContent='إلغاء';close.onclick=()=>sectionPanel.close();sectionPanel.append(save,close);sectionPanel.showModal();}
    function windowSectionAdd(){add('section');const i=current();i.w=450;i.h=220;i.z=1;}
    const sectionMenuBase=showMenu;showMenu=function(e){sectionMenuBase(e);const b=Array.from(menu.children).find(b=>b.textContent==='إنشاء سيكشن');if(b)b.onclick=()=>{menu.style.display='none';editSection(null);};action('إعدادات السيكشن',()=>editSection(current()),current()?.type==='section');};
    function checkSections(){const now=Date.now();const expired=state.items.filter(i=>i.sectionConfig?.timer?.enabled&&i.sectionConfig.timer.endsAt&&Date.parse(i.sectionConfig.timer.endsAt)<=now);if(expired.length){checkpoint();expired.forEach(i=>{const copy=clone(i);copy.sectionConfig.lastTimer=clone(copy.sectionConfig.timer);copy.sectionConfig.timer.enabled=false;copy.sectionConfig.archivedAt=new Date().toISOString();state.archive.push(copy);});const ids=new Set(expired.map(i=>i.id));state.items=state.items.filter(i=>!ids.has(i.id));const first=state.items.find(isFlowElement);if(first)reflowAt(first.id,null);changed();render();document.getElementById('save').click();}canvas.querySelectorAll('.item').forEach(el=>{const timer=state.items.find(i=>i.id===el.dataset.id)?.sectionConfig?.timer;el.style.opacity=timer?.enabled&&timer.startsAt&&Date.parse(timer.startsAt)>now?'0.45':'';});}
    setInterval(checkSections,1000);caption.textContent='VISUAL EDITOR · SECTION CAMPAIGN';checkSections();
    
    
    </script><script>
    // Clean section panel. Integration supplies a real, authenticated data provider.
    // window.elanSectionDataProvider.getOptions() -> {brands,stores,categories,occasions,notes,sizes}
    // Each option: {id,name}; sizes: {size_ml,name}.
    // getPerfumes(filters) -> [{product_id,product_size_id,name,size_label}]
    // Provider must apply public_products/cheapest_offers and all supplied schema restrictions.
    const cleanSectionStyle=document.createElement('style');cleanSectionStyle.textContent='.sectionPanelClean{width:760px;max-width:95vw;background:#fffdf8;color:#28251e;padding:22px}.sectionPanelClean h3{margin:0 0 18px;color:#866329}.sectionPanelClean .sectionGrid{display:grid;grid-template-columns:1fr 1fr;gap:12px}.sectionPanelClean .filterGrid{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:10px}.sectionPanelClean label{margin:0;display:flex;flex-direction:column;gap:6px;font-size:13px}.sectionPanelClean input,.sectionPanelClean select{width:100%;min-width:0;background:white;min-height:38px}.sectionPanelClean fieldset{margin:15px 0;padding:14px;border:1px solid #e0d0af;border-radius:12px}.sectionPanelClean legend{font-weight:bold;color:#8c6830;padding:0 7px}.sectionPanelClean .perfumeRow{display:grid;grid-template-columns:1fr auto;gap:10px;align-items:end;margin:12px 0}.sectionPanelClean .selectionList{display:grid;gap:7px;margin-top:12px}.sectionPanelClean .chosenPerfume{display:flex;align-items:center;gap:10px;border:1px solid #e4d7be;background:white;border-radius:8px;padding:9px;font-size:13px}.sectionPanelClean .chosenPerfume span{flex:1}.sectionPanelClean .notice{font-size:12px;color:#716344;line-height:1.7;padding:9px 0;background:none}.sectionPanelClean .actions{display:flex;gap:10px;margin-top:16px}.sectionPanelClean .actions button{flex:1}.sectionPanelClean .primary{background:#28241e;color:#efdeb8}.sectionPanelClean .toggle{display:flex;flex-direction:row;align-items:center;gap:8px}.sectionPanelClean .toggle input{width:auto;min-height:0}@media(max-width:560px){.sectionPanelClean .filterGrid{grid-template-columns:1fr 1fr}.sectionPanelClean{padding:14px}.sectionPanelClean .sectionGrid{grid-template-columns:1fr}}';document.head.append(cleanSectionStyle);
    editSection=function(item){const old=item?.sectionConfig||{};sectionPanel.replaceChildren();sectionPanel.className='sectionPanelClean';sectionPanel.style.width='760px';const heading=document.createElement('h3');heading.textContent=item?'إعدادات السيكشن':'إنشاء سيكشن';sectionPanel.append(heading);function inputField(parent,label,type,value){const l=document.createElement('label');l.textContent=label;const i=document.createElement('input');i.type=type;i.value=value??'';l.append(i);parent.append(l);return i;}function selectField(parent,label,options,value){const l=document.createElement('label');l.textContent=label;const s=document.createElement('select');options.forEach(([v,t])=>{const o=document.createElement('option');o.value=v;o.textContent=t;s.append(o);});s.value=value??'';l.append(s);parent.append(l);return s;}function fieldset(title){const f=document.createElement('fieldset');const l=document.createElement('legend');l.textContent=title;f.append(l);sectionPanel.append(f);return f;}
    const basics=document.createElement('div');basics.className='sectionGrid';sectionPanel.append(basics);const name=inputField(basics,'اسم السيكشن','text',old.name||item?.text||''),purpose=inputField(basics,'الغرض من السيكشن','text',old.purpose||'');const content=fieldset('اختيار العطور');const mode=selectField(content,'طريقة الاختيار',[['manual','اختيار عطور محددة'],['automatic','تلقائي حسب الفلاتر']],old.selectionMode||'manual');const grid=document.createElement('div');grid.className='filterGrid';content.append(grid);const controls={};const optionSpec=[['brand_id','البراند','brands'],['store_id','المتجر','stores'],['category_id','الفئة','categories'],['occasion_id','المناسبة','occasions'],['note_id','النوتة العطرية','notes'],['size_ml','الحجم','sizes']];optionSpec.forEach(([key,label])=>{const s=selectField(grid,label,[['','الكل']], '');s.disabled=true;controls[key]=s;});const min=inputField(grid,'السعر من','number',old.filters?.price_min),max=inputField(grid,'السعر إلى','number',old.filters?.price_max);min.min=max.min='0';const message=document.createElement('div');message.className='notice';content.append(message);const row=document.createElement('div');row.className='perfumeRow';content.append(row);const perfume=selectField(row,'العطر والحجم',[['','اختر العطر من نتائج الفلترة']], '');perfume.disabled=true;const addButton=document.createElement('button');addButton.textContent='إضافة';addButton.disabled=true;row.append(addButton);const selectedBox=document.createElement('div');selectedBox.className='selectionList';content.append(selectedBox);let picks=clone(old.manualProducts||[]),results=[],requestSerial=0;
    function paintPicks(){selectedBox.replaceChildren();picks.forEach((p,n)=>{const box=document.createElement('div');box.className='chosenPerfume';const span=document.createElement('span');span.textContent=p.name+(p.sizeLabel?' — '+p.sizeLabel:'');const b=document.createElement('button');b.textContent='إزالة';b.onclick=()=>{picks.splice(n,1);paintPicks();};box.append(span,b);selectedBox.append(box);});}paintPicks();
    function filters(){const result={};Object.entries(controls).forEach(([key,s])=>{if(s.value)result[key]=key==='size_ml'?Number(s.value):s.value;});if(min.value!=='')result.price_min=Number(min.value);if(max.value!=='')result.price_max=Number(max.value);return result;}
    async function refreshPerfumes(){const seq=++requestSerial;results=[];perfume.replaceChildren();const p=document.createElement('option');p.value='';p.textContent='جارٍ قراءة نتائج الفلترة…';perfume.append(p);perfume.disabled=true;addButton.disabled=true;const provider=window.elanSectionDataProvider;if(!provider?.getPerfumes){p.textContent='العطور متاحة بعد ربط سابابيس';message.textContent='القوائم مجهزة للاختيار بالأسماء. اتصال سابابيس غير منفّذ في هذا الملف، لذلك لا نعرض أسماء أو عطورًا وهمية.';return;}try{const f=filters();if((f.price_min!==undefined&&!Number.isFinite(f.price_min))||(f.price_max!==undefined&&!Number.isFinite(f.price_max))||(f.price_min!==undefined&&f.price_max!==undefined&&f.price_min>f.price_max))throw Error('راجع حدود السعر');const data=await provider.getPerfumes(f);if(seq!==requestSerial)return;if(!Array.isArray(data)||data.some(p=>!p.product_id||!p.product_size_id||!p.name))throw Error('بيانات نتائج غير متوافقة');results=data;perfume.replaceChildren();const empty=document.createElement('option');empty.value='';empty.textContent=results.length?'اختر العطر والحجم':'لا توجد عطور متاحة تطابق الفلاتر';perfume.append(empty);results.forEach((p,n)=>{const o=document.createElement('option');o.value=String(n);o.textContent=p.name+(p.size_label?' — '+p.size_label:'');perfume.append(o);});perfume.disabled=!results.length;message.textContent='عدد النتائج المتاحة: '+results.length;}catch(err){if(seq!==requestSerial)return;perfume.replaceChildren();const o=document.createElement('option');o.value='';o.textContent='تعذر تحميل العطور';perfume.append(o);message.textContent='تعذر قراءة النتائج؛ لم تُضف بيانات بديلة.';}}
    async function loadOptions(){const provider=window.elanSectionDataProvider;if(!provider?.getOptions){refreshPerfumes();return;}message.textContent='جارٍ تحميل قوائم سابابيس…';try{const data=await provider.getOptions();for(const [key,label,list]of optionSpec){if(!Array.isArray(data[list]))throw Error('قائمة ناقصة');const s=controls[key];s.replaceChildren();const all=document.createElement('option');all.value='';all.textContent='كل '+label;s.append(all);data[list].forEach(record=>{const id=key==='size_ml'?record.size_ml:record.id;if(id===undefined||id===null||!record.name)return;const o=document.createElement('option');o.value=String(id);o.textContent=record.name;s.append(o);});if(old.filters?.[key]!==undefined)s.value=String(old.filters[key]);s.disabled=false;s.onchange=refreshPerfumes;}refreshPerfumes();}catch(e){message.textContent='تعذر تحميل قوائم سابابيس. لن يتم تعويضها بقيم وهمية.';}}
    min.onchange=max.onchange=refreshPerfumes;perfume.onchange=()=>addButton.disabled=mode.value!=='manual'||perfume.value==='';addButton.onclick=()=>{const p=results[Number(perfume.value)];if(perfume.value===''||!p)return;if(!picks.some(i=>i.productSizeId===p.product_size_id)){picks.push({productId:p.product_id,productSizeId:p.product_size_id,name:p.name,sizeLabel:p.size_label||null});paintPicks();}};mode.onchange=()=>{row.hidden=mode.value==='automatic';selectedBox.hidden=mode.value==='automatic';addButton.disabled=mode.value!=='manual'||perfume.value==='';};mode.onchange();
    const timerBox=fieldset('توقيت السيكشن');const toggle=document.createElement('label');toggle.className='toggle';const enabled=document.createElement('input');enabled.type='checkbox';enabled.checked=!!old.timer?.enabled;toggle.append(enabled,'تشغيل التوقيت');timerBox.append(toggle);const timing=selectField(timerBox,'طريقة التوقيت',[['dates','بداية ونهاية محددتان'],['duration','مدة من أول حفظ للسيكشن']],old.timer?.mode||'dates');const dateGrid=document.createElement('div');dateGrid.className='sectionGrid';timerBox.append(dateGrid);const start=inputField(dateGrid,'البداية، توقيت مصر','datetime-local',localCairo(old.timer?.startsAt)),end=inputField(dateGrid,'النهاية، توقيت مصر','datetime-local',localCairo(old.timer?.endsAt));const durationGrid=document.createElement('div');durationGrid.className='sectionGrid';timerBox.append(durationGrid);const count=inputField(durationGrid,'المدة','number',old.timer?.durationValue||1);count.min='1';const unit=selectField(durationGrid,'الوحدة',[['hours','ساعات'],['days','أيام']],old.timer?.durationUnit||'hours');function timingUI(){timing.closest('label').hidden=!enabled.checked;dateGrid.hidden=!enabled.checked||timing.value!=='dates';durationGrid.hidden=!enabled.checked||timing.value!=='duration';}enabled.onchange=timingUI;timing.onchange=timingUI;timingUI();
    const actions=document.createElement('div');actions.className='actions';const save=document.createElement('button');save.className='primary';save.textContent='حفظ السيكشن';const close=document.createElement('button');close.textContent='إلغاء';close.onclick=()=>sectionPanel.close();actions.append(save,close);sectionPanel.append(actions);
    save.onclick=()=>{try{if(!name.value.trim()||!purpose.value.trim())throw Error('اكتب الاسم والغرض.');const providerReady=!!window.elanSectionDataProvider?.getOptions;const f=providerReady?filters():clone(old.filters||{});if((f.price_min!==undefined&&f.price_min<0)||(f.price_max!==undefined&&f.price_max<0)||(f.price_min!==undefined&&f.price_max!==undefined&&f.price_min>f.price_max))throw Error('راجع حدود السعر.');const createdAt=old.createdAt||new Date().toISOString();const timer={enabled:enabled.checked,mode:timing.value,timeZone:'Africa/Cairo',durationValue:Number(count.value),durationUnit:unit.value,startsAt:null,endsAt:null};if(timer.enabled){if(timer.mode==='dates'){timer.startsAt=cairoUTC(start.value);timer.endsAt=cairoUTC(end.value);if(!timer.startsAt||!timer.endsAt||Date.parse(timer.endsAt)<=Date.parse(timer.startsAt))throw Error('حدد مواعيد صحيحة.');}else{if(!Number.isFinite(timer.durationValue)||timer.durationValue<=0)throw Error('حدد مدة أكبر من صفر');timer.startsAt=createdAt;timer.endsAt=new Date(Date.parse(createdAt)+timer.durationValue*(unit.value==='days'?86400000:3600000)).toISOString();}}checkpoint();let target=item;if(!target){windowSectionAdd();target=current();}target.text=name.value.trim();target.sectionConfig={name:name.value.trim(),purpose:purpose.value.trim(),selectionMode:mode.value,filters:f,manualProducts:picks,createdAt,timer,dataSource:{products:'public_products',offers:'cheapest_offers',connection:providerReady?'provider_configured':'not_connected'}};attachDefinition(target);target.binding.name=target.sectionConfig.name;target.binding.purpose=target.sectionConfig.purpose;selected=target.id;reflowAt(target.id,{...contextPoint});changed();document.getElementById('save').click();sectionPanel.close();checkSections();}catch(e){alert(e.message);}};sectionPanel.showModal();loadOptions();};
    
    cleanSectionStyle.textContent += ".sectionPanelClean [hidden]{display:none!important}";
    
    </script><script>
    // Manual sidebar mirrors the real provider results; automatic mode retains all matching results.
    const selectionRepairStyle=document.createElement('style');selectionRepairStyle.textContent='.sectionPanelClean{width:1000px!important}.sectionPanelClean .manualLayout{display:grid;grid-template-columns:minmax(0,1fr) 270px;gap:14px}.sectionPanelClean .manualResults{border:1px solid #d7c29c;border-radius:12px;padding:12px;background:#fffaf0;max-height:420px;overflow:auto}.sectionPanelClean .manualResults h4{margin-top:0}.sectionPanelClean .manualResults label{display:flex;flex-direction:row;align-items:center;gap:8px;padding:9px 0;border-bottom:1px solid #e7ddc8}.sectionPanelClean .manualResults input{width:auto;min-height:0}.sectionPanelClean .modeHelp{font-size:12px;line-height:1.8;color:#756443;margin:8px 0}@media(max-width:700px){.sectionPanelClean .manualLayout{grid-template-columns:1fr}}';document.head.append(selectionRepairStyle);
    const sectionBeforeSelectionFix=editSection;
    editSection=function(item){sectionBeforeSelectionFix(item);const panel=sectionPanel;const content=Array.from(panel.querySelectorAll('fieldset')).find(f=>f.querySelector('legend')?.textContent==='اختيار العطور');if(!content)return;const mode=content.querySelector('select');const row=content.querySelector('.perfumeRow');const select=row.querySelector('select');const add=row.querySelector('button');const chosen=content.querySelector('.selectionList');const notice=content.querySelector('.notice');const grid=content.querySelector('.filterGrid');grid.querySelectorAll('select').forEach(s=>{s.disabled=false;s.title='قائمة الأسماء تأتي من سابابيس عند الربط';});
    const layout=document.createElement('div');layout.className='manualLayout';const main=document.createElement('div');const sidebar=document.createElement('div');sidebar.className='manualResults';content.append(layout);layout.append(main,sidebar);main.append(grid,notice,chosen);row.hidden=true;row.style.display='none';main.append(row);const explanation=document.createElement('div');explanation.className='modeHelp';content.insertBefore(explanation,layout);
    let marked=new Set();function drawSidebar(){sidebar.replaceChildren();const h=document.createElement('h4');h.textContent='العطور الناتجة عن الفلترة';sidebar.append(h);const options=Array.from(select.options).filter(o=>o.value!=='');if(!options.length){const p=document.createElement('p');p.textContent=window.elanSectionDataProvider?'لا توجد نتائج جاهزة، أو جارٍ تحميلها.':'قائمة النتائج تحتاج اتصال سابابيس؛ لا توجد بيانات فعلية في الملف.';sidebar.append(p);return;}options.forEach(o=>{const label=document.createElement('label');const box=document.createElement('input');box.type='checkbox';box.checked=marked.has(o.value);box.onchange=()=>box.checked?marked.add(o.value):marked.delete(o.value);label.append(box,o.textContent);sidebar.append(label);});const addSelected=document.createElement('button');addSelected.textContent='إضافة العطور المحددة';addSelected.onclick=()=>{for(const value of marked){select.value=value;select.dispatchEvent(new Event('change'));if(!add.disabled)add.click();}marked.clear();drawSidebar();};sidebar.append(addSelected);}
    const modeHandler=mode.onchange;mode.onchange=()=>{modeHandler();row.hidden=true;row.style.display='none';sidebar.hidden=mode.value!=='manual';layout.style.gridTemplateColumns=mode.value==='manual'?'minmax(0,1fr) 270px':'1fr';explanation.textContent=mode.value==='manual'?'اختر الفلاتر، ثم حدّد عطورًا من القائمة الجانبية واضغط إضافة.':'كل العطور المطابقة للفلاتر تدخل في السيكشن تلقائيًا بعد الربط، بدون تحديد عطر فردي أو حد مختارات.';drawSidebar();};mode.onchange();const observer=new MutationObserver(()=>{marked.clear();drawSidebar();});observer.observe(select,{childList:true});panel.addEventListener('close',()=>observer.disconnect(),{once:true});
    const save=panel.querySelector('.actions .primary');const oldSave=save.onclick;save.onclick=()=>{oldSave();if(panel.open)return;const target=current();if(target?.sectionConfig){target.sectionConfig.includeAllMatching=mode.value==='automatic';target.sectionConfig.selectionStrategy=mode.value==='automatic'?'all_filtered_products':'explicit_product_size_ids';target.sectionConfig.resultSource={products:'public_products',offers:'cheapest_offers',filters:clone(target.sectionConfig.filters),manualSelectionUses:'manualProducts.productSizeId'};document.getElementById('save').click();}};
    };caption.textContent='VISUAL EDITOR · SECTION SELECTION';
    
    
    </script><script>
    // Always-visible explicit add actions for both selection modes.
    const sectionBeforeAddActions=editSection;
    editSection=function(item){sectionBeforeAddActions(item);const panel=sectionPanel;const content=Array.from(panel.querySelectorAll('fieldset')).find(f=>f.querySelector('legend')?.textContent==='اختيار العطور');if(!content)return;const mode=content.querySelector('select');const sidebar=content.querySelector('.manualResults');const bar=document.createElement('div');bar.style.cssText='display:flex;align-items:center;gap:10px;margin-top:12px;flex-wrap:wrap';const manualButton=document.createElement('button');manualButton.textContent='إضافة العطور المحددة';manualButton.className='primary';const automaticButton=document.createElement('button');automaticButton.textContent='إضافة العناصر';automaticButton.className='primary';const feedback=document.createElement('span');feedback.style.cssText='font-size:12px;color:#79643f';bar.append(manualButton,automaticButton,feedback);content.append(bar);let automaticMatches=null;
    function updateAddActions(){manualButton.hidden=mode.value!=='manual';automaticButton.hidden=mode.value!=='automatic';if(mode.value==='manual')feedback.textContent='حدّد العطور في القائمة الجانبية، ثم اضغط إضافة.';else feedback.textContent='إضافة كل نتائج الفلاتر الحالية، بدون اختيار عطر فردي.';}
    const modeBeforeButtons=mode.onchange;mode.onchange=()=>{modeBeforeButtons();automaticMatches=null;updateAddActions();};updateAddActions();
    manualButton.onclick=()=>{const checks=sidebar?Array.from(sidebar.querySelectorAll('input[type=checkbox]:checked')):[];if(!checks.length){feedback.textContent='اختر عطرًا أو أكثر من نتائج الفلترة أولًا.';return;}const button=Array.from(sidebar.querySelectorAll('button')).find(b=>b.textContent==='إضافة العطور المحددة');if(button){button.click();feedback.textContent='أضيفت العطور إلى اختيارات السيكشن. اضغط حفظ السيكشن لاعتمادها.';}else feedback.textContent='تعذر إضافة الاختيارات، أعد تحميل النتائج.';};
    // Sidebar's own button can remain; main action is always present.
    automaticButton.onclick=async()=>{const provider=window.elanSectionDataProvider;if(!provider?.getPerfumes){feedback.textContent='إضافة العناصر الفعلية تتطلب ربط سابابيس. لم تتم إضافة عطور وهمية.';return;}const grid=content.querySelector('.filterGrid');const selects=Array.from(grid.querySelectorAll('select'));const keys=['brand_id','store_id','category_id','occasion_id','note_id','size_ml'];const filters={};selects.forEach((s,n)=>{if(s.value)filters[keys[n]]=keys[n]==='size_ml'?Number(s.value):s.value;});const numbers=Array.from(grid.querySelectorAll('input[type=number]'));if(numbers[0]?.value!=='')filters.price_min=Number(numbers[0].value);if(numbers[1]?.value!=='')filters.price_max=Number(numbers[1].value);automaticButton.disabled=true;feedback.textContent='جارٍ إضافة نتائج الفلترة…';try{const rows=await provider.getPerfumes(filters);if(!Array.isArray(rows)||rows.some(p=>!p.product_id||!p.product_size_id||!p.name))throw Error();automaticMatches=rows.map(p=>({productId:p.product_id,productSizeId:p.product_size_id,name:p.name,sizeLabel:p.size_label||null}));feedback.textContent='أضيفت '+automaticMatches.length+' نتيجة إلى إعداد السيكشن. اضغط حفظ السيكشن لاعتمادها.';}catch(e){feedback.textContent='تعذر تحميل العناصر؛ لم تُعتمد نتائج بديلة.';}finally{automaticButton.disabled=false;}};
    content.querySelector('.filterGrid').addEventListener('change',()=>{automaticMatches=null;});const save=panel.querySelector('.actions .primary');const saveBeforeMatches=save.onclick;save.onclick=()=>{saveBeforeMatches();if(panel.open)return;const target=current();if(target?.sectionConfig&&mode.value==='automatic'){target.sectionConfig.automaticSelectionPreview=automaticMatches||[];target.sectionConfig.includeAllMatching=true;target.sectionConfig.automaticRefreshFromFilters=true;document.getElementById('save').click();}};
    };caption.textContent='VISUAL EDITOR · SECTION ADD ACTIONS';
    
    
    </script><script>
    // Per-perfume manual addition; one add-all action for automatic selection.
    const sectionBeforeRowActions=editSection;
    editSection=function(item){sectionBeforeRowActions(item);const content=Array.from(sectionPanel.querySelectorAll('fieldset')).find(f=>f.querySelector('legend')?.textContent==='اختيار العطور');if(!content)return;const mode=content.querySelector('select'),sidebar=content.querySelector('.manualResults'),chosen=content.querySelector('.selectionList');if(!sidebar)return;
    const primaryManual=Array.from(content.querySelectorAll('button')).find(b=>b.textContent==='إضافة العطور المحددة'&&b.parentElement!==sidebar);if(primaryManual){primaryManual.style.display='none';const feedback=primaryManual.parentElement.querySelector('span');if(feedback)feedback.style.display='none';}
    function selectedNames(){return new Set(Array.from(chosen.querySelectorAll('.chosenPerfume span')).map(s=>s.textContent.trim()));}
    function updateRows(){const saved=selectedNames();Array.from(sidebar.querySelectorAll('label')).forEach(label=>{const checkbox=label.querySelector('input[type=checkbox]');if(!checkbox)return;if(!label.dataset.perPerfume){const name=Array.from(label.childNodes).filter(n=>n.nodeType===Node.TEXT_NODE).map(n=>n.textContent).join('').trim();label.dataset.perPerfume='true';label.dataset.perfumeName=name;checkbox.style.display='none';label.style.display='flex';const title=document.createElement('span');title.textContent=name;title.style.flex='1';Array.from(label.childNodes).filter(n=>n.nodeType===Node.TEXT_NODE).forEach(n=>n.remove());label.append(title);const b=document.createElement('button');b.type='button';b.dataset.singleAdd='true';b.style.cssText='white-space:nowrap;padding:7px 10px';b.onclick=e=>{e.preventDefault();e.stopPropagation();if(b.disabled)return;sidebar.querySelectorAll('input[type=checkbox]').forEach(c=>{c.checked=c===checkbox;c.onchange?.();});const bulk=Array.from(sidebar.children).find(n=>n.tagName==='BUTTON'&&n.textContent==='إضافة العطور المحددة');if(bulk){bulk.click();updateRows();}};label.append(b);}const button=label.querySelector('button[data-single-add]');const isAdded=saved.has(label.dataset.perfumeName);if(button.disabled!==isAdded)button.disabled=isAdded;const text=isAdded?'✓ تمت الإضافة':'إضافة';if(button.textContent!==text)button.textContent=text;button.style.background=isAdded?'#e3efe2':'#fffaf0';});Array.from(sidebar.children).filter(n=>n.tagName==='BUTTON'&&n.textContent==='إضافة العطور المحددة').forEach(b=>b.style.display='none');}
    const previousMode=mode.onchange;mode.onchange=()=>{previousMode();if(primaryManual)primaryManual.style.display='none';updateRows();};
    const observer=new MutationObserver(updateRows);observer.observe(sidebar,{childList:true,subtree:true});observer.observe(chosen,{childList:true,subtree:true});sectionPanel.addEventListener('close',()=>observer.disconnect(),{once:true});updateRows();};caption.textContent='VISUAL EDITOR · INDIVIDUAL PERFUME ADD';
    
    
    </script><script>
    // Approved brand creation panel: one name input, Create and Cancel.
    const brandPanel=document.createElement('dialog');brandPanel.style.cssText='width:380px;max-width:92vw;padding:22px;background:#fffdf8;border:1px solid #c6aa70;border-radius:14px';document.body.append(brandPanel);
    function openBrandPanel(){brandPanel.replaceChildren();const title=document.createElement('h3');title.textContent='إنشاء كارت براند';title.style.cssText='margin:0 0 18px;color:#87652d';const label=document.createElement('label');label.textContent='اسم البراند';const name=document.createElement('input');name.type='text';name.autocomplete='off';name.style.cssText='display:block;width:100%;margin-top:8px;padding:10px;background:white';label.append(name);const actions=document.createElement('div');actions.style.cssText='display:flex;gap:10px;margin-top:18px';const create=document.createElement('button');create.textContent='إنشاء';create.style.cssText='flex:1;background:#29251e;color:#f0dfb9';const cancel=document.createElement('button');cancel.textContent='إلغاء';cancel.style.flex='1';cancel.onclick=()=>brandPanel.close();create.onclick=()=>{const value=name.value.trim();if(!value){name.focus();name.setCustomValidity('اكتب اسم البراند');name.reportValidity();return;}name.setCustomValidity('');addKind('brand');const item=current();if(!item)return;item.text=value;attachDefinition(item);item.binding.name=value;item.binding.entityId=null;item.binding.status='pending_connection';item.brandCreationRequest={version:1,name:value,status:'pending_connection',table:'brands',reuseExistingIfMatched:true,createIfNew:true,matchSource:'connected_store_catalogues',populateOfficialDataOnlyWhenVerified:true,includeOnlyMatchingBrandProducts:true,productVisibility:'public_products',offerSource:'cheapest_offers',noFabricatedProducts:true,unverifiedMatchRequiresReview:true};changed();render();document.getElementById('save').click();brandPanel.close();};name.oninput=()=>name.setCustomValidity('');name.onkeydown=e=>{if(e.key==='Enter'){e.preventDefault();create.click();}};actions.append(create,cancel);brandPanel.append(title,label,actions);brandPanel.showModal();name.focus();}
    const menuBeforeBrandPanel=showMenu;showMenu=function(e){menuBeforeBrandPanel(e);const button=Array.from(menu.children).find(b=>b.textContent==='إنشاء كارت براند');if(button)button.onclick=()=>{menu.style.display='none';openBrandPanel();};};caption.textContent='VISUAL EDITOR · BRAND PANEL';
    
    
    </script><script>
    // Vertical text position, independent from horizontal alignment.
    const positionLabel=document.createElement('label');positionLabel.textContent='الوضعية';const positionSelect=document.createElement('select');[['top','أعلى'],['middle','وسط'],['bottom','أسفل']].forEach(([value,label])=>{const o=document.createElement('option');o.value=value;o.textContent=label;positionSelect.append(o);});positionLabel.append(positionSelect);textGroup.grid.append(positionLabel);
    const textPositionStyle=document.createElement('style');textPositionStyle.textContent='#format .textRow{grid-template-columns:minmax(0,1.5fr) repeat(3,minmax(0,1fr))}';document.head.append(textPositionStyle);
    const openBeforeTextPosition=openFormat;openFormat=function(){openBeforeTextPosition();const item=state.items.find(i=>i.id===formatTargetId);positionSelect.value=item?.textPosition||'top';};
    const applyBeforeTextPosition=document.getElementById('apply').onclick;document.getElementById('apply').onclick=()=>{const item=state.items.find(i=>i.id===formatTargetId);const value=positionSelect.value;applyBeforeTextPosition();if(item){item.textPosition=value;changed();render();}};
    const renderBeforeTextPosition=render;render=function(){renderBeforeTextPosition();state.items.forEach(item=>{if(!['text','card','section'].includes(item.type))return;const el=Array.from(canvas.children).find(el=>el.dataset.id===item.id);const content=el?.querySelector('.content');if(!content)return;content.style.display='flex';content.style.flexDirection='column';content.style.justifyContent=item.textPosition==='middle'?'center':item.textPosition==='bottom'?'flex-end':'flex-start';});};
    positionSelect.addEventListener('change',()=>{sample.style.display='flex';sample.style.flexDirection='column';sample.style.minHeight='100px';sample.style.justifyContent=positionSelect.value==='middle'?'center':positionSelect.value==='bottom'?'flex-end':'flex-start';});caption.textContent='VISUAL EDITOR · TEXT POSITION';render();
    
    
    </script><script>
    // Reuse the approved section panel without section name/purpose.
    function openPerfumePanel(){const point={...contextPoint};const origin=selected;const anchor=state.items.find(i=>i.id===origin);const stage={id:uid(),type:'section',text:'',binding:{},sectionConfig:{name:'اختيار عطور',purpose:'إضافة كروت عطور',selectionMode:'manual',manualProducts:[],filters:{},timer:{enabled:false,mode:'dates'}}};editSection(stage);sectionPanel.querySelector('h3').textContent='إنشاء كارت عطر';const basics=sectionPanel.querySelector('.sectionGrid');if(basics){basics.style.display='none';basics.querySelectorAll('input').forEach((input,n)=>input.value=n===0?'اختيار عطور':'إضافة كروت عطور');}const commit=sectionPanel.querySelector('.actions .primary');commit.textContent='حفظ كروت العطور';const panelSave=commit.onclick;commit.onclick=async()=>{const originalSelected=selected;selected=null;panelSave();if(sectionPanel.open){selected=originalSelected;return;}const cfg=stage.sectionConfig;const provider=window.elanSectionDataProvider;let choices=cfg.manualProducts||[];if(cfg.selectionMode==='automatic'){if(!provider?.getPerfumes){alert('لا توجد بيانات عطور متصلة. إضافة كل النتائج تحتاج ربط سابابيس، ولن ننشئ كروتًا وهمية.');selected=originalSelected;sectionPanel.showModal();return;}try{const rows=await provider.getPerfumes(cfg.filters);if(!Array.isArray(rows)||rows.some(p=>!p.product_id||!p.product_size_id||!p.name))throw Error();choices=rows.map(p=>({productId:p.product_id,productSizeId:p.product_size_id,name:p.name,sizeLabel:p.size_label||null}));}catch(e){alert('تعذر تحميل نتائج الفلترة؛ لم تُنشأ كروت بديلة.');selected=originalSelected;sectionPanel.showModal();return;}}if(!choices.length){alert('أضف عطرًا من القائمة أولًا، أو اختر فلاتر لها نتائج في الوضع التلقائي.');selected=originalSelected;sectionPanel.showModal();return;}checkpoint();const ids=new Set();const added=[];choices.forEach((p,n)=>{if(ids.has(p.productSizeId))return;ids.add(p.productSizeId);const id=uid();const i={id,type:'card',kind:'perfume',text:p.name+(p.sizeLabel?'\n'+p.sizeLabel:''),x:Math.max(0,Math.min(800,point.x)),y:Math.max(0,point.y)+n*264,w:300,h:240,font:'Tahoma',size:22,color:'#222222',bg:'#fffdf9',align:'right',binding:{name:p.name,entityId:p.productId,productSizeId:p.productSizeId,status:'catalogue_selected'},parentSectionId:anchor?.type==='section'?anchor.id:null,sectionConfig:clone(cfg)};i.sectionConfig.manualProducts=[clone(p)];i.sectionConfig.selectionStrategy=cfg.selectionMode==='automatic'?'all_filtered_products':'explicit_product_size_ids';i.sectionConfig.includeAllMatching=cfg.selectionMode==='automatic';attachDefinition(i);state.items.push(i);added.push(i);});if(anchor?.type==='section'){if(!anchor.sectionConfig)anchor.sectionConfig={manualProducts:[]};if(!Array.isArray(anchor.sectionConfig.manualProducts))anchor.sectionConfig.manualProducts=[];choices.forEach(p=>{if(!anchor.sectionConfig.manualProducts.some(x=>x.productSizeId===p.productSizeId))anchor.sectionConfig.manualProducts.push(clone(p));});}if(added.length){selected=added[0].id;reflowAt(selected,point);}else selected=originalSelected;changed();render();document.getElementById('save').click();checkSections();};}
    const menuBeforePerfumePanel=showMenu;showMenu=function(e){menuBeforePerfumePanel(e);const button=Array.from(menu.children).find(b=>b.textContent==='إنشاء كارت عطر');if(button)button.onclick=()=>{menu.style.display='none';openPerfumePanel();};};caption.textContent='VISUAL EDITOR · PERFUME PANEL';
    
    
    </script><script>
    // Compact styling for section/perfume panels only.
    const compactCampaignStyle=document.createElement('style');compactCampaignStyle.textContent='.sectionPanelClean{width:min(960px,96vw)!important;max-height:96dvh!important;padding:12px 16px!important}.sectionPanelClean h3{font-size:17px;margin:0 0 8px!important}.sectionPanelClean label{font-size:11px;gap:3px}.sectionPanelClean input,.sectionPanelClean select{font-size:11px;min-height:29px!important;padding:5px 7px}.sectionPanelClean button{font-size:11px;padding:6px 9px}.sectionPanelClean fieldset{margin:7px 0;padding:8px 10px}.sectionPanelClean legend{font-size:12px}.sectionPanelClean .sectionGrid{gap:8px}.sectionPanelClean .filterGrid{grid-template-columns:repeat(4,minmax(0,1fr));gap:6px}.sectionPanelClean .manualLayout{gap:9px}.sectionPanelClean .manualResults{padding:8px;max-height:190px!important;overflow:auto}.sectionPanelClean .manualResults h4{font-size:12px;margin:0 0 5px}.sectionPanelClean .manualResults label{padding:5px 0;font-size:11px}.sectionPanelClean .selectionList{margin-top:5px;gap:4px;max-height:76px;overflow:auto}.sectionPanelClean .chosenPerfume{font-size:11px;padding:5px 7px}.sectionPanelClean .notice,.sectionPanelClean .modeHelp{font-size:10px;line-height:1.5;margin:4px 0;padding:3px 0}.sectionPanelClean .actions{margin-top:8px;gap:8px}.sectionPanelClean .toggle{font-size:11px;margin-bottom:4px}.sectionPanelClean .perfumeRow{margin:6px 0}.sectionPanelClean fieldset:last-of-type>.sectionGrid{display:grid;grid-template-columns:1fr 1fr}.sectionPanelClean fieldset:last-of-type>label:not(.toggle){max-width:100%}@media(min-width:700px) and (min-height:700px){.sectionPanelClean{max-height:94dvh}}@media(max-width:600px){.sectionPanelClean{padding:10px!important}.sectionPanelClean .filterGrid{grid-template-columns:repeat(2,minmax(0,1fr))}.sectionPanelClean .manualResults{max-height:140px!important}}';document.head.append(compactCampaignStyle);caption.textContent='VISUAL EDITOR · COMPACT PANELS';
    
    
    </script><script>
    // Replace the overcompressed panel styling; behavior stays unchanged.
    compactCampaignStyle.remove();
    const balancedPanelStyle=document.createElement('style');balancedPanelStyle.textContent=`
    .sectionPanelClean{width:min(790px,94vw)!important;max-height:92dvh!important;padding:20px!important;background:#fffdf9;color:#302b23;border:1px solid #c8ae79;border-radius:18px;box-shadow:0 24px 80px #0003;overflow:auto}
    .sectionPanelClean::backdrop{background:rgba(21,19,15,.45)}
    .sectionPanelClean h3{font-size:19px;font-weight:700;line-height:1.4;color:#86642e;margin:0 0 15px!important;padding-bottom:12px;border-bottom:1px solid #e9dec8}
    .sectionPanelClean label{font-size:12px;line-height:1.5;font-weight:500;gap:5px;min-width:0}
    .sectionPanelClean input,.sectionPanelClean select{width:100%;min-width:0;font:12px Tahoma,Arial;min-height:35px!important;height:35px;padding:7px 9px;border:1px solid #dccfb6;border-radius:7px;background:#fff;box-shadow:none;color:#302b23}
    .sectionPanelClean input:focus,.sectionPanelClean select:focus{outline:2px solid #cfb57966;outline-offset:1px;border-color:#ae8d4e}
    .sectionPanelClean input:disabled,.sectionPanelClean select:disabled{background:#f1eee7;color:#938977}
    .sectionPanelClean button{font:12px Tahoma,Arial;padding:8px 12px;border-radius:8px;min-height:34px}
    .sectionPanelClean fieldset{margin:12px 0;padding:12px;border:1px solid #e2d6bd;border-radius:12px;background:#faf7f0;min-width:0}
    .sectionPanelClean legend{font-size:13px;font-weight:700;color:#86642e;padding:0 7px}
    .sectionPanelClean .sectionGrid{display:grid;grid-template-columns:1fr 1fr;gap:10px}
    .sectionPanelClean .filterGrid{grid-template-columns:repeat(3,minmax(0,1fr))!important;gap:9px}
    .sectionPanelClean .manualLayout{grid-template-columns:minmax(0,1fr) 225px;gap:12px;align-items:start}
    .sectionPanelClean .manualResults{padding:10px;max-height:255px!important;min-height:110px;border:1px solid #ddcba7;background:#fffdf8;border-radius:10px;overflow:auto}
    .sectionPanelClean .manualResults h4{font-size:13px;color:#76582a;margin:0 0 9px;padding-bottom:7px;border-bottom:1px solid #ece2cf}
    .sectionPanelClean .manualResults label{font-size:12px;padding:7px 0;gap:6px}
    .sectionPanelClean .manualResults p{font-size:12px;line-height:1.8;color:#827459;margin:6px 0}
    .sectionPanelClean .manualResults input[type=checkbox],.sectionPanelClean .toggle input{width:16px;height:16px;min-height:16px!important;padding:0;flex-shrink:0}
    .sectionPanelClean .selectionList{gap:6px;margin-top:9px;max-height:110px;overflow:auto}
    .sectionPanelClean .chosenPerfume{font-size:12px;padding:7px 9px;background:#fff;border-color:#e2d7c3}
    .sectionPanelClean .notice,.sectionPanelClean .modeHelp{font-size:11px;line-height:1.7;color:#827358;padding:5px 0;margin:5px 0}
    .sectionPanelClean .toggle{font-size:12px;margin-bottom:9px;gap:8px}
    .sectionPanelClean .actions{margin-top:14px;padding-top:12px;border-top:1px solid #e9dec8;gap:10px}
    .sectionPanelClean .actions button{min-height:39px;font-size:13px}
    .sectionPanelClean .primary{background:#30291f;color:#f1dfb7;border-color:#30291f}
    .sectionPanelClean [hidden]{display:none!important}
    @media(max-width:650px){.sectionPanelClean{width:94vw!important;padding:14px!important}.sectionPanelClean .manualLayout{grid-template-columns:1fr!important}.sectionPanelClean .filterGrid{grid-template-columns:repeat(2,minmax(0,1fr))!important}.sectionPanelClean .manualResults{max-height:190px!important}}
    `;document.head.append(balancedPanelStyle);
    // Keep the automatic-mode single column, and balanced manual-mode proportions.
    const panelBeforeBalanced=editSection;editSection=function(item){panelBeforeBalanced(item);const content=Array.from(sectionPanel.querySelectorAll('fieldset')).find(f=>f.querySelector('legend')?.textContent==='اختيار العطور');const mode=content?.querySelector('select'),layout=content?.querySelector('.manualLayout');if(mode&&layout){const old=mode.onchange;mode.onchange=()=>{old();layout.style.gridTemplateColumns=mode.value==='manual'?'minmax(0,1fr) 225px':'1fr';};layout.style.gridTemplateColumns=mode.value==='manual'?'minmax(0,1fr) 225px':'1fr';}};
    caption.textContent='VISUAL EDITOR · BALANCED PANELS';
    
    
    </script><script>
    // Remove exactly the two requested explanatory messages.
    const removedPanelTexts=new Set(['اختر الفلاتر، ثم حدّد عطورًا من القائمة الجانبية واضغط إضافة.','القوائم مجهزة للاختيار بالأسماء. اتصال سابابيس غير منفّذ في هذا الملف، لذلك لا نعرض أسماء أو عطورًا وهمية.']);
    function cleanRequestedPanelCopy(){sectionPanel.querySelectorAll('.modeHelp,.notice').forEach(el=>{if(removedPanelTexts.has(el.textContent.trim())){el.textContent='';el.hidden=true;}else if(el.textContent.trim()){el.hidden=false;}});}
    const panelBeforeCopyRemoval=editSection;editSection=function(item){panelBeforeCopyRemoval(item);cleanRequestedPanelCopy();const watch=new MutationObserver(cleanRequestedPanelCopy);watch.observe(sectionPanel,{childList:true,subtree:true,characterData:true});sectionPanel.addEventListener('close',()=>watch.disconnect(),{once:true});};
    
    
    </script><script>
    // Requested sidebar height and context-menu cleanup only.
    const tallerPerfumeSidebar=document.createElement('style');tallerPerfumeSidebar.textContent='.sectionPanelClean .manualResults{min-height:300px!important;max-height:420px!important}@media(max-width:650px){.sectionPanelClean .manualResults{min-height:220px!important;max-height:330px!important}}';document.head.append(tallerPerfumeSidebar);
    const menuBeforeTwoRemovals=showMenu;showMenu=function(e){menuBeforeTwoRemovals(e);Array.from(menu.children).forEach(button=>{if(['تعريف العنصر ومصدر بياناته','إعدادات السيكشن'].includes(button.textContent.trim()))button.remove();});const rect=menu.getBoundingClientRect();menu.style.top=Math.max(4,Math.min(e.clientY,innerHeight-rect.height-8))+'px';};
    
    
    </script><script>
    // Remove only the requested label text; retain the selection-mode control.
    const panelBeforeModeLabelRemoval=editSection;
    editSection=function(item){panelBeforeModeLabelRemoval(item);sectionPanel.querySelectorAll('label').forEach(label=>{if(!label.querySelector('select'))return;Array.from(label.childNodes).forEach(node=>{if(node.nodeType===Node.TEXT_NODE&&node.textContent.trim()==='طريقة الاختيار')node.remove();});});};
    
    
    </script><script>
    // Name-only occasion and aromatic-note panels; no fabricated product matching.
    const taxonomyPanel=document.createElement('dialog');taxonomyPanel.style.cssText='width:380px;max-width:92vw;padding:22px;background:#fffdf8;border:1px solid #c6aa70;border-radius:14px';document.body.append(taxonomyPanel);
    function openTaxonomyPanel(kind){const occasion=kind==='occasion';const table=occasion?'occasions':'aromatic_notes',relationTable=occasion?'product_occasions':'product_notes',relationId=occasion?'occasion_id':'note_id';taxonomyPanel.replaceChildren();const title=document.createElement('h3');title.textContent=occasion?'إنشاء كارت مناسبة':'إنشاء كارت نوتة عطرية';title.style.cssText='margin:0 0 18px;color:#87652d';const label=document.createElement('label');label.textContent=occasion?'اسم المناسبة':'اسم النوتة العطرية';const name=document.createElement('input');name.type='text';name.autocomplete='off';name.style.cssText='display:block;width:100%;margin-top:8px;padding:10px;background:white';label.append(name);const actions=document.createElement('div');actions.style.cssText='display:flex;gap:10px;margin-top:18px';const create=document.createElement('button');create.textContent='إنشاء';create.style.cssText='flex:1;background:#29251e;color:#f0dfb9';const cancel=document.createElement('button');cancel.textContent='إلغاء';cancel.style.flex='1';cancel.onclick=()=>taxonomyPanel.close();name.oninput=()=>name.setCustomValidity('');create.onclick=()=>{const value=name.value.trim();if(!value){name.focus();name.setCustomValidity('اكتب الاسم');name.reportValidity();return;}name.setCustomValidity('');addKind(kind);const item=current();if(!item)return;item.text=value;attachDefinition(item);item.binding.name=value;item.binding.entityId=null;item.binding.status='pending_connection';item.taxonomyCreationRequest={version:1,kind,name:value,status:'pending_connection',table,relationTable,relationId,productIdField:'product_id',reuseExistingIfMatched:true,createIfNew:true,automaticProductAssignment:true,manualProductSelectionRequired:false,matchSource:'available_verified_database_and_catalogue_data',preferExistingRelations:true,createRelationsOnlyWithVerifiedEvidence:true,noUnsupportedInference:true,emptyWhenEvidenceInsufficient:true,productVisibility:'public_products',offerSource:'cheapest_offers',noFabricatedProducts:true};changed();render();document.getElementById('save').click();taxonomyPanel.close();};name.onkeydown=e=>{if(e.key==='Enter'){e.preventDefault();create.click();}};actions.append(create,cancel);taxonomyPanel.append(title,label,actions);taxonomyPanel.showModal();name.focus();}
    const menuBeforeTaxonomyPanels=showMenu;showMenu=function(e){menuBeforeTaxonomyPanels(e);Array.from(menu.children).forEach(button=>{if(button.textContent==='إنشاء مناسبة')button.onclick=()=>{menu.style.display='none';openTaxonomyPanel('occasion');};if(button.textContent==='إنشاء نوتة عطر')button.onclick=()=>{menu.style.display='none';openTaxonomyPanel('note');};});};caption.textContent='VISUAL EDITOR · OCCASION & NOTE';
    
    
    </script><script>
    // Name-only store creation panel with the supplied schema and pricing rules.
    const storePanel=document.createElement('dialog');storePanel.style.cssText='width:380px;max-width:92vw;padding:22px;background:#fffdf8;border:1px solid #c6aa70;border-radius:14px';document.body.append(storePanel);
    function openStorePanel(){storePanel.replaceChildren();const title=document.createElement('h3');title.textContent='إنشاء كارت متجر';title.style.cssText='margin:0 0 18px;color:#87652d';const label=document.createElement('label');label.textContent='اسم المتجر';const name=document.createElement('input');name.type='text';name.autocomplete='off';name.style.cssText='display:block;width:100%;margin-top:8px;padding:10px;background:white';label.append(name);const actions=document.createElement('div');actions.style.cssText='display:flex;gap:10px;margin-top:18px';const create=document.createElement('button');create.textContent='إنشاء';create.style.cssText='flex:1;background:#29251e;color:#f0dfb9';const cancel=document.createElement('button');cancel.textContent='إلغاء';cancel.style.flex='1';cancel.onclick=()=>storePanel.close();name.oninput=()=>name.setCustomValidity('');create.onclick=()=>{const value=name.value.trim();if(!value){name.focus();name.setCustomValidity('اكتب اسم المتجر');name.reportValidity();return;}name.setCustomValidity('');addKind('store');const item=current();if(!item)return;item.text=value;attachDefinition(item);item.binding.name=value;item.binding.entityId=null;item.binding.status='pending_connection';item.storeCreationRequest={version:1,name:value,status:'pending_connection',table:'stores',fields:clone(suppliedSchema.tables.stores),relations:{'store_products.store_id':'stores.id','store_products.product_size_id':'product_sizes.id','product_sizes.product_id':'products.id','products.brand_id':'brands.id'},reuseExistingIfMatched:true,createIfNew:true,integrationCompleted:false,separateStoreCatalogue:true,approvedBrands:clone(suppliedSchema.initial.brands),hiddenPublicFields:['website_url'],dataSources:{price:'store_catalog',availability:'store_catalog',quantity:'store_catalog',offers:'store_catalog'},rules:clone(suppliedSchema.rules),visibilityView:'public_products',cheapestOfferDefinition:clone(suppliedSchema.views.cheapest_offers),storeCataloguePrices:'Use this store actual offers; never attribute another store price or stock to this store.',credentialsRequiredInThisPanel:false};changed();render();document.getElementById('save').click();storePanel.close();};name.onkeydown=e=>{if(e.key==='Enter'){e.preventDefault();create.click();}};actions.append(create,cancel);storePanel.append(title,label,actions);storePanel.showModal();name.focus();}
    const menuBeforeStorePanel=showMenu;showMenu=function(e){menuBeforeStorePanel(e);const button=Array.from(menu.children).find(b=>b.textContent==='إنشاء كارت متجر');if(button)button.onclick=()=>{menu.style.display='none';openStorePanel();};};caption.textContent='VISUAL EDITOR · STORE PANEL';
    
    
    </script><script>
    // Store definition completed from the supplied schema, without database changes.
    const exactStoreSchema={table:'stores',columns:{id:{type:'uuid',primaryKey:true},name:{type:'not specified'},slug:{type:'not specified',unique:true},logo_url:{type:'not specified'},image_url:{type:'not specified'},short_description:{type:'not specified'},website_url:{type:'not specified',hiddenFromCustomer:true},status:{type:'not specified',allowedValues:['active','inactive']},commission_rate:{type:'numeric',default:0},priority_rank:{type:'integer',default:100},created_at:{type:'not specified',automatic:true},updated_at:{type:'not specified',automatic:true}},rowLevelSecurity:true,publicRead:'Available products, brands, stores, offers and prices only, as stated in the supplied schema.',storeAccountWrite:'Store accounts modify their own store catalogue only.',platform_admin:'Full access.',relatedTables:['store_accounts','store_products','offers','commissions','sync_logs','product_sizes','products','brands'],relations:{'store_accounts.store_id':'stores.id','store_accounts.user_id':'auth.users.id','store_products.store_id':'stores.id','store_products.product_size_id':'product_sizes.id','product_sizes.product_id':'products.id','products.brand_id':'brands.id','offers.store_id':'stores.id','offers.product_size_id':'product_sizes.id','commissions.store_id':'stores.id','commissions.order_item_id':'order_items.id','sync_logs.store_id':'stores.id'},uniqueConstraints:{store_accounts:['store_id','user_id'],store_products:['store_id','product_size_id']},requestedIndexes:['brand_id','store_id','product_id','product_size_id','price','is_available','commission_rate'],storeProductFields:clone(suppliedSchema.tables.store_products),storeProductDefaults:{stock_quantity:0,is_available:false,is_new_arrival:false,is_coming_soon:false,currency:'EGP',data_source:'store_catalog',sync_status:'unavailable'},storeProductRequired:{price:'numeric not null'},storeProductSyncValues:['synced','stale','unavailable'],storeProductTimestamps:'created_at and updated_at automatic',views:clone(suppliedSchema.views),dataRules:clone(suppliedSchema.rules),initialStores:clone(suppliedSchema.initial.stores),approvedBrands:clone(suppliedSchema.initial.brands),source:'merchant supplied schema, not a verification of deployed SQL'};
    const attachBeforeStoreCompletion=attachDefinition;attachDefinition=function(item){attachBeforeStoreCompletion(item);if(item.kind!=='store')return;item.storeSchemaDefinition=clone(exactStoreSchema);if(item.storeCreationRequest){item.storeCreationRequest.schemaDefinition=clone(exactStoreSchema);item.storeCreationRequest.suppliedSchemaReference=clone(suppliedSchema);}};
    const saveBeforeStoreCompletion=document.getElementById('save').onclick;document.getElementById('save').onclick=()=>{state.items.forEach(attachDefinition);state.archive.forEach(attachDefinition);if(Array.isArray(state.savedElements))state.savedElements.forEach(attachDefinition);saveBeforeStoreCompletion();};state.items.forEach(attachDefinition);state.archive.forEach(attachDefinition);if(Array.isArray(state.savedElements))state.savedElements.forEach(attachDefinition);
    
    
    </script><script>
    // Canonical table clauses transcribed from the supplied schema, including its exceptions.
    const canonicalTableSpecs={
    brands:'id, name, slug unique, official_logo_url, description, official_website_url, is_active default true, created_at, updated_at',
    stores:'id, name, slug unique, logo_url, image_url, short_description, website_url; status (active / inactive); commission_rate numeric default 0; priority_rank integer default 100; created_at, updated_at',
    store_accounts:'id, store_id references stores, user_id references auth.users, role text default store_admin, created_at; unique (store_id, user_id)',
    aromatic_notes:'id, name unique, image_url, created_at, updated_at',categories:'id, name unique, image_url, created_at, updated_at',occasions:'id, name unique, image_url, created_at, updated_at',
    products:'id, brand_id references brands, name, slug unique; short_description, official_description, composition; gender (men / women / unisex); notes_source (brand_official / store_catalog / mixed); content_source text; status (draft / published / archived) default draft; meta_title, meta_description; is_active default true; created_at, updated_at',
    product_sizes:'id, product_id references products, size_ml integer, size_label text, sku text; unique (product_id, size_label); created_at, updated_at',
    product_images:'id, product_id references products, product_size_id nullable references product_sizes; image_url, alt_text, sort_order integer default 0, is_primary default false; created_at',
    product_notes:'product_id references products, note_id references aromatic_notes; primary key (product_id, note_id)',
    product_categories:'product_id references products, category_id references categories; primary key (product_id, category_id)',
    product_occasions:'product_id references products, occasion_id references occasions; primary key (product_id, occasion_id)',
    store_products:'id; store_id references stores; product_size_id references product_sizes; price numeric not null; original_price numeric; discount_percentage numeric; stock_quantity integer default 0; is_available boolean default false; is_new_arrival boolean default false; is_coming_soon boolean default false; price_includes_tax boolean; price_includes_shipping boolean; currency text default EGP; data_source text default store_catalog; sync_status (synced / stale / unavailable) default unavailable; last_synced_at timestamptz; created_at, updated_at; unique (store_id, product_size_id)',
    offers:'id, store_id references stores, product_size_id nullable references product_sizes; title, description; discount_type (percentage / fixed / package); discount_value numeric; start_date, end_date; is_active default true; created_at, updated_at',
    product_stats:'product_id primary key references products; views_count integer default 0; sales_count integer default 0; search_count integer default 0; request_count integer default 0; average_rating numeric; reviews_count integer default 0; updated_at',
    reviews:'id, user_id references profiles, product_id references products; rating integer check 1-5, comment text, is_approved default false; created_at, updated_at; unique (user_id, product_id)',
    profiles:'id primary key references auth.users; full_name, phone, avatar_url; role (customer / store_admin / platform_admin) default customer; created_at, updated_at',
    favorites:'id, user_id references profiles, product_id references products; created_at; unique (user_id, product_id)',
    cart_items:'id, user_id references profiles, store_product_id references store_products; quantity integer default 1 check > 0; created_at, updated_at; unique (user_id, store_product_id)',
    orders:'id, user_id references profiles; status (pending / confirmed / shipped / delivered / cancelled); subtotal numeric, tax_amount numeric default 0, shipping_amount numeric default 0, total_amount numeric; created_at, updated_at',
    order_items:'id, order_id references orders, store_product_id references store_products; quantity integer, price_at_time numeric; created_at',
    commissions:'id, store_id references stores, order_item_id references order_items; rate numeric, amount numeric; status (pending / payable / paid) default pending; created_at, updated_at',
    contact_messages:'id, name, email, phone, message, is_read default false, created_at',
    notifications:'id, user_id references profiles, title, body, is_read default false, created_at',
    marketing_phrases:'id, phrase_ar, phrase_en nullable; category (slogan / section / internal_reference); is_public boolean default false; usage_scope text; created_at',
    media_library:'id, file_url, file_type (image / video); source (device_upload / ai_generated / store_catalog / brand_official); alt_text, linked_entity_type, linked_entity_id; is_approved default false; created_at',
    analytics_events:'id, event_type (view / search / add_to_cart / request); product_id nullable, product_size_id nullable, user_id nullable; metadata jsonb; created_at',
    site_settings:'key text primary key, value text, updated_at',
    sync_logs:'id, store_id references stores, status text, message text, records_count integer, created_at'
    };
    const canonicalGeneralRules={primaryKeyInstruction:'UUID as primary key for all tables',timestampsInstruction:'created_at and updated_at automatic on every table',preserveExplicitTableExceptions:true,rowLevelSecurity:'Enable on every table',publicRead:'Only available products, brands, stores, offers and prices',userWrite:'Authenticated users may write only their own favorites, cart, orders, reviews and messages',storeWrite:'Store accounts modify their own store catalogue only',platform_admin:'Full access',indexes:['brand_id','store_id','product_id','product_size_id','price','is_available','commission_rate']};
    const canonicalForbiddenData=[
    'Price, availability, quantity, offers, new arrivals and best sellers come only from store catalogues.',
    'Description, composition, notes and official content may be supplemented only from the official brand website.',
    'Never store or display official brand website price as the displayed price.',
    'brands.official_website_url is stored but never displayed to customers.',
    'No store or brand website link is displayed to customers.',
    'Do not display a perfume unless available for sale at at least one platform store.',
    'Each size has independent price, availability, quantity and comparison; no comparison across sizes.',
    'One card for the same perfume and size: cheapest available store; tie: highest commission_rate then priority_rank.'
    ];
    const canonicalViews={cheapest_offers:{per:'product_size_id',eligibility:['is_available = true','stock_quantity > 0','sync_status = synced'],selection:'Cheapest store_products row',tieOrder:['commission_rate DESC','priority_rank ASC'],columns:['product_size_id','product_id','brand_id','store_id','store_name','price','stock_quantity','currency','price_includes_tax','price_includes_shipping','last_synced_at']},public_products:{eligibility:'Published products with at least one offer in cheapest_offers',usage:'The only product-display rule for cards, sections and search',columns:'Not listed in the supplied schema'}};
    const elementSchemaTables={
    section:Object.keys(canonicalTableSpecs),
    perfume:['products','product_sizes','product_images','brands','stores','store_products','aromatic_notes','product_notes','categories','product_categories','occasions','product_occasions','offers','product_stats','reviews','profiles','favorites','cart_items','orders','order_items','commissions','media_library','analytics_events','sync_logs'],
    brand:['brands','products','product_sizes','product_images','stores','store_products','offers','product_stats','media_library','sync_logs'],
    store:['stores','store_accounts','profiles','products','brands','product_sizes','product_images','store_products','offers','product_stats','reviews','order_items','commissions','media_library','sync_logs'],
    occasion:['occasions','product_occasions','products','product_sizes','product_images','brands','stores','store_products','media_library'],
    note:['aromatic_notes','product_notes','products','product_sizes','product_images','brands','stores','store_products','media_library'],
    banner:['media_library'],text:['marketing_phrases'],text_block:['marketing_phrases']};
    const canonicalSchemaReference={id:'elan-merchant-schema-v1',tables:canonicalTableSpecs,generalRules:canonicalGeneralRules,dataRestrictions:canonicalForbiddenData,relations:clone(suppliedSchema.relations),views:canonicalViews,initialData:clone(suppliedSchema.initial),marketingPhraseSeedRule:'Identity phrases are is_public=false except phrases explicitly assigned to each section.',verification:'Matched to supplied specification; no live database verification.'};
    function canonicalElementDefinition(item){const kind=definitionKind(item);if(!kind)return null;const tables=elementSchemaTables[kind]||[];const clauses={};tables.forEach(name=>clauses[name]=canonicalTableSpecs[name]);const tableSet=new Set(tables);const relations=Object.fromEntries(Object.entries(suppliedSchema.relations).filter(([left,right])=>tableSet.has(left.split('.')[0])||tableSet.has(right.split('.')[0])));return {kind,schemaReferenceId:canonicalSchemaReference.id,entityTable:elanElementDefinitions.elements[kind]?.table||null,tableSpecifications:clauses,relations,generalRules:clone(canonicalGeneralRules),dataRestrictions:clone(canonicalForbiddenData),views:['banner','text','text_block'].includes(kind)?null:clone(canonicalViews),initialData:clone(suppliedSchema.initial),independentLayoutTableSpecified:!['section','banner','text','text_block'].includes(kind),connectionStatus:'not_connected'};}
    const attachBeforeCanonicalAudit=attachDefinition;attachDefinition=function(item){attachBeforeCanonicalAudit(item);if(!definitionKind(item))return;item.schemaDefinition=canonicalElementDefinition(item);item.schemaReferenceId=canonicalSchemaReference.id;};
    Object.entries(elanElementDefinitions.elements).forEach(([kind,def])=>{def.schemaReferenceId=canonicalSchemaReference.id;def.tableSpecifications={};(elementSchemaTables[kind]||[]).forEach(name=>def.tableSpecifications[name]=canonicalTableSpecs[name]);});
    elanElementDefinitions.canonicalSchema=canonicalSchemaReference;
    const saveBeforeCanonicalAudit=document.getElementById('save').onclick;document.getElementById('save').onclick=()=>{state.canonicalSchemaReference=clone(canonicalSchemaReference);state.items.forEach(attachDefinition);state.archive.forEach(attachDefinition);if(Array.isArray(state.savedElements))state.savedElements.forEach(attachDefinition);saveBeforeCanonicalAudit();};
    state.canonicalSchemaReference=clone(canonicalSchemaReference);state.items.forEach(attachDefinition);state.archive.forEach(attachDefinition);if(Array.isArray(state.savedElements))state.savedElements.forEach(attachDefinition);
    const audit={expectedTables:29,actualTables:Object.keys(canonicalTableSpecs).length,missingTables:Object.keys(suppliedSchema.tables).filter(t=>!canonicalTableSpecs[t]),elementKinds:Object.keys(elementSchemaTables),requiredPriceColumnsMissing:suppliedSchema.views.cheapest_offers.columns.filter(c=>!canonicalViews.cheapest_offers.columns.includes(c))};
    state.schemaDefinitionAudit=audit;
    if(audit.actualTables!==29||audit.missingTables.length||audit.requiredPriceColumnsMissing.length)console.error('Schema definition mismatch',audit);
    caption.textContent='VISUAL EDITOR · FINAL SCHEMA REVIEW';
    
    
    </script><script>
    // Cloud library integration boundary. No credentials and no invented Supabase tables.
    // Provider contract: getLibrary() -> {archive,media,savedElements,revision};
    // saveLibrary({archive,media,savedElements}, expectedRevision) -> {revision};
    // uploadMedia(file,{category}) -> {id,name,src,type,category};
    // generateMedia({prompt,category}) -> stored cloud media record, only after external service configuration.
    let cloudLibraryReady=false,cloudLibraryRevision=null,cloudLibraryTimer=null,cloudLibrarySaving=false,cloudLibraryPending=false;
    function librarySnapshot(){return clone({archive:state.archive,media:state.media,savedElements:state.savedElements||[]});}
    function cloudProvider(){return window.elanLibraryDataProvider;}
    function showLibraryCloudMessage(text){let msg=libraryDialog.querySelector('[data-cloud-message]');if(!msg){msg=document.createElement('p');msg.dataset.cloudMessage='true';msg.style.cssText='font-size:12px;line-height:1.8;color:#846631';libraryDialog.append(msg);}msg.textContent=text;}
    function validLibrary(data){return data&&Array.isArray(data.archive)&&Array.isArray(data.media)&&Array.isArray(data.savedElements)&&data.revision!==undefined;}
    async function loadCloudLibrary(){const provider=cloudProvider();if(!provider?.getLibrary){showLibraryCloudMessage('المكتبة المركزية غير متصلة. الموجود حاليًا نسخة محلية، ولا يوجد حفظ مؤكد في سابابيس.');return false;}if(cloudLibraryPending){showLibraryCloudMessage('توجد تغييرات غير محفوظة مركزيًا. لا نستبدلها قبل المزامنة.');return false;}try{const data=await provider.getLibrary();if(!validLibrary(data))throw Error('Invalid cloud response');state.archive=clone(data.archive);state.media=clone(data.media);state.savedElements=clone(data.savedElements);cloudLibraryRevision=data.revision;cloudLibraryReady=true;document.getElementById('save').click();library();showLibraryCloudMessage('المكتبة محمّلة من المصدر المركزي.');return true;}catch(e){cloudLibraryReady=false;showLibraryCloudMessage('تعذر قراءة المكتبة المركزية. لم تُستبدل بياناتك المحلية.');return false;}}
    async function persistCloudLibrary(){if(!cloudLibraryReady||!cloudProvider()?.saveLibrary)return;if(cloudLibrarySaving)return;cloudLibrarySaving=true;const snapshot=librarySnapshot();cloudLibraryPending=false;try{const result=await cloudProvider().saveLibrary(snapshot,cloudLibraryRevision);if(result?.revision===undefined)throw Error('Missing revision');cloudLibraryRevision=result.revision;if(libraryDialog.open)showLibraryCloudMessage('تم تأكيد حفظ المكتبة والأرشيف مركزيًا.');}catch(e){cloudLibraryPending=true;if(libraryDialog.open)showLibraryCloudMessage('لم يتم تأكيد الحفظ المركزي، أو تعارض مع نسخة أحدث. بياناتك المحلية لم تُحذف؛ لا تُعتبر هذه التغييرات محفوظة على الخادم.');}finally{cloudLibrarySaving=false;}}
    let lastLibrarySignature=JSON.stringify(librarySnapshot());const changedBeforeCloudLibrary=changed;changed=function(){changedBeforeCloudLibrary();const signature=JSON.stringify(librarySnapshot());if(signature===lastLibrarySignature)return;lastLibrarySignature=signature;cloudLibraryPending=true;if(cloudLibraryReady){clearTimeout(cloudLibraryTimer);cloudLibraryTimer=setTimeout(persistCloudLibrary,350);}};
    window.connectElanLibrary=async function(provider){if(!provider||typeof provider.getLibrary!=='function'||typeof provider.saveLibrary!=='function')throw Error('Library provider requires authenticated load/save methods');window.elanLibraryDataProvider=provider;cloudLibraryPending=false;return loadCloudLibrary();};
    const libraryBeforeCloudSources=library;library=function(){libraryBeforeCloudSources();const controls=document.createElement('div');controls.style.cssText='display:flex;gap:8px;flex-wrap:wrap;margin-top:12px';const cloud=document.createElement('button');cloud.textContent='تحميل المكتبة من سابابيس';cloud.onclick=loadCloudLibrary;const sync=document.createElement('button');sync.textContent='مزامنة التغييرات';sync.onclick=()=>{if(!cloudLibraryReady){showLibraryCloudMessage('أكمل الاتصال أولًا. لا يتم رفع الأرشيف المحلي تلقائيًا إلى قاعدة البيانات.');return;}persistCloudLibrary();};controls.append(cloud,sync);if(libraryTab==='saved'){const ai=document.createElement('button');ai.textContent='إضافة من الذكاء الاصطناعي';ai.onclick=async()=>{const provider=cloudProvider();if(!cloudLibraryReady||!provider?.generateMedia){showLibraryCloudMessage('مولّد الميديا غير متصل. يلزم إعداد خدمة توليد وربط الحفظ المركزي أولًا.');return;}const promptText=prompt('وصف الصورة أو الفيديو المطلوب');if(!promptText?.trim())return;if(!confirm('إرسال طلب التوليد للخدمة المرتبطة؟ قد تُحتسب تكلفة وفق حسابك لديها.'))return;ai.disabled=true;try{const record=await provider.generateMedia({prompt:promptText.trim(),category:libraryCategory});if(!record?.id||!record.src||!['image','video'].includes(record.type))throw Error();checkpoint();state.media.push({...record,category:libraryCategory});changed();await persistCloudLibrary();library();}catch(e){showLibraryCloudMessage('لم يتم تأكيد توليد الميديا وحفظها مركزيًا.');}finally{ai.disabled=false;}};controls.append(ai);}libraryDialog.append(controls);showLibraryCloudMessage(cloudLibraryReady?(cloudLibraryPending?'تغييرات تنتظر تأكيد الحفظ المركزي.':'المكتبة متصلة بالمصدر المركزي.'):'الربط المركزي غير منفّذ؛ لا تزال المكتبة المحلية هي المعروضة.');};document.getElementById('library').onclick=()=>library();
    const localUploadBeforeCloud=document.getElementById('upload').onchange;document.getElementById('upload').onchange=async e=>{const file=e.target.files[0];if(!file)return;if(!cloudLibraryReady||!cloudProvider()?.uploadMedia||file.name.toLowerCase().endsWith('.json')){localUploadBeforeCloud(e);return;}if(!file.type.startsWith('image/')&&!file.type.startsWith('video/')){alert('اختر صورة أو فيديو');e.target.value='';return;}const category=uploadOnlyCategory;uploadOnlyCategory=null;const targetId=replaceId||(current()&&['card','section'].includes(current().type)?selected:null);replaceId=null;e.target.value='';try{const target=state.items.find(i=>i.id===targetId);const record=await cloudProvider().uploadMedia(file,{category:category||(target?itemCategory(target):file.type.startsWith('image/')?'image':'video')});if(!record?.id||!record.src||!['image','video'].includes(record.type))throw Error();checkpoint();state.media.push(record);if(!category){if(target&&['card','section'].includes(target.type)){target.mediaSrc=record.src;target.mediaType=record.type;}else if(target&&['image','video'].includes(target.type)){target.src=record.src;target.type=record.type;}else add(record.type,record.src);}changed();render();await persistCloudLibrary();if(libraryDialog.open)library();}catch(e){alert('لم يتم تأكيد رفع الملف للمكتبة المركزية. لم نعرضه كملف محفوظ بنجاح.');}};
    state.libraryStorageDefinition={target:'supabase',mediaMetadataTable:'media_library',mediaBinaryStorage:'Configured private Supabase Storage with authenticated access',archive:'Full element payload including layout, data definitions, bindings, timers and content; storage location chosen only after inspecting existing backend',savedElements:'Full reusable element payload',sources:['central_library','device_upload','configured_ai_generator'],secretKeysInBrowser:false,liveConnection:false};
    caption.textContent='VISUAL EDITOR · CENTRAL LIBRARY READY';
    
    
    </script><script>
    // Media source chooser for the selected element, with explicit connection status.
    const mediaSourceDialog=document.createElement('dialog');mediaSourceDialog.style.cssText='width:420px;max-width:94vw;padding:22px;background:#fffdf8;border:1px solid #c6aa70;border-radius:14px';document.body.append(mediaSourceDialog);
    function applyChosenMedia(targetId,record){const target=state.items.find(i=>i.id===targetId);if(!target){alert('العنصر المطلوب غير موجود.');return;}checkpoint();if(['card','section'].includes(target.type)){target.mediaSrc=record.src;target.mediaType=record.type;}else if(['image','video'].includes(target.type)){target.src=record.src;target.type=record.type;}else{alert('هذا العنصر لا يدعم الميديا.');return;}changed();render();document.getElementById('save').click();}
    function chooseMediaSource(){const target=current();if(!target||!['card','section','image','video'].includes(target.type))return;const targetId=target.id;mediaSourceDialog.replaceChildren();const title=document.createElement('h3');title.textContent='مصدر الصورة أو الفيديو';title.style.color='#87652d';const statusText=document.createElement('p');statusText.style.cssText='font-size:12px;line-height:1.7;color:#7d6a49';function sourceButton(label,fn){const b=document.createElement('button');b.textContent=label;b.style.cssText='display:block;width:100%;margin:9px 0';b.onclick=fn;mediaSourceDialog.append(b);return b;}mediaSourceDialog.append(title);
    sourceButton('من مكتبة سابابيس',async()=>{const provider=cloudProvider();if(!provider?.getLibrary){statusText.textContent='مكتبة سابابيس غير متصلة بعد. لم نعرض المكتبة المحلية باعتبارها مكتبة سحابية.';return;}try{const data=await provider.getLibrary();if(!validLibrary(data))throw Error();const list=document.createElement('div');const heading=document.createElement('h4');heading.textContent='اختر الميديا';list.append(heading);const media=data.media.filter(m=>m.src&&['image','video'].includes(m.type));if(!media.length){const empty=document.createElement('p');empty.textContent='لا توجد صور أو فيديوهات محفوظة في المكتبة المركزية.';list.append(empty);}media.forEach(record=>{const b=document.createElement('button');b.textContent=record.name||record.type;b.style.cssText='display:block;width:100%;margin:6px 0';b.onclick=()=>{applyChosenMedia(targetId,record);mediaSourceDialog.close();};list.append(b);});mediaSourceDialog.querySelector('[data-media-list]')?.remove();list.dataset.mediaList='true';mediaSourceDialog.append(list);}catch(e){statusText.textContent='تعذر تحميل المكتبة المركزية، ولم تُعرض بيانات بديلة.';}});
    sourceButton('من الجهاز',()=>{selected=targetId;replaceId=targetId;uploadOnlyCategory=null;mediaSourceDialog.close();document.getElementById('upload').accept='image/*,video/*';document.getElementById('upload').click();});
    const aiButton=sourceButton('من الذكاء الاصطناعي',async()=>{const provider=cloudProvider();if(!cloudLibraryReady||!provider?.generateMedia){statusText.textContent='خدمة التوليد والحفظ المركزي غير متصلة بعد.';return;}const description=prompt('وصف الصورة أو الفيديو المطلوب');if(!description?.trim())return;if(!confirm('إرسال طلب التوليد للخدمة المرتبطة؟ قد تكون هناك تكلفة حسب حسابك.'))return;aiButton.disabled=true;try{const record=await provider.generateMedia({prompt:description.trim(),category:itemCategory(target)});if(!record?.id||!record.src||!['image','video'].includes(record.type))throw Error();state.media.push(record);applyChosenMedia(targetId,record);await persistCloudLibrary();mediaSourceDialog.close();}catch(e){statusText.textContent='لم يتم تأكيد توليد الميديا وحفظها.';}finally{aiButton.disabled=false;}});mediaSourceDialog.append(statusText);sourceButton('إلغاء',()=>mediaSourceDialog.close());mediaSourceDialog.showModal();}
    const menuBeforeMediaSources=showMenu;showMenu=function(e){menuBeforeMediaSources(e);const button=Array.from(menu.children).find(b=>b.textContent==='رفع صورة أو فيديو داخل العناصر أو الهيرو');if(button){button.disabled=!current()||!['card','section','image','video'].includes(current().type);button.onclick=()=>{menu.style.display='none';chooseMediaSource();};}};caption.textContent='VISUAL EDITOR · MEDIA SOURCES';
    
    
    </script><script>
    // Integration shell: existing standalone editing remains separate and unchanged.
    const bridgeProtocol='elan-editor-bridge/v1';let liveMode=false,bridgeReady=false,bridgeSession='',bridgeOrigin='',bridgeRevision=null,bridgeDirty=false;const bridgePending=new Map();let bridgeTimeout=null;
    const livePanel=document.createElement('section');livePanel.style.cssText='padding:10px 20px;background:#fffaf0;border-bottom:1px solid #c2a66a';const address=document.createElement('input');address.type='url';address.value=location.origin+'/';address.style.cssText='width:min(480px,70vw);direction:ltr';const openLive=document.createElement('button');openLive.textContent='فتح المنصة داخل الإديتور';const localButton=document.createElement('button');localButton.textContent='المحرر المستقل';const bridgeStatus=document.createElement('span');bridgeStatus.style.cssText='display:block;font-size:12px;margin-top:8px';bridgeStatus.textContent='الموقع لا يصبح قابلًا للتعديل قبل تثبيت الربط داخل إيلان سنتس.';livePanel.append(address,openLive,localButton,bridgeStatus);document.querySelector('header').after(livePanel);
    const liveArea=document.createElement('section');liveArea.hidden=true;const liveTools=document.createElement('div');liveTools.style.cssText='display:flex;gap:6px;flex-wrap:wrap;padding:10px;background:#fffdf8';const liveFrame=document.createElement('iframe');liveFrame.title='إيلان سنتس، وضع التحرير';liveFrame.referrerPolicy='strict-origin-when-cross-origin';liveFrame.style.cssText='display:block;width:100%;height:calc(100vh - 230px);border:0;background:white';liveArea.append(liveTools,liveFrame);livePanel.after(liveArea);const originalHeaderButtons=Array.from(document.querySelectorAll('header button'));const localViewport=document.getElementById('viewport');const localHint=document.getElementById('hint');let selectedLive=null;
    function markBridge(text){bridgeStatus.textContent=text;status.textContent=text;liveTools.querySelectorAll('button').forEach(b=>b.disabled=!bridgeReady);}
    function requestLive(action,payload={}){if(!bridgeReady)return Promise.reject(Error('المنصة غير متصلة بوضع التحرير'));const id=crypto.randomUUID();return new Promise((resolve,reject)=>{const timer=setTimeout(()=>{bridgePending.delete(id);reject(Error('لم يصل تأكيد التنفيذ. لا نفترض نجاح الحفظ؛ تحقّق من الإصدار قبل إعادة المحاولة.'));},20000);bridgePending.set(id,{resolve,reject,timer});liveFrame.contentWindow.postMessage({protocol:bridgeProtocol,type:'request',session:bridgeSession,id,action,payload,expectedRevision:bridgeRevision},bridgeOrigin);});}
    async function runLive(action,payload={}){try{const result=await requestLive(action,payload);if(action==='page.save'){if(result?.revision===undefined||result?.published!==true)throw Error('لم يصل تأكيد نشر الإصدار');bridgeRevision=result.revision;bridgeDirty=false;markBridge('تم تأكيد الحفظ والنشر، الإصدار '+bridgeRevision);}return result;}catch(e){markBridge(e.message);return null;}}
    function tool(label,action,payload){const b=document.createElement('button');b.textContent=label;b.disabled=true;b.onclick=()=>runLive(action,typeof payload==='function'?payload():payload||{});liveTools.append(b);}
    tool('↶ تراجع','history.undo');tool('↷ إعادة','history.redo');const saveBtn=document.createElement('button');saveBtn.textContent='حفظ';saveBtn.disabled=true;saveBtn.onclick=()=>saveLive();liveTools.append(saveBtn);tool('المكتبة','library.open');tool('تنسيق العنصر','ui.openFormatPanel',()=>({elementId:selectedLive?.id}));tool('مصدر الصورة أو الفيديو','ui.openMediaPanel',()=>({elementId:selectedLive?.id,sources:['central_library','device_upload','configured_ai_generator']}));['section','perfume','brand','store','occasion','note','banner','text_block'].forEach((kind,n)=>tool(['إنشاء سيكشن','إنشاء كارت عطر','إنشاء براند','إنشاء متجر','إنشاء مناسبة','إنشاء نوتة','إنشاء بانر','إنشاء كتلة نصية'][n],'ui.openCreatePanel',{kind,schemaReferenceId:'elan-merchant-schema-v1'}));tool('حذف إلى الأرشيف','element.archive',()=>({elementId:selectedLive?.id}));
    tool('استعادة من الأرشيف','archive.restore',null);
    liveTools.lastChild.onclick=async()=>{const st=await runLive('page.getState');if(!st)return;if(!st.archive.length){markBridge('الأرشيف فاضي.');return;}const pick=prompt('اكتبي رقم العنصر لاستعادته:\n'+st.archive.map((a,i)=>(i+1)+'. '+a.name).join('\n'));const n=parseInt(pick,10);if(n>=1&&n<=st.archive.length)runLive('archive.restore',{elementId:st.archive[n-1].id});};
    const deviceBox=document.createElement('span');deviceBox.style.cssText='margin-inline-start:auto;display:flex;gap:6px';[['لاب','100%'],['تابلت','820px'],['موبايل','390px']].forEach(([label,w])=>{const b=document.createElement('button');b.textContent=label;b.onclick=()=>{liveFrame.style.width=w;liveFrame.style.margin='0 auto';liveFrame.style.borderInline=w==='100%'?'0':'1px solid #c2a66a';};deviceBox.append(b);});liveTools.append(deviceBox);
    const refreshBtn=document.createElement('button');refreshBtn.textContent='تحديث';refreshBtn.title='يتأكد إن النشر خلص ويعيد تحميل الصفحة على آخر نسخة';refreshBtn.onclick=()=>refreshLive();liveTools.append(refreshBtn);
    
    
    const SAVE_ERR={conflict:'حد غيّر الصفحة وإنتي بتعدّلي. دوسي تحديث وجرّبي تاني.',unauthorized:'انتهت الجلسة، سجّلي الدخول من جديد.',editor_not_configured:'إعدادات الإديتور ناقصة على Railway.',main_not_allowed:'الحفظ على main مقفول.',github_auth_failed:'مفتاح GitHub مش شغال أو صلاحيته ناقصة.',invalid_design:'في تعديل مش مسموح (راجعي الألوان والروابط).',branch_not_found:'الفرع المطلوب مش موجود على GitHub.'};
    
    const stageBox=document.createElement('span');stageBox.style.cssText='display:flex;gap:6px;margin-inline-start:8px';
    const stage=(txt)=>{const c=document.createElement('span');c.textContent=txt;c.style.cssText='font-size:12px;padding:3px 9px;border-radius:99px;border:1px solid #685b41;color:#8c8068';return c;};
    const chipUp=stage('رفع على GitHub'),chipPub=stage('نشر على Railway'),chipLoad=stage('تحميل النسخة الجديدة');stageBox.append(chipUp,chipPub,chipLoad);
    function setStages(n){[chipUp,chipPub,chipLoad].forEach((c,i)=>{const on=i<n;c.style.color=on?'#d7f2c4':'#8c8068';c.style.borderColor=on?'#7ab35b':'#685b41';c.textContent=(on?'✔ ':'')+['رفع على GitHub','نشر على Railway','تحميل النسخة الجديدة'][i];});}
    status.after(stageBox);
    const logoutBtn=document.createElement('button');logoutBtn.textContent='خروج';logoutBtn.style.cssText='background:#302b23;border:1px solid #685b41;color:#efe4cc;border-radius:8px;padding:6px 12px';logoutBtn.onclick=async()=>{if(bridgeDirty&&!confirm('في تعديلات لسه ما اتحفظتش. تخرجي برضه؟'))return;try{await fetch('/api/editor-logout',{method:'POST'});}catch(_){}document.body.textContent='';location.replace('/editor');};
    status.after(logoutBtn);
    let publishWatch=null,pendingLoadStage=false;
    async function waitPublished(revision){for(let i=0;i<60;i++){await new Promise(r=>setTimeout(r,5000));try{const r=await fetch('/api/editor',{method:'POST',headers:{'Content-Type':'application/json'},credentials:'same-origin',body:JSON.stringify({action:'status',revision})});if(r.status===401)throw Error(SAVE_ERR.unauthorized);const j=await r.json();if(j.ok&&j.published)return true;}catch(e){if(e.message===SAVE_ERR.unauthorized)throw e;}}return false;}
    async function saveLive(){if(!bridgeReady)return markBridge('المنصة غير متصلة بوضع التحرير');setStages(0);markBridge('جاري الحفظ...');try{const st=await requestLive('page.getState');const rid=crypto.randomUUID().replace(/-/g,'');const r=await fetch('/api/editor',{method:'POST',headers:{'Content-Type':'application/json'},credentials:'same-origin',body:JSON.stringify({action:'save',design:st.design,expectedRevision:st.revision==='initial'?null:st.revision,requestId:rid})});const j=await r.json().catch(()=>({}));if(!r.ok||!j.ok)throw Error(SAVE_ERR[j.error]||('تعذّر الحفظ ('+(j.error||r.status)+')'));await requestLive('page.markSaved',{revision:j.revision});bridgeRevision=j.revision;bridgeDirty=false;if(!j.committed){markBridge('مفيش تغيير جديد للحفظ.');return;}setStages(1);markBridge('تم الرفع على GitHub ✔ بستنى النشر على Railway...');const my=publishWatch=Symbol();const ok=await waitPublished(j.revision);if(publishWatch!==my)return;if(ok)setStages(2);markBridge(ok?'تم النشر على Railway ✔ دوسي تحديث لتحميل النسخة الجديدة.':'اتحفظ على GitHub بس النشر لسه ماتأكدش. دوسي تحديث بعد شوية.');}catch(e){markBridge(e.message);if(/GitHub/.test(e.message))explainGithub();}}
    async function explainGithub(){try{markBridge('بفحص سبب رفض GitHub...');const r=await fetch('/api/editor?action=diagnose',{credentials:'same-origin',cache:'no-store'});const j=await r.json();if(!j.ok)return markBridge('تعذّر الفحص ('+(j.error||r.status)+').');let eb=document.getElementById('liveError');if(!eb){eb=document.createElement('div');eb.id='liveError';eb.style.cssText='position:fixed;top:78px;left:50%;transform:translateX(-50%);z-index:60;background:#fbe9e7;color:#8a1c12;border:1px solid #d9a199;border-radius:10px;padding:12px 18px;max-width:80vw;font:15px Tahoma;box-shadow:0 8px 24px #0003;cursor:pointer';eb.title='اضغطي لإغلاق الرسالة';eb.onclick=()=>eb.remove();document.body.appendChild(eb);}eb.textContent='سبب رفض GitHub: '+j.verdict;markBridge(j.verdict);}catch(e){markBridge('تعذّر فحص GitHub.');}}
    async function refreshLive(){if(bridgeDirty&&!confirm('في تعديلات لسه ما اتحفظتش. التحديث هيمسحها. تكملي؟'))return;markBridge('بتأكد من النشر...');try{const ok=await waitPublished(bridgeRevision);if(!ok&&!confirm('النشر لسه ماتأكدش. أعيد التحميل برضه؟'))return;}catch(e){return markBridge(e.message);}pendingLoadStage=true;openLive.onclick();}
    
    /* The original right-click menu, shown over the platform page. Same entries, same look, same behaviour. */
    function showLiveMenu(info){const el=info&&info.element;selectedLive=el||null;const r=liveFrame.getBoundingClientRect();menu.replaceChildren();const at={x:info.x,y:info.y};
    (info.tools||[]).forEach(t=>action(t.label,()=>{if(t.ui==='format')openLiveFormat();else if(t.ui==='media'&&window.elanLiveMedia)window.elanLiveMedia(el);else if(t.ui==='media_new'&&window.elanLiveMediaNew)window.elanLiveMediaNew(t,at);else runLive('tool.run',{id:t.id,elementId:el&&el.id,at});},t.enabled));
    menu.style.display='block';const mr=menu.getBoundingClientRect();menu.style.left=Math.max(4,Math.min(r.left+info.x,innerWidth-mr.width-8))+'px';menu.style.top=Math.max(4,Math.min(r.top+info.y,innerHeight-mr.height-8))+'px';}
    function openLiveFormat(){const s=selectedLive&&selectedLive.style;if(!s)return;const hex=v=>/^#[0-9a-f]{6}$/i.test(v||'')?v:null;const fontSel=document.getElementById('font');const fam=(s.fontFamily||'Tahoma').replace(/["']/g,'');if(![...fontSel.options].some(o=>o.value===fam)){const o=document.createElement('option');o.value=fam;o.textContent=fam;fontSel.append(o);}fontSel.value=fam;document.getElementById('size').value=s.fontSize||24;document.getElementById('color').value=hex(s.color)||'#222222';document.getElementById('bg').value=hex(s.background)||'#fffdf9';document.getElementById('align').value=s.align||'right';try{effectSelect.value=s.effect||'none';}catch(_){}window.liveFormatInitial={color:document.getElementById('color').value,bg:document.getElementById('bg').value};document.getElementById('format').showModal();try{updatePanelPreview();}catch(_){}}
    document.getElementById('apply').addEventListener('click',e=>{if(!liveMode)return;e.stopImmediatePropagation();e.preventDefault();if(!selectedLive)return;const fonts=fontDefinitions.flatMap(g=>g[1]);const init=window.liveFormatInitial||{};const style={fontSize:Math.max(8,Math.min(120,Math.round(Number(document.getElementById('size').value)||24))),align:document.getElementById('align').value};if(document.getElementById('color').value!==init.color)style.color=document.getElementById('color').value;if(document.getElementById('bg').value!==init.bg)style.background=document.getElementById('bg').value;const f=document.getElementById('font').value;if(fonts.includes(f))style.fontFamily=f;try{style.effect=effectSelect.value;}catch(_){}document.getElementById('format').close();runLive('element.format',{elementId:selectedLive.id,style});},true);
    [['undo',()=>runLive('history.undo')],['redo',()=>runLive('history.redo')],['save',()=>saveLive()],['library',()=>runLive('library.open')]].forEach(([id,fn])=>document.getElementById(id).addEventListener('click',e=>{if(!liveMode)return;e.stopImmediatePropagation();e.preventDefault();fn();},true));
    window.addEventListener('blur',()=>{if(liveMode)menu.style.display='none';});
    Array.from(liveTools.children).forEach(c=>{if(c!==deviceBox&&c!==refreshBtn)c.hidden=true;});
    function abandonBridge(){bridgeReady=false;try{clearInterval(helloTimer);}catch(_){}clearTimeout(bridgeTimeout);bridgePending.forEach(p=>{clearTimeout(p.timer);p.reject(Error('تم إغلاق الاتصال'));});bridgePending.clear();}
    openLive.onclick=()=>{if(bridgeDirty&&!confirm('توجد تعديلات لم يُؤكد حفظها. إعادة فتح الصفحة قد تفقدها. المتابعة؟'))return;let url;try{url=new URL(address.value);if(url.protocol!=='https:'&&!(url.protocol==='http:'&&/^(127\.0\.0\.1|localhost)$/.test(url.hostname)))throw Error();}catch(e){alert('أدخل رابط HTTPS صحيحًا للمنصة');return;}abandonBridge();bridgeSession=crypto.randomUUID();bridgeOrigin=url.origin;bridgeDirty=false;selectedLive=null;liveMode=true;liveArea.hidden=false;localViewport.hidden=true;if(localHint)localHint.hidden=true;originalHeaderButtons.forEach(b=>{b.hidden=false;b.disabled=false;});menu.style.display='none';url.searchParams.set('elan_editor','1');liveFrame.src=url.href;markBridge('جارٍ فتح الموقع. العرض داخل النافذة لا يعني أن الربط أو الحفظ يعمل.');};
    let helloTimer=null;liveFrame.onload=()=>{if(!liveMode)return;const hello=()=>{try{liveFrame.contentWindow.postMessage({protocol:bridgeProtocol,type:'hello',session:bridgeSession},bridgeOrigin);}catch(_){}};hello();clearInterval(helloTimer);helloTimer=setInterval(()=>{if(bridgeReady||!liveMode){clearInterval(helloTimer);return;}hello();},700);clearTimeout(bridgeTimeout);bridgeTimeout=setTimeout(()=>{if(!bridgeReady)markBridge('لم يصل تأكيد اتصال: قد يحتاج الموقع تفعيل الربط وتسجيل دخول الإدارة أو السماح بعرضه داخل الإديتور. أدوات التعديل متوقفة.');},12000);};
    window.addEventListener('message',e=>{const m=e.data;if(!liveMode||e.source!==liveFrame.contentWindow||e.origin!==bridgeOrigin||m?.protocol!==bridgeProtocol||m.session!==bridgeSession)return;if(m.type==='ready'&&m.authorized===true&&m.page?.revision!==undefined){clearTimeout(bridgeTimeout);bridgeReady=true;bridgeRevision=m.page.revision;markBridge('متصل بوضع التحرير، الإصدار المنشور '+bridgeRevision);{const eb=document.getElementById('liveError');if(eb)eb.remove();}if(pendingLoadStage){pendingLoadStage=false;setStages(3);markBridge('تم تحميل صفحة جديدة من النسخة المحدثة ✔');}}else if(m.type==='denied'){abandonBridge();const why=(typeof m.message==='string'&&/[\u0600-\u06FF]/.test(m.message)&&m.message.length<300)?m.message:'وضع التحرير غير جاهز أو حساب الإدارة غير مصرح له.';markBridge(why);let eb=document.getElementById('liveError');if(!eb){eb=document.createElement('div');eb.id='liveError';eb.style.cssText='position:fixed;top:78px;left:50%;transform:translateX(-50%);z-index:60;background:#fbe9e7;color:#8a1c12;border:1px solid #d9a199;border-radius:10px;padding:12px 18px;max-width:80vw;font:15px Tahoma;box-shadow:0 8px 24px #0003';document.body.appendChild(eb);}eb.textContent='أدوات التحرير لسه مش شغالة: '+why;}else if(bridgeReady&&m.type==='selection'){selectedLive=m.element;bridgeStatus.textContent='العنصر المحدد: '+(selectedLive?.name||selectedLive?.id||'لا يوجد');menu.style.display='none';}else if(bridgeReady&&m.type==='context'){showLiveMenu(m.info);}else if(bridgeReady&&m.type==='dirty'){bridgeDirty=!!m.dirty;bridgeStatus.textContent=bridgeDirty?'تعديلات غير محفوظة على المنصة.':'لا توجد تعديلات معلقة.';status.textContent=bridgeDirty?'تعديلات غير محفوظة':'محفوظ';}else if(bridgeReady&&m.type==='revision'){bridgeRevision=m.revision;}else if(m.type==='response'){const p=bridgePending.get(m.id);if(!p)return;clearTimeout(p.timer);bridgePending.delete(m.id);m.ok?p.resolve(m.result):p.reject(Error(m.error||'فشل التنفيذ'));}});
    localButton.onclick=()=>{if(bridgeDirty&&!confirm('تعديلات المنصة لم يُؤكد حفظها. الخروج؟'))return;abandonBridge();liveMode=false;liveArea.hidden=true;liveFrame.src='about:blank';localViewport.hidden=false;if(localHint)localHint.hidden=false;originalHeaderButtons.forEach(b=>b.hidden=false);markBridge('المحرر المستقل، ليس صفحة المنصة الحقيقية ولا دليلًا على الحفظ المركزي.');};
    window.addEventListener('beforeunload',e=>{if(bridgeDirty||bridgePending.size){e.preventDefault();e.returnValue='';}});
    address.hidden=true;openLive.hidden=true;localButton.hidden=true;bridgeStatus.textContent='جاري فتح الموقع...';setTimeout(()=>openLive.onclick(),0);
    window.elanLiveEditorBridge={request:requestLive,getState:()=>({connected:bridgeReady,revision:bridgeRevision,dirty:bridgeDirty})};
    caption.textContent='VISUAL EDITOR · LIVE PLATFORM BRIDGE';
    
    </script></body></html>
    
  operator: 'match'
  stack: |-
    TestContext.<anonymous> (/home/ubuntu/elan-scents/tests/editor-format-panel.test.js:36:10)
    Test.runInAsyncScope (node:async_hooks:211:14)
    Test.run (node:internal/test_runner/test:931:25)
    Test.processPendingSubtests (node:internal/test_runner/test:629:18)
    Test.postRun (node:internal/test_runner/test:1042:19)
    Test.run (node:internal/test_runner/test:970:12)
    async Test.processPendingSubtests (node:internal/test_runner/test:629:7)
  ...
# Subtest: the owner editor page is private: anonymous visitors only ever get the login page
ok 62 - the owner editor page is private: anonymous visitors only ever get the login page
  ---
  duration_ms: 133.482338
  ...
# Subtest: only an admin can log in; the session is a browser-session cookie and logout ends it
ok 63 - only an admin can log in; the session is a browser-session cookie and logout ends it
  ---
  duration_ms: 55.035134
  ...
# Subtest: cross-site login attempts are refused
ok 64 - cross-site login attempts are refused
  ---
  duration_ms: 5.887955
  ...
# Subtest: edit mode only loads inside the editor window and never talks to customers
ok 65 - edit mode only loads inside the editor window and never talks to customers
  ---
  duration_ms: 0.901133
  ...
# Subtest: free-form edits are validated and resolved per screen size
ok 66 - free-form edits are validated and resolved per screen size
  ---
  duration_ms: 2.159664
  ...
# Subtest: the original editor look options (fonts, 3D effects, left/right) are accepted and nothing else is
ok 67 - the original editor look options (fonts, 3D effects, left/right) are accepted and nothing else is
  ---
  duration_ms: 0.536176
  ...
# Subtest: the editor page wires the original context menu, format dialog and header to the platform
ok 68 - the editor page wires the original context menu, format dialog and header to the platform
  ---
  duration_ms: 5.094811
  ...
# Subtest: the menu is built from a tool registry so new capabilities are one register() call
not ok 69 - the menu is built from a tool registry so new capabilities are one register() call
  ---
  duration_ms: 2.919588
  location: '/home/ubuntu/elan-scents/tests/editor-host.test.js:132:1'
  failureType: 'testCodeFailure'
  error: |-
    The input did not match the regular expression /el\?\.tools\|\|info\?\.tools/. Input:
    
    `<!doctype html><html lang="ar" dir="rtl"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>محرر إيلان — بداية جديدة</title><style>*{box-sizing:border-box}body{margin:0;font-family:Tahoma,Arial;background:#eae7e1;color:#222}header{height:68px;background:#191919;color:#eeddb8;display:flex;align-items:center;gap:10px;padding:12px 20px;position:sticky;top:0;z-index:5}button,input,select{font:inherit}button{cursor:pointer;border:1px solid #c2a66a;border-radius:7px;padding:9px 13px;background:#fffaf0;color:#29251c}header strong{margin-left:auto}#status{font-size:12px;color:#ddd}#hint{padding:12px;text-align:center;font-size:13px;line-height:1.7}#viewport{overflow:auto;padding:20px;height:calc(100vh - 125px)}#canvas{width:1100px;height:900px;position:relative;background:#fffdf9;box-shadow:0 8px 40px #0001;margin:0 auto;direction:rtl}.item{position:absolute;touch-action:none;outline:none;overflow:hidden}.item.selected{outline:2px solid #a88032;overflow:visible}.content{width:100%;height:100%;overflow:hidden}.text .content{white-space:pre-wrap;line-height:1.4;cursor:move}.editing .content{cursor:text;user-select:text;overflow:auto}.image img{width:100%;height:100%;object-fit:cover;pointer-events:none}.card .content{padding:22px;border:1px solid #bd9c57;border-radius:16px;box-shadow:0 8px 20px #0001;background:#fffdf8}.handle{position:absolute;width:13px;height:13px;background:#fff;border:2px solid #a88032;right:-7px;bottom:-7px;cursor:nwse-resize;z-index:3;display:none;touch-action:none}.selected .handle{display:block}#menu{display:none;position:fixed;z-index:20;width:220px;max-height:80vh;overflow:auto;padding:8px;border:1px solid #b59655;border-radius:12px;background:#fff;box-shadow:0 10px 35px #0003}#menu button{display:block;width:100%;text-align:right;margin:4px 0}dialog{border:1px solid #c0a064;border-radius:14px;padding:24px;max-width:95vw;max-height:90vh;overflow:auto}dialog::backdrop{background:#0005}label{display:block;margin:12px 0}input,select,textarea{padding:8px;border:1px solid #ccb98d;border-radius:6px;max-width:100%}#archiveList button{display:block;margin:8px 0}small{display:block;line-height:1.7;color:#666}button:disabled{opacity:.4;cursor:default}</style></head><body><header><strong>Élan Scents · محرر تجريبي جديد</strong><button id="undo">↶ تراجع</button><button id="redo">↷ إعادة</button><button id="save">حفظ</button><button id="library">المكتبة</button><span id="status">حفظ محلي فقط</span></header><div id="hint">كليك شمال للتحديد والسحب. اسحب المقبض لتغيير الحجم. كليك يمين للأدوات. اضغط مرتين على النص واكتب بالكيبورد. هذه مساحة اختبار ثابتة، وليست منصة متصلة.</div><div id="viewport"><div id="canvas"></div></div><div id="menu"></div><input id="upload" type="file" accept="image/*,video/*" hidden><dialog id="format"><h3>تنسيق العنصر</h3><label>الخط <select id="font"><option>Tahoma</option><option>Arial</option><option>Georgia</option><option>Times New Roman</option><option>Verdana</option></select></label><label>حجم الخط <input id="size" type="number" min="8" max="160"></label><label>لون النص <input id="color" type="color"></label><label>لون الخلفية <input id="bg" type="color"></label><label>المحاذاة <select id="align"><option value="right">يمين</option><option value="center">وسط</option><option value="left">يسار</option></select></label><button id="apply">تطبيق</button> <button onclick="this.closest('dialog').close()">إغلاق</button></dialog><dialog id="libraryDialog"><h3>المكتبة والأرشيف المحلي</h3><button id="addMedia">رفع صورة أو فيديو</button><h4>الميديا المحفوظة</h4><div id="mediaList"></div><h4>العناصر المحذوفة</h4><div id="archiveList"></div><small>للملفات الصغيرة فقط، حد الملف 1 ميجابايت. ليست مكتبة سحابية.</small><button onclick="this.closest('dialog').close()">إغلاق</button></dialog><script src="/editor/editor-data-bridge.js?v=20261014-01"></script><script>\n` +
      "const canvas=document.getElementById('canvas'),menu=document.getElementById('menu'),status=document.getElementById('status');const storageKey='elan-fresh-editor-v1';let state={items:[{id:'title',type:'text',x:280,y:90,w:540,h:110,text:'Élan Scents',font:'Georgia',size:64,color:'#a17b35',bg:'#fffdf9',align:'center'},{id:'subtitle',type:'text',x:280,y:220,w:540,h:65,text:'سحر الخليج بين يديك',font:'Tahoma',size:30,color:'#282828',bg:'#fffdf9',align:'center'},{id:'card',type:'card',x:390,y:360,w:300,h:200,text:'كارت عطر تجريبي\\nليست بيانات متجر حقيقية',font:'Tahoma',size:22,color:'#282828',bg:'#fffdf9',align:'center'}],archive:[],media:[]};let selected=null,history=[],future=[],dirty=false,editing=false,gesture=null,replaceId=null;\n" +
      "try{const s=JSON.parse(localStorage.getItem(storageKey));if(s&&Array.isArray(s.items)&&Array.isArray(s.archive)&&Array.isArray(s.media))state=s;}catch(e){status.textContent='تعذر قراءة الحفظ السابق.';}\n" +
      "const clone=x=>JSON.parse(JSON.stringify(x));function checkpoint(){history.push(clone(state));if(history.length>30)history.shift();future=[];}function changed(){dirty=true;status.textContent='تعديلات غير محفوظة';document.getElementById('undo').disabled=!history.length;document.getElementById('redo').disabled=!future.length;}function current(){return state.items.find(i=>i.id===selected);}function uid(){return 'item-'+Date.now()+'-'+Math.random().toString(16).slice(2,8);}function select(id){selected=id;canvas.querySelectorAll('.item').forEach(el=>el.classList.toggle('selected',el.dataset.id===id));}\n" +
      "function render(){canvas.replaceChildren();state.items.forEach(item=>{const el=document.createElement('div');el.className='item '+item.type;el.dataset.id=item.id;Object.assign(el.style,{left:item.x+'px',top:item.y+'px',width:item.w+'px',height:item.h+'px',zIndex:String(item.z||1)});const content=document.createElement('div');content.className='content';Object.assign(content.style,{fontFamily:item.font||'Tahoma',fontSize:(item.size||24)+'px',color:item.color||'#222',backgroundColor:item.bg||'#fffdf9',textAlign:item.align||'right',whiteSpace:'pre-wrap'});if(item.type==='image'){const img=document.createElement('img');img.src=item.src;img.alt='صورة في التصميم';content.append(img);}else if(item.type==='video'){const v=document.createElement('video');v.src=item.src;v.controls=true;v.style.cssText='width:100%;height:100%;object-fit:contain';content.append(v);}else content.textContent=item.text||'';el.append(content);const handle=document.createElement('div');handle.className='handle';el.append(handle);canvas.append(el);\n" +
      "el.addEventListener('pointerdown',e=>{if(e.button!==0||editing||e.target.closest('video'))return;e.preventDefault();select(item.id);menu.style.display='none';checkpoint();gesture={id:item.id,mode:e.target===handle?'resize':'move',sx:e.clientX,sy:e.clientY,x:item.x,y:item.y,w:item.w,h:item.h};el.setPointerCapture(e.pointerId);});el.addEventListener('pointermove',e=>{if(!gesture||gesture.id!==item.id)return;const dx=e.clientX-gesture.sx,dy=e.clientY-gesture.sy;if(gesture.mode==='resize'){item.w=Math.max(40,Math.min(1100-item.x,gesture.w+dx));item.h=Math.max(30,Math.min(900-item.y,gesture.h+dy));}else{item.x=Math.max(0,Math.min(1100-item.w,gesture.x+dx));item.y=Math.max(0,Math.min(900-item.h,gesture.y+dy));}Object.assign(el.style,{left:item.x+'px',top:item.y+'px',width:item.w+'px',height:item.h+'px'});changed();});function finish(){gesture=null;}el.addEventListener('pointerup',finish);el.addEventListener('pointercancel',finish);\n" +
      "el.addEventListener('dblclick',e=>{if(!['text','card'].includes(item.type))return;select(item.id);checkpoint();editing=true;el.classList.add('editing');content.contentEditable='plaintext-only';content.focus();});content.addEventListener('input',()=>{if(editing){item.text=content.innerText;changed();}});content.addEventListener('blur',()=>{content.contentEditable='false';el.classList.remove('editing');editing=false;});el.addEventListener('contextmenu',e=>{e.preventDefault();e.stopPropagation();select(item.id);showMenu(e);});});select(selected);document.getElementById('undo').disabled=!history.length;document.getElementById('redo').disabled=!future.length;}\n" +
      "function add(type,src){checkpoint();const item={id:uid(),type,x:350,y:300,w:320,h:type==='text'?90:220,text:type==='text'?'اكتب نصك هنا':'كارت جديد',font:'Tahoma',size:26,color:'#252525',bg:'#fffdf9',align:'right',src};state.items.push(item);selected=item.id;changed();render();}\n" +
      "function action(label,callback,enabled=true){const b=document.createElement('button');b.textContent=label;b.disabled=!enabled;b.onclick=()=>{menu.style.display='none';callback();};menu.append(b);}\n" +
      `function showMenu(e){menu.replaceChildren();const item=current();action('إضافة نص',()=>add('text'));action('إضافة كارت',()=>add('card'));action('إضافة صورة أو فيديو',()=>{replaceId=null;document.getElementById('upload').click();});action('تعديل النص بالكيبورد',()=>{const el=canvas.querySelector('[data-id="'+selected+'"]');el?.dispatchEvent(new MouseEvent('dblclick',{bubbles:true}));},!!item&&['text','card'].includes(item.type));action('الخط واللون والحجم',openFormat,!!item);action('تكبير الخط +',()=>resizeText(2),!!item&&['text','card'].includes(item.type));action('تصغير الخط −',()=>resizeText(-2),!!item&&['text','card'].includes(item.type));action('استبدال الصورة أو الفيديو',()=>{replaceId=selected;document.getElementById('upload').click();},!!item&&['image','video'].includes(item.type));action('نسخ العنصر',()=>{checkpoint();const copy=clone(current());copy.id=uid();copy.x=Math.min(1100-copy.w,copy.x+20);copy.y=Math.min(900-copy.h,copy.y+20);state.items.push(copy);selected=copy.id;changed();render();},!!item);action('حذف إلى الأرشيف',()=>{checkpoint();state.archive.push(clone(current()));state.items=state.items.filter(i=>i.id!==selected);selected=null;changed();render();},!!item);menu.style.display='block';const r=menu.getBoundingClientRect();menu.style.left=Math.max(4,Math.min(e.clientX,innerWidth-r.width-8))+'px';menu.style.top=Math.max(4,Math.min(e.clientY,innerHeight-r.height-8))+'px';}\n` +
      'function resizeText(d){const '... 182017 more characters
    
  code: 'ERR_ASSERTION'
  name: 'AssertionError'
  expected:
  actual: |-
    <!doctype html><html lang="ar" dir="rtl"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>محرر إيلان — بداية جديدة</title><style>*{box-sizing:border-box}body{margin:0;font-family:Tahoma,Arial;background:#eae7e1;color:#222}header{height:68px;background:#191919;color:#eeddb8;display:flex;align-items:center;gap:10px;padding:12px 20px;position:sticky;top:0;z-index:5}button,input,select{font:inherit}button{cursor:pointer;border:1px solid #c2a66a;border-radius:7px;padding:9px 13px;background:#fffaf0;color:#29251c}header strong{margin-left:auto}#status{font-size:12px;color:#ddd}#hint{padding:12px;text-align:center;font-size:13px;line-height:1.7}#viewport{overflow:auto;padding:20px;height:calc(100vh - 125px)}#canvas{width:1100px;height:900px;position:relative;background:#fffdf9;box-shadow:0 8px 40px #0001;margin:0 auto;direction:rtl}.item{position:absolute;touch-action:none;outline:none;overflow:hidden}.item.selected{outline:2px solid #a88032;overflow:visible}.content{width:100%;height:100%;overflow:hidden}.text .content{white-space:pre-wrap;line-height:1.4;cursor:move}.editing .content{cursor:text;user-select:text;overflow:auto}.image img{width:100%;height:100%;object-fit:cover;pointer-events:none}.card .content{padding:22px;border:1px solid #bd9c57;border-radius:16px;box-shadow:0 8px 20px #0001;background:#fffdf8}.handle{position:absolute;width:13px;height:13px;background:#fff;border:2px solid #a88032;right:-7px;bottom:-7px;cursor:nwse-resize;z-index:3;display:none;touch-action:none}.selected .handle{display:block}#menu{display:none;position:fixed;z-index:20;width:220px;max-height:80vh;overflow:auto;padding:8px;border:1px solid #b59655;border-radius:12px;background:#fff;box-shadow:0 10px 35px #0003}#menu button{display:block;width:100%;text-align:right;margin:4px 0}dialog{border:1px solid #c0a064;border-radius:14px;padding:24px;max-width:95vw;max-height:90vh;overflow:auto}dialog::backdrop{background:#0005}label{display:block;margin:12px 0}input,select,textarea{padding:8px;border:1px solid #ccb98d;border-radius:6px;max-width:100%}#archiveList button{display:block;margin:8px 0}small{display:block;line-height:1.7;color:#666}button:disabled{opacity:.4;cursor:default}</style></head><body><header><strong>Élan Scents · محرر تجريبي جديد</strong><button id="undo">↶ تراجع</button><button id="redo">↷ إعادة</button><button id="save">حفظ</button><button id="library">المكتبة</button><span id="status">حفظ محلي فقط</span></header><div id="hint">كليك شمال للتحديد والسحب. اسحب المقبض لتغيير الحجم. كليك يمين للأدوات. اضغط مرتين على النص واكتب بالكيبورد. هذه مساحة اختبار ثابتة، وليست منصة متصلة.</div><div id="viewport"><div id="canvas"></div></div><div id="menu"></div><input id="upload" type="file" accept="image/*,video/*" hidden><dialog id="format"><h3>تنسيق العنصر</h3><label>الخط <select id="font"><option>Tahoma</option><option>Arial</option><option>Georgia</option><option>Times New Roman</option><option>Verdana</option></select></label><label>حجم الخط <input id="size" type="number" min="8" max="160"></label><label>لون النص <input id="color" type="color"></label><label>لون الخلفية <input id="bg" type="color"></label><label>المحاذاة <select id="align"><option value="right">يمين</option><option value="center">وسط</option><option value="left">يسار</option></select></label><button id="apply">تطبيق</button> <button onclick="this.closest('dialog').close()">إغلاق</button></dialog><dialog id="libraryDialog"><h3>المكتبة والأرشيف المحلي</h3><button id="addMedia">رفع صورة أو فيديو</button><h4>الميديا المحفوظة</h4><div id="mediaList"></div><h4>العناصر المحذوفة</h4><div id="archiveList"></div><small>للملفات الصغيرة فقط، حد الملف 1 ميجابايت. ليست مكتبة سحابية.</small><button onclick="this.closest('dialog').close()">إغلاق</button></dialog><script src="/editor/editor-data-bridge.js?v=20261014-01"></script><script>
    const canvas=document.getElementById('canvas'),menu=document.getElementById('menu'),status=document.getElementById('status');const storageKey='elan-fresh-editor-v1';let state={items:[{id:'title',type:'text',x:280,y:90,w:540,h:110,text:'Élan Scents',font:'Georgia',size:64,color:'#a17b35',bg:'#fffdf9',align:'center'},{id:'subtitle',type:'text',x:280,y:220,w:540,h:65,text:'سحر الخليج بين يديك',font:'Tahoma',size:30,color:'#282828',bg:'#fffdf9',align:'center'},{id:'card',type:'card',x:390,y:360,w:300,h:200,text:'كارت عطر تجريبي\nليست بيانات متجر حقيقية',font:'Tahoma',size:22,color:'#282828',bg:'#fffdf9',align:'center'}],archive:[],media:[]};let selected=null,history=[],future=[],dirty=false,editing=false,gesture=null,replaceId=null;
    try{const s=JSON.parse(localStorage.getItem(storageKey));if(s&&Array.isArray(s.items)&&Array.isArray(s.archive)&&Array.isArray(s.media))state=s;}catch(e){status.textContent='تعذر قراءة الحفظ السابق.';}
    const clone=x=>JSON.parse(JSON.stringify(x));function checkpoint(){history.push(clone(state));if(history.length>30)history.shift();future=[];}function changed(){dirty=true;status.textContent='تعديلات غير محفوظة';document.getElementById('undo').disabled=!history.length;document.getElementById('redo').disabled=!future.length;}function current(){return state.items.find(i=>i.id===selected);}function uid(){return 'item-'+Date.now()+'-'+Math.random().toString(16).slice(2,8);}function select(id){selected=id;canvas.querySelectorAll('.item').forEach(el=>el.classList.toggle('selected',el.dataset.id===id));}
    function render(){canvas.replaceChildren();state.items.forEach(item=>{const el=document.createElement('div');el.className='item '+item.type;el.dataset.id=item.id;Object.assign(el.style,{left:item.x+'px',top:item.y+'px',width:item.w+'px',height:item.h+'px',zIndex:String(item.z||1)});const content=document.createElement('div');content.className='content';Object.assign(content.style,{fontFamily:item.font||'Tahoma',fontSize:(item.size||24)+'px',color:item.color||'#222',backgroundColor:item.bg||'#fffdf9',textAlign:item.align||'right',whiteSpace:'pre-wrap'});if(item.type==='image'){const img=document.createElement('img');img.src=item.src;img.alt='صورة في التصميم';content.append(img);}else if(item.type==='video'){const v=document.createElement('video');v.src=item.src;v.controls=true;v.style.cssText='width:100%;height:100%;object-fit:contain';content.append(v);}else content.textContent=item.text||'';el.append(content);const handle=document.createElement('div');handle.className='handle';el.append(handle);canvas.append(el);
    el.addEventListener('pointerdown',e=>{if(e.button!==0||editing||e.target.closest('video'))return;e.preventDefault();select(item.id);menu.style.display='none';checkpoint();gesture={id:item.id,mode:e.target===handle?'resize':'move',sx:e.clientX,sy:e.clientY,x:item.x,y:item.y,w:item.w,h:item.h};el.setPointerCapture(e.pointerId);});el.addEventListener('pointermove',e=>{if(!gesture||gesture.id!==item.id)return;const dx=e.clientX-gesture.sx,dy=e.clientY-gesture.sy;if(gesture.mode==='resize'){item.w=Math.max(40,Math.min(1100-item.x,gesture.w+dx));item.h=Math.max(30,Math.min(900-item.y,gesture.h+dy));}else{item.x=Math.max(0,Math.min(1100-item.w,gesture.x+dx));item.y=Math.max(0,Math.min(900-item.h,gesture.y+dy));}Object.assign(el.style,{left:item.x+'px',top:item.y+'px',width:item.w+'px',height:item.h+'px'});changed();});function finish(){gesture=null;}el.addEventListener('pointerup',finish);el.addEventListener('pointercancel',finish);
    el.addEventListener('dblclick',e=>{if(!['text','card'].includes(item.type))return;select(item.id);checkpoint();editing=true;el.classList.add('editing');content.contentEditable='plaintext-only';content.focus();});content.addEventListener('input',()=>{if(editing){item.text=content.innerText;changed();}});content.addEventListener('blur',()=>{content.contentEditable='false';el.classList.remove('editing');editing=false;});el.addEventListener('contextmenu',e=>{e.preventDefault();e.stopPropagation();select(item.id);showMenu(e);});});select(selected);document.getElementById('undo').disabled=!history.length;document.getElementById('redo').disabled=!future.length;}
    function add(type,src){checkpoint();const item={id:uid(),type,x:350,y:300,w:320,h:type==='text'?90:220,text:type==='text'?'اكتب نصك هنا':'كارت جديد',font:'Tahoma',size:26,color:'#252525',bg:'#fffdf9',align:'right',src};state.items.push(item);selected=item.id;changed();render();}
    function action(label,callback,enabled=true){const b=document.createElement('button');b.textContent=label;b.disabled=!enabled;b.onclick=()=>{menu.style.display='none';callback();};menu.append(b);}
    function showMenu(e){menu.replaceChildren();const item=current();action('إضافة نص',()=>add('text'));action('إضافة كارت',()=>add('card'));action('إضافة صورة أو فيديو',()=>{replaceId=null;document.getElementById('upload').click();});action('تعديل النص بالكيبورد',()=>{const el=canvas.querySelector('[data-id="'+selected+'"]');el?.dispatchEvent(new MouseEvent('dblclick',{bubbles:true}));},!!item&&['text','card'].includes(item.type));action('الخط واللون والحجم',openFormat,!!item);action('تكبير الخط +',()=>resizeText(2),!!item&&['text','card'].includes(item.type));action('تصغير الخط −',()=>resizeText(-2),!!item&&['text','card'].includes(item.type));action('استبدال الصورة أو الفيديو',()=>{replaceId=selected;document.getElementById('upload').click();},!!item&&['image','video'].includes(item.type));action('نسخ العنصر',()=>{checkpoint();const copy=clone(current());copy.id=uid();copy.x=Math.min(1100-copy.w,copy.x+20);copy.y=Math.min(900-copy.h,copy.y+20);state.items.push(copy);selected=copy.id;changed();render();},!!item);action('حذف إلى الأرشيف',()=>{checkpoint();state.archive.push(clone(current()));state.items=state.items.filter(i=>i.id!==selected);selected=null;changed();render();},!!item);menu.style.display='block';const r=menu.getBoundingClientRect();menu.style.left=Math.max(4,Math.min(e.clientX,innerWidth-r.width-8))+'px';menu.style.top=Math.max(4,Math.min(e.clientY,innerHeight-r.height-8))+'px';}
    function resizeText(d){const i=current();if(!i)return;checkpoint();i.size=Math.max(8,Math.min(160,(i.size||24)+d));changed();render();}
    function openFormat(){const i=current();if(!i)return;document.getElementById('font').value=i.font||'Tahoma';document.getElementById('size').value=i.size||24;document.getElementById('color').value=i.color||'#222222';document.getElementById('bg').value=i.bg||'#fffdf9';document.getElementById('align').value=i.align||'right';document.getElementById('format').showModal();}
    document.getElementById('apply').onclick=()=>{const i=current();if(!i)return;checkpoint();i.font=document.getElementById('font').value;i.size=Math.max(8,Math.min(160,Number(document.getElementById('size').value)||24));i.color=document.getElementById('color').value;i.bg=document.getElementById('bg').value;i.align=document.getElementById('align').value;changed();render();document.getElementById('format').close();};
    canvas.addEventListener('contextmenu',e=>{e.preventDefault();select(null);showMenu(e);});canvas.addEventListener('pointerdown',e=>{if(e.target===canvas){select(null);menu.style.display='none';}});document.addEventListener('pointerdown',e=>{if(!menu.contains(e.target))menu.style.display='none';});document.addEventListener('keydown',e=>{if(e.key==='Escape')menu.style.display='none';});
    document.getElementById('undo').onclick=()=>{if(!history.length)return;future.push(clone(state));state=history.pop();changed();render();};document.getElementById('redo').onclick=()=>{if(!future.length)return;history.push(clone(state));state=future.pop();changed();render();};document.getElementById('save').onclick=()=>{try{localStorage.setItem(storageKey,JSON.stringify(state));dirty=false;status.textContent='تم الحفظ في هذا المتصفح فقط';}catch(e){status.textContent='فشل الحفظ: مساحة المتصفح غير كافية';}};
    function library(){const media=document.getElementById('mediaList'),archive=document.getElementById('archiveList');media.replaceChildren();archive.replaceChildren();if(!state.media.length)media.textContent='لم تُرفع ميديا بعد.';state.media.forEach(m=>{const b=document.createElement('button');b.textContent='إضافة: '+m.name;b.onclick=()=>{add(m.type,m.src);document.getElementById('libraryDialog').close();};media.append(b);});if(!state.archive.length)archive.textContent='الأرشيف فارغ.';state.archive.forEach((i,index)=>{const b=document.createElement('button');b.textContent='استرجاع: '+(i.text?.slice(0,25)||i.type);b.onclick=()=>{checkpoint();const copy=clone(i);if(state.items.some(x=>x.id===copy.id))copy.id=uid();state.items.push(copy);state.archive.splice(index,1);selected=copy.id;changed();render();library();};archive.append(b);});if(!document.getElementById('libraryDialog').open)document.getElementById('libraryDialog').showModal();}
    document.getElementById('library').onclick=library;document.getElementById('addMedia').onclick=()=>{replaceId=null;document.getElementById('upload').click();};document.getElementById('upload').onchange=e=>{const f=e.target.files[0];if(!f)return;if(f.size>1024*1024){alert('هذه نسخة محلية: استخدم ملفًا أقل من 1 ميجابايت.');return;}if(!f.type.startsWith('image/')&&!f.type.startsWith('video/'))return;const target=replaceId;const reader=new FileReader();reader.onload=()=>{checkpoint();const type=f.type.startsWith('image/')?'image':'video';state.media.push({name:f.name,src:reader.result,type});const i=state.items.find(i=>i.id===target);if(i){i.src=reader.result;i.type=type;changed();render();}else{add(type,reader.result);}if(document.getElementById('libraryDialog').open)library();};reader.readAsDataURL(f);e.target.value='';};window.addEventListener('beforeunload',e=>{if(dirty){e.preventDefault();e.returnValue='';}});// Keep the simple editor, extend cards and visual effects.
    const extraStyle=document.createElement('style');extraStyle.textContent='.card .content{position:relative;z-index:2;background:transparent}.card .cardMedia{position:absolute;inset:0;width:100%;height:100%;object-fit:cover;border-radius:16px;z-index:1}.item.card{border-radius:16px}.item.card:not(.selected){overflow:hidden}.section .content{border-radius:16px;border:1px solid #c2a66a}.item.text{z-index:100}.item.selected{z-index:200!important}';document.head.appendChild(extraStyle);
    const effectLabel=document.createElement('label');effectLabel.textContent='تأثير ثلاثي الأبعاد ';const effectSelect=document.createElement('select');[['none','بدون تأثير'],['soft','بروز ناعم'],['gold','ذهبي بارز'],['deep','عمق واضح']].forEach(([value,label])=>{const o=document.createElement('option');o.value=value;o.textContent=label;effectSelect.append(o);});effectLabel.append(effectSelect);document.getElementById('apply').before(effectLabel);
    const fitLabel=document.createElement('label');fitLabel.textContent='عرض الصورة داخل الكارت ';const fitSelect=document.createElement('select');[['cover','ملء الكارت، مع قص الأطراف عند الحاجة'],['contain','الصورة كاملة، بدون قص']].forEach(([value,label])=>{const o=document.createElement('option');o.value=value;o.textContent=label;fitSelect.append(o);});fitLabel.append(fitSelect);document.getElementById('apply').before(fitLabel);
    const originalFormat=openFormat;openFormat=function(){originalFormat();const i=current();if(i){effectSelect.value=i.effect||'none';fitSelect.value=i.fit||'cover';}};
    const previousApply=document.getElementById('apply').onclick;document.getElementById('apply').onclick=()=>{const i=current();if(!i)return;const effect=effectSelect.value,fit=fitSelect.value;previousApply();i.effect=effect;i.fit=fit;changed();render();};
    const baseRender=render;render=function(){baseRender();state.items.forEach(i=>{const el=Array.from(canvas.children).find(e=>e.dataset.id===i.id);if(!el)return;const content=el.querySelector('.content');if(i.type==='text')el.style.zIndex=String(i.z||100);if(['card','section'].includes(i.type)){content.style.backgroundColor=i.mediaSrc?'transparent':(i.bg||'#fffdf9');if(i.mediaSrc){const media=document.createElement(i.mediaType==='video'?'video':'img');media.className='cardMedia';media.src=i.mediaSrc;if(i.mediaType==='video'){media.muted=true;media.loop=true;media.autoplay=true;media.playsInline=true;}else media.alt='ميديا الكارت';media.style.objectFit=i.fit||'contain';el.prepend(media);}}if(i.effect==='soft'){content.style.textShadow='0 1px 0 #fff,0 3px 4px rgba(0,0,0,.22)';el.style.boxShadow='0 7px 18px rgba(0,0,0,.14)';}if(i.effect==='gold'){content.style.color='#ae852e';content.style.textShadow='0 1px 0 #fceab1,0 2px 0 #77541e,0 4px 6px rgba(80,52,0,.3)';el.style.boxShadow='0 2px 0 #d6bc79,0 9px 22px rgba(101,72,18,.22)';}if(i.effect==='deep'){content.style.textShadow='1px 1px 0 rgba(255,255,255,.6),2px 3px 3px rgba(0,0,0,.3)';el.style.boxShadow='0 4px 0 rgba(0,0,0,.13),0 14px 26px rgba(0,0,0,.22)';}});};
    function addKind(kind){if(kind==='section'){add('section');const i=current();i.text='سيكشن جديد';i.w=1000;i.h=240;i.x=50;i.y=420;i.z=0;changed();render();return;}add('card');const i=current();i.kind=kind;i.text=kind==='brand'?'اسم البراند':kind==='store'?'اسم المتجر':'اسم العطر\nبيانات تجريبية';i.w=300;i.h=240;changed();render();}
    const originalShowMenu=showMenu;showMenu=function(e){originalShowMenu(e);const i=current();action('إنشاء سيكشن',()=>addKind('section'));action('إنشاء كارت براند',()=>addKind('brand'));action('إنشاء كارت متجر',()=>addKind('store'));action('إنشاء كارت عطر',()=>addKind('perfume'));action('رفع ميديا داخل الكارت',()=>{replaceId=selected;document.getElementById('upload').click();},!!i&&i.type==='card');action('نص فوق العنصر',()=>{const anchor=current();add('text');const t=current();if(anchor){t.x=anchor.x+15;t.y=anchor.y+15;t.w=Math.max(40,anchor.w-30);t.h=Math.min(90,anchor.h);}t.z=100;t.bg='#fffdf9';t.transparent=true;t.overlayOf=anchor?.id||null;changed();render();});action('خلفية نص شفافة',()=>{checkpoint();current().transparent=true;changed();render();},!!i&&i.type==='text');action('حذف ميديا الكارت',()=>{checkpoint();delete current().mediaSrc;delete current().mediaType;changed();render();},!!i&&!!i.mediaSrc);const r=menu.getBoundingClientRect();menu.style.left=Math.max(4,Math.min(e.clientX,innerWidth-r.width-8))+'px';menu.style.top=Math.max(4,Math.min(e.clientY,innerHeight-r.height-8))+'px';};
    const mediaRender=render;render=function(){mediaRender();state.items.forEach(i=>{if(i.transparent){const el=Array.from(canvas.children).find(e=>e.dataset.id===i.id);if(el)el.querySelector('.content').style.backgroundColor='transparent';}});};
    document.getElementById('upload').onchange=e=>{const f=e.target.files[0];if(!f)return;if(f.size>1024*1024){alert('حد الملف المحلي 1 ميجابايت. الفيديوهات الكبيرة تحتاج تخزينًا خارجيًا لاحقًا.');e.target.value='';return;}if(!f.type.startsWith('image/')&&!f.type.startsWith('video/'))return;const selectedItem=current();const target=replaceId||(selectedItem?.type==='card'?selectedItem.id:null);const reader=new FileReader();reader.onload=()=>{checkpoint();const type=f.type.startsWith('image/')?'image':'video';state.media.push({name:f.name,src:reader.result,type});const i=state.items.find(i=>i.id===target);if(i&&['card','section'].includes(i.type)){i.mediaSrc=reader.result;i.mediaType=type;i.fit=i.fit||'contain';changed();render();}else if(i&&['image','video'].includes(i.type)){i.src=reader.result;i.type=type;changed();render();}else add(type,reader.result);replaceId=null;if(document.getElementById('libraryDialog').open)library();};reader.readAsDataURL(f);e.target.value='';};
    const flowButton=document.createElement('button');flowButton.textContent='ترتيب تلقائي: مفعّل';let autoFlow=true;document.querySelector('header').append(flowButton);flowButton.onclick=()=>{autoFlow=!autoFlow;flowButton.textContent='ترتيب تلقائي: '+(autoFlow?'مفعّل':'متوقف');};
    function packCards(){const cards=state.items.filter(i=>i.type==='card').sort((a,b)=>a.y-b.y||a.x-b.x);if(!cards.length)return;let x=40,y=340,rowHeight=0;cards.forEach(i=>{const oldX=i.x,oldY=i.y;if(x+i.w>1060){x=40;y+=rowHeight+24;rowHeight=0;}i.x=x;i.y=y;state.items.filter(t=>t.overlayOf===i.id).forEach(t=>{t.x+=i.x-oldX;t.y+=i.y-oldY;});x+=i.w+24;rowHeight=Math.max(rowHeight,i.h);});canvas.style.height=Math.max(900,y+rowHeight+60)+'px';}
    let dragWasCard=false;let dragStartPoint=null;canvas.addEventListener('pointerdown',e=>{dragStartPoint={x:e.clientX,y:e.clientY};},true);canvas.addEventListener('pointerup',e=>{if(dragStartPoint&&Math.hypot(e.clientX-dragStartPoint.x,e.clientY-dragStartPoint.y)<4)dragWasCard=false;dragStartPoint=null;},true);canvas.addEventListener('pointerdown',e=>{const el=e.target.closest('.item');dragWasCard=!!el&&state.items.find(i=>i.id===el.dataset.id)?.type==='card'&&!e.target.classList.contains('handle');},true);canvas.addEventListener('pointerup',()=>{if(autoFlow&&dragWasCard&&!editing){packCards();changed();render();}dragWasCard=false;});
    const kindDblClick=canvas.addEventListener('dblclick',e=>{const el=e.target.closest('.item');const i=state.items.find(i=>i.id===el?.dataset.id);if(i?.type==='section'){checkpoint();editing=true;el.classList.add('editing');const c=el.querySelector('.content');c.contentEditable='plaintext-only';c.focus();}});
    document.getElementById('hint').textContent='حدد الكارت ثم كليك يمين لرفع الميديا داخله. النص طبقة مستقلة فوق العناصر. ترتيب تلقائي يرص الكروت بعد سحبها، ويمكن إيقافه. الحفظ محلي، مساحة اختبار ثابتة.';
    // Visible version marker and direct access to the requested functions.
    document.querySelector('header strong').textContent='Élan Scents · النسخة 3 — ميديا داخل الكارت';
    const quick=document.createElement('div');quick.style.cssText='display:flex;gap:8px;flex-wrap:wrap;justify-content:center;padding:10px;background:#f6f0e4';document.getElementById('hint').after(quick);function quickButton(label,callback){const b=document.createElement('button');b.textContent=label;b.onclick=callback;quick.append(b);}quickButton('+ سيكشن',()=>addKind('section'));quickButton('+ كارت براند',()=>addKind('brand'));quickButton('+ كارت متجر',()=>addKind('store'));quickButton('+ كارت عطر',()=>addKind('perfume'));quickButton('ميديا داخل الكارت المحدد',()=>{const i=current();if(!i||i.type!=='card'){alert('حدد كارتًا أولًا بكليك شمال، ثم اضغط هذا الزر.');return;}replaceId=i.id;document.getElementById('upload').click();});quickButton('تنسيق وتأثير 3D',()=>{if(!current()){alert('حدد عنصرًا أولًا.');return;}openFormat();});quickButton('نص فوق العنصر',()=>{const anchor=current();add('text');const t=current();t.transparent=true;t.z=100;t.overlayOf=anchor?.id||null;if(anchor){t.x=anchor.x+15;t.y=anchor.y+15;t.w=Math.max(40,anchor.w-30);}changed();render();});
    const menuWithAdditions=showMenu;showMenu=function(e){menuWithAdditions(e);const buttons=Array.from(menu.children);const additions=buttons.slice(-8);additions.reverse().forEach(b=>menu.prepend(b));};
    const originalLibrary=library;library=function(){originalLibrary();const holder=document.getElementById('mediaList');Array.from(holder.children).forEach((b,index)=>{const m=state.media[index];if(!m)return;b.textContent='استخدام: '+m.name;b.onclick=()=>{const i=current();if(i&&['card','section'].includes(i.type)){checkpoint();i.mediaSrc=m.src;i.mediaType=m.type;i.fit=i.fit||'contain';changed();render();}else add(m.type,m.src);document.getElementById('libraryDialog').close();};});};document.getElementById('library').onclick=()=>library();
    const correctedRender=render;render=function(){correctedRender();state.items.forEach(i=>{const el=Array.from(canvas.children).find(e=>e.dataset.id===i.id);if(!el)return;const content=el.querySelector('.content');if(i.mediaSrc&&i.type==='card'){el.style.backgroundColor=i.bg||'#fffdf9';const media=el.querySelector('.cardMedia');if(media){media.style.pointerEvents='none';media.style.clipPath='inset(0 round 16px)';}content.style.backgroundColor='transparent';}if(i.effect==='gold'&&!i.mediaSrc&&!i.transparent)content.style.backgroundImage='linear-gradient(145deg,'+(i.bg||'#fffdf9')+' 0%,#e9dbba 55%,'+(i.bg||'#fffdf9')+' 100%)';if(i.effect==='soft'&&!i.mediaSrc&&!i.transparent)content.style.backgroundImage='linear-gradient(145deg,#ffffff,'+(i.bg||'#fffdf9')+')';});};
    document.getElementById('hint').textContent='نسخة 3: حدّد كارتًا وارفع الميديا داخله. الأدوات الجديدة ظاهرة في الشريط المختصر وكليك يمين. الترتيب التلقائي للكروت فقط، والسيكشن ليس حاوية متكاملة بعد. الحفظ محلي.';
    // Repair interaction layering and keep all creation tools in the context menu.
    quick.remove();flowButton.remove();document.querySelector('header strong').textContent='Élan Scents · النسخة 4 — إصلاح التفاعل';
    const repairs=document.createElement('style');repairs.textContent='#menu{z-index:2147483000!important;direction:rtl}.item{user-select:none}.editing .content{user-select:text}.card .cardMedia{object-fit:contain}#format{min-width:320px}';document.head.appendChild(repairs);
    state.items.forEach(i=>{if(i.type==='card')i.fit='contain';});
    let contextPoint={x:350,y:300};let pendingInsertIndex=null;let dropTarget=null;
    function cardOrder(){return state.items.filter(i=>i.type==='card').sort((a,b)=>a.y-b.y||a.x-b.x);}
    function nearestCard(x,y,exclude){const cards=cardOrder().filter(c=>c.id!==exclude);let nearest=null,best=Infinity;cards.forEach(c=>{const distance=Math.hypot(x-(c.x+c.w/2),y-(c.y+c.h/2));if(distance<best){best=distance;nearest=c;}});return nearest;}
    packCards=function(){const cards=cardOrder();if(!cards.length)return;const moving=cards.find(c=>c.id===selected);if(moving&&dropTarget){const target=cards.find(c=>c.id===dropTarget.id);if(target){const without=cards.filter(c=>c.id!==moving.id);let idx=without.findIndex(c=>c.id===target.id)+(dropTarget.after?1:0);without.splice(Math.max(0,idx),0,moving);cards.splice(0,cards.length,...without);}}let x=40,y=340,rowHeight=0;cards.forEach(i=>{const oldX=i.x,oldY=i.y;if(x+i.w>1060){x=40;y+=rowHeight+24;rowHeight=0;}i.x=x;i.y=y;state.items.filter(t=>t.overlayOf===i.id).forEach(t=>{t.x+=i.x-oldX;t.y+=i.y-oldY;});x+=i.w+24;rowHeight=Math.max(rowHeight,i.h);});canvas.style.height=Math.max(900,y+rowHeight+60)+'px';dropTarget=null;};
    canvas.addEventListener('pointermove',e=>{if(!gesture||gesture.mode!=='move')return;const moving=state.items.find(i=>i.id===gesture.id);if(!moving||moving.type!=='card')return;const rect=canvas.getBoundingClientRect();const x=e.clientX-rect.left,y=e.clientY-rect.top;const target=nearestCard(x,y,moving.id);dropTarget=target?{id:target.id,after:x>target.x+target.w/2}:null;canvas.querySelectorAll('.item').forEach(el=>{el.style.borderLeft='';el.style.borderRight='';if(dropTarget&&el.dataset.id===dropTarget.id)el.style[dropTarget.after?'borderRight':'borderLeft']='4px solid #b48b38';});});
    const menuRepair=showMenu;showMenu=function(e){const rect=canvas.getBoundingClientRect();contextPoint={x:Math.max(0,Math.min(1000,e.clientX-rect.left)),y:Math.max(0,e.clientY-rect.top)};menuRepair(e);const formatButton=Array.from(menu.children).find(b=>b.textContent==='الخط واللون والحجم');if(formatButton){formatButton.disabled=!current();formatButton.textContent='تنسيق النص: الخط • اللون • الحجم • 3D';formatButton.onclick=()=>{menu.style.display='none';if(current())openFormat();};menu.prepend(formatButton);}action('الترتيب التلقائي: '+(autoFlow?'مفعّل':'متوقف'),()=>{autoFlow=!autoFlow;status.textContent=autoFlow?'الترتيب التلقائي للكروت مفعّل':'التحريك الحر مفعّل؛ العناصر الأخرى لن تتحرك';});const r=menu.getBoundingClientRect();menu.style.left=Math.max(4,Math.min(e.clientX,innerWidth-r.width-8))+'px';menu.style.top=Math.max(4,Math.min(e.clientY,innerHeight-r.height-8))+'px';};
    const addAtClick=add;add=function(type,src){addAtClick(type,src);const i=current();if(!i)return;i.x=Math.min(1100-i.w,contextPoint.x);i.y=contextPoint.y;if(type==='text'){i.transparent=true;i.z=100;}if(type==='card'&&autoFlow){const t=nearestCard(contextPoint.x,contextPoint.y,i.id);dropTarget=t?{id:t.id,after:contextPoint.x>t.x+t.w/2}:null;packCards();}render();};
    const oldKind=addKind;addKind=function(kind){oldKind(kind);if(kind!=='section'&&autoFlow){packCards();render();}};
    const interactionRender=render;render=function(){interactionRender();canvas.querySelectorAll('.item').forEach(el=>{const content=el.querySelector('.content');content.addEventListener('dblclick',()=>{const i=state.items.find(i=>i.id===el.dataset.id);if(i&&['text','card','section'].includes(i.type)){select(i.id);content.contentEditable='plaintext-only';content.focus();}});});};
    // Expand movement bounds to the current canvas height.
    canvas.addEventListener('pointermove',e=>{if(!gesture)return;const i=state.items.find(i=>i.id===gesture.id);const el=Array.from(canvas.children).find(el=>el.dataset.id===gesture.id);if(!i||!el)return;const height=Math.max(900,canvas.offsetHeight);if(gesture.mode==='move'){i.y=Math.max(0,Math.min(height-i.h,gesture.y+e.clientY-gesture.sy));el.style.top=i.y+'px';}else{i.h=Math.max(30,Math.min(height-i.y,gesture.h+e.clientY-gesture.sy));el.style.height=i.h+'px';}});
    document.getElementById('hint').textContent='كليك يمين لإنشاء العناصر أو تنسيق النص. الصور كاملة داخل الكارت بدون قص افتراضيًا؛ اختلاف النسب قد يترك فراغًا. عند سحب كارت يظهر خط ذهبي لتحديد موضع إدراجه. النصوص تتحرك بحرية. لا يوجد ربط أو نشر.';
    // Repair text editing and make media behavior explicit for all visual containers.
    const mediaCSS=document.createElement('style');mediaCSS.textContent='.section .content{position:relative;z-index:2}.section .cardMedia{position:absolute;inset:0;width:100%;height:100%;z-index:1;border-radius:16px;pointer-events:none}.item .cardMedia{pointer-events:none}';document.head.appendChild(mediaCSS);
    const adaptOption=document.createElement('option');adaptOption.value='adapt';adaptOption.textContent='الصورة كاملة: تعديل ارتفاع الإطار ليناسب أبعادها';fitSelect.append(adaptOption);
    const transparencyLabel=document.createElement('label');const transparencyInput=document.createElement('input');transparencyInput.type='checkbox';transparencyLabel.append(transparencyInput,' خلفية النص شفافة');document.getElementById('apply').before(transparencyLabel);
    let formatTargetId=null;openFormat=function(){const i=current();if(!i)return;formatTargetId=i.id;document.getElementById('font').value=i.font||'Tahoma';document.getElementById('size').value=i.size||24;document.getElementById('color').value=/^#[0-9a-f]{6}$/i.test(i.color||'')?i.color:'#222222';document.getElementById('bg').value=/^#[0-9a-f]{6}$/i.test(i.bg||'')?i.bg:'#fffdf9';document.getElementById('align').value=i.align||'right';effectSelect.value=i.effect||'none';fitSelect.value=i.fit||'cover';transparencyInput.checked=!!i.transparent;document.getElementById('format').showModal();};
    document.getElementById('bg').oninput=()=>transparencyInput.checked=false;
    function applyMediaAspect(i){if(!i.mediaSrc||i.fit!=='adapt')return;const probe=document.createElement(i.mediaType==='video'?'video':'img');const update=()=>{const width=probe.naturalWidth||probe.videoWidth;const height=probe.naturalHeight||probe.videoHeight;if(width&&height){i.h=Math.max(30,Math.round(i.w*height/width));canvas.style.height=Math.max(canvas.offsetHeight,i.y+i.h+50)+'px';render();}};if(i.mediaType==='video')probe.onloadedmetadata=update;else probe.onload=update;probe.src=i.mediaSrc;}
    document.getElementById('apply').onclick=()=>{const i=state.items.find(i=>i.id===formatTargetId);if(!i)return;checkpoint();i.font=document.getElementById('font').value;i.size=Math.max(8,Math.min(160,Number(document.getElementById('size').value)||24));i.color=document.getElementById('color').value;i.bg=document.getElementById('bg').value;i.align=document.getElementById('align').value;i.effect=effectSelect.value;i.fit=fitSelect.value;i.transparent=transparencyInput.checked;selected=i.id;changed();render();applyMediaAspect(i);document.getElementById('format').close();};
    const finalMediaRender=render;render=function(){finalMediaRender();state.items.forEach(i=>{const el=Array.from(canvas.children).find(e=>e.dataset.id===i.id);if(!el)return;const media=el.querySelector('.cardMedia');if(media){media.style.objectFit=i.fit==='contain'?'contain':'cover';media.style.width='100%';media.style.height='100%';el.querySelector('.content').style.backgroundColor='transparent';}if(i.type==='text'&&!i.transparent)el.querySelector('.content').style.backgroundColor=i.bg||'#fffdf9';});};
    let explicitUploadTarget=null;const previousUpload=document.getElementById('upload').onchange;document.getElementById('upload').onchange=e=>{const i=state.items.find(i=>i.id===replaceId)||current();if(i&&['card','section'].includes(i.type)){replaceId=i.id;i.fit='cover';}previousUpload(e);};
    const fixedMenu=showMenu;showMenu=function(e){fixedMenu(e);const i=current();Array.from(menu.children).forEach(b=>{if(b.textContent==='إضافة كارت'){b.textContent='إضافة بانر';b.onclick=()=>{menu.style.display='none';addKind('section');const item=current();item.text='';item.kind='banner';render();};}if(b.textContent.startsWith('تنسيق النص:')||b.textContent==='الخط واللون والحجم'){b.disabled=!i;b.onclick=()=>{menu.style.display='none';openFormat();};}if(b.textContent==='رفع ميديا داخل الكارت'){b.textContent='رفع صورة أو فيديو داخل العنصر';b.disabled=!i||!['card','section'].includes(i.type);b.onclick=()=>{menu.style.display='none';replaceId=selected;document.getElementById('upload').click();};}});action('مسح الاسم أو النص التلقائي',()=>{const target=current();if(!target)return;checkpoint();target.text='';changed();render();},!!i&&['text','card','section'].includes(i.type));action('كتابة أو تعديل نص العنصر',()=>{const target=current();if(!target)return;const value=prompt('اكتب النص أو اتركه فارغًا لمسحه',target.text||'');if(value===null)return;checkpoint();target.text=value;changed();render();},!!i&&['text','card','section'].includes(i.type));const r=menu.getBoundingClientRect();menu.style.top=Math.max(4,Math.min(e.clientY,innerHeight-r.height-8))+'px';};
    document.querySelector('header strong').textContent='Élan Scents · النسخة 5 — النصوص والبانر';document.getElementById('hint').textContent='كليك يمين: تنسيق الخط واللون والحجم والخلفية، أو مسح النص التلقائي. الميديا تملأ الإطار مع قص عند اختلاف النسب؛ اختر تعديل ارتفاع الإطار من التنسيق لعرضها كاملة بدون قص. حفظ محلي فقط.';
    // Requested border controls and a consolidated context menu.
    const borderControls=document.createElement('fieldset');borderControls.style.cssText='border:1px solid #d6c49d;border-radius:10px;margin:16px 0;padding:12px';const borderLegend=document.createElement('legend');borderLegend.textContent='إطار مربع النص أو العنصر';borderControls.append(borderLegend);
    function borderField(label,input){const l=document.createElement('label');l.append(label,input);borderControls.append(l);}
    const borderColor=document.createElement('input');borderColor.type='color';borderField(' لون الإطار ',borderColor);
    const borderTransparent=document.createElement('input');borderTransparent.type='checkbox';borderField(' إطار شفاف ',borderTransparent);borderColor.oninput=()=>borderTransparent.checked=false;
    const borderDepth=document.createElement('input');borderDepth.type='checkbox';borderField(' تفعيل تأثير 3D للإطار ',borderDepth);
    const borderShape=document.createElement('select');[['rectangle','مستطيل'],['circle','دائرة']].forEach(([value,text])=>{const o=document.createElement('option');o.value=value;o.textContent=text;borderShape.append(o);});borderField(' شكل مربع النص ',borderShape);document.getElementById('apply').before(borderControls);
    const formatBeforeBorder=openFormat;openFormat=function(){formatBeforeBorder();const i=state.items.find(i=>i.id===formatTargetId);if(!i)return;borderColor.value=i.borderColor||'#b99755';borderTransparent.checked=i.borderTransparent!==false;borderDepth.checked=!!i.borderDepth;borderShape.value=i.borderShape||'rectangle';};
    const applyBeforeBorder=document.getElementById('apply').onclick;document.getElementById('apply').onclick=()=>{const i=state.items.find(i=>i.id===formatTargetId);if(!i)return;const values={borderColor:borderColor.value,borderTransparent:borderTransparent.checked,borderDepth:borderDepth.checked,borderShape:borderShape.value};applyBeforeBorder();Object.assign(i,values);if(i.borderShape==='circle')i.h=i.w;changed();render();};
    const renderBeforeBorder=render;render=function(){renderBeforeBorder();state.items.forEach(i=>{const el=Array.from(canvas.children).find(e=>e.dataset.id===i.id);if(!el)return;const content=el.querySelector('.content');if(i.borderShape){const radius=i.borderShape==='circle'?'50%':'0px';content.style.borderRadius=radius;content.style.border='2px solid '+(i.borderTransparent?'transparent':(i.borderColor||'#b99755'));content.style.boxShadow=i.borderDepth&&!i.borderTransparent?'inset 1px 1px 2px rgba(255,255,255,.85),inset -2px -2px 3px rgba(0,0,0,.25),0 5px 10px rgba(0,0,0,.2)':'none';el.style.borderRadius=radius;const media=el.querySelector('.cardMedia');if(media){media.style.borderRadius=radius;media.style.clipPath=i.borderShape==='circle'?'circle(50%)':'inset(0)';}}});};
    const menuBeforeCleanup=showMenu;showMenu=function(e){menuBeforeCleanup(e);const elements=Array.from(menu.children);let createText=null,banner=null,perfume=null;elements.forEach(b=>{const text=b.textContent;if(text==='إضافة نص'||text==='نص فوق العنصر'){if(!createText){createText=b;b.textContent='إنشاء نص';b.disabled=false;b.onclick=()=>{menu.style.display='none';const anchor=current();add('text');const t=current();t.transparent=true;t.z=100;t.overlayOf=anchor?.id||null;if(anchor){t.x=anchor.x+15;t.y=anchor.y+15;t.w=Math.max(40,anchor.w-30);}changed();render();};}else b.remove();}else if(text==='خلفية نص شفافة'||text==='إضافة صورة أو فيديو'){b.remove();}else if(text==='إضافة بانر'){banner=b;b.textContent='إنشاء بانر صورة أو فيديو';}else if(text==='إنشاء كارت عطر'){perfume=b;}else if(text==='رفع صورة أو فيديو داخل العنصر'){b.textContent='رفع صورة أو فيديو داخل العناصر أو الهيرو';b.disabled=!current()||!['card','section','image','video'].includes(current().type);}else if(text==='حذف ميديا الكارت'){b.textContent='حذف ميديا الكارت أو الهيرو إلى الأرشيف';const i=current();b.disabled=!i||!(i.mediaSrc||(['image','video'].includes(i.type)&&i.src));b.onclick=()=>{menu.style.display='none';const target=current();if(!target)return;checkpoint();if(target.mediaSrc){state.archive.push({id:uid(),type:target.mediaType==='video'?'video':'image',src:target.mediaSrc,x:target.x,y:target.y,w:target.w,h:target.h,text:'',font:'Tahoma',size:24,color:'#222222',bg:'#fffdf9',align:'right'});delete target.mediaSrc;delete target.mediaType;}else if(['image','video'].includes(target.type)&&target.src){state.archive.push(clone(target));state.items=state.items.filter(i=>i.id!==target.id);selected=null;}changed();render();};}});if(perfume){let after=perfume;if(banner){after.after(banner);after=banner;}if(createText)after.after(createText);}const r=menu.getBoundingClientRect();menu.style.top=Math.max(4,Math.min(e.clientY,innerHeight-r.height-8))+'px';};
    canvas.addEventListener('pointerup',()=>{const i=current();if(i?.borderShape==='circle'){i.h=i.w;render();}});
    document.querySelector('header strong').textContent='Élan Scents · النسخة 6 — الإطار والقائمة';
    // Working empty banner and a clearer, contextual formatting panel.
    const bannerMenu=showMenu;showMenu=function(e){bannerMenu(e);const b=Array.from(menu.children).find(b=>b.textContent==='إنشاء بانر صورة أو فيديو');if(b){b.disabled=false;b.onclick=()=>{menu.style.display='none';add('card');const i=current();i.kind='banner';i.text='';i.w=300;i.h=240;i.borderColor='#b99755';i.borderTransparent=false;i.borderShape='rectangle';if(autoFlow)packCards();changed();render();};}};
    const formatPanel=document.getElementById('format');formatPanel.style.width='540px';formatPanel.querySelector('h3').textContent='تنسيق العنصر';
    const panelStyle=document.createElement('style');panelStyle.textContent='#format{background:#fffdf8;color:#28251e;padding:20px}#format h3{margin:0 0 18px;color:#86632b}#format fieldset{border:1px solid #e0d1b0;border-radius:12px;padding:12px;margin:12px 0}#format legend{font-weight:bold;color:#87642e;padding:0 8px}#format .fieldGrid{display:grid;grid-template-columns:1fr 1fr;gap:12px}#format label{margin:0;display:flex;flex-direction:column;gap:7px;font-size:13px}#format label:has(input[type=checkbox]){flex-direction:row;align-items:center;grid-column:1/-1}#format select,#format input[type=number]{width:100%;background:white;min-height:38px}#format .colorRow{display:flex;align-items:center;gap:8px;direction:ltr}#format input[type=color]{width:55px;height:40px;padding:3px;cursor:pointer}#format .colorValue{font-family:Arial;font-size:12px;border:1px solid #d8c69f;background:white;padding:8px;border-radius:7px}#format .sample{padding:18px;border:1px solid #e0d1b0;border-radius:12px;margin:12px 0;background:#f1eee7}#format .sample span{display:block;padding:14px;text-align:center}#format .panelActions{display:flex;gap:10px;padding-top:10px}#format .panelActions button{flex:1}#format .panelActions #apply{background:#26231d;color:#efddaf}@media(max-width:480px){#format .fieldGrid{grid-template-columns:1fr}}';document.head.append(panelStyle);
    function panelGroup(title){const f=document.createElement('fieldset');const l=document.createElement('legend');l.textContent=title;const grid=document.createElement('div');grid.className='fieldGrid';f.append(l,grid);formatPanel.append(f);return {fieldset:f,grid};}
    const textGroup=panelGroup('الكتابة');textGroup.grid.append(document.getElementById('font').closest('label'),document.getElementById('size').closest('label'),document.getElementById('align').closest('label'));
    const colorsGroup=panelGroup('ألوان النص والخلفية');colorsGroup.grid.append(document.getElementById('color').closest('label'),document.getElementById('bg').closest('label'),transparencyLabel,effectLabel);
    const borderGroup=panelGroup('الإطار');borderGroup.grid.append(...Array.from(borderControls.querySelectorAll('label')));borderControls.remove();
    const mediaGroupPanel=panelGroup('طريقة عرض الميديا');mediaGroupPanel.grid.append(fitLabel);const mediaExplanation=document.createElement('small');mediaExplanation.textContent='ملء الإطار قد يقص الأطراف. عرض الصورة كاملة قد يترك فراغًا. تعديل الارتفاع يجعل الإطار يتناسب مع الصورة.';mediaGroupPanel.grid.append(mediaExplanation);
    const sampleBox=document.createElement('div');sampleBox.className='sample';const sampleCaption=document.createElement('small');sampleCaption.textContent='معاينة تنسيق فقط، لا تغيّر العنصر قبل الضغط على تطبيق';const sample=document.createElement('span');sample.textContent='معاينة النص';sampleBox.append(sampleCaption,sample);formatPanel.append(sampleBox);
    const actions=document.createElement('div');actions.className='panelActions';actions.append(document.getElementById('apply'));const closeButton=Array.from(formatPanel.querySelectorAll('button')).find(b=>b.textContent==='إغلاق');if(closeButton)actions.append(closeButton);formatPanel.append(actions);
    const colorValues=new Map();[document.getElementById('color'),document.getElementById('bg'),borderColor].forEach(input=>{const row=document.createElement('div');row.className='colorRow';input.before(row);row.append(input);const value=document.createElement('span');value.className='colorValue';row.append(value);colorValues.set(input,value);});
    function updatePanelPreview(){colorValues.forEach((value,input)=>{value.textContent=input.value.toUpperCase();value.style.borderBottom='4px solid '+input.value;});const i=(typeof liveMode!=='undefined'&&liveMode&&selectedLive)?{text:selectedLive.text}:state.items.find(i=>i.id===formatTargetId);sample.textContent=i?.text?.trim().slice(0,80)||'معاينة النص';sample.style.fontFamily=document.getElementById('font').value;sample.style.fontSize=Math.min(42,Number(document.getElementById('size').value)||24)+'px';sample.style.color=document.getElementById('color').value;sample.style.backgroundColor=transparencyInput.checked?'transparent':document.getElementById('bg').value;sample.style.border='2px solid '+(borderTransparent.checked?'transparent':borderColor.value);sample.style.borderRadius=borderShape.value==='circle'?'50%':'0';sample.style.boxShadow=borderDepth.checked&&!borderTransparent.checked?'inset 1px 1px 2px #fff,inset -2px -2px 3px #0004,0 5px 10px #0003':'none';sample.style.textShadow=effectSelect.value==='none'?'none':'0 1px 0 #fff,1px 2px 2px #0004';sample.style.textAlign=document.getElementById('align').value;}
    formatPanel.querySelectorAll('input,select').forEach(input=>{input.addEventListener('input',updatePanelPreview);input.addEventListener('change',updatePanelPreview);});
    const organizedFormat=openFormat;openFormat=function(){organizedFormat();const i=state.items.find(i=>i.id===formatTargetId);const hasMedia=!!i&&(!!i.mediaSrc||['image','video'].includes(i.type));mediaGroupPanel.fieldset.hidden=!hasMedia;textGroup.fieldset.hidden=!!i&&['image','video'].includes(i.type);updatePanelPreview();};
    document.querySelector('header strong').textContent='Élan Scents · النسخة 7 — البانر ولوحة التنسيق';
    // Compact formatting panel and expanded Arabic/English font choices.
    const fontDefinitions=[['عربي',['Cairo','Tajawal','Almarai','Amiri','Changa','El Messiri','Noto Kufi Arabic','Noto Naskh Arabic','Noto Sans Arabic','Reem Kufi','IBM Plex Sans Arabic']],['إنجليزي',['Inter','Roboto','Open Sans','Lato','Montserrat','Poppins','Playfair Display','Cormorant Garamond','Libre Baskerville','Merriweather']],['خطوط الجهاز',['Tahoma','Arial','Georgia','Times New Roman','Verdana','Trebuchet MS','Courier New','system-ui']]];
    const fontControl=document.getElementById('font');fontControl.replaceChildren();fontDefinitions.forEach(([group,names])=>{const optgroup=document.createElement('optgroup');optgroup.label=group;names.forEach(name=>{const o=document.createElement('option');o.value=name;o.textContent=name;optgroup.append(o);});fontControl.append(optgroup);});
    const fontCSS=document.createElement('link');fontCSS.rel='stylesheet';const families=fontDefinitions.slice(0,2).flatMap(g=>g[1]).map(name=>'family='+name.replace(/ /g,'+')+':wght@400;700').join('&');fontCSS.href='https://fonts.googleapis.com/css2?'+families+'&display=swap';document.head.append(fontCSS);
    const compactStyle=document.createElement('style');compactStyle.textContent='#format{width:580px!important;padding:16px}#format .fieldGrid{gap:10px}#format fieldset{margin:9px 0;padding:10px}#format label{font-size:12px;gap:5px}#format select,#format input[type=number]{min-height:34px;padding:6px}#format .textRow{grid-template-columns:minmax(0,1.7fr) minmax(0,1fr) minmax(0,1fr)}#format .colorRow{direction:rtl;background:white;border:1px solid #ddcfb2;border-radius:8px;padding:6px;gap:7px}#format .colorChip{width:36px;height:30px;border-radius:6px;border:1px solid #c9bb9b;box-shadow:inset 0 0 0 2px #ffffff99;display:block;flex-shrink:0}#format .colorLabel{font-family:Tahoma;font-size:12px;color:#514737}#format .colorHex{font-family:Arial;font-size:11px;color:#777;direction:ltr}#format .borderToggles{grid-column:1/-1;display:flex;gap:20px;align-items:center;flex-wrap:nowrap;padding:7px 0}#format .borderToggles label{display:flex;flex-direction:row;gap:7px;white-space:nowrap}#format .sample{padding:8px;margin:8px 0}#format .sample span{padding:10px}@media(max-width:420px){#format{padding:10px}#format .textRow{grid-template-columns:minmax(0,1.3fr) minmax(0,1fr) minmax(0,1fr)}#format .borderToggles{gap:8px;font-size:11px}}';document.head.append(compactStyle);
    textGroup.grid.classList.add('textRow');
    const toggles=document.createElement('div');toggles.className='borderToggles';toggles.append(borderDepth.closest('label'),borderTransparent.closest('label'));borderGroup.grid.append(toggles);
    function colorName(hex){const r=parseInt(hex.slice(1,3),16),g=parseInt(hex.slice(3,5),16),b=parseInt(hex.slice(5,7),16);if(Math.max(r,g,b)-Math.min(r,g,b)<25){if(r>235)return 'أبيض';if(r<35)return 'أسود';return 'رمادي';}if(r>180&&g>150&&b<140)return 'ذهبي';if(r>210&&g>190&&b>155)return 'عاجي';if(r>g*1.2&&r>b*1.2)return 'أحمر';if(g>r*1.2&&g>b*1.2)return 'أخضر';if(b>r*1.2&&b>g*1.2)return 'أزرق';return 'لون مخصص';}
    const chips=new Map();colorValues.forEach((value,input)=>{value.remove();const row=input.parentElement;const control=document.createElement('button');control.type='button';control.style.cssText='display:flex;align-items:center;gap:8px;background:none;border:0;padding:0;width:100%;text-align:right';const chip=document.createElement('span');chip.className='colorChip';const info=document.createElement('span');const name=document.createElement('span');name.className='colorLabel';const code=document.createElement('span');code.className='colorHex';code.style.display='block';info.append(name,code);control.append(chip,info);row.append(control);input.style.cssText='position:absolute;opacity:0;width:1px;height:1px;padding:0;border:0;pointer-events:none';input.tabIndex=-1;control.onclick=()=>{if(typeof input.showPicker==='function'){try{input.showPicker();}catch(e){input.click();}}else input.click();};chips.set(input,{chip,name,code});});
    const updateBeforeChips=updatePanelPreview;updatePanelPreview=function(){updateBeforeChips();chips.forEach((parts,input)=>{parts.chip.style.backgroundColor=input.value;parts.name.textContent=colorName(input.value);parts.code.textContent=input.value.toUpperCase();});};
    chips.forEach((parts,input)=>{input.addEventListener('input',()=>updatePanelPreview());input.addEventListener('change',()=>updatePanelPreview());});
    const fontNotice=document.createElement('small');fontNotice.textContent='الخطوط الإضافية تُحمّل من Google Fonts وتحتاج الإنترنت؛ عند تعذر التحميل يُستخدم خط بديل.';textGroup.fieldset.append(fontNotice);
    document.querySelector('header strong').textContent='Élan Scents · النسخة 8 — لوحة مختصرة وخطوط';
    // Focused visual and library improvements.
    fontNotice.remove();document.getElementById('hint').remove();
    const textEffectsRow=document.createElement('div');textEffectsRow.className='borderToggles';textEffectsRow.append(transparencyLabel,effectLabel);colorsGroup.grid.append(textEffectsRow);effectLabel.style.flexDirection='row';effectSelect.style.width='145px';
    const paletteColors=[['ذهبي','#D4AF37'],['ذهبي داكن','#B8860B'],['ذهبي فاتح','#E6C76A'],['أسود','#000000'],['أبيض','#FFFFFF'],['عاجي','#FFFFF0'],['أوف وايت','#FAF9F6'],['رمادي','#808080'],['رمادي داكن','#444444'],['بيج','#E8DCC4'],['أحمر','#C62828'],['أزرق','#1565C0'],['أخضر','#2E7D32'],['بنفسجي','#7B1FA2']];
    const paletteDialog=document.createElement('dialog');paletteDialog.style.width='430px';document.body.append(paletteDialog);let paletteTarget=null;function openPalette(input){paletteTarget=input;paletteDialog.replaceChildren();const h=document.createElement('h3');h.textContent='اختيار لون صريح';paletteDialog.append(h);const grid=document.createElement('div');grid.style.cssText='display:grid;grid-template-columns:repeat(3,1fr);gap:8px';paletteColors.forEach(([label,color])=>{const b=document.createElement('button');b.style.cssText='display:flex;align-items:center;gap:7px;font-size:12px;padding:8px';const sw=document.createElement('span');sw.style.cssText='width:24px;height:24px;border:1px solid #aaa;border-radius:4px;background:'+color;b.append(sw,label);b.onclick=()=>{input.value=color;input.dispatchEvent(new Event('input',{bubbles:true}));input.dispatchEvent(new Event('change',{bubbles:true}));paletteDialog.close();};grid.append(b);});paletteDialog.append(grid);const label=document.createElement('label');label.textContent='أو أدخل كود اللون بدقة';const hex=document.createElement('input');hex.value=input.value.toUpperCase();hex.dir='ltr';hex.placeholder='#D4AF37';label.append(hex);paletteDialog.append(label);const apply=document.createElement('button');apply.textContent='اعتماد اللون';apply.onclick=()=>{const value=hex.value.trim();if(!/^#[0-9a-f]{6}$/i.test(value)){alert('اكتب # وبعده ستة أحرف أو أرقام، مثال #D4AF37');return;}input.value=value;input.dispatchEvent(new Event('input',{bubbles:true}));input.dispatchEvent(new Event('change',{bubbles:true}));paletteDialog.close();};const close=document.createElement('button');close.textContent='إغلاق';close.onclick=()=>paletteDialog.close();paletteDialog.append(apply,close);paletteDialog.showModal();}
    chips.forEach((parts,input)=>{input.parentElement.querySelector('button').onclick=()=>openPalette(input);});
    state.items.forEach(i=>{if(i.mediaSrc)i.fit='contain';});
    const safeMediaRender=render;render=function(){safeMediaRender();state.items.forEach(i=>{const el=Array.from(canvas.children).find(e=>e.dataset.id===i.id);if(!el)return;el.querySelectorAll('img,video').forEach(media=>{media.style.objectFit='contain';media.style.width='100%';media.style.height='100%';});const c=el.querySelector('.content');c.style.backgroundImage='none';c.style.color=i.color||'#222222';if(i.effect==='gold')c.style.textShadow='0 1px 0 rgba(255,255,255,.6),1px 2px 2px rgba(0,0,0,.25)';});};
    mediaGroupPanel.fieldset.hidden=true;const openBeforeMediaHide=openFormat;openFormat=function(){openBeforeMediaHide();mediaGroupPanel.fieldset.hidden=true;};
    const categoryDefinitions=[['section','سيكشن'],['brand','براند'],['store','متجر'],['perfume','عطر'],['banner','بانر'],['text','نص'],['hero','هيرو'],['image','صورة'],['video','فيديو']];
    function itemCategory(item){if(['brand','store','perfume','banner','hero'].includes(item.kind))return item.kind;if(item.type==='card')return 'perfume';if(item.type==='section')return 'section';return ['text','image','video'].includes(item.type)?item.type:'banner';}
    if(!Array.isArray(state.savedElements))state.savedElements=[];
    let libraryTab='archive',libraryCategory='section',uploadOnlyCategory=null;
    const libraryDialog=document.getElementById('libraryDialog');libraryDialog.style.width='720px';
    function libraryButton(text,fn){const b=document.createElement('button');b.textContent=text;b.onclick=fn;return b;}
    library=function(){libraryDialog.replaceChildren();const title=document.createElement('h3');title.textContent='مكتبة إيلان المحلية';libraryDialog.append(title);const tabs=document.createElement('div');tabs.style.cssText='display:flex;gap:8px;margin-bottom:12px';[['archive','العناصر المحذوفة'],['saved','الميديا والعناصر المحفوظة']].forEach(([value,text])=>{const b=libraryButton(text,()=>{libraryTab=value;library();});if(libraryTab===value)b.style.background='#e8d6ad';tabs.append(b);});libraryDialog.append(tabs);const folders=document.createElement('div');folders.style.cssText='display:grid;grid-template-columns:repeat(3,1fr);gap:8px';categoryDefinitions.forEach(([key,label])=>{const count=libraryTab==='archive'?state.archive.filter(i=>itemCategory(i)===key).length:(state.savedElements||[]).filter(i=>itemCategory(i)===key).length+state.media.filter(m=>(m.category||m.type)===key).length;const b=libraryButton(label+' ('+count+')',()=>{libraryCategory=key;library();});if(libraryCategory===key)b.style.background='#e8d6ad';folders.append(b);});libraryDialog.append(folders);const heading=document.createElement('h4');heading.textContent=categoryDefinitions.find(c=>c[0]===libraryCategory)?.[1]||'';libraryDialog.append(heading);const list=document.createElement('div');list.style.cssText='display:grid;gap:10px';libraryDialog.append(list);
    function row(item,label,callback){const box=document.createElement('div');box.style.cssText='display:flex;align-items:center;gap:10px;padding:10px;border:1px solid #dfd0b3;border-radius:10px';if(item.type==='image'||item.mediaType==='image'){const img=document.createElement('img');img.src=item.src||item.mediaSrc;img.style.cssText='width:60px;height:50px;object-fit:contain';box.append(img);}const text=document.createElement('span');text.textContent=item.name||item.text?.slice(0,35)||heading.textContent;text.style.flex='1';box.append(text,libraryButton(label,callback));list.append(box);}
    if(libraryTab==='archive'){state.archive.forEach((item,index)=>{if(itemCategory(item)!==libraryCategory)return;row(item,'استرجاع',()=>{checkpoint();const copy=clone(item);if(state.items.some(i=>i.id===copy.id))copy.id=uid();state.items.push(copy);state.archive.splice(index,1);selected=copy.id;changed();render();library();});});}else{state.savedElements.forEach(item=>{if(itemCategory(item)!==libraryCategory)return;row(item,'إضافة نسخة',()=>{checkpoint();const copy=clone(item);copy.id=uid();copy.x=80;copy.y=300;state.items.push(copy);selected=copy.id;changed();render();libraryDialog.close();});});state.media.forEach(m=>{if((m.category||m.type)!==libraryCategory)return;row(m,'استخدام',()=>{const i=current();if(i&&['card','section'].includes(i.type)){checkpoint();i.mediaSrc=m.src;i.mediaType=m.type;i.fit='contain';changed();render();}else{add(m.type,m.src);}libraryDialog.close();});});const uploadButton=libraryButton('رفع ملف وحفظه في '+heading.textContent,()=>{uploadOnlyCategory=libraryCategory;replaceId=null;document.getElementById('upload').click();});libraryDialog.append(uploadButton);const note=document.createElement('small');note.textContent='صور وفيديوهات صغيرة، أو ملف عنصر JSON صادر من هذا المحرر. الملفات تُحفظ محليًا، ولا تُضاف للصفحة عند الرفع للمكتبة.';libraryDialog.append(note);}
    if(!list.children.length){const empty=document.createElement('p');empty.textContent='لا توجد عناصر في هذا القسم بعد.';list.append(empty);}libraryDialog.append(libraryButton('إغلاق',()=>libraryDialog.close()));if(!libraryDialog.open)libraryDialog.showModal();};document.getElementById('library').onclick=()=>library();
    document.getElementById('upload').accept='image/*,video/*,.json';document.getElementById('upload').onchange=async e=>{const f=e.target.files[0];if(!f)return;e.target.value='';const category=uploadOnlyCategory;uploadOnlyCategory=null;if(f.size>1024*1024){alert('النسخة المحلية تقبل ملفًا أقل من 1 ميجابايت.');return;}if(f.name.toLowerCase().endsWith('.json')){if(!category){alert('استيراد العناصر من داخل المكتبة فقط.');return;}try{const obj=JSON.parse(await f.text());if(obj.format!=='elan-element-v1'||!obj.element||!['card','section','text','image','video'].includes(obj.element.type))throw new Error();checkpoint();const item=clone(obj.element);item.id=uid();if(['brand','store','perfume','banner','hero'].includes(category))item.kind=category;else item.type=category;state.savedElements.push(item);changed();library();}catch(err){alert('الملف ليس عنصرًا متوافقًا صادرًا من المحرر.');}return;}if(!f.type.startsWith('image/')&&!f.type.startsWith('video/')){alert('اختر صورة أو فيديو أو ملف عنصر متوافق.');return;}const target=replaceId||(current()&&['card','section'].includes(current().type)?selected:null);replaceId=null;const reader=new FileReader();reader.onload=()=>{checkpoint();const type=f.type.startsWith('image/')?'image':'video';const i=state.items.find(i=>i.id===target);const m={name:f.name,src:reader.result,type,category:category||(i?itemCategory(i):type)};state.media.push(m);if(!category){if(i&&['card','section'].includes(i.type)){i.mediaSrc=m.src;i.mediaType=type;i.fit='contain';}else if(i&&['image','video'].includes(i.type)){i.src=m.src;i.type=type;}else{add(type,m.src);}}changed();render();if(libraryDialog.open)library();};reader.readAsDataURL(f);};
    function downloadElement(item){const url=URL.createObjectURL(new Blob([JSON.stringify({format:'elan-element-v1',element:item},null,2)],{type:'application/json'}));const a=document.createElement('a');a.href=url;a.download='elan-element.json';a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);}
    const cleanMenu=showMenu;showMenu=function(e){cleanMenu(e);Array.from(menu.children).forEach(b=>{if(b.textContent==='استبدال الصورة أو الفيديو')b.remove();if(b.textContent==='حذف إلى الأرشيف')b.textContent='حذف العنصر إلى الأرشيف';});action('حفظ العنصر في المكتبة',()=>{const i=current();if(!i)return;checkpoint();if(!Array.isArray(state.savedElements))state.savedElements=[];state.savedElements.push(clone(i));changed();},!!current());action('تنزيل العنصر للمكتبة كملف',()=>{if(current())downloadElement(current());},!!current());const r=menu.getBoundingClientRect();menu.style.top=Math.max(4,Math.min(e.clientY,innerHeight-r.height-8))+'px';};
    // Sections participate in the same flow as cards instead of floating on top.
    cardOrder=function(){return state.items.filter(i=>['card','section'].includes(i.type)).sort((a,b)=>a.y-b.y||a.x-b.x);};
    packCards=function(){const elements=cardOrder();const moving=elements.find(i=>i.id===selected);if(moving&&dropTarget){const without=elements.filter(i=>i.id!==moving.id);const index=without.findIndex(i=>i.id===dropTarget.id);if(index>=0){without.splice(index+(dropTarget.after?1:0),0,moving);elements.splice(0,elements.length,...without);}}let x=40,y=340,rowHeight=0;elements.forEach(i=>{const oldX=i.x,oldY=i.y;if(i.type==='section'){if(x!==40){y+=rowHeight+24;x=40;rowHeight=0;}i.w=Math.min(i.w,1020);i.x=40;i.y=y;y+=i.h+24;}else{if(x+i.w>1060){x=40;y+=rowHeight+24;rowHeight=0;}i.x=x;i.y=y;x+=i.w+24;rowHeight=Math.max(rowHeight,i.h);}state.items.filter(t=>t.overlayOf===i.id).forEach(t=>{t.x+=i.x-oldX;t.y+=i.y-oldY;});});canvas.style.height=Math.max(900,y+rowHeight+60)+'px';dropTarget=null;};
    canvas.addEventListener('pointerdown',e=>{const el=e.target.closest('.item');if(el&&state.items.find(i=>i.id===el.dataset.id)?.type==='section'&&!e.target.classList.contains('handle'))dragWasCard=true;},true);
    canvas.addEventListener('pointermove',e=>{if(!gesture||gesture.mode!=='move')return;const i=state.items.find(i=>i.id===gesture.id);if(i?.type!=='section')return;const rect=canvas.getBoundingClientRect();const target=nearestCard(e.clientX-rect.left,e.clientY-rect.top,i.id);dropTarget=target?{id:target.id,after:e.clientY-rect.top>target.y+target.h/2}:null;});
    const createKindBeforeFlow=addKind;addKind=function(kind){createKindBeforeFlow(kind);if(kind==='section'&&autoFlow){packCards();render();}};
    const migrateSavedRender=render;render=function(){if(!Array.isArray(state.savedElements))state.savedElements=[];migrateSavedRender();};
    document.querySelector('header strong').textContent='Élan Scents · النسخة 9 — الألوان والمكتبة';
    // Place elements where requested; flow only on deliberate dragging.
    let requestedFlow=false;cardOrder=function(){return state.items.filter(i=>['card','section','image','video'].includes(i.type)).sort((a,b)=>a.y-b.y||a.x-b.x);};
    packCards=function(){if(!requestedFlow)return;const elements=cardOrder();const moving=elements.find(i=>i.id===selected);if(moving&&dropTarget){const rest=elements.filter(i=>i.id!==moving.id);const index=rest.findIndex(i=>i.id===dropTarget.id);if(index>=0){rest.splice(index+(dropTarget.after?1:0),0,moving);elements.splice(0,elements.length,...rest);}}let startY=Math.max(30,Math.min(...elements.map(i=>i.y)));let x=40,y=Number.isFinite(startY)?startY:340,rowHeight=0;elements.forEach(i=>{const oldX=i.x,oldY=i.y;i.w=Math.min(i.w,1020);if(x+i.w>1060){x=40;y+=rowHeight+24;rowHeight=0;}i.x=x;i.y=y;x+=i.w+24;rowHeight=Math.max(rowHeight,i.h);state.items.filter(t=>t.overlayOf===i.id).forEach(t=>{t.x+=i.x-oldX;t.y+=i.y-oldY;});});canvas.style.height=Math.max(900,y+rowHeight+50)+'px';dropTarget=null;requestedFlow=false;};
    const kindAtPosition=addKind;addKind=function(kind){kindAtPosition(kind);const i=current();if(!i)return;i.x=Math.max(0,Math.min(1100-i.w,contextPoint.x));i.y=Math.max(0,contextPoint.y);if(kind==='section'){i.w=450;i.h=220;i.x=Math.max(0,Math.min(1100-i.w,contextPoint.x));}canvas.style.height=Math.max(canvas.offsetHeight,i.y+i.h+50)+'px';render();};
    const lastMenu=showMenu;showMenu=function(e){lastMenu(e);Array.from(menu.children).forEach(b=>{if(['مسح الاسم أو النص التلقائي','كتابة أو تعديل نص العنصر'].includes(b.textContent))b.remove();});};
    let flowPointerStart=null;canvas.addEventListener('pointerdown',e=>{flowPointerStart={x:e.clientX,y:e.clientY};},true);canvas.addEventListener('pointerup',e=>{const g=gesture;if(!g||g.mode!=='move'||!flowPointerStart)return;const moved=Math.hypot(e.clientX-flowPointerStart.x,e.clientY-flowPointerStart.y)>4;const item=state.items.find(i=>i.id===g.id);if(moved&&item&&['card','section','image','video'].includes(item.type)){const rect=canvas.getBoundingClientRect();const x=e.clientX-rect.left,y=e.clientY-rect.top;const target=nearestCard(x,y,item.id);dropTarget=target?{id:target.id,after:y>target.y+target.h*.7||(Math.abs(y-(target.y+target.h/2))<target.h*.4&&x>target.x+target.w/2)}:null;requestedFlow=!!target;dragWasCard=true;}flowPointerStart=null;},true);
    // Clicking saved media inserts a new element, never silently overwrites the selection.
    const libraryBeforeFix=library;library=function(){libraryBeforeFix();const list=Array.from(libraryDialog.children).find(el=>el.tagName==='DIV'&&el.style.display==='grid'&&!el.textContent.includes('سيكشن ('));if(!list)return;const entries=libraryTab==='archive'?state.archive.filter(i=>itemCategory(i)===libraryCategory):[...state.savedElements.filter(i=>itemCategory(i)===libraryCategory),...state.media.filter(m=>(m.category||m.type)===libraryCategory)];Array.from(list.children).forEach((row,index)=>{const source=entries[index];if(!source||row.tagName!=='DIV')return;const use=row.querySelector('button');if(libraryTab==='saved'&&use){use.onclick=()=>{checkpoint();let copy;if(state.media.includes(source)){if(['section','brand','store','perfume','banner','hero'].includes(libraryCategory)){copy={id:uid(),type:libraryCategory==='section'?'section':'card',kind:libraryCategory,mediaSrc:source.src,mediaType:source.type,fit:'contain',text:'',w:300,h:240,font:'Tahoma',size:24,color:'#222222',bg:'#fffdf9',align:'right'};}else copy={id:uid(),type:source.type,src:source.src,w:300,h:240,text:'',fit:'contain'};}else{copy=clone(source);copy.id=uid();}copy.x=Math.max(0,Math.min(1100-copy.w,contextPoint.x));copy.y=Math.max(0,contextPoint.y);state.items.push(copy);selected=copy.id;if(autoFlow){const near=nearestCard(copy.x,copy.y,copy.id);if(near){dropTarget={id:near.id,after:true};requestedFlow=true;packCards();}}canvas.style.height=Math.max(canvas.offsetHeight,copy.y+copy.h+50)+'px';changed();render();libraryDialog.close();};}const del=document.createElement('button');del.textContent='حذف نهائي';del.style.color='#a02222';del.onclick=()=>{if(!confirm('حذف هذا العنصر نهائيًا من المكتبة؟ النسخ الموجودة في الصفحة لن تُحذف. يمكن التراجع أثناء هذه الجلسة فقط.'))return;checkpoint();const collection=libraryTab==='archive'?state.archive:state.savedElements.includes(source)?state.savedElements:state.media;const idx=collection.indexOf(source);if(idx>=0)collection.splice(idx,1);changed();library();};row.append(del);});};document.getElementById('library').onclick=()=>library();
    document.querySelector('header strong').textContent='Élan Scents · النسخة 10 — المواضع والمكتبة';
    // Two scoped fixes: automatic insertion/flow and media filling its frame.
    let insertPending=false;
    function isFlowElement(i){return ['card','section','image','video'].includes(i.type);}
    function reflowAt(id,point){const moving=state.items.find(i=>i.id===id);if(!moving||!isFlowElement(moving))return;const others=state.items.filter(i=>isFlowElement(i)&&i.id!==id).sort((a,b)=>a.y-b.y||a.x-b.x);let index=others.filter(i=>i.y<moving.y||(i.y===moving.y&&i.x<moving.x)).length;if(point&&others.length){let best=Infinity,nearestIndex=0;others.forEach((i,n)=>{const distance=Math.hypot(point.x-(i.x+i.w/2),point.y-(i.y+i.h/2));if(distance<best){best=distance;nearestIndex=n;}});const target=others[nearestIndex];index=nearestIndex+((point.y>target.y+target.h*.75)||(point.y>=target.y&&point.x>target.x+target.w/2)?1:0);}const top=others.length?Math.max(0,Math.min(...others.map(i=>i.y))):Math.max(0,moving.y);others.splice(index,0,moving);let x=40,y=top,rowH=0;others.forEach(i=>{const oldX=i.x,oldY=i.y;i.w=Math.max(40,Math.min(1020,i.w));if(x+i.w>1060){x=40;y+=rowH+24;rowH=0;}i.x=x;i.y=y;state.items.filter(t=>t.overlayOf===i.id).forEach(t=>{t.x+=i.x-oldX;t.y+=i.y-oldY;});x+=i.w+24;rowH=Math.max(rowH,i.h);});canvas.style.height=Math.max(900,y+rowH+60)+'px';dropTarget=null;requestedFlow=false;changed();render();}
    function scheduleInsertion(){if(insertPending)return;insertPending=true;queueMicrotask(()=>{insertPending=false;const i=current();if(i&&isFlowElement(i))reflowAt(i.id,{...contextPoint});});}
    const insertionAdd=add;add=function(type,src){insertionAdd(type,src);if(isFlowElement(current()||{}))scheduleInsertion();};const insertionKind=addKind;addKind=function(kind){insertionKind(kind);scheduleInsertion();};
    let lastDrag=null;canvas.addEventListener('pointerdown',e=>{const el=e.target.closest('.item');if(!el)return;const i=state.items.find(i=>i.id===el.dataset.id);if(i&&isFlowElement(i)){lastDrag={id:i.id,x:e.clientX,y:e.clientY,resize:e.target.classList.contains('handle')};}},true);canvas.addEventListener('pointerup',e=>{if(!lastDrag)return;const drag=lastDrag;lastDrag=null;const distance=Math.hypot(e.clientX-drag.x,e.clientY-drag.y);if(distance<4)return;const rect=canvas.getBoundingClientRect();const point={x:e.clientX-rect.left,y:e.clientY-rect.top};queueMicrotask(()=>{if(state.items.some(i=>i.id===drag.id)){selected=drag.id;reflowAt(drag.id,drag.resize?null:point);}});},true);canvas.addEventListener('pointercancel',()=>lastDrag=null,true);
    const fillRender=render;render=function(){fillRender();state.items.forEach(i=>{const el=Array.from(canvas.children).find(e=>e.dataset.id===i.id);if(!el)return;el.querySelectorAll('img,video').forEach(media=>{media.style.objectFit='cover';media.style.objectPosition='center';media.style.width='100%';media.style.height='100%';media.style.display='block';});});};
    document.querySelector('header strong').textContent='Élan Scents · النسخة 11 — الإزاحة وملء الميديا';
    // Menu-only cleanup; automatic arrangement remains enabled.
    autoFlow=true;
    const menuBeforeFinalCleanup=showMenu;
    showMenu=function(e){autoFlow=true;menuBeforeFinalCleanup(e);Array.from(menu.children).forEach(b=>{const label=b.textContent.trim();if(label==='تكبير الخط +'||label==='تصغير الخط −'||label.startsWith('الترتيب التلقائي:'))b.remove();});const r=menu.getBoundingClientRect();menu.style.top=Math.max(4,Math.min(e.clientY,innerHeight-r.height-8))+'px';};
    document.querySelector('header strong').textContent='Élan Scents · النسخة 12';
    // Fit the complete media without cropping or distorting it.
    const completeMediaRender=render;
    render=function(){completeMediaRender();state.items.forEach(i=>{const el=Array.from(canvas.children).find(e=>e.dataset.id===i.id);if(!el)return;el.querySelectorAll('img,video').forEach(media=>{media.style.objectFit='contain';media.style.objectPosition='center';media.style.width='100%';media.style.height='100%';media.style.display='block';});});};
    const headerStyle=document.createElement('style');headerStyle.textContent='header{height:auto;min-height:82px;background:linear-gradient(110deg,#151515,#24211c);border-bottom:1px solid #b99755;box-shadow:0 4px 18px rgba(0,0,0,.16);padding:13px 26px;gap:10px;flex-wrap:wrap}header strong{display:flex;flex-direction:column;min-width:160px;margin-left:auto;line-height:1.15}header .brandName{font-family:Georgia,serif;font-size:30px;letter-spacing:.4px;color:#e7c779;text-shadow:0 1px 0 #6b4d16,0 2px 5px #0005}header .brandName .scents{font-size:23px;color:#f3ead9;font-weight:400}header .brandCaption{font:10px Arial,sans-serif;letter-spacing:2px;color:#c6b796;margin-top:7px}header button{background:#302b23;border:1px solid #685b41;color:#efe4cc;border-radius:10px;min-height:42px;padding:10px 15px;display:flex;align-items:center;gap:8px;box-shadow:inset 0 1px 0 #ffffff0d;transition:background .15s,border-color .15s}header button:hover:not(:disabled){background:#463a27;border-color:#c7a663}header button:disabled{opacity:.35}header #save{background:#d4b76e;color:#211d15;border-color:#dfc88e;font-weight:bold}header #save:hover{background:#e2c983}header #status{font-size:11px;color:#cabfa9;border-right:1px solid #65583f;padding-right:12px;max-width:190px;line-height:1.7}#viewport{height:calc(100vh - 100px)}@media(max-width:600px){header{padding:10px;gap:6px}header strong{width:100%;align-items:center;margin-bottom:5px}header button{padding:8px 10px;flex:1;justify-content:center}header #status{max-width:none;width:100%;text-align:center;border:0}#viewport{height:calc(100vh - 170px)}}';document.head.append(headerStyle);
    const logo=document.querySelector('header strong');logo.replaceChildren();const brand=document.createElement('span');brand.className='brandName';brand.dir='ltr';brand.append('Élan ');const scents=document.createElement('span');scents.className='scents';scents.textContent='Scents';brand.append(scents);const caption=document.createElement('span');caption.className='brandCaption';caption.dir='ltr';caption.textContent='VISUAL EDITOR · 13';logo.append(brand,caption);
    [['undo','↶','تراجع'],['redo','↷','إعادة'],['save','✓','حفظ'],['library','▦','المكتبة']].forEach(([id,icon,label])=>{const button=document.getElementById(id);button.replaceChildren();const mark=document.createElement('span');mark.textContent=icon;mark.style.fontSize='19px';mark.setAttribute('aria-hidden','true');const text=document.createElement('span');text.textContent=label;button.append(mark,text);button.title=label;});
    // Stretch media to exactly match the element's width and height.
    const exactFillStyle=document.createElement('style');exactFillStyle.textContent='#status{display:none!important}.item img,.item video{object-fit:fill!important;object-position:center!important;width:100%!important;height:100%!important;max-width:none!important;max-height:none!important}.item.image .content,.item.video .content{padding:0!important}';document.head.append(exactFillStyle);
    const beforeExactFill=render;render=function(){beforeExactFill();state.items.forEach(i=>{const el=Array.from(canvas.children).find(e=>e.dataset.id===i.id);if(!el)return;el.querySelectorAll('img,video').forEach(media=>{media.style.setProperty('object-fit','fill','important');media.style.setProperty('width','100%','important');media.style.setProperty('height','100%','important');if(i.borderShape!=='circle')media.style.clipPath='none';});});};
    caption.textContent='VISUAL EDITOR · 14';
    // Enable keyboard text editing for sections without synthetic double-clicks.
    const beforeSectionTextMenu=showMenu;
    showMenu=function(e){beforeSectionTextMenu(e);const item=current();const button=Array.from(menu.children).find(b=>b.textContent==='تعديل النص بالكيبورد');if(button){button.disabled=!item||!['text','card','section'].includes(item.type);button.onclick=()=>{menu.style.display='none';const target=current();if(!target||!['text','card','section'].includes(target.type))return;const el=Array.from(canvas.children).find(node=>node.dataset.id===target.id);const content=el?.querySelector('.content');if(!content)return;checkpoint();editing=true;el.classList.add('editing');content.contentEditable='plaintext-only';content.focus();const range=document.createRange();range.selectNodeContents(content);range.collapse(false);const selection=window.getSelection();selection.removeAllRanges();selection.addRange(range);};}};
    caption.textContent='VISUAL EDITOR · 15';
    // Elan domain definitions: declarative bindings, not a live database connection.
    const elanElementDefinitions={
    version:1,
    rules:{priceSource:'store_catalog',availabilitySource:'store_catalog',officialBrandContentOnly:true,neverUseBrandPrice:true,externalBrandStoreLinksVisible:false,oneCardPerProductSize:true,compareSameSizeConcentrationEditionPackaging:true,requireVerifiedAvailableOffer:true,priceOrder:['price ASC','commission_rate DESC','priority_rank ASC'],unknownQuantityIsNotZero:true,noAutomaticSplit:true,noVendorSwitchForInsufficientRequestedQuantity:true,comingSoonNotPurchasable:true},
    initialBrands:['AMOUAGE','ARMAF','AFNAN','ASAF','RASASI','FRENCH AVENUE','ARABIYAT PRESTIGE','LATTAFA','Maison Alhambra'],
    elements:{
    section:{label:'سيكشن',source:['public_products','cheapest_offers'],fields:['name','purpose','filter','preview_limit'],behavior:'Dynamic query by approved purpose; display only matching available perfumes with unified cards; coming soon is a separately labeled exception.'},
    perfume:{label:'كارت عطر',source:['products','product_sizes','cheapest_offers'],fields:['product_id','product_size_id','name','image','brand','store','category','price','short_description','occasions','notes','availability','quantity','last_synced_at'],behavior:'One card per exact product variant and size. Verified lowest eligible store offer. Details and cart actions use bound IDs; unavailable data stays empty, not fabricated.'},
    brand:{label:'كارت براند',source:['brands','public_products','cheapest_offers'],fields:['brand_id','name','official_logo_url'],behavior:'Original official logo without cropping; only this brand perfumes available at participating stores.'},
    store:{label:'كارت متجر',source:['stores','store_products'],fields:['store_id','name','logo_url','image_url','short_description','status'],behavior:'Separate seller catalogue restricted to approved brands. Show this seller actual price and stock, never attribute another seller price. New seller remains pending integration.'},
    occasion:{label:'كارت مناسبة',source:['occasions','product_occasions','public_products','cheapest_offers'],fields:['occasion_id','name','image_url'],behavior:'Only verified linked products. A new name does not imply automatic fragrance classification.'},
    note:{label:'كارت نوتة عطرية',source:['aromatic_notes','product_notes','public_products','cheapest_offers'],fields:['note_id','name','image_url'],behavior:'Only matching verified product-note relations; preserve official content provenance.'},
    banner:{label:'بانر',source:['editor_content'],fields:['name','media','alt_text','optional_internal_target'],behavior:'Editorial image/video; no invented commercial data.'},
    text:{label:'نص',source:['editor_content','marketing_phrases'],fields:['text','font','color','background','size'],behavior:'Overlay text; only assigned marketing wording, no unsupported claims.'},
    text_block:{label:'كتلة نصية',source:['editor_content','marketing_phrases'],fields:['text','font','color','background','size'],behavior:'Flow block, not overlay; occupies layout space and displaces neighbouring elements.'}
    }};
    function definitionKind(item){if(item.kind==='text_block')return 'text_block';if(['brand','store','perfume','occasion','note','banner'].includes(item.kind))return item.kind;if(item.type==='section')return 'section';if(item.type==='text')return 'text';if(item.type==='card')return 'perfume';return null;}
    function attachDefinition(item){const kind=definitionKind(item);if(!kind)return;item.definitionKey=kind;item.definitionVersion=1;if(!item.binding)item.binding={status:['text','text_block','banner'].includes(kind)?'editorial':'not_connected',entityId:null,productSizeId:null,name:'',purpose:null};}
    state.elementDefinitions=clone(elanElementDefinitions);state.items.forEach(attachDefinition);
    const definitionDialog=document.createElement('dialog');definitionDialog.style.width='470px';document.body.append(definitionDialog);
    function configureDefinition(){const item=current();if(!item)return;attachDefinition(item);const def=elanElementDefinitions.elements[item.definitionKey];if(!def)return;definitionDialog.replaceChildren();const h=document.createElement('h3');h.textContent='تعريف '+def.label;definitionDialog.append(h);const fields={};function input(label,key,value){const l=document.createElement('label');l.textContent=label;const i=document.createElement('input');i.value=value||'';i.style.cssText='display:block;width:100%;margin-top:6px';l.append(i);definitionDialog.append(l);fields[key]=i;}
    input('اسم العنصر أو السجل المطلوب','name',item.binding.name);if(!['text','text_block','banner','section'].includes(item.definitionKey)){input('معرّف السجل في سابابيس، اختياري الآن','entityId',item.binding.entityId);fields.entityId.dir='ltr';}if(item.definitionKey==='perfume'){input('معرّف حجم العطر، اختياري الآن','productSizeId',item.binding.productSizeId);fields.productSizeId.dir='ltr';}
    let purpose=null;if(item.definitionKey==='section'){const l=document.createElement('label');l.textContent='غرض السيكشن';purpose=document.createElement('select');[['available','سحر الخليج، العطور المتاحة'],['brands','البراندات'],['offers','العروض والخصومات'],['new_arrivals','وصل حديثًا وفق إعلان المتجر'],['masterpieces','المختارات بمؤشرات موثقة'],['categories','الفئات'],['occasions','المناسبات'],['notes','النوتات'],['coming_soon','مرتقب وصولها، غير قابلة للشراء'],['stores','المتاجر'],['about','عن إيلان'],['contact','التواصل'],['custom','غرض مخصص يحتاج قاعدة بيانات معتمدة']].forEach(([value,label])=>{const o=document.createElement('option');o.value=value;o.textContent=label;purpose.append(o);});purpose.value=item.binding.purpose||'available';l.append(purpose);definitionDialog.append(l);}
    const note=document.createElement('small');note.textContent='تعريف محفوظ داخل التصميم لتجهيز الربط. لا يتم جلب بيانات أو إنشاء سجل في سابابيس من هذه النسخة. ربط الاسم وحده لا يكفي، ويحتاج معرّفًا وقاعدة عرض.';definitionDialog.append(note);const save=document.createElement('button');save.textContent='حفظ التعريف';save.onclick=()=>{const uuid=/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;for(const key of ['entityId','productSizeId'])if(fields[key]?.value.trim()&&!uuid.test(fields[key].value.trim())){alert('معرّف السجل يجب أن يكون UUID صحيحًا، أو اتركه فارغًا.');return;}checkpoint();Object.entries(fields).forEach(([key,value])=>item.binding[key]=value.value.trim()||null);if(purpose)item.binding.purpose=purpose.value;if(item.binding.name&&!['text','text_block'].includes(item.definitionKey))item.text=item.binding.name;changed();render();definitionDialog.close();};const close=document.createElement('button');close.textContent='إغلاق';close.onclick=()=>definitionDialog.close();definitionDialog.append(save,close);definitionDialog.showModal();}
    const kindsBeforeDefinition=addKind;addKind=function(kind){kindsBeforeDefinition(kind);const item=current();if(!item)return;if(kind==='occasion'){item.text='اسم المناسبة';item.kind='occasion';}if(kind==='note'){item.text='اسم النوتة العطرية';item.kind='note';}attachDefinition(item);render();};
    function createTextBlock(){add('text');const item=current();item.kind='text_block';item.z=1;item.transparent=false;delete item.overlayOf;item.w=450;item.h=150;item.text='كتلة نصية جديدة';attachDefinition(item);changed();render();scheduleInsertion();}
    isFlowElement=function(item){return ['card','section','image','video'].includes(item.type)||item.kind==='text_block';};cardOrder=function(){return state.items.filter(isFlowElement).sort((a,b)=>a.y-b.y||a.x-b.x);};
    const renderWithDefinitions=render;render=function(){state.elementDefinitions=clone(elanElementDefinitions);state.items.forEach(attachDefinition);renderWithDefinitions();state.items.filter(i=>i.kind==='text_block').forEach(i=>{const el=Array.from(canvas.children).find(el=>el.dataset.id===i.id);if(el){el.style.zIndex='1';el.dataset.layout='flow';}});};
    const menuWithDefinitions=showMenu;showMenu=function(e){menuWithDefinitions(e);const added=[];function extra(label,fn){action(label,fn);added.push(menu.lastElementChild);}extra('إنشاء مناسبة',()=>addKind('occasion'));extra('إنشاء نوتة عطر',()=>addKind('note'));extra('إنشاء كتلة نصية',createTextBlock);const anchor=Array.from(menu.children).find(b=>b.textContent==='إنشاء كارت عطر');if(anchor){let after=anchor;added.forEach(b=>{after.after(b);after=b;});}action('تعريف العنصر ومصدر بياناته',configureDefinition,!!current()&&!!definitionKind(current()));const r=menu.getBoundingClientRect();menu.style.top=Math.max(4,Math.min(e.clientY,innerHeight-r.height-8))+'px';};
    const categoryBeforeDefinition=itemCategory;itemCategory=function(item){if(['occasion','note','text_block'].includes(item.kind))return item.kind;return categoryBeforeDefinition(item);};categoryDefinitions.push(['occasion','مناسبة'],['note','نوتة عطرية'],['text_block','كتلة نصية']);
    caption.textContent='VISUAL EDITOR · 17';
    // Final element data contract: only names, fields, relations and rules supplied by the merchant.
    const suppliedSchema={
    tables:{
    brands:['id','name','slug','official_logo_url','description','official_website_url','is_active','created_at','updated_at'],
    stores:['id','name','slug','logo_url','image_url','short_description','website_url','status','commission_rate','priority_rank','created_at','updated_at'],
    store_accounts:['id','store_id','user_id','role','created_at'],
    aromatic_notes:['id','name','image_url','created_at','updated_at'],categories:['id','name','image_url','created_at','updated_at'],occasions:['id','name','image_url','created_at','updated_at'],
    products:['id','brand_id','name','slug','short_description','official_description','composition','gender','notes_source','content_source','status','meta_title','meta_description','is_active','created_at','updated_at'],
    product_sizes:['id','product_id','size_ml','size_label','sku','created_at','updated_at'],
    product_images:['id','product_id','product_size_id','image_url','alt_text','sort_order','is_primary','created_at'],
    product_notes:['product_id','note_id'],product_categories:['product_id','category_id'],product_occasions:['product_id','occasion_id'],
    store_products:['id','store_id','product_size_id','price','original_price','discount_percentage','stock_quantity','is_available','is_new_arrival','is_coming_soon','price_includes_tax','price_includes_shipping','currency','data_source','sync_status','last_synced_at','created_at','updated_at'],
    offers:['id','store_id','product_size_id','title','description','discount_type','discount_value','start_date','end_date','is_active','created_at','updated_at'],
    product_stats:['product_id','views_count','sales_count','search_count','request_count','average_rating','reviews_count','updated_at'],
    reviews:['id','user_id','product_id','rating','comment','is_approved','created_at','updated_at'],
    profiles:['id','full_name','phone','avatar_url','role','created_at','updated_at'],
    favorites:['id','user_id','product_id','created_at'],cart_items:['id','user_id','store_product_id','quantity','created_at','updated_at'],
    orders:['id','user_id','status','subtotal','tax_amount','shipping_amount','total_amount','created_at','updated_at'],order_items:['id','order_id','store_product_id','quantity','price_at_time','created_at'],
    commissions:['id','store_id','order_item_id','rate','amount','status','created_at','updated_at'],contact_messages:['id','name','email','phone','message','is_read','created_at'],notifications:['id','user_id','title','body','is_read','created_at'],
    marketing_phrases:['id','phrase_ar','phrase_en','category','is_public','usage_scope','created_at'],media_library:['id','file_url','file_type','source','alt_text','linked_entity_type','linked_entity_id','is_approved','created_at'],analytics_events:['id','event_type','product_id','product_size_id','user_id','metadata','created_at'],site_settings:['key','value','updated_at'],sync_logs:['id','store_id','status','message','records_count','created_at']},
    relations:{'products.brand_id':'brands.id','product_sizes.product_id':'products.id','product_images.product_id':'products.id','product_images.product_size_id':'product_sizes.id','product_notes.product_id':'products.id','product_notes.note_id':'aromatic_notes.id','product_categories.product_id':'products.id','product_categories.category_id':'categories.id','product_occasions.product_id':'products.id','product_occasions.occasion_id':'occasions.id','store_products.store_id':'stores.id','store_products.product_size_id':'product_sizes.id','offers.store_id':'stores.id','offers.product_size_id':'product_sizes.id','product_stats.product_id':'products.id','store_accounts.store_id':'stores.id','store_accounts.user_id':'auth.users.id','profiles.id':'auth.users.id','reviews.user_id':'profiles.id','reviews.product_id':'products.id','favorites.user_id':'profiles.id','favorites.product_id':'products.id','cart_items.user_id':'profiles.id','cart_items.store_product_id':'store_products.id','orders.user_id':'profiles.id','order_items.order_id':'orders.id','order_items.store_product_id':'store_products.id','commissions.store_id':'stores.id','commissions.order_item_id':'order_items.id','notifications.user_id':'profiles.id'},
    views:{cheapest_offers:{per:'product_size_id',conditions:['is_available = true','stock_quantity > 0','sync_status = synced'],order:['price ASC','commission_rate DESC','priority_rank ASC'],columns:['product_size_id','product_id','brand_id','store_id','store_name','price','stock_quantity','currency','price_includes_tax','price_includes_shipping','last_synced_at']},public_products:{conditions:['published products','at least one offer in cheapest_offers'],usage:'The only product visibility rule for cards, sections and search',columns:'not specified in supplied schema'}},
    rules:{priceAvailabilityQuantityOffersNewArrivalBestSellingSource:'store_catalog',descriptionCompositionNotesOfficialContentSupplementSource:'brand_official',brandWebsitePriceProhibited:true,brandStoreWebsiteLinksHidden:true,atLeastOneAvailableStoreRequired:true,eachSizeIndependent:true,compareDifferentSizesProhibited:true,oneCardPerProductAndSize:true,tieBreak:['commission_rate DESC','priority_rank ASC']},
    initial:{brands:['AMOUAGE','ARMAF','AFNAN','ASAF','RASASI','FRENCH AVENUE','ARABIYAT PRESTIGE','LATTAFA','Maison Alhambra'],stores:[{name:'Afnan Egypt',website_url:'egypt.afnan.com'},{name:'Emarati Scents',website_url:'emaratiscents.com'}],notes:['عنبري','حمضي','خشبي','عود','هيل'],categories:['رجالي','نسائي','عطر يجمعنا'],occasions:['نهاري','ليلي','عمل','موعد','هدية'],site_settings:['contact_email','instagram_url','tiktok_url','pinterest_url','footer_tagline','developer_credit','whatsapp_number']},
    security:{rlsAllTables:true,publicRead:'available products, brands, stores, offers and prices only',ownUserWrites:['favorites','cart_items','orders','reviews','contact_messages'],storeAccounts:'own store catalogue only',platform_admin:'full access'},
    connection:'not_connected',origin:'merchant supplied schema specification, not live database inspection'};
    function schemaElement(label,table,related,extra){return {label,table,fields:table?clone(suppliedSchema.tables[table]):[],relatedTables:related||[],...extra};}
    elanElementDefinitions.version=3;elanElementDefinitions.rules=clone(suppliedSchema.rules);elanElementDefinitions.schema=clone(suppliedSchema);
    elanElementDefinitions.elements={
    section:schemaElement('سيكشن',null,[],{schemaDefinition:'No independent section table or layout fields specified.',productVisibilityView:'public_products'}),
    perfume:schemaElement('كارت عطر','products',['product_sizes','product_images','brands','stores','store_products','product_notes','aromatic_notes','product_categories','categories','product_occasions','occasions'],{sizeKey:'product_sizes.id',offerView:'cheapest_offers',productVisibilityView:'public_products',cardUniqueness:'same product and same size'}),
    brand:schemaElement('كارت براند','brands',['products','product_sizes','store_products','stores'],{hiddenFields:['official_website_url'],productVisibilityView:'public_products',offerView:'cheapest_offers'}),
    store:schemaElement('كارت متجر','stores',['store_products','product_sizes','products','brands'],{hiddenFields:['website_url'],productVisibilityView:'public_products',offerView:'cheapest_offers'}),
    occasion:schemaElement('كارت مناسبة','occasions',['product_occasions','products','product_sizes'],{relation:'product_occasions.occasion_id -> occasions.id; product_occasions.product_id -> products.id',productVisibilityView:'public_products',offerView:'cheapest_offers'}),
    note:schemaElement('كارت نوتة عطرية','aromatic_notes',['product_notes','products','product_sizes'],{relation:'product_notes.note_id -> aromatic_notes.id; product_notes.product_id -> products.id',productVisibilityView:'public_products',offerView:'cheapest_offers'}),
    banner:schemaElement('بانر',null,['media_library'],{schemaDefinition:'No independent banner table or behavior specified.'}),
    text:schemaElement('نص',null,['marketing_phrases'],{schemaDefinition:'No independent editor text table specified.'}),
    text_block:schemaElement('كتلة نصية',null,['marketing_phrases'],{schemaDefinition:'No independent text-block table specified.',editorLayout:'flow as requested by merchant'})};
    const beforeExactDefinition=attachDefinition;attachDefinition=function(item){beforeExactDefinition(item);if(!item.definitionKey)return;const def=elanElementDefinitions.elements[item.definitionKey];item.definitionVersion=3;item.dataDefinition={kind:item.definitionKey,table:def.table,fields:clone(def.fields),relatedTables:clone(def.relatedTables),contract:clone(def),rules:clone(suppliedSchema.rules)};};
    state.items.forEach(attachDefinition);
    // No purpose/filter implementation is inferred from the schema.
    configureDefinition=function(){const item=current();if(!item)return;attachDefinition(item);definitionDialog.replaceChildren();const def=elanElementDefinitions.elements[item.definitionKey];const h=document.createElement('h3');h.textContent='تعريف '+def.label;definitionDialog.append(h);const l=document.createElement('label');l.textContent='اسم العنصر';const name=document.createElement('input');name.value=item.binding.name||'';l.append(name);definitionDialog.append(l);const identity=document.createElement('input');if(def.table){const label=document.createElement('label');label.textContent='معرّف السجل، يحدد عند الربط';identity.value=item.binding.entityId||'';identity.dir='ltr';label.append(identity);definitionDialog.append(label);}const note=document.createElement('p');note.textContent=def.table?'مصدر التعريف: '+def.table:'الشّيما لا تحدد جدولًا مستقلًا لهذا العنصر؛ لا يتم افتراض جدول جديد.';definitionDialog.append(note);const save=document.createElement('button');save.textContent='حفظ';save.onclick=()=>{if(identity.value.trim()&&!/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(identity.value.trim())){alert('اكتب UUID أو اترك المعرّف فارغًا.');return;}checkpoint();item.binding.name=name.value.trim()||null;if(def.table)item.binding.entityId=identity.value.trim()||null;if(item.binding.name&&!['text','text_block'].includes(item.definitionKey))item.text=item.binding.name;attachDefinition(item);changed();render();definitionDialog.close();};const close=document.createElement('button');close.textContent='إغلاق';close.onclick=()=>definitionDialog.close();definitionDialog.append(save,close);definitionDialog.showModal();};
    const exactSchemaSave=document.getElementById('save').onclick;document.getElementById('save').onclick=()=>{state.elementDefinitions=clone(elanElementDefinitions);state.items.forEach(attachDefinition);exactSchemaSave();};
    caption.textContent='VISUAL EDITOR · SCHEMA FINAL';
    render();
    
    </script><script>
    // Section campaign extension. No remote connection or fake catalogue.
    const sectionPanel=document.createElement('dialog');sectionPanel.style.cssText='width:650px;max-height:90vh';document.body.append(sectionPanel);
    function localCairo(iso){if(!iso)return '';const p=Object.fromEntries(new Intl.DateTimeFormat('en-GB',{timeZone:'Africa/Cairo',year:'numeric',month:'2-digit',day:'2-digit',hour:'2-digit',minute:'2-digit',hourCycle:'h23'}).formatToParts(new Date(iso)).filter(p=>p.type!=='literal').map(p=>[p.type,p.value]));return `${p.year}-${p.month}-${p.day}T${p.hour}:${p.minute}`;}
    function cairoUTC(s){if(!s)return null;let t=Date.parse(s+'Z'),g=t;if(!Number.isFinite(t))throw Error('موعد غير صحيح');for(let n=0;n<4;n++){const shown=Date.parse(localCairo(new Date(g).toISOString())+'Z');g+=t-shown;}return new Date(g).toISOString();}
    function editSection(item){const old=item?.sectionConfig||{};sectionPanel.replaceChildren();const h=document.createElement('h3');h.textContent=item?'إعدادات السيكشن':'إنشاء سيكشن';sectionPanel.append(h);function field(title,type,value){const l=document.createElement('label');l.textContent=title;const i=document.createElement('input');i.type=type;i.value=value??'';i.style.cssText='display:block;width:100%;margin-top:5px';l.append(i);sectionPanel.append(l);return i;}function select(title,choices,value){const l=document.createElement('label');l.textContent=title;const s=document.createElement('select');choices.forEach(([v,t])=>{const o=document.createElement('option');o.value=v;o.textContent=t;s.append(o);});s.value=value;l.append(s);sectionPanel.append(l);return s;}
    const name=field('اسم السيكشن','text',old.name||item?.text||''),purpose=field('الغرض من السيكشن','text',old.purpose||'');const mode=select('اختيار العطور',[['manual','يدوي'],['automatic','تلقائي بالفلاتر']],old.selectionMode||'manual');const filters={};[['brand_id','البراند'],['store_id','المتجر'],['category_id','الفئة'],['occasion_id','المناسبة'],['note_id','النوتة'],['size_ml','الحجم بالمل'],['price_min','أقل سعر'],['price_max','أعلى سعر']].forEach(([key,title])=>{const number=['size_ml','price_min','price_max'].includes(key);filters[key]=field(title,number?'number':'text',old.filters?.[key]);if(!number)filters[key].placeholder='معرّف السجل؛ قائمة الأسماء بعد ربط سابابيس';else filters[key].min='0';});
    let picks=clone(old.manualProducts||[]);const add=document.createElement('button');add.textContent='إضافة عطر';const results=document.createElement('div'),chosen=document.createElement('div');function paint(){chosen.replaceChildren();picks.forEach((p,n)=>{const line=document.createElement('div');line.textContent=p.name+' — '+p.productSizeId;const b=document.createElement('button');b.textContent='إزالة';b.onclick=()=>{picks.splice(n,1);paint();};line.append(b);chosen.append(line);});}paint();add.onclick=()=>{results.replaceChildren();const available=state.items.filter(i=>i.kind==='perfume'&&i.binding?.entityId&&i.binding?.productSizeId);if(!available.length){results.textContent='لا يوجد كتالوج متصل. اختيار العطور بأسمائها وتطبيق الفلاتر على نتائج حقيقية يحتاج ربط سابابيس. لا نعرض بيانات وهمية.';return;}available.forEach(i=>{const b=document.createElement('button');b.textContent=i.binding.name||i.text;b.onclick=()=>{if(!picks.some(p=>p.productSizeId===i.binding.productSizeId))picks.push({productId:i.binding.entityId,productSizeId:i.binding.productSizeId,name:i.binding.name||i.text});paint();};results.append(b);});};sectionPanel.append(add,results,chosen);mode.onchange=()=>{add.hidden=mode.value!=='manual';chosen.hidden=mode.value!=='manual';results.replaceChildren();};mode.onchange();
    const label=document.createElement('label'),enabled=document.createElement('input');enabled.type='checkbox';enabled.checked=!!old.timer?.enabled;label.append(enabled,' تشغيل التوقيت');sectionPanel.append(label);const timing=select('طريقة التوقيت',[['dates','بداية ونهاية'],['duration','ساعات أو أيام من أول حفظ']],old.timer?.mode||'dates');const start=field('البداية، توقيت مصر','datetime-local',localCairo(old.timer?.startsAt)),end=field('النهاية، توقيت مصر','datetime-local',localCairo(old.timer?.endsAt)),count=field('عدد الساعات أو الأيام','number',old.timer?.durationValue||1);count.min='1';const unit=select('الوحدة',[['hours','ساعات'],['days','أيام']],old.timer?.durationUnit||'hours');function timingUI(){timing.closest('label').hidden=!enabled.checked;start.closest('label').hidden=end.closest('label').hidden=!enabled.checked||timing.value!=='dates';count.closest('label').hidden=unit.closest('label').hidden=!enabled.checked||timing.value!=='duration';}enabled.onchange=timingUI;timing.onchange=timingUI;timingUI();
    const note=document.createElement('small');note.textContent='هذه نسخة محلية: التعريفات جاهزة للربط، والتوقيت يعمل أثناء فتح المحرر وعند إعادة فتحه. البداية المستقبلية تظهر باهتة للمعاينة فقط.';sectionPanel.append(note);const save=document.createElement('button');save.textContent='حفظ السيكشن';save.onclick=()=>{try{if(!name.value.trim()||!purpose.value.trim())throw Error('اكتب الاسم والغرض.');const values={};Object.entries(filters).forEach(([key,i])=>{if(!i.value.trim())return;if(i.type==='number'){if(!Number.isFinite(Number(i.value))||Number(i.value)<0)throw Error('قيمة فلتر غير صحيحة');values[key]=Number(i.value);}else{if(!/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(i.value.trim()))throw Error('استخدم معرّف سجل صحيحًا أو اترك الفلتر فارغًا.');values[key]=i.value.trim();}});if(values.price_min!==undefined&&values.price_max!==undefined&&values.price_min>values.price_max)throw Error('أقل سعر أكبر من أعلى سعر.');const createdAt=old.createdAt||new Date().toISOString();const timer={enabled:enabled.checked,mode:timing.value,timeZone:'Africa/Cairo',durationValue:Number(count.value),durationUnit:unit.value,startsAt:null,endsAt:null};if(timer.enabled){if(timer.mode==='dates'){timer.startsAt=cairoUTC(start.value);timer.endsAt=cairoUTC(end.value);if(!timer.startsAt||!timer.endsAt||Date.parse(timer.endsAt)<=Date.parse(timer.startsAt))throw Error('حدد مواعيد صحيحة.');}else{if(!Number.isFinite(timer.durationValue)||timer.durationValue<=0)throw Error('حدد مدة أكبر من صفر');timer.startsAt=createdAt;timer.endsAt=new Date(Date.parse(createdAt)+timer.durationValue*(unit.value==='days'?86400000:3600000)).toISOString();}}checkpoint();let target=item;if(!target){windowSectionAdd();target=current();}target.text=name.value.trim();target.sectionConfig={name:name.value.trim(),purpose:purpose.value.trim(),selectionMode:mode.value,filters:values,manualProducts:picks,createdAt,timer,dataSource:{products:'public_products',offers:'cheapest_offers',connection:'not_connected'}};attachDefinition(target);target.binding.name=target.sectionConfig.name;target.binding.purpose=target.sectionConfig.purpose;selected=target.id;reflowAt(target.id,{...contextPoint});changed();document.getElementById('save').click();sectionPanel.close();checkSections();}catch(e){alert(e.message);}};const close=document.createElement('button');close.textContent='إلغاء';close.onclick=()=>sectionPanel.close();sectionPanel.append(save,close);sectionPanel.showModal();}
    function windowSectionAdd(){add('section');const i=current();i.w=450;i.h=220;i.z=1;}
    const sectionMenuBase=showMenu;showMenu=function(e){sectionMenuBase(e);const b=Array.from(menu.children).find(b=>b.textContent==='إنشاء سيكشن');if(b)b.onclick=()=>{menu.style.display='none';editSection(null);};action('إعدادات السيكشن',()=>editSection(current()),current()?.type==='section');};
    function checkSections(){const now=Date.now();const expired=state.items.filter(i=>i.sectionConfig?.timer?.enabled&&i.sectionConfig.timer.endsAt&&Date.parse(i.sectionConfig.timer.endsAt)<=now);if(expired.length){checkpoint();expired.forEach(i=>{const copy=clone(i);copy.sectionConfig.lastTimer=clone(copy.sectionConfig.timer);copy.sectionConfig.timer.enabled=false;copy.sectionConfig.archivedAt=new Date().toISOString();state.archive.push(copy);});const ids=new Set(expired.map(i=>i.id));state.items=state.items.filter(i=>!ids.has(i.id));const first=state.items.find(isFlowElement);if(first)reflowAt(first.id,null);changed();render();document.getElementById('save').click();}canvas.querySelectorAll('.item').forEach(el=>{const timer=state.items.find(i=>i.id===el.dataset.id)?.sectionConfig?.timer;el.style.opacity=timer?.enabled&&timer.startsAt&&Date.parse(timer.startsAt)>now?'0.45':'';});}
    setInterval(checkSections,1000);caption.textContent='VISUAL EDITOR · SECTION CAMPAIGN';checkSections();
    
    
    </script><script>
    // Clean section panel. Integration supplies a real, authenticated data provider.
    // window.elanSectionDataProvider.getOptions() -> {brands,stores,categories,occasions,notes,sizes}
    // Each option: {id,name}; sizes: {size_ml,name}.
    // getPerfumes(filters) -> [{product_id,product_size_id,name,size_label}]
    // Provider must apply public_products/cheapest_offers and all supplied schema restrictions.
    const cleanSectionStyle=document.createElement('style');cleanSectionStyle.textContent='.sectionPanelClean{width:760px;max-width:95vw;background:#fffdf8;color:#28251e;padding:22px}.sectionPanelClean h3{margin:0 0 18px;color:#866329}.sectionPanelClean .sectionGrid{display:grid;grid-template-columns:1fr 1fr;gap:12px}.sectionPanelClean .filterGrid{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:10px}.sectionPanelClean label{margin:0;display:flex;flex-direction:column;gap:6px;font-size:13px}.sectionPanelClean input,.sectionPanelClean select{width:100%;min-width:0;background:white;min-height:38px}.sectionPanelClean fieldset{margin:15px 0;padding:14px;border:1px solid #e0d0af;border-radius:12px}.sectionPanelClean legend{font-weight:bold;color:#8c6830;padding:0 7px}.sectionPanelClean .perfumeRow{display:grid;grid-template-columns:1fr auto;gap:10px;align-items:end;margin:12px 0}.sectionPanelClean .selectionList{display:grid;gap:7px;margin-top:12px}.sectionPanelClean .chosenPerfume{display:flex;align-items:center;gap:10px;border:1px solid #e4d7be;background:white;border-radius:8px;padding:9px;font-size:13px}.sectionPanelClean .chosenPerfume span{flex:1}.sectionPanelClean .notice{font-size:12px;color:#716344;line-height:1.7;padding:9px 0;background:none}.sectionPanelClean .actions{display:flex;gap:10px;margin-top:16px}.sectionPanelClean .actions button{flex:1}.sectionPanelClean .primary{background:#28241e;color:#efdeb8}.sectionPanelClean .toggle{display:flex;flex-direction:row;align-items:center;gap:8px}.sectionPanelClean .toggle input{width:auto;min-height:0}@media(max-width:560px){.sectionPanelClean .filterGrid{grid-template-columns:1fr 1fr}.sectionPanelClean{padding:14px}.sectionPanelClean .sectionGrid{grid-template-columns:1fr}}';document.head.append(cleanSectionStyle);
    editSection=function(item){const old=item?.sectionConfig||{};sectionPanel.replaceChildren();sectionPanel.className='sectionPanelClean';sectionPanel.style.width='760px';const heading=document.createElement('h3');heading.textContent=item?'إعدادات السيكشن':'إنشاء سيكشن';sectionPanel.append(heading);function inputField(parent,label,type,value){const l=document.createElement('label');l.textContent=label;const i=document.createElement('input');i.type=type;i.value=value??'';l.append(i);parent.append(l);return i;}function selectField(parent,label,options,value){const l=document.createElement('label');l.textContent=label;const s=document.createElement('select');options.forEach(([v,t])=>{const o=document.createElement('option');o.value=v;o.textContent=t;s.append(o);});s.value=value??'';l.append(s);parent.append(l);return s;}function fieldset(title){const f=document.createElement('fieldset');const l=document.createElement('legend');l.textContent=title;f.append(l);sectionPanel.append(f);return f;}
    const basics=document.createElement('div');basics.className='sectionGrid';sectionPanel.append(basics);const name=inputField(basics,'اسم السيكشن','text',old.name||item?.text||''),purpose=inputField(basics,'الغرض من السيكشن','text',old.purpose||'');const content=fieldset('اختيار العطور');const mode=selectField(content,'طريقة الاختيار',[['manual','اختيار عطور محددة'],['automatic','تلقائي حسب الفلاتر']],old.selectionMode||'manual');const grid=document.createElement('div');grid.className='filterGrid';content.append(grid);const controls={};const optionSpec=[['brand_id','البراند','brands'],['store_id','المتجر','stores'],['category_id','الفئة','categories'],['occasion_id','المناسبة','occasions'],['note_id','النوتة العطرية','notes'],['size_ml','الحجم','sizes']];optionSpec.forEach(([key,label])=>{const s=selectField(grid,label,[['','الكل']], '');s.disabled=true;controls[key]=s;});const min=inputField(grid,'السعر من','number',old.filters?.price_min),max=inputField(grid,'السعر إلى','number',old.filters?.price_max);min.min=max.min='0';const message=document.createElement('div');message.className='notice';content.append(message);const row=document.createElement('div');row.className='perfumeRow';content.append(row);const perfume=selectField(row,'العطر والحجم',[['','اختر العطر من نتائج الفلترة']], '');perfume.disabled=true;const addButton=document.createElement('button');addButton.textContent='إضافة';addButton.disabled=true;row.append(addButton);const selectedBox=document.createElement('div');selectedBox.className='selectionList';content.append(selectedBox);let picks=clone(old.manualProducts||[]),results=[],requestSerial=0;
    function paintPicks(){selectedBox.replaceChildren();picks.forEach((p,n)=>{const box=document.createElement('div');box.className='chosenPerfume';const span=document.createElement('span');span.textContent=p.name+(p.sizeLabel?' — '+p.sizeLabel:'');const b=document.createElement('button');b.textContent='إزالة';b.onclick=()=>{picks.splice(n,1);paintPicks();};box.append(span,b);selectedBox.append(box);});}paintPicks();
    function filters(){const result={};Object.entries(controls).forEach(([key,s])=>{if(s.value)result[key]=key==='size_ml'?Number(s.value):s.value;});if(min.value!=='')result.price_min=Number(min.value);if(max.value!=='')result.price_max=Number(max.value);return result;}
    async function refreshPerfumes(){const seq=++requestSerial;results=[];perfume.replaceChildren();const p=document.createElement('option');p.value='';p.textContent='جارٍ قراءة نتائج الفلترة…';perfume.append(p);perfume.disabled=true;addButton.disabled=true;const provider=window.elanSectionDataProvider;if(!provider?.getPerfumes){p.textContent='العطور متاحة بعد ربط سابابيس';message.textContent='القوائم مجهزة للاختيار بالأسماء. اتصال سابابيس غير منفّذ في هذا الملف، لذلك لا نعرض أسماء أو عطورًا وهمية.';return;}try{const f=filters();if((f.price_min!==undefined&&!Number.isFinite(f.price_min))||(f.price_max!==undefined&&!Number.isFinite(f.price_max))||(f.price_min!==undefined&&f.price_max!==undefined&&f.price_min>f.price_max))throw Error('راجع حدود السعر');const data=await provider.getPerfumes(f);if(seq!==requestSerial)return;if(!Array.isArray(data)||data.some(p=>!p.product_id||!p.product_size_id||!p.name))throw Error('بيانات نتائج غير متوافقة');results=data;perfume.replaceChildren();const empty=document.createElement('option');empty.value='';empty.textContent=results.length?'اختر العطر والحجم':'لا توجد عطور متاحة تطابق الفلاتر';perfume.append(empty);results.forEach((p,n)=>{const o=document.createElement('option');o.value=String(n);o.textContent=p.name+(p.size_label?' — '+p.size_label:'');perfume.append(o);});perfume.disabled=!results.length;message.textContent='عدد النتائج المتاحة: '+results.length;}catch(err){if(seq!==requestSerial)return;perfume.replaceChildren();const o=document.createElement('option');o.value='';o.textContent='تعذر تحميل العطور';perfume.append(o);message.textContent='تعذر قراءة النتائج؛ لم تُضف بيانات بديلة.';}}
    async function loadOptions(){const provider=window.elanSectionDataProvider;if(!provider?.getOptions){refreshPerfumes();return;}message.textContent='جارٍ تحميل قوائم سابابيس…';try{const data=await provider.getOptions();for(const [key,label,list]of optionSpec){if(!Array.isArray(data[list]))throw Error('قائمة ناقصة');const s=controls[key];s.replaceChildren();const all=document.createElement('option');all.value='';all.textContent='كل '+label;s.append(all);data[list].forEach(record=>{const id=key==='size_ml'?record.size_ml:record.id;if(id===undefined||id===null||!record.name)return;const o=document.createElement('option');o.value=String(id);o.textContent=record.name;s.append(o);});if(old.filters?.[key]!==undefined)s.value=String(old.filters[key]);s.disabled=false;s.onchange=refreshPerfumes;}refreshPerfumes();}catch(e){message.textContent='تعذر تحميل قوائم سابابيس. لن يتم تعويضها بقيم وهمية.';}}
    min.onchange=max.onchange=refreshPerfumes;perfume.onchange=()=>addButton.disabled=mode.value!=='manual'||perfume.value==='';addButton.onclick=()=>{const p=results[Number(perfume.value)];if(perfume.value===''||!p)return;if(!picks.some(i=>i.productSizeId===p.product_size_id)){picks.push({productId:p.product_id,productSizeId:p.product_size_id,name:p.name,sizeLabel:p.size_label||null});paintPicks();}};mode.onchange=()=>{row.hidden=mode.value==='automatic';selectedBox.hidden=mode.value==='automatic';addButton.disabled=mode.value!=='manual'||perfume.value==='';};mode.onchange();
    const timerBox=fieldset('توقيت السيكشن');const toggle=document.createElement('label');toggle.className='toggle';const enabled=document.createElement('input');enabled.type='checkbox';enabled.checked=!!old.timer?.enabled;toggle.append(enabled,'تشغيل التوقيت');timerBox.append(toggle);const timing=selectField(timerBox,'طريقة التوقيت',[['dates','بداية ونهاية محددتان'],['duration','مدة من أول حفظ للسيكشن']],old.timer?.mode||'dates');const dateGrid=document.createElement('div');dateGrid.className='sectionGrid';timerBox.append(dateGrid);const start=inputField(dateGrid,'البداية، توقيت مصر','datetime-local',localCairo(old.timer?.startsAt)),end=inputField(dateGrid,'النهاية، توقيت مصر','datetime-local',localCairo(old.timer?.endsAt));const durationGrid=document.createElement('div');durationGrid.className='sectionGrid';timerBox.append(durationGrid);const count=inputField(durationGrid,'المدة','number',old.timer?.durationValue||1);count.min='1';const unit=selectField(durationGrid,'الوحدة',[['hours','ساعات'],['days','أيام']],old.timer?.durationUnit||'hours');function timingUI(){timing.closest('label').hidden=!enabled.checked;dateGrid.hidden=!enabled.checked||timing.value!=='dates';durationGrid.hidden=!enabled.checked||timing.value!=='duration';}enabled.onchange=timingUI;timing.onchange=timingUI;timingUI();
    const actions=document.createElement('div');actions.className='actions';const save=document.createElement('button');save.className='primary';save.textContent='حفظ السيكشن';const close=document.createElement('button');close.textContent='إلغاء';close.onclick=()=>sectionPanel.close();actions.append(save,close);sectionPanel.append(actions);
    save.onclick=()=>{try{if(!name.value.trim()||!purpose.value.trim())throw Error('اكتب الاسم والغرض.');const providerReady=!!window.elanSectionDataProvider?.getOptions;const f=providerReady?filters():clone(old.filters||{});if((f.price_min!==undefined&&f.price_min<0)||(f.price_max!==undefined&&f.price_max<0)||(f.price_min!==undefined&&f.price_max!==undefined&&f.price_min>f.price_max))throw Error('راجع حدود السعر.');const createdAt=old.createdAt||new Date().toISOString();const timer={enabled:enabled.checked,mode:timing.value,timeZone:'Africa/Cairo',durationValue:Number(count.value),durationUnit:unit.value,startsAt:null,endsAt:null};if(timer.enabled){if(timer.mode==='dates'){timer.startsAt=cairoUTC(start.value);timer.endsAt=cairoUTC(end.value);if(!timer.startsAt||!timer.endsAt||Date.parse(timer.endsAt)<=Date.parse(timer.startsAt))throw Error('حدد مواعيد صحيحة.');}else{if(!Number.isFinite(timer.durationValue)||timer.durationValue<=0)throw Error('حدد مدة أكبر من صفر');timer.startsAt=createdAt;timer.endsAt=new Date(Date.parse(createdAt)+timer.durationValue*(unit.value==='days'?86400000:3600000)).toISOString();}}checkpoint();let target=item;if(!target){windowSectionAdd();target=current();}target.text=name.value.trim();target.sectionConfig={name:name.value.trim(),purpose:purpose.value.trim(),selectionMode:mode.value,filters:f,manualProducts:picks,createdAt,timer,dataSource:{products:'public_products',offers:'cheapest_offers',connection:providerReady?'provider_configured':'not_connected'}};attachDefinition(target);target.binding.name=target.sectionConfig.name;target.binding.purpose=target.sectionConfig.purpose;selected=target.id;reflowAt(target.id,{...contextPoint});changed();document.getElementById('save').click();sectionPanel.close();checkSections();}catch(e){alert(e.message);}};sectionPanel.showModal();loadOptions();};
    
    cleanSectionStyle.textContent += ".sectionPanelClean [hidden]{display:none!important}";
    
    </script><script>
    // Manual sidebar mirrors the real provider results; automatic mode retains all matching results.
    const selectionRepairStyle=document.createElement('style');selectionRepairStyle.textContent='.sectionPanelClean{width:1000px!important}.sectionPanelClean .manualLayout{display:grid;grid-template-columns:minmax(0,1fr) 270px;gap:14px}.sectionPanelClean .manualResults{border:1px solid #d7c29c;border-radius:12px;padding:12px;background:#fffaf0;max-height:420px;overflow:auto}.sectionPanelClean .manualResults h4{margin-top:0}.sectionPanelClean .manualResults label{display:flex;flex-direction:row;align-items:center;gap:8px;padding:9px 0;border-bottom:1px solid #e7ddc8}.sectionPanelClean .manualResults input{width:auto;min-height:0}.sectionPanelClean .modeHelp{font-size:12px;line-height:1.8;color:#756443;margin:8px 0}@media(max-width:700px){.sectionPanelClean .manualLayout{grid-template-columns:1fr}}';document.head.append(selectionRepairStyle);
    const sectionBeforeSelectionFix=editSection;
    editSection=function(item){sectionBeforeSelectionFix(item);const panel=sectionPanel;const content=Array.from(panel.querySelectorAll('fieldset')).find(f=>f.querySelector('legend')?.textContent==='اختيار العطور');if(!content)return;const mode=content.querySelector('select');const row=content.querySelector('.perfumeRow');const select=row.querySelector('select');const add=row.querySelector('button');const chosen=content.querySelector('.selectionList');const notice=content.querySelector('.notice');const grid=content.querySelector('.filterGrid');grid.querySelectorAll('select').forEach(s=>{s.disabled=false;s.title='قائمة الأسماء تأتي من سابابيس عند الربط';});
    const layout=document.createElement('div');layout.className='manualLayout';const main=document.createElement('div');const sidebar=document.createElement('div');sidebar.className='manualResults';content.append(layout);layout.append(main,sidebar);main.append(grid,notice,chosen);row.hidden=true;row.style.display='none';main.append(row);const explanation=document.createElement('div');explanation.className='modeHelp';content.insertBefore(explanation,layout);
    let marked=new Set();function drawSidebar(){sidebar.replaceChildren();const h=document.createElement('h4');h.textContent='العطور الناتجة عن الفلترة';sidebar.append(h);const options=Array.from(select.options).filter(o=>o.value!=='');if(!options.length){const p=document.createElement('p');p.textContent=window.elanSectionDataProvider?'لا توجد نتائج جاهزة، أو جارٍ تحميلها.':'قائمة النتائج تحتاج اتصال سابابيس؛ لا توجد بيانات فعلية في الملف.';sidebar.append(p);return;}options.forEach(o=>{const label=document.createElement('label');const box=document.createElement('input');box.type='checkbox';box.checked=marked.has(o.value);box.onchange=()=>box.checked?marked.add(o.value):marked.delete(o.value);label.append(box,o.textContent);sidebar.append(label);});const addSelected=document.createElement('button');addSelected.textContent='إضافة العطور المحددة';addSelected.onclick=()=>{for(const value of marked){select.value=value;select.dispatchEvent(new Event('change'));if(!add.disabled)add.click();}marked.clear();drawSidebar();};sidebar.append(addSelected);}
    const modeHandler=mode.onchange;mode.onchange=()=>{modeHandler();row.hidden=true;row.style.display='none';sidebar.hidden=mode.value!=='manual';layout.style.gridTemplateColumns=mode.value==='manual'?'minmax(0,1fr) 270px':'1fr';explanation.textContent=mode.value==='manual'?'اختر الفلاتر، ثم حدّد عطورًا من القائمة الجانبية واضغط إضافة.':'كل العطور المطابقة للفلاتر تدخل في السيكشن تلقائيًا بعد الربط، بدون تحديد عطر فردي أو حد مختارات.';drawSidebar();};mode.onchange();const observer=new MutationObserver(()=>{marked.clear();drawSidebar();});observer.observe(select,{childList:true});panel.addEventListener('close',()=>observer.disconnect(),{once:true});
    const save=panel.querySelector('.actions .primary');const oldSave=save.onclick;save.onclick=()=>{oldSave();if(panel.open)return;const target=current();if(target?.sectionConfig){target.sectionConfig.includeAllMatching=mode.value==='automatic';target.sectionConfig.selectionStrategy=mode.value==='automatic'?'all_filtered_products':'explicit_product_size_ids';target.sectionConfig.resultSource={products:'public_products',offers:'cheapest_offers',filters:clone(target.sectionConfig.filters),manualSelectionUses:'manualProducts.productSizeId'};document.getElementById('save').click();}};
    };caption.textContent='VISUAL EDITOR · SECTION SELECTION';
    
    
    </script><script>
    // Always-visible explicit add actions for both selection modes.
    const sectionBeforeAddActions=editSection;
    editSection=function(item){sectionBeforeAddActions(item);const panel=sectionPanel;const content=Array.from(panel.querySelectorAll('fieldset')).find(f=>f.querySelector('legend')?.textContent==='اختيار العطور');if(!content)return;const mode=content.querySelector('select');const sidebar=content.querySelector('.manualResults');const bar=document.createElement('div');bar.style.cssText='display:flex;align-items:center;gap:10px;margin-top:12px;flex-wrap:wrap';const manualButton=document.createElement('button');manualButton.textContent='إضافة العطور المحددة';manualButton.className='primary';const automaticButton=document.createElement('button');automaticButton.textContent='إضافة العناصر';automaticButton.className='primary';const feedback=document.createElement('span');feedback.style.cssText='font-size:12px;color:#79643f';bar.append(manualButton,automaticButton,feedback);content.append(bar);let automaticMatches=null;
    function updateAddActions(){manualButton.hidden=mode.value!=='manual';automaticButton.hidden=mode.value!=='automatic';if(mode.value==='manual')feedback.textContent='حدّد العطور في القائمة الجانبية، ثم اضغط إضافة.';else feedback.textContent='إضافة كل نتائج الفلاتر الحالية، بدون اختيار عطر فردي.';}
    const modeBeforeButtons=mode.onchange;mode.onchange=()=>{modeBeforeButtons();automaticMatches=null;updateAddActions();};updateAddActions();
    manualButton.onclick=()=>{const checks=sidebar?Array.from(sidebar.querySelectorAll('input[type=checkbox]:checked')):[];if(!checks.length){feedback.textContent='اختر عطرًا أو أكثر من نتائج الفلترة أولًا.';return;}const button=Array.from(sidebar.querySelectorAll('button')).find(b=>b.textContent==='إضافة العطور المحددة');if(button){button.click();feedback.textContent='أضيفت العطور إلى اختيارات السيكشن. اضغط حفظ السيكشن لاعتمادها.';}else feedback.textContent='تعذر إضافة الاختيارات، أعد تحميل النتائج.';};
    // Sidebar's own button can remain; main action is always present.
    automaticButton.onclick=async()=>{const provider=window.elanSectionDataProvider;if(!provider?.getPerfumes){feedback.textContent='إضافة العناصر الفعلية تتطلب ربط سابابيس. لم تتم إضافة عطور وهمية.';return;}const grid=content.querySelector('.filterGrid');const selects=Array.from(grid.querySelectorAll('select'));const keys=['brand_id','store_id','category_id','occasion_id','note_id','size_ml'];const filters={};selects.forEach((s,n)=>{if(s.value)filters[keys[n]]=keys[n]==='size_ml'?Number(s.value):s.value;});const numbers=Array.from(grid.querySelectorAll('input[type=number]'));if(numbers[0]?.value!=='')filters.price_min=Number(numbers[0].value);if(numbers[1]?.value!=='')filters.price_max=Number(numbers[1].value);automaticButton.disabled=true;feedback.textContent='جارٍ إضافة نتائج الفلترة…';try{const rows=await provider.getPerfumes(filters);if(!Array.isArray(rows)||rows.some(p=>!p.product_id||!p.product_size_id||!p.name))throw Error();automaticMatches=rows.map(p=>({productId:p.product_id,productSizeId:p.product_size_id,name:p.name,sizeLabel:p.size_label||null}));feedback.textContent='أضيفت '+automaticMatches.length+' نتيجة إلى إعداد السيكشن. اضغط حفظ السيكشن لاعتمادها.';}catch(e){feedback.textContent='تعذر تحميل العناصر؛ لم تُعتمد نتائج بديلة.';}finally{automaticButton.disabled=false;}};
    content.querySelector('.filterGrid').addEventListener('change',()=>{automaticMatches=null;});const save=panel.querySelector('.actions .primary');const saveBeforeMatches=save.onclick;save.onclick=()=>{saveBeforeMatches();if(panel.open)return;const target=current();if(target?.sectionConfig&&mode.value==='automatic'){target.sectionConfig.automaticSelectionPreview=automaticMatches||[];target.sectionConfig.includeAllMatching=true;target.sectionConfig.automaticRefreshFromFilters=true;document.getElementById('save').click();}};
    };caption.textContent='VISUAL EDITOR · SECTION ADD ACTIONS';
    
    
    </script><script>
    // Per-perfume manual addition; one add-all action for automatic selection.
    const sectionBeforeRowActions=editSection;
    editSection=function(item){sectionBeforeRowActions(item);const content=Array.from(sectionPanel.querySelectorAll('fieldset')).find(f=>f.querySelector('legend')?.textContent==='اختيار العطور');if(!content)return;const mode=content.querySelector('select'),sidebar=content.querySelector('.manualResults'),chosen=content.querySelector('.selectionList');if(!sidebar)return;
    const primaryManual=Array.from(content.querySelectorAll('button')).find(b=>b.textContent==='إضافة العطور المحددة'&&b.parentElement!==sidebar);if(primaryManual){primaryManual.style.display='none';const feedback=primaryManual.parentElement.querySelector('span');if(feedback)feedback.style.display='none';}
    function selectedNames(){return new Set(Array.from(chosen.querySelectorAll('.chosenPerfume span')).map(s=>s.textContent.trim()));}
    function updateRows(){const saved=selectedNames();Array.from(sidebar.querySelectorAll('label')).forEach(label=>{const checkbox=label.querySelector('input[type=checkbox]');if(!checkbox)return;if(!label.dataset.perPerfume){const name=Array.from(label.childNodes).filter(n=>n.nodeType===Node.TEXT_NODE).map(n=>n.textContent).join('').trim();label.dataset.perPerfume='true';label.dataset.perfumeName=name;checkbox.style.display='none';label.style.display='flex';const title=document.createElement('span');title.textContent=name;title.style.flex='1';Array.from(label.childNodes).filter(n=>n.nodeType===Node.TEXT_NODE).forEach(n=>n.remove());label.append(title);const b=document.createElement('button');b.type='button';b.dataset.singleAdd='true';b.style.cssText='white-space:nowrap;padding:7px 10px';b.onclick=e=>{e.preventDefault();e.stopPropagation();if(b.disabled)return;sidebar.querySelectorAll('input[type=checkbox]').forEach(c=>{c.checked=c===checkbox;c.onchange?.();});const bulk=Array.from(sidebar.children).find(n=>n.tagName==='BUTTON'&&n.textContent==='إضافة العطور المحددة');if(bulk){bulk.click();updateRows();}};label.append(b);}const button=label.querySelector('button[data-single-add]');const isAdded=saved.has(label.dataset.perfumeName);if(button.disabled!==isAdded)button.disabled=isAdded;const text=isAdded?'✓ تمت الإضافة':'إضافة';if(button.textContent!==text)button.textContent=text;button.style.background=isAdded?'#e3efe2':'#fffaf0';});Array.from(sidebar.children).filter(n=>n.tagName==='BUTTON'&&n.textContent==='إضافة العطور المحددة').forEach(b=>b.style.display='none');}
    const previousMode=mode.onchange;mode.onchange=()=>{previousMode();if(primaryManual)primaryManual.style.display='none';updateRows();};
    const observer=new MutationObserver(updateRows);observer.observe(sidebar,{childList:true,subtree:true});observer.observe(chosen,{childList:true,subtree:true});sectionPanel.addEventListener('close',()=>observer.disconnect(),{once:true});updateRows();};caption.textContent='VISUAL EDITOR · INDIVIDUAL PERFUME ADD';
    
    
    </script><script>
    // Approved brand creation panel: one name input, Create and Cancel.
    const brandPanel=document.createElement('dialog');brandPanel.style.cssText='width:380px;max-width:92vw;padding:22px;background:#fffdf8;border:1px solid #c6aa70;border-radius:14px';document.body.append(brandPanel);
    function openBrandPanel(){brandPanel.replaceChildren();const title=document.createElement('h3');title.textContent='إنشاء كارت براند';title.style.cssText='margin:0 0 18px;color:#87652d';const label=document.createElement('label');label.textContent='اسم البراند';const name=document.createElement('input');name.type='text';name.autocomplete='off';name.style.cssText='display:block;width:100%;margin-top:8px;padding:10px;background:white';label.append(name);const actions=document.createElement('div');actions.style.cssText='display:flex;gap:10px;margin-top:18px';const create=document.createElement('button');create.textContent='إنشاء';create.style.cssText='flex:1;background:#29251e;color:#f0dfb9';const cancel=document.createElement('button');cancel.textContent='إلغاء';cancel.style.flex='1';cancel.onclick=()=>brandPanel.close();create.onclick=()=>{const value=name.value.trim();if(!value){name.focus();name.setCustomValidity('اكتب اسم البراند');name.reportValidity();return;}name.setCustomValidity('');addKind('brand');const item=current();if(!item)return;item.text=value;attachDefinition(item);item.binding.name=value;item.binding.entityId=null;item.binding.status='pending_connection';item.brandCreationRequest={version:1,name:value,status:'pending_connection',table:'brands',reuseExistingIfMatched:true,createIfNew:true,matchSource:'connected_store_catalogues',populateOfficialDataOnlyWhenVerified:true,includeOnlyMatchingBrandProducts:true,productVisibility:'public_products',offerSource:'cheapest_offers',noFabricatedProducts:true,unverifiedMatchRequiresReview:true};changed();render();document.getElementById('save').click();brandPanel.close();};name.oninput=()=>name.setCustomValidity('');name.onkeydown=e=>{if(e.key==='Enter'){e.preventDefault();create.click();}};actions.append(create,cancel);brandPanel.append(title,label,actions);brandPanel.showModal();name.focus();}
    const menuBeforeBrandPanel=showMenu;showMenu=function(e){menuBeforeBrandPanel(e);const button=Array.from(menu.children).find(b=>b.textContent==='إنشاء كارت براند');if(button)button.onclick=()=>{menu.style.display='none';openBrandPanel();};};caption.textContent='VISUAL EDITOR · BRAND PANEL';
    
    
    </script><script>
    // Vertical text position, independent from horizontal alignment.
    const positionLabel=document.createElement('label');positionLabel.textContent='الوضعية';const positionSelect=document.createElement('select');[['top','أعلى'],['middle','وسط'],['bottom','أسفل']].forEach(([value,label])=>{const o=document.createElement('option');o.value=value;o.textContent=label;positionSelect.append(o);});positionLabel.append(positionSelect);textGroup.grid.append(positionLabel);
    const textPositionStyle=document.createElement('style');textPositionStyle.textContent='#format .textRow{grid-template-columns:minmax(0,1.5fr) repeat(3,minmax(0,1fr))}';document.head.append(textPositionStyle);
    const openBeforeTextPosition=openFormat;openFormat=function(){openBeforeTextPosition();const item=state.items.find(i=>i.id===formatTargetId);positionSelect.value=item?.textPosition||'top';};
    const applyBeforeTextPosition=document.getElementById('apply').onclick;document.getElementById('apply').onclick=()=>{const item=state.items.find(i=>i.id===formatTargetId);const value=positionSelect.value;applyBeforeTextPosition();if(item){item.textPosition=value;changed();render();}};
    const renderBeforeTextPosition=render;render=function(){renderBeforeTextPosition();state.items.forEach(item=>{if(!['text','card','section'].includes(item.type))return;const el=Array.from(canvas.children).find(el=>el.dataset.id===item.id);const content=el?.querySelector('.content');if(!content)return;content.style.display='flex';content.style.flexDirection='column';content.style.justifyContent=item.textPosition==='middle'?'center':item.textPosition==='bottom'?'flex-end':'flex-start';});};
    positionSelect.addEventListener('change',()=>{sample.style.display='flex';sample.style.flexDirection='column';sample.style.minHeight='100px';sample.style.justifyContent=positionSelect.value==='middle'?'center':positionSelect.value==='bottom'?'flex-end':'flex-start';});caption.textContent='VISUAL EDITOR · TEXT POSITION';render();
    
    
    </script><script>
    // Reuse the approved section panel without section name/purpose.
    function openPerfumePanel(){const point={...contextPoint};const origin=selected;const anchor=state.items.find(i=>i.id===origin);const stage={id:uid(),type:'section',text:'',binding:{},sectionConfig:{name:'اختيار عطور',purpose:'إضافة كروت عطور',selectionMode:'manual',manualProducts:[],filters:{},timer:{enabled:false,mode:'dates'}}};editSection(stage);sectionPanel.querySelector('h3').textContent='إنشاء كارت عطر';const basics=sectionPanel.querySelector('.sectionGrid');if(basics){basics.style.display='none';basics.querySelectorAll('input').forEach((input,n)=>input.value=n===0?'اختيار عطور':'إضافة كروت عطور');}const commit=sectionPanel.querySelector('.actions .primary');commit.textContent='حفظ كروت العطور';const panelSave=commit.onclick;commit.onclick=async()=>{const originalSelected=selected;selected=null;panelSave();if(sectionPanel.open){selected=originalSelected;return;}const cfg=stage.sectionConfig;const provider=window.elanSectionDataProvider;let choices=cfg.manualProducts||[];if(cfg.selectionMode==='automatic'){if(!provider?.getPerfumes){alert('لا توجد بيانات عطور متصلة. إضافة كل النتائج تحتاج ربط سابابيس، ولن ننشئ كروتًا وهمية.');selected=originalSelected;sectionPanel.showModal();return;}try{const rows=await provider.getPerfumes(cfg.filters);if(!Array.isArray(rows)||rows.some(p=>!p.product_id||!p.product_size_id||!p.name))throw Error();choices=rows.map(p=>({productId:p.product_id,productSizeId:p.product_size_id,name:p.name,sizeLabel:p.size_label||null}));}catch(e){alert('تعذر تحميل نتائج الفلترة؛ لم تُنشأ كروت بديلة.');selected=originalSelected;sectionPanel.showModal();return;}}if(!choices.length){alert('أضف عطرًا من القائمة أولًا، أو اختر فلاتر لها نتائج في الوضع التلقائي.');selected=originalSelected;sectionPanel.showModal();return;}checkpoint();const ids=new Set();const added=[];choices.forEach((p,n)=>{if(ids.has(p.productSizeId))return;ids.add(p.productSizeId);const id=uid();const i={id,type:'card',kind:'perfume',text:p.name+(p.sizeLabel?'\n'+p.sizeLabel:''),x:Math.max(0,Math.min(800,point.x)),y:Math.max(0,point.y)+n*264,w:300,h:240,font:'Tahoma',size:22,color:'#222222',bg:'#fffdf9',align:'right',binding:{name:p.name,entityId:p.productId,productSizeId:p.productSizeId,status:'catalogue_selected'},parentSectionId:anchor?.type==='section'?anchor.id:null,sectionConfig:clone(cfg)};i.sectionConfig.manualProducts=[clone(p)];i.sectionConfig.selectionStrategy=cfg.selectionMode==='automatic'?'all_filtered_products':'explicit_product_size_ids';i.sectionConfig.includeAllMatching=cfg.selectionMode==='automatic';attachDefinition(i);state.items.push(i);added.push(i);});if(anchor?.type==='section'){if(!anchor.sectionConfig)anchor.sectionConfig={manualProducts:[]};if(!Array.isArray(anchor.sectionConfig.manualProducts))anchor.sectionConfig.manualProducts=[];choices.forEach(p=>{if(!anchor.sectionConfig.manualProducts.some(x=>x.productSizeId===p.productSizeId))anchor.sectionConfig.manualProducts.push(clone(p));});}if(added.length){selected=added[0].id;reflowAt(selected,point);}else selected=originalSelected;changed();render();document.getElementById('save').click();checkSections();};}
    const menuBeforePerfumePanel=showMenu;showMenu=function(e){menuBeforePerfumePanel(e);const button=Array.from(menu.children).find(b=>b.textContent==='إنشاء كارت عطر');if(button)button.onclick=()=>{menu.style.display='none';openPerfumePanel();};};caption.textContent='VISUAL EDITOR · PERFUME PANEL';
    
    
    </script><script>
    // Compact styling for section/perfume panels only.
    const compactCampaignStyle=document.createElement('style');compactCampaignStyle.textContent='.sectionPanelClean{width:min(960px,96vw)!important;max-height:96dvh!important;padding:12px 16px!important}.sectionPanelClean h3{font-size:17px;margin:0 0 8px!important}.sectionPanelClean label{font-size:11px;gap:3px}.sectionPanelClean input,.sectionPanelClean select{font-size:11px;min-height:29px!important;padding:5px 7px}.sectionPanelClean button{font-size:11px;padding:6px 9px}.sectionPanelClean fieldset{margin:7px 0;padding:8px 10px}.sectionPanelClean legend{font-size:12px}.sectionPanelClean .sectionGrid{gap:8px}.sectionPanelClean .filterGrid{grid-template-columns:repeat(4,minmax(0,1fr));gap:6px}.sectionPanelClean .manualLayout{gap:9px}.sectionPanelClean .manualResults{padding:8px;max-height:190px!important;overflow:auto}.sectionPanelClean .manualResults h4{font-size:12px;margin:0 0 5px}.sectionPanelClean .manualResults label{padding:5px 0;font-size:11px}.sectionPanelClean .selectionList{margin-top:5px;gap:4px;max-height:76px;overflow:auto}.sectionPanelClean .chosenPerfume{font-size:11px;padding:5px 7px}.sectionPanelClean .notice,.sectionPanelClean .modeHelp{font-size:10px;line-height:1.5;margin:4px 0;padding:3px 0}.sectionPanelClean .actions{margin-top:8px;gap:8px}.sectionPanelClean .toggle{font-size:11px;margin-bottom:4px}.sectionPanelClean .perfumeRow{margin:6px 0}.sectionPanelClean fieldset:last-of-type>.sectionGrid{display:grid;grid-template-columns:1fr 1fr}.sectionPanelClean fieldset:last-of-type>label:not(.toggle){max-width:100%}@media(min-width:700px) and (min-height:700px){.sectionPanelClean{max-height:94dvh}}@media(max-width:600px){.sectionPanelClean{padding:10px!important}.sectionPanelClean .filterGrid{grid-template-columns:repeat(2,minmax(0,1fr))}.sectionPanelClean .manualResults{max-height:140px!important}}';document.head.append(compactCampaignStyle);caption.textContent='VISUAL EDITOR · COMPACT PANELS';
    
    
    </script><script>
    // Replace the overcompressed panel styling; behavior stays unchanged.
    compactCampaignStyle.remove();
    const balancedPanelStyle=document.createElement('style');balancedPanelStyle.textContent=`
    .sectionPanelClean{width:min(790px,94vw)!important;max-height:92dvh!important;padding:20px!important;background:#fffdf9;color:#302b23;border:1px solid #c8ae79;border-radius:18px;box-shadow:0 24px 80px #0003;overflow:auto}
    .sectionPanelClean::backdrop{background:rgba(21,19,15,.45)}
    .sectionPanelClean h3{font-size:19px;font-weight:700;line-height:1.4;color:#86642e;margin:0 0 15px!important;padding-bottom:12px;border-bottom:1px solid #e9dec8}
    .sectionPanelClean label{font-size:12px;line-height:1.5;font-weight:500;gap:5px;min-width:0}
    .sectionPanelClean input,.sectionPanelClean select{width:100%;min-width:0;font:12px Tahoma,Arial;min-height:35px!important;height:35px;padding:7px 9px;border:1px solid #dccfb6;border-radius:7px;background:#fff;box-shadow:none;color:#302b23}
    .sectionPanelClean input:focus,.sectionPanelClean select:focus{outline:2px solid #cfb57966;outline-offset:1px;border-color:#ae8d4e}
    .sectionPanelClean input:disabled,.sectionPanelClean select:disabled{background:#f1eee7;color:#938977}
    .sectionPanelClean button{font:12px Tahoma,Arial;padding:8px 12px;border-radius:8px;min-height:34px}
    .sectionPanelClean fieldset{margin:12px 0;padding:12px;border:1px solid #e2d6bd;border-radius:12px;background:#faf7f0;min-width:0}
    .sectionPanelClean legend{font-size:13px;font-weight:700;color:#86642e;padding:0 7px}
    .sectionPanelClean .sectionGrid{display:grid;grid-template-columns:1fr 1fr;gap:10px}
    .sectionPanelClean .filterGrid{grid-template-columns:repeat(3,minmax(0,1fr))!important;gap:9px}
    .sectionPanelClean .manualLayout{grid-template-columns:minmax(0,1fr) 225px;gap:12px;align-items:start}
    .sectionPanelClean .manualResults{padding:10px;max-height:255px!important;min-height:110px;border:1px solid #ddcba7;background:#fffdf8;border-radius:10px;overflow:auto}
    .sectionPanelClean .manualResults h4{font-size:13px;color:#76582a;margin:0 0 9px;padding-bottom:7px;border-bottom:1px solid #ece2cf}
    .sectionPanelClean .manualResults label{font-size:12px;padding:7px 0;gap:6px}
    .sectionPanelClean .manualResults p{font-size:12px;line-height:1.8;color:#827459;margin:6px 0}
    .sectionPanelClean .manualResults input[type=checkbox],.sectionPanelClean .toggle input{width:16px;height:16px;min-height:16px!important;padding:0;flex-shrink:0}
    .sectionPanelClean .selectionList{gap:6px;margin-top:9px;max-height:110px;overflow:auto}
    .sectionPanelClean .chosenPerfume{font-size:12px;padding:7px 9px;background:#fff;border-color:#e2d7c3}
    .sectionPanelClean .notice,.sectionPanelClean .modeHelp{font-size:11px;line-height:1.7;color:#827358;padding:5px 0;margin:5px 0}
    .sectionPanelClean .toggle{font-size:12px;margin-bottom:9px;gap:8px}
    .sectionPanelClean .actions{margin-top:14px;padding-top:12px;border-top:1px solid #e9dec8;gap:10px}
    .sectionPanelClean .actions button{min-height:39px;font-size:13px}
    .sectionPanelClean .primary{background:#30291f;color:#f1dfb7;border-color:#30291f}
    .sectionPanelClean [hidden]{display:none!important}
    @media(max-width:650px){.sectionPanelClean{width:94vw!important;padding:14px!important}.sectionPanelClean .manualLayout{grid-template-columns:1fr!important}.sectionPanelClean .filterGrid{grid-template-columns:repeat(2,minmax(0,1fr))!important}.sectionPanelClean .manualResults{max-height:190px!important}}
    `;document.head.append(balancedPanelStyle);
    // Keep the automatic-mode single column, and balanced manual-mode proportions.
    const panelBeforeBalanced=editSection;editSection=function(item){panelBeforeBalanced(item);const content=Array.from(sectionPanel.querySelectorAll('fieldset')).find(f=>f.querySelector('legend')?.textContent==='اختيار العطور');const mode=content?.querySelector('select'),layout=content?.querySelector('.manualLayout');if(mode&&layout){const old=mode.onchange;mode.onchange=()=>{old();layout.style.gridTemplateColumns=mode.value==='manual'?'minmax(0,1fr) 225px':'1fr';};layout.style.gridTemplateColumns=mode.value==='manual'?'minmax(0,1fr) 225px':'1fr';}};
    caption.textContent='VISUAL EDITOR · BALANCED PANELS';
    
    
    </script><script>
    // Remove exactly the two requested explanatory messages.
    const removedPanelTexts=new Set(['اختر الفلاتر، ثم حدّد عطورًا من القائمة الجانبية واضغط إضافة.','القوائم مجهزة للاختيار بالأسماء. اتصال سابابيس غير منفّذ في هذا الملف، لذلك لا نعرض أسماء أو عطورًا وهمية.']);
    function cleanRequestedPanelCopy(){sectionPanel.querySelectorAll('.modeHelp,.notice').forEach(el=>{if(removedPanelTexts.has(el.textContent.trim())){el.textContent='';el.hidden=true;}else if(el.textContent.trim()){el.hidden=false;}});}
    const panelBeforeCopyRemoval=editSection;editSection=function(item){panelBeforeCopyRemoval(item);cleanRequestedPanelCopy();const watch=new MutationObserver(cleanRequestedPanelCopy);watch.observe(sectionPanel,{childList:true,subtree:true,characterData:true});sectionPanel.addEventListener('close',()=>watch.disconnect(),{once:true});};
    
    
    </script><script>
    // Requested sidebar height and context-menu cleanup only.
    const tallerPerfumeSidebar=document.createElement('style');tallerPerfumeSidebar.textContent='.sectionPanelClean .manualResults{min-height:300px!important;max-height:420px!important}@media(max-width:650px){.sectionPanelClean .manualResults{min-height:220px!important;max-height:330px!important}}';document.head.append(tallerPerfumeSidebar);
    const menuBeforeTwoRemovals=showMenu;showMenu=function(e){menuBeforeTwoRemovals(e);Array.from(menu.children).forEach(button=>{if(['تعريف العنصر ومصدر بياناته','إعدادات السيكشن'].includes(button.textContent.trim()))button.remove();});const rect=menu.getBoundingClientRect();menu.style.top=Math.max(4,Math.min(e.clientY,innerHeight-rect.height-8))+'px';};
    
    
    </script><script>
    // Remove only the requested label text; retain the selection-mode control.
    const panelBeforeModeLabelRemoval=editSection;
    editSection=function(item){panelBeforeModeLabelRemoval(item);sectionPanel.querySelectorAll('label').forEach(label=>{if(!label.querySelector('select'))return;Array.from(label.childNodes).forEach(node=>{if(node.nodeType===Node.TEXT_NODE&&node.textContent.trim()==='طريقة الاختيار')node.remove();});});};
    
    
    </script><script>
    // Name-only occasion and aromatic-note panels; no fabricated product matching.
    const taxonomyPanel=document.createElement('dialog');taxonomyPanel.style.cssText='width:380px;max-width:92vw;padding:22px;background:#fffdf8;border:1px solid #c6aa70;border-radius:14px';document.body.append(taxonomyPanel);
    function openTaxonomyPanel(kind){const occasion=kind==='occasion';const table=occasion?'occasions':'aromatic_notes',relationTable=occasion?'product_occasions':'product_notes',relationId=occasion?'occasion_id':'note_id';taxonomyPanel.replaceChildren();const title=document.createElement('h3');title.textContent=occasion?'إنشاء كارت مناسبة':'إنشاء كارت نوتة عطرية';title.style.cssText='margin:0 0 18px;color:#87652d';const label=document.createElement('label');label.textContent=occasion?'اسم المناسبة':'اسم النوتة العطرية';const name=document.createElement('input');name.type='text';name.autocomplete='off';name.style.cssText='display:block;width:100%;margin-top:8px;padding:10px;background:white';label.append(name);const actions=document.createElement('div');actions.style.cssText='display:flex;gap:10px;margin-top:18px';const create=document.createElement('button');create.textContent='إنشاء';create.style.cssText='flex:1;background:#29251e;color:#f0dfb9';const cancel=document.createElement('button');cancel.textContent='إلغاء';cancel.style.flex='1';cancel.onclick=()=>taxonomyPanel.close();name.oninput=()=>name.setCustomValidity('');create.onclick=()=>{const value=name.value.trim();if(!value){name.focus();name.setCustomValidity('اكتب الاسم');name.reportValidity();return;}name.setCustomValidity('');addKind(kind);const item=current();if(!item)return;item.text=value;attachDefinition(item);item.binding.name=value;item.binding.entityId=null;item.binding.status='pending_connection';item.taxonomyCreationRequest={version:1,kind,name:value,status:'pending_connection',table,relationTable,relationId,productIdField:'product_id',reuseExistingIfMatched:true,createIfNew:true,automaticProductAssignment:true,manualProductSelectionRequired:false,matchSource:'available_verified_database_and_catalogue_data',preferExistingRelations:true,createRelationsOnlyWithVerifiedEvidence:true,noUnsupportedInference:true,emptyWhenEvidenceInsufficient:true,productVisibility:'public_products',offerSource:'cheapest_offers',noFabricatedProducts:true};changed();render();document.getElementById('save').click();taxonomyPanel.close();};name.onkeydown=e=>{if(e.key==='Enter'){e.preventDefault();create.click();}};actions.append(create,cancel);taxonomyPanel.append(title,label,actions);taxonomyPanel.showModal();name.focus();}
    const menuBeforeTaxonomyPanels=showMenu;showMenu=function(e){menuBeforeTaxonomyPanels(e);Array.from(menu.children).forEach(button=>{if(button.textContent==='إنشاء مناسبة')button.onclick=()=>{menu.style.display='none';openTaxonomyPanel('occasion');};if(button.textContent==='إنشاء نوتة عطر')button.onclick=()=>{menu.style.display='none';openTaxonomyPanel('note');};});};caption.textContent='VISUAL EDITOR · OCCASION & NOTE';
    
    
    </script><script>
    // Name-only store creation panel with the supplied schema and pricing rules.
    const storePanel=document.createElement('dialog');storePanel.style.cssText='width:380px;max-width:92vw;padding:22px;background:#fffdf8;border:1px solid #c6aa70;border-radius:14px';document.body.append(storePanel);
    function openStorePanel(){storePanel.replaceChildren();const title=document.createElement('h3');title.textContent='إنشاء كارت متجر';title.style.cssText='margin:0 0 18px;color:#87652d';const label=document.createElement('label');label.textContent='اسم المتجر';const name=document.createElement('input');name.type='text';name.autocomplete='off';name.style.cssText='display:block;width:100%;margin-top:8px;padding:10px;background:white';label.append(name);const actions=document.createElement('div');actions.style.cssText='display:flex;gap:10px;margin-top:18px';const create=document.createElement('button');create.textContent='إنشاء';create.style.cssText='flex:1;background:#29251e;color:#f0dfb9';const cancel=document.createElement('button');cancel.textContent='إلغاء';cancel.style.flex='1';cancel.onclick=()=>storePanel.close();name.oninput=()=>name.setCustomValidity('');create.onclick=()=>{const value=name.value.trim();if(!value){name.focus();name.setCustomValidity('اكتب اسم المتجر');name.reportValidity();return;}name.setCustomValidity('');addKind('store');const item=current();if(!item)return;item.text=value;attachDefinition(item);item.binding.name=value;item.binding.entityId=null;item.binding.status='pending_connection';item.storeCreationRequest={version:1,name:value,status:'pending_connection',table:'stores',fields:clone(suppliedSchema.tables.stores),relations:{'store_products.store_id':'stores.id','store_products.product_size_id':'product_sizes.id','product_sizes.product_id':'products.id','products.brand_id':'brands.id'},reuseExistingIfMatched:true,createIfNew:true,integrationCompleted:false,separateStoreCatalogue:true,approvedBrands:clone(suppliedSchema.initial.brands),hiddenPublicFields:['website_url'],dataSources:{price:'store_catalog',availability:'store_catalog',quantity:'store_catalog',offers:'store_catalog'},rules:clone(suppliedSchema.rules),visibilityView:'public_products',cheapestOfferDefinition:clone(suppliedSchema.views.cheapest_offers),storeCataloguePrices:'Use this store actual offers; never attribute another store price or stock to this store.',credentialsRequiredInThisPanel:false};changed();render();document.getElementById('save').click();storePanel.close();};name.onkeydown=e=>{if(e.key==='Enter'){e.preventDefault();create.click();}};actions.append(create,cancel);storePanel.append(title,label,actions);storePanel.showModal();name.focus();}
    const menuBeforeStorePanel=showMenu;showMenu=function(e){menuBeforeStorePanel(e);const button=Array.from(menu.children).find(b=>b.textContent==='إنشاء كارت متجر');if(button)button.onclick=()=>{menu.style.display='none';openStorePanel();};};caption.textContent='VISUAL EDITOR · STORE PANEL';
    
    
    </script><script>
    // Store definition completed from the supplied schema, without database changes.
    const exactStoreSchema={table:'stores',columns:{id:{type:'uuid',primaryKey:true},name:{type:'not specified'},slug:{type:'not specified',unique:true},logo_url:{type:'not specified'},image_url:{type:'not specified'},short_description:{type:'not specified'},website_url:{type:'not specified',hiddenFromCustomer:true},status:{type:'not specified',allowedValues:['active','inactive']},commission_rate:{type:'numeric',default:0},priority_rank:{type:'integer',default:100},created_at:{type:'not specified',automatic:true},updated_at:{type:'not specified',automatic:true}},rowLevelSecurity:true,publicRead:'Available products, brands, stores, offers and prices only, as stated in the supplied schema.',storeAccountWrite:'Store accounts modify their own store catalogue only.',platform_admin:'Full access.',relatedTables:['store_accounts','store_products','offers','commissions','sync_logs','product_sizes','products','brands'],relations:{'store_accounts.store_id':'stores.id','store_accounts.user_id':'auth.users.id','store_products.store_id':'stores.id','store_products.product_size_id':'product_sizes.id','product_sizes.product_id':'products.id','products.brand_id':'brands.id','offers.store_id':'stores.id','offers.product_size_id':'product_sizes.id','commissions.store_id':'stores.id','commissions.order_item_id':'order_items.id','sync_logs.store_id':'stores.id'},uniqueConstraints:{store_accounts:['store_id','user_id'],store_products:['store_id','product_size_id']},requestedIndexes:['brand_id','store_id','product_id','product_size_id','price','is_available','commission_rate'],storeProductFields:clone(suppliedSchema.tables.store_products),storeProductDefaults:{stock_quantity:0,is_available:false,is_new_arrival:false,is_coming_soon:false,currency:'EGP',data_source:'store_catalog',sync_status:'unavailable'},storeProductRequired:{price:'numeric not null'},storeProductSyncValues:['synced','stale','unavailable'],storeProductTimestamps:'created_at and updated_at automatic',views:clone(suppliedSchema.views),dataRules:clone(suppliedSchema.rules),initialStores:clone(suppliedSchema.initial.stores),approvedBrands:clone(suppliedSchema.initial.brands),source:'merchant supplied schema, not a verification of deployed SQL'};
    const attachBeforeStoreCompletion=attachDefinition;attachDefinition=function(item){attachBeforeStoreCompletion(item);if(item.kind!=='store')return;item.storeSchemaDefinition=clone(exactStoreSchema);if(item.storeCreationRequest){item.storeCreationRequest.schemaDefinition=clone(exactStoreSchema);item.storeCreationRequest.suppliedSchemaReference=clone(suppliedSchema);}};
    const saveBeforeStoreCompletion=document.getElementById('save').onclick;document.getElementById('save').onclick=()=>{state.items.forEach(attachDefinition);state.archive.forEach(attachDefinition);if(Array.isArray(state.savedElements))state.savedElements.forEach(attachDefinition);saveBeforeStoreCompletion();};state.items.forEach(attachDefinition);state.archive.forEach(attachDefinition);if(Array.isArray(state.savedElements))state.savedElements.forEach(attachDefinition);
    
    
    </script><script>
    // Canonical table clauses transcribed from the supplied schema, including its exceptions.
    const canonicalTableSpecs={
    brands:'id, name, slug unique, official_logo_url, description, official_website_url, is_active default true, created_at, updated_at',
    stores:'id, name, slug unique, logo_url, image_url, short_description, website_url; status (active / inactive); commission_rate numeric default 0; priority_rank integer default 100; created_at, updated_at',
    store_accounts:'id, store_id references stores, user_id references auth.users, role text default store_admin, created_at; unique (store_id, user_id)',
    aromatic_notes:'id, name unique, image_url, created_at, updated_at',categories:'id, name unique, image_url, created_at, updated_at',occasions:'id, name unique, image_url, created_at, updated_at',
    products:'id, brand_id references brands, name, slug unique; short_description, official_description, composition; gender (men / women / unisex); notes_source (brand_official / store_catalog / mixed); content_source text; status (draft / published / archived) default draft; meta_title, meta_description; is_active default true; created_at, updated_at',
    product_sizes:'id, product_id references products, size_ml integer, size_label text, sku text; unique (product_id, size_label); created_at, updated_at',
    product_images:'id, product_id references products, product_size_id nullable references product_sizes; image_url, alt_text, sort_order integer default 0, is_primary default false; created_at',
    product_notes:'product_id references products, note_id references aromatic_notes; primary key (product_id, note_id)',
    product_categories:'product_id references products, category_id references categories; primary key (product_id, category_id)',
    product_occasions:'product_id references products, occasion_id references occasions; primary key (product_id, occasion_id)',
    store_products:'id; store_id references stores; product_size_id references product_sizes; price numeric not null; original_price numeric; discount_percentage numeric; stock_quantity integer default 0; is_available boolean default false; is_new_arrival boolean default false; is_coming_soon boolean default false; price_includes_tax boolean; price_includes_shipping boolean; currency text default EGP; data_source text default store_catalog; sync_status (synced / stale / unavailable) default unavailable; last_synced_at timestamptz; created_at, updated_at; unique (store_id, product_size_id)',
    offers:'id, store_id references stores, product_size_id nullable references product_sizes; title, description; discount_type (percentage / fixed / package); discount_value numeric; start_date, end_date; is_active default true; created_at, updated_at',
    product_stats:'product_id primary key references products; views_count integer default 0; sales_count integer default 0; search_count integer default 0; request_count integer default 0; average_rating numeric; reviews_count integer default 0; updated_at',
    reviews:'id, user_id references profiles, product_id references products; rating integer check 1-5, comment text, is_approved default false; created_at, updated_at; unique (user_id, product_id)',
    profiles:'id primary key references auth.users; full_name, phone, avatar_url; role (customer / store_admin / platform_admin) default customer; created_at, updated_at',
    favorites:'id, user_id references profiles, product_id references products; created_at; unique (user_id, product_id)',
    cart_items:'id, user_id references profiles, store_product_id references store_products; quantity integer default 1 check > 0; created_at, updated_at; unique (user_id, store_product_id)',
    orders:'id, user_id references profiles; status (pending / confirmed / shipped / delivered / cancelled); subtotal numeric, tax_amount numeric default 0, shipping_amount numeric default 0, total_amount numeric; created_at, updated_at',
    order_items:'id, order_id references orders, store_product_id references store_products; quantity integer, price_at_time numeric; created_at',
    commissions:'id, store_id references stores, order_item_id references order_items; rate numeric, amount numeric; status (pending / payable / paid) default pending; created_at, updated_at',
    contact_messages:'id, name, email, phone, message, is_read default false, created_at',
    notifications:'id, user_id references profiles, title, body, is_read default false, created_at',
    marketing_phrases:'id, phrase_ar, phrase_en nullable; category (slogan / section / internal_reference); is_public boolean default false; usage_scope text; created_at',
    media_library:'id, file_url, file_type (image / video); source (device_upload / ai_generated / store_catalog / brand_official); alt_text, linked_entity_type, linked_entity_id; is_approved default false; created_at',
    analytics_events:'id, event_type (view / search / add_to_cart / request); product_id nullable, product_size_id nullable, user_id nullable; metadata jsonb; created_at',
    site_settings:'key text primary key, value text, updated_at',
    sync_logs:'id, store_id references stores, status text, message text, records_count integer, created_at'
    };
    const canonicalGeneralRules={primaryKeyInstruction:'UUID as primary key for all tables',timestampsInstruction:'created_at and updated_at automatic on every table',preserveExplicitTableExceptions:true,rowLevelSecurity:'Enable on every table',publicRead:'Only available products, brands, stores, offers and prices',userWrite:'Authenticated users may write only their own favorites, cart, orders, reviews and messages',storeWrite:'Store accounts modify their own store catalogue only',platform_admin:'Full access',indexes:['brand_id','store_id','product_id','product_size_id','price','is_available','commission_rate']};
    const canonicalForbiddenData=[
    'Price, availability, quantity, offers, new arrivals and best sellers come only from store catalogues.',
    'Description, composition, notes and official content may be supplemented only from the official brand website.',
    'Never store or display official brand website price as the displayed price.',
    'brands.official_website_url is stored but never displayed to customers.',
    'No store or brand website link is displayed to customers.',
    'Do not display a perfume unless available for sale at at least one platform store.',
    'Each size has independent price, availability, quantity and comparison; no comparison across sizes.',
    'One card for the same perfume and size: cheapest available store; tie: highest commission_rate then priority_rank.'
    ];
    const canonicalViews={cheapest_offers:{per:'product_size_id',eligibility:['is_available = true','stock_quantity > 0','sync_status = synced'],selection:'Cheapest store_products row',tieOrder:['commission_rate DESC','priority_rank ASC'],columns:['product_size_id','product_id','brand_id','store_id','store_name','price','stock_quantity','currency','price_includes_tax','price_includes_shipping','last_synced_at']},public_products:{eligibility:'Published products with at least one offer in cheapest_offers',usage:'The only product-display rule for cards, sections and search',columns:'Not listed in the supplied schema'}};
    const elementSchemaTables={
    section:Object.keys(canonicalTableSpecs),
    perfume:['products','product_sizes','product_images','brands','stores','store_products','aromatic_notes','product_notes','categories','product_categories','occasions','product_occasions','offers','product_stats','reviews','profiles','favorites','cart_items','orders','order_items','commissions','media_library','analytics_events','sync_logs'],
    brand:['brands','products','product_sizes','product_images','stores','store_products','offers','product_stats','media_library','sync_logs'],
    store:['stores','store_accounts','profiles','products','brands','product_sizes','product_images','store_products','offers','product_stats','reviews','order_items','commissions','media_library','sync_logs'],
    occasion:['occasions','product_occasions','products','product_sizes','product_images','brands','stores','store_products','media_library'],
    note:['aromatic_notes','product_notes','products','product_sizes','product_images','brands','stores','store_products','media_library'],
    banner:['media_library'],text:['marketing_phrases'],text_block:['marketing_phrases']};
    const canonicalSchemaReference={id:'elan-merchant-schema-v1',tables:canonicalTableSpecs,generalRules:canonicalGeneralRules,dataRestrictions:canonicalForbiddenData,relations:clone(suppliedSchema.relations),views:canonicalViews,initialData:clone(suppliedSchema.initial),marketingPhraseSeedRule:'Identity phrases are is_public=false except phrases explicitly assigned to each section.',verification:'Matched to supplied specification; no live database verification.'};
    function canonicalElementDefinition(item){const kind=definitionKind(item);if(!kind)return null;const tables=elementSchemaTables[kind]||[];const clauses={};tables.forEach(name=>clauses[name]=canonicalTableSpecs[name]);const tableSet=new Set(tables);const relations=Object.fromEntries(Object.entries(suppliedSchema.relations).filter(([left,right])=>tableSet.has(left.split('.')[0])||tableSet.has(right.split('.')[0])));return {kind,schemaReferenceId:canonicalSchemaReference.id,entityTable:elanElementDefinitions.elements[kind]?.table||null,tableSpecifications:clauses,relations,generalRules:clone(canonicalGeneralRules),dataRestrictions:clone(canonicalForbiddenData),views:['banner','text','text_block'].includes(kind)?null:clone(canonicalViews),initialData:clone(suppliedSchema.initial),independentLayoutTableSpecified:!['section','banner','text','text_block'].includes(kind),connectionStatus:'not_connected'};}
    const attachBeforeCanonicalAudit=attachDefinition;attachDefinition=function(item){attachBeforeCanonicalAudit(item);if(!definitionKind(item))return;item.schemaDefinition=canonicalElementDefinition(item);item.schemaReferenceId=canonicalSchemaReference.id;};
    Object.entries(elanElementDefinitions.elements).forEach(([kind,def])=>{def.schemaReferenceId=canonicalSchemaReference.id;def.tableSpecifications={};(elementSchemaTables[kind]||[]).forEach(name=>def.tableSpecifications[name]=canonicalTableSpecs[name]);});
    elanElementDefinitions.canonicalSchema=canonicalSchemaReference;
    const saveBeforeCanonicalAudit=document.getElementById('save').onclick;document.getElementById('save').onclick=()=>{state.canonicalSchemaReference=clone(canonicalSchemaReference);state.items.forEach(attachDefinition);state.archive.forEach(attachDefinition);if(Array.isArray(state.savedElements))state.savedElements.forEach(attachDefinition);saveBeforeCanonicalAudit();};
    state.canonicalSchemaReference=clone(canonicalSchemaReference);state.items.forEach(attachDefinition);state.archive.forEach(attachDefinition);if(Array.isArray(state.savedElements))state.savedElements.forEach(attachDefinition);
    const audit={expectedTables:29,actualTables:Object.keys(canonicalTableSpecs).length,missingTables:Object.keys(suppliedSchema.tables).filter(t=>!canonicalTableSpecs[t]),elementKinds:Object.keys(elementSchemaTables),requiredPriceColumnsMissing:suppliedSchema.views.cheapest_offers.columns.filter(c=>!canonicalViews.cheapest_offers.columns.includes(c))};
    state.schemaDefinitionAudit=audit;
    if(audit.actualTables!==29||audit.missingTables.length||audit.requiredPriceColumnsMissing.length)console.error('Schema definition mismatch',audit);
    caption.textContent='VISUAL EDITOR · FINAL SCHEMA REVIEW';
    
    
    </script><script>
    // Cloud library integration boundary. No credentials and no invented Supabase tables.
    // Provider contract: getLibrary() -> {archive,media,savedElements,revision};
    // saveLibrary({archive,media,savedElements}, expectedRevision) -> {revision};
    // uploadMedia(file,{category}) -> {id,name,src,type,category};
    // generateMedia({prompt,category}) -> stored cloud media record, only after external service configuration.
    let cloudLibraryReady=false,cloudLibraryRevision=null,cloudLibraryTimer=null,cloudLibrarySaving=false,cloudLibraryPending=false;
    function librarySnapshot(){return clone({archive:state.archive,media:state.media,savedElements:state.savedElements||[]});}
    function cloudProvider(){return window.elanLibraryDataProvider;}
    function showLibraryCloudMessage(text){let msg=libraryDialog.querySelector('[data-cloud-message]');if(!msg){msg=document.createElement('p');msg.dataset.cloudMessage='true';msg.style.cssText='font-size:12px;line-height:1.8;color:#846631';libraryDialog.append(msg);}msg.textContent=text;}
    function validLibrary(data){return data&&Array.isArray(data.archive)&&Array.isArray(data.media)&&Array.isArray(data.savedElements)&&data.revision!==undefined;}
    async function loadCloudLibrary(){const provider=cloudProvider();if(!provider?.getLibrary){showLibraryCloudMessage('المكتبة المركزية غير متصلة. الموجود حاليًا نسخة محلية، ولا يوجد حفظ مؤكد في سابابيس.');return false;}if(cloudLibraryPending){showLibraryCloudMessage('توجد تغييرات غير محفوظة مركزيًا. لا نستبدلها قبل المزامنة.');return false;}try{const data=await provider.getLibrary();if(!validLibrary(data))throw Error('Invalid cloud response');state.archive=clone(data.archive);state.media=clone(data.media);state.savedElements=clone(data.savedElements);cloudLibraryRevision=data.revision;cloudLibraryReady=true;document.getElementById('save').click();library();showLibraryCloudMessage('المكتبة محمّلة من المصدر المركزي.');return true;}catch(e){cloudLibraryReady=false;showLibraryCloudMessage('تعذر قراءة المكتبة المركزية. لم تُستبدل بياناتك المحلية.');return false;}}
    async function persistCloudLibrary(){if(!cloudLibraryReady||!cloudProvider()?.saveLibrary)return;if(cloudLibrarySaving)return;cloudLibrarySaving=true;const snapshot=librarySnapshot();cloudLibraryPending=false;try{const result=await cloudProvider().saveLibrary(snapshot,cloudLibraryRevision);if(result?.revision===undefined)throw Error('Missing revision');cloudLibraryRevision=result.revision;if(libraryDialog.open)showLibraryCloudMessage('تم تأكيد حفظ المكتبة والأرشيف مركزيًا.');}catch(e){cloudLibraryPending=true;if(libraryDialog.open)showLibraryCloudMessage('لم يتم تأكيد الحفظ المركزي، أو تعارض مع نسخة أحدث. بياناتك المحلية لم تُحذف؛ لا تُعتبر هذه التغييرات محفوظة على الخادم.');}finally{cloudLibrarySaving=false;}}
    let lastLibrarySignature=JSON.stringify(librarySnapshot());const changedBeforeCloudLibrary=changed;changed=function(){changedBeforeCloudLibrary();const signature=JSON.stringify(librarySnapshot());if(signature===lastLibrarySignature)return;lastLibrarySignature=signature;cloudLibraryPending=true;if(cloudLibraryReady){clearTimeout(cloudLibraryTimer);cloudLibraryTimer=setTimeout(persistCloudLibrary,350);}};
    window.connectElanLibrary=async function(provider){if(!provider||typeof provider.getLibrary!=='function'||typeof provider.saveLibrary!=='function')throw Error('Library provider requires authenticated load/save methods');window.elanLibraryDataProvider=provider;cloudLibraryPending=false;return loadCloudLibrary();};
    const libraryBeforeCloudSources=library;library=function(){libraryBeforeCloudSources();const controls=document.createElement('div');controls.style.cssText='display:flex;gap:8px;flex-wrap:wrap;margin-top:12px';const cloud=document.createElement('button');cloud.textContent='تحميل المكتبة من سابابيس';cloud.onclick=loadCloudLibrary;const sync=document.createElement('button');sync.textContent='مزامنة التغييرات';sync.onclick=()=>{if(!cloudLibraryReady){showLibraryCloudMessage('أكمل الاتصال أولًا. لا يتم رفع الأرشيف المحلي تلقائيًا إلى قاعدة البيانات.');return;}persistCloudLibrary();};controls.append(cloud,sync);if(libraryTab==='saved'){const ai=document.createElement('button');ai.textContent='إضافة من الذكاء الاصطناعي';ai.onclick=async()=>{const provider=cloudProvider();if(!cloudLibraryReady||!provider?.generateMedia){showLibraryCloudMessage('مولّد الميديا غير متصل. يلزم إعداد خدمة توليد وربط الحفظ المركزي أولًا.');return;}const promptText=prompt('وصف الصورة أو الفيديو المطلوب');if(!promptText?.trim())return;if(!confirm('إرسال طلب التوليد للخدمة المرتبطة؟ قد تُحتسب تكلفة وفق حسابك لديها.'))return;ai.disabled=true;try{const record=await provider.generateMedia({prompt:promptText.trim(),category:libraryCategory});if(!record?.id||!record.src||!['image','video'].includes(record.type))throw Error();checkpoint();state.media.push({...record,category:libraryCategory});changed();await persistCloudLibrary();library();}catch(e){showLibraryCloudMessage('لم يتم تأكيد توليد الميديا وحفظها مركزيًا.');}finally{ai.disabled=false;}};controls.append(ai);}libraryDialog.append(controls);showLibraryCloudMessage(cloudLibraryReady?(cloudLibraryPending?'تغييرات تنتظر تأكيد الحفظ المركزي.':'المكتبة متصلة بالمصدر المركزي.'):'الربط المركزي غير منفّذ؛ لا تزال المكتبة المحلية هي المعروضة.');};document.getElementById('library').onclick=()=>library();
    const localUploadBeforeCloud=document.getElementById('upload').onchange;document.getElementById('upload').onchange=async e=>{const file=e.target.files[0];if(!file)return;if(!cloudLibraryReady||!cloudProvider()?.uploadMedia||file.name.toLowerCase().endsWith('.json')){localUploadBeforeCloud(e);return;}if(!file.type.startsWith('image/')&&!file.type.startsWith('video/')){alert('اختر صورة أو فيديو');e.target.value='';return;}const category=uploadOnlyCategory;uploadOnlyCategory=null;const targetId=replaceId||(current()&&['card','section'].includes(current().type)?selected:null);replaceId=null;e.target.value='';try{const target=state.items.find(i=>i.id===targetId);const record=await cloudProvider().uploadMedia(file,{category:category||(target?itemCategory(target):file.type.startsWith('image/')?'image':'video')});if(!record?.id||!record.src||!['image','video'].includes(record.type))throw Error();checkpoint();state.media.push(record);if(!category){if(target&&['card','section'].includes(target.type)){target.mediaSrc=record.src;target.mediaType=record.type;}else if(target&&['image','video'].includes(target.type)){target.src=record.src;target.type=record.type;}else add(record.type,record.src);}changed();render();await persistCloudLibrary();if(libraryDialog.open)library();}catch(e){alert('لم يتم تأكيد رفع الملف للمكتبة المركزية. لم نعرضه كملف محفوظ بنجاح.');}};
    state.libraryStorageDefinition={target:'supabase',mediaMetadataTable:'media_library',mediaBinaryStorage:'Configured private Supabase Storage with authenticated access',archive:'Full element payload including layout, data definitions, bindings, timers and content; storage location chosen only after inspecting existing backend',savedElements:'Full reusable element payload',sources:['central_library','device_upload','configured_ai_generator'],secretKeysInBrowser:false,liveConnection:false};
    caption.textContent='VISUAL EDITOR · CENTRAL LIBRARY READY';
    
    
    </script><script>
    // Media source chooser for the selected element, with explicit connection status.
    const mediaSourceDialog=document.createElement('dialog');mediaSourceDialog.style.cssText='width:420px;max-width:94vw;padding:22px;background:#fffdf8;border:1px solid #c6aa70;border-radius:14px';document.body.append(mediaSourceDialog);
    function applyChosenMedia(targetId,record){const target=state.items.find(i=>i.id===targetId);if(!target){alert('العنصر المطلوب غير موجود.');return;}checkpoint();if(['card','section'].includes(target.type)){target.mediaSrc=record.src;target.mediaType=record.type;}else if(['image','video'].includes(target.type)){target.src=record.src;target.type=record.type;}else{alert('هذا العنصر لا يدعم الميديا.');return;}changed();render();document.getElementById('save').click();}
    function chooseMediaSource(){const target=current();if(!target||!['card','section','image','video'].includes(target.type))return;const targetId=target.id;mediaSourceDialog.replaceChildren();const title=document.createElement('h3');title.textContent='مصدر الصورة أو الفيديو';title.style.color='#87652d';const statusText=document.createElement('p');statusText.style.cssText='font-size:12px;line-height:1.7;color:#7d6a49';function sourceButton(label,fn){const b=document.createElement('button');b.textContent=label;b.style.cssText='display:block;width:100%;margin:9px 0';b.onclick=fn;mediaSourceDialog.append(b);return b;}mediaSourceDialog.append(title);
    sourceButton('من مكتبة سابابيس',async()=>{const provider=cloudProvider();if(!provider?.getLibrary){statusText.textContent='مكتبة سابابيس غير متصلة بعد. لم نعرض المكتبة المحلية باعتبارها مكتبة سحابية.';return;}try{const data=await provider.getLibrary();if(!validLibrary(data))throw Error();const list=document.createElement('div');const heading=document.createElement('h4');heading.textContent='اختر الميديا';list.append(heading);const media=data.media.filter(m=>m.src&&['image','video'].includes(m.type));if(!media.length){const empty=document.createElement('p');empty.textContent='لا توجد صور أو فيديوهات محفوظة في المكتبة المركزية.';list.append(empty);}media.forEach(record=>{const b=document.createElement('button');b.textContent=record.name||record.type;b.style.cssText='display:block;width:100%;margin:6px 0';b.onclick=()=>{applyChosenMedia(targetId,record);mediaSourceDialog.close();};list.append(b);});mediaSourceDialog.querySelector('[data-media-list]')?.remove();list.dataset.mediaList='true';mediaSourceDialog.append(list);}catch(e){statusText.textContent='تعذر تحميل المكتبة المركزية، ولم تُعرض بيانات بديلة.';}});
    sourceButton('من الجهاز',()=>{selected=targetId;replaceId=targetId;uploadOnlyCategory=null;mediaSourceDialog.close();document.getElementById('upload').accept='image/*,video/*';document.getElementById('upload').click();});
    const aiButton=sourceButton('من الذكاء الاصطناعي',async()=>{const provider=cloudProvider();if(!cloudLibraryReady||!provider?.generateMedia){statusText.textContent='خدمة التوليد والحفظ المركزي غير متصلة بعد.';return;}const description=prompt('وصف الصورة أو الفيديو المطلوب');if(!description?.trim())return;if(!confirm('إرسال طلب التوليد للخدمة المرتبطة؟ قد تكون هناك تكلفة حسب حسابك.'))return;aiButton.disabled=true;try{const record=await provider.generateMedia({prompt:description.trim(),category:itemCategory(target)});if(!record?.id||!record.src||!['image','video'].includes(record.type))throw Error();state.media.push(record);applyChosenMedia(targetId,record);await persistCloudLibrary();mediaSourceDialog.close();}catch(e){statusText.textContent='لم يتم تأكيد توليد الميديا وحفظها.';}finally{aiButton.disabled=false;}});mediaSourceDialog.append(statusText);sourceButton('إلغاء',()=>mediaSourceDialog.close());mediaSourceDialog.showModal();}
    const menuBeforeMediaSources=showMenu;showMenu=function(e){menuBeforeMediaSources(e);const button=Array.from(menu.children).find(b=>b.textContent==='رفع صورة أو فيديو داخل العناصر أو الهيرو');if(button){button.disabled=!current()||!['card','section','image','video'].includes(current().type);button.onclick=()=>{menu.style.display='none';chooseMediaSource();};}};caption.textContent='VISUAL EDITOR · MEDIA SOURCES';
    
    
    </script><script>
    // Integration shell: existing standalone editing remains separate and unchanged.
    const bridgeProtocol='elan-editor-bridge/v1';let liveMode=false,bridgeReady=false,bridgeSession='',bridgeOrigin='',bridgeRevision=null,bridgeDirty=false;const bridgePending=new Map();let bridgeTimeout=null;
    const livePanel=document.createElement('section');livePanel.style.cssText='padding:10px 20px;background:#fffaf0;border-bottom:1px solid #c2a66a';const address=document.createElement('input');address.type='url';address.value=location.origin+'/';address.style.cssText='width:min(480px,70vw);direction:ltr';const openLive=document.createElement('button');openLive.textContent='فتح المنصة داخل الإديتور';const localButton=document.createElement('button');localButton.textContent='المحرر المستقل';const bridgeStatus=document.createElement('span');bridgeStatus.style.cssText='display:block;font-size:12px;margin-top:8px';bridgeStatus.textContent='الموقع لا يصبح قابلًا للتعديل قبل تثبيت الربط داخل إيلان سنتس.';livePanel.append(address,openLive,localButton,bridgeStatus);document.querySelector('header').after(livePanel);
    const liveArea=document.createElement('section');liveArea.hidden=true;const liveTools=document.createElement('div');liveTools.style.cssText='display:flex;gap:6px;flex-wrap:wrap;padding:10px;background:#fffdf8';const liveFrame=document.createElement('iframe');liveFrame.title='إيلان سنتس، وضع التحرير';liveFrame.referrerPolicy='strict-origin-when-cross-origin';liveFrame.style.cssText='display:block;width:100%;height:calc(100vh - 230px);border:0;background:white';liveArea.append(liveTools,liveFrame);livePanel.after(liveArea);const originalHeaderButtons=Array.from(document.querySelectorAll('header button'));const localViewport=document.getElementById('viewport');const localHint=document.getElementById('hint');let selectedLive=null;
    function markBridge(text){bridgeStatus.textContent=text;status.textContent=text;liveTools.querySelectorAll('button').forEach(b=>b.disabled=!bridgeReady);}
    function requestLive(action,payload={}){if(!bridgeReady)return Promise.reject(Error('المنصة غير متصلة بوضع التحرير'));const id=crypto.randomUUID();return new Promise((resolve,reject)=>{const timer=setTimeout(()=>{bridgePending.delete(id);reject(Error('لم يصل تأكيد التنفيذ. لا نفترض نجاح الحفظ؛ تحقّق من الإصدار قبل إعادة المحاولة.'));},20000);bridgePending.set(id,{resolve,reject,timer});liveFrame.contentWindow.postMessage({protocol:bridgeProtocol,type:'request',session:bridgeSession,id,action,payload,expectedRevision:bridgeRevision},bridgeOrigin);});}
    async function runLive(action,payload={}){try{const result=await requestLive(action,payload);if(action==='page.save'){if(result?.revision===undefined||result?.published!==true)throw Error('لم يصل تأكيد نشر الإصدار');bridgeRevision=result.revision;bridgeDirty=false;markBridge('تم تأكيد الحفظ والنشر، الإصدار '+bridgeRevision);}return result;}catch(e){markBridge(e.message);return null;}}
    function tool(label,action,payload){const b=document.createElement('button');b.textContent=label;b.disabled=true;b.onclick=()=>runLive(action,typeof payload==='function'?payload():payload||{});liveTools.append(b);}
    tool('↶ تراجع','history.undo');tool('↷ إعادة','history.redo');const saveBtn=document.createElement('button');saveBtn.textContent='حفظ';saveBtn.disabled=true;saveBtn.onclick=()=>saveLive();liveTools.append(saveBtn);tool('المكتبة','library.open');tool('تنسيق العنصر','ui.openFormatPanel',()=>({elementId:selectedLive?.id}));tool('مصدر الصورة أو الفيديو','ui.openMediaPanel',()=>({elementId:selectedLive?.id,sources:['central_library','device_upload','configured_ai_generator']}));['section','perfume','brand','store','occasion','note','banner','text_block'].forEach((kind,n)=>tool(['إنشاء سيكشن','إنشاء كارت عطر','إنشاء براند','إنشاء متجر','إنشاء مناسبة','إنشاء نوتة','إنشاء بانر','إنشاء كتلة نصية'][n],'ui.openCreatePanel',{kind,schemaReferenceId:'elan-merchant-schema-v1'}));tool('حذف إلى الأرشيف','element.archive',()=>({elementId:selectedLive?.id}));
    tool('استعادة من الأرشيف','archive.restore',null);
    liveTools.lastChild.onclick=async()=>{const st=await runLive('page.getState');if(!st)return;if(!st.archive.length){markBridge('الأرشيف فاضي.');return;}const pick=prompt('اكتبي رقم العنصر لاستعادته:\n'+st.archive.map((a,i)=>(i+1)+'. '+a.name).join('\n'));const n=parseInt(pick,10);if(n>=1&&n<=st.archive.length)runLive('archive.restore',{elementId:st.archive[n-1].id});};
    const deviceBox=document.createElement('span');deviceBox.style.cssText='margin-inline-start:auto;display:flex;gap:6px';[['لاب','100%'],['تابلت','820px'],['موبايل','390px']].forEach(([label,w])=>{const b=document.createElement('button');b.textContent=label;b.onclick=()=>{liveFrame.style.width=w;liveFrame.style.margin='0 auto';liveFrame.style.borderInline=w==='100%'?'0':'1px solid #c2a66a';};deviceBox.append(b);});liveTools.append(deviceBox);
    const refreshBtn=document.createElement('button');refreshBtn.textContent='تحديث';refreshBtn.title='يتأكد إن النشر خلص ويعيد تحميل الصفحة على آخر نسخة';refreshBtn.onclick=()=>refreshLive();liveTools.append(refreshBtn);
    
    
    const SAVE_ERR={conflict:'حد غيّر الصفحة وإنتي بتعدّلي. دوسي تحديث وجرّبي تاني.',unauthorized:'انتهت الجلسة، سجّلي الدخول من جديد.',editor_not_configured:'إعدادات الإديتور ناقصة على Railway.',main_not_allowed:'الحفظ على main مقفول.',github_auth_failed:'مفتاح GitHub مش شغال أو صلاحيته ناقصة.',invalid_design:'في تعديل مش مسموح (راجعي الألوان والروابط).',branch_not_found:'الفرع المطلوب مش موجود على GitHub.'};
    
    const stageBox=document.createElement('span');stageBox.style.cssText='display:flex;gap:6px;margin-inline-start:8px';
    const stage=(txt)=>{const c=document.createElement('span');c.textContent=txt;c.style.cssText='font-size:12px;padding:3px 9px;border-radius:99px;border:1px solid #685b41;color:#8c8068';return c;};
    const chipUp=stage('رفع على GitHub'),chipPub=stage('نشر على Railway'),chipLoad=stage('تحميل النسخة الجديدة');stageBox.append(chipUp,chipPub,chipLoad);
    function setStages(n){[chipUp,chipPub,chipLoad].forEach((c,i)=>{const on=i<n;c.style.color=on?'#d7f2c4':'#8c8068';c.style.borderColor=on?'#7ab35b':'#685b41';c.textContent=(on?'✔ ':'')+['رفع على GitHub','نشر على Railway','تحميل النسخة الجديدة'][i];});}
    status.after(stageBox);
    const logoutBtn=document.createElement('button');logoutBtn.textContent='خروج';logoutBtn.style.cssText='background:#302b23;border:1px solid #685b41;color:#efe4cc;border-radius:8px;padding:6px 12px';logoutBtn.onclick=async()=>{if(bridgeDirty&&!confirm('في تعديلات لسه ما اتحفظتش. تخرجي برضه؟'))return;try{await fetch('/api/editor-logout',{method:'POST'});}catch(_){}document.body.textContent='';location.replace('/editor');};
    status.after(logoutBtn);
    let publishWatch=null,pendingLoadStage=false;
    async function waitPublished(revision){for(let i=0;i<60;i++){await new Promise(r=>setTimeout(r,5000));try{const r=await fetch('/api/editor',{method:'POST',headers:{'Content-Type':'application/json'},credentials:'same-origin',body:JSON.stringify({action:'status',revision})});if(r.status===401)throw Error(SAVE_ERR.unauthorized);const j=await r.json();if(j.ok&&j.published)return true;}catch(e){if(e.message===SAVE_ERR.unauthorized)throw e;}}return false;}
    async function saveLive(){if(!bridgeReady)return markBridge('المنصة غير متصلة بوضع التحرير');setStages(0);markBridge('جاري الحفظ...');try{const st=await requestLive('page.getState');const rid=crypto.randomUUID().replace(/-/g,'');const r=await fetch('/api/editor',{method:'POST',headers:{'Content-Type':'application/json'},credentials:'same-origin',body:JSON.stringify({action:'save',design:st.design,expectedRevision:st.revision==='initial'?null:st.revision,requestId:rid})});const j=await r.json().catch(()=>({}));if(!r.ok||!j.ok)throw Error(SAVE_ERR[j.error]||('تعذّر الحفظ ('+(j.error||r.status)+')'));await requestLive('page.markSaved',{revision:j.revision});bridgeRevision=j.revision;bridgeDirty=false;if(!j.committed){markBridge('مفيش تغيير جديد للحفظ.');return;}setStages(1);markBridge('تم الرفع على GitHub ✔ بستنى النشر على Railway...');const my=publishWatch=Symbol();const ok=await waitPublished(j.revision);if(publishWatch!==my)return;if(ok)setStages(2);markBridge(ok?'تم النشر على Railway ✔ دوسي تحديث لتحميل النسخة الجديدة.':'اتحفظ على GitHub بس النشر لسه ماتأكدش. دوسي تحديث بعد شوية.');}catch(e){markBridge(e.message);if(/GitHub/.test(e.message))explainGithub();}}
    async function explainGithub(){try{markBridge('بفحص سبب رفض GitHub...');const r=await fetch('/api/editor?action=diagnose',{credentials:'same-origin',cache:'no-store'});const j=await r.json();if(!j.ok)return markBridge('تعذّر الفحص ('+(j.error||r.status)+').');let eb=document.getElementById('liveError');if(!eb){eb=document.createElement('div');eb.id='liveError';eb.style.cssText='position:fixed;top:78px;left:50%;transform:translateX(-50%);z-index:60;background:#fbe9e7;color:#8a1c12;border:1px solid #d9a199;border-radius:10px;padding:12px 18px;max-width:80vw;font:15px Tahoma;box-shadow:0 8px 24px #0003;cursor:pointer';eb.title='اضغطي لإغلاق الرسالة';eb.onclick=()=>eb.remove();document.body.appendChild(eb);}eb.textContent='سبب رفض GitHub: '+j.verdict;markBridge(j.verdict);}catch(e){markBridge('تعذّر فحص GitHub.');}}
    async function refreshLive(){if(bridgeDirty&&!confirm('في تعديلات لسه ما اتحفظتش. التحديث هيمسحها. تكملي؟'))return;markBridge('بتأكد من النشر...');try{const ok=await waitPublished(bridgeRevision);if(!ok&&!confirm('النشر لسه ماتأكدش. أعيد التحميل برضه؟'))return;}catch(e){return markBridge(e.message);}pendingLoadStage=true;openLive.onclick();}
    
    /* The original right-click menu, shown over the platform page. Same entries, same look, same behaviour. */
    function showLiveMenu(info){const el=info&&info.element;selectedLive=el||null;const r=liveFrame.getBoundingClientRect();menu.replaceChildren();const at={x:info.x,y:info.y};
    (info.tools||[]).forEach(t=>action(t.label,()=>{if(t.ui==='format')openLiveFormat();else if(t.ui==='media'&&window.elanLiveMedia)window.elanLiveMedia(el);else if(t.ui==='media_new'&&window.elanLiveMediaNew)window.elanLiveMediaNew(t,at);else runLive('tool.run',{id:t.id,elementId:el&&el.id,at});},t.enabled));
    menu.style.display='block';const mr=menu.getBoundingClientRect();menu.style.left=Math.max(4,Math.min(r.left+info.x,innerWidth-mr.width-8))+'px';menu.style.top=Math.max(4,Math.min(r.top+info.y,innerHeight-mr.height-8))+'px';}
    function openLiveFormat(){const s=selectedLive&&selectedLive.style;if(!s)return;const hex=v=>/^#[0-9a-f]{6}$/i.test(v||'')?v:null;const fontSel=document.getElementById('font');const fam=(s.fontFamily||'Tahoma').replace(/["']/g,'');if(![...fontSel.options].some(o=>o.value===fam)){const o=document.createElement('option');o.value=fam;o.textContent=fam;fontSel.append(o);}fontSel.value=fam;document.getElementById('size').value=s.fontSize||24;document.getElementById('color').value=hex(s.color)||'#222222';document.getElementById('bg').value=hex(s.background)||'#fffdf9';document.getElementById('align').value=s.align||'right';try{effectSelect.value=s.effect||'none';}catch(_){}window.liveFormatInitial={color:document.getElementById('color').value,bg:document.getElementById('bg').value};document.getElementById('format').showModal();try{updatePanelPreview();}catch(_){}}
    document.getElementById('apply').addEventListener('click',e=>{if(!liveMode)return;e.stopImmediatePropagation();e.preventDefault();if(!selectedLive)return;const fonts=fontDefinitions.flatMap(g=>g[1]);const init=window.liveFormatInitial||{};const style={fontSize:Math.max(8,Math.min(120,Math.round(Number(document.getElementById('size').value)||24))),align:document.getElementById('align').value};if(document.getElementById('color').value!==init.color)style.color=document.getElementById('color').value;if(document.getElementById('bg').value!==init.bg)style.background=document.getElementById('bg').value;const f=document.getElementById('font').value;if(fonts.includes(f))style.fontFamily=f;try{style.effect=effectSelect.value;}catch(_){}document.getElementById('format').close();runLive('element.format',{elementId:selectedLive.id,style});},true);
    [['undo',()=>runLive('history.undo')],['redo',()=>runLive('history.redo')],['save',()=>saveLive()],['library',()=>runLive('library.open')]].forEach(([id,fn])=>document.getElementById(id).addEventListener('click',e=>{if(!liveMode)return;e.stopImmediatePropagation();e.preventDefault();fn();},true));
    window.addEventListener('blur',()=>{if(liveMode)menu.style.display='none';});
    Array.from(liveTools.children).forEach(c=>{if(c!==deviceBox&&c!==refreshBtn)c.hidden=true;});
    function abandonBridge(){bridgeReady=false;try{clearInterval(helloTimer);}catch(_){}clearTimeout(bridgeTimeout);bridgePending.forEach(p=>{clearTimeout(p.timer);p.reject(Error('تم إغلاق الاتصال'));});bridgePending.clear();}
    openLive.onclick=()=>{if(bridgeDirty&&!confirm('توجد تعديلات لم يُؤكد حفظها. إعادة فتح الصفحة قد تفقدها. المتابعة؟'))return;let url;try{url=new URL(address.value);if(url.protocol!=='https:'&&!(url.protocol==='http:'&&/^(127\.0\.0\.1|localhost)$/.test(url.hostname)))throw Error();}catch(e){alert('أدخل رابط HTTPS صحيحًا للمنصة');return;}abandonBridge();bridgeSession=crypto.randomUUID();bridgeOrigin=url.origin;bridgeDirty=false;selectedLive=null;liveMode=true;liveArea.hidden=false;localViewport.hidden=true;if(localHint)localHint.hidden=true;originalHeaderButtons.forEach(b=>{b.hidden=false;b.disabled=false;});menu.style.display='none';url.searchParams.set('elan_editor','1');liveFrame.src=url.href;markBridge('جارٍ فتح الموقع. العرض داخل النافذة لا يعني أن الربط أو الحفظ يعمل.');};
    let helloTimer=null;liveFrame.onload=()=>{if(!liveMode)return;const hello=()=>{try{liveFrame.contentWindow.postMessage({protocol:bridgeProtocol,type:'hello',session:bridgeSession},bridgeOrigin);}catch(_){}};hello();clearInterval(helloTimer);helloTimer=setInterval(()=>{if(bridgeReady||!liveMode){clearInterval(helloTimer);return;}hello();},700);clearTimeout(bridgeTimeout);bridgeTimeout=setTimeout(()=>{if(!bridgeReady)markBridge('لم يصل تأكيد اتصال: قد يحتاج الموقع تفعيل الربط وتسجيل دخول الإدارة أو السماح بعرضه داخل الإديتور. أدوات التعديل متوقفة.');},12000);};
    window.addEventListener('message',e=>{const m=e.data;if(!liveMode||e.source!==liveFrame.contentWindow||e.origin!==bridgeOrigin||m?.protocol!==bridgeProtocol||m.session!==bridgeSession)return;if(m.type==='ready'&&m.authorized===true&&m.page?.revision!==undefined){clearTimeout(bridgeTimeout);bridgeReady=true;bridgeRevision=m.page.revision;markBridge('متصل بوضع التحرير، الإصدار المنشور '+bridgeRevision);{const eb=document.getElementById('liveError');if(eb)eb.remove();}if(pendingLoadStage){pendingLoadStage=false;setStages(3);markBridge('تم تحميل صفحة جديدة من النسخة المحدثة ✔');}}else if(m.type==='denied'){abandonBridge();const why=(typeof m.message==='string'&&/[\u0600-\u06FF]/.test(m.message)&&m.message.length<300)?m.message:'وضع التحرير غير جاهز أو حساب الإدارة غير مصرح له.';markBridge(why);let eb=document.getElementById('liveError');if(!eb){eb=document.createElement('div');eb.id='liveError';eb.style.cssText='position:fixed;top:78px;left:50%;transform:translateX(-50%);z-index:60;background:#fbe9e7;color:#8a1c12;border:1px solid #d9a199;border-radius:10px;padding:12px 18px;max-width:80vw;font:15px Tahoma;box-shadow:0 8px 24px #0003';document.body.appendChild(eb);}eb.textContent='أدوات التحرير لسه مش شغالة: '+why;}else if(bridgeReady&&m.type==='selection'){selectedLive=m.element;bridgeStatus.textContent='العنصر المحدد: '+(selectedLive?.name||selectedLive?.id||'لا يوجد');menu.style.display='none';}else if(bridgeReady&&m.type==='context'){showLiveMenu(m.info);}else if(bridgeReady&&m.type==='dirty'){bridgeDirty=!!m.dirty;bridgeStatus.textContent=bridgeDirty?'تعديلات غير محفوظة على المنصة.':'لا توجد تعديلات معلقة.';status.textContent=bridgeDirty?'تعديلات غير محفوظة':'محفوظ';}else if(bridgeReady&&m.type==='revision'){bridgeRevision=m.revision;}else if(m.type==='response'){const p=bridgePending.get(m.id);if(!p)return;clearTimeout(p.timer);bridgePending.delete(m.id);m.ok?p.resolve(m.result):p.reject(Error(m.error||'فشل التنفيذ'));}});
    localButton.onclick=()=>{if(bridgeDirty&&!confirm('تعديلات المنصة لم يُؤكد حفظها. الخروج؟'))return;abandonBridge();liveMode=false;liveArea.hidden=true;liveFrame.src='about:blank';localViewport.hidden=false;if(localHint)localHint.hidden=false;originalHeaderButtons.forEach(b=>b.hidden=false);markBridge('المحرر المستقل، ليس صفحة المنصة الحقيقية ولا دليلًا على الحفظ المركزي.');};
    window.addEventListener('beforeunload',e=>{if(bridgeDirty||bridgePending.size){e.preventDefault();e.returnValue='';}});
    address.hidden=true;openLive.hidden=true;localButton.hidden=true;bridgeStatus.textContent='جاري فتح الموقع...';setTimeout(()=>openLive.onclick(),0);
    window.elanLiveEditorBridge={request:requestLive,getState:()=>({connected:bridgeReady,revision:bridgeRevision,dirty:bridgeDirty})};
    caption.textContent='VISUAL EDITOR · LIVE PLATFORM BRIDGE';
    
    </script></body></html>
    
  operator: 'match'
  stack: |-
    TestContext.<anonymous> (/home/ubuntu/elan-scents/tests/editor-host.test.js:139:10)
    Test.runInAsyncScope (node:async_hooks:211:14)
    Test.run (node:internal/test_runner/test:931:25)
    Test.processPendingSubtests (node:internal/test_runner/test:629:18)
    Test.postRun (node:internal/test_runner/test:1042:19)
    Test.run (node:internal/test_runner/test:970:12)
    process.processTicksAndRejections (node:internal/process/task_queues:105:5)
    async Test.processPendingSubtests (node:internal/test_runner/test:629:7)
  ...
# Subtest: moving is a one-shot tool chosen from the menu: no drag without it, no arrow keys, it ends on release
ok 70 - moving is a one-shot tool chosen from the menu: no drag without it, no arrow keys, it ends on release
  ---
  duration_ms: 2.285231
  ...
# Subtest: inner pages keep their own edits, separate from the home page
not ok 71 - inner pages keep their own edits, separate from the home page
  ---
  duration_ms: 1.368443
  location: '/home/ubuntu/elan-scents/tests/editor-host.test.js:156:1'
  failureType: 'testCodeFailure'
  error: |-
    Expected values to be strictly equal:
    
    false !== true
    
  code: 'ERR_ASSERTION'
  name: 'AssertionError'
  expected: true
  actual: false
  operator: 'strictEqual'
  stack: |-
    TestContext.<anonymous> (/home/ubuntu/elan-scents/tests/editor-host.test.js:159:10)
    Test.runInAsyncScope (node:async_hooks:211:14)
    Test.run (node:internal/test_runner/test:931:25)
    Test.processPendingSubtests (node:internal/test_runner/test:629:18)
    Test.postRun (node:internal/test_runner/test:1042:19)
    Test.run (node:internal/test_runner/test:970:12)
    process.processTicksAndRejections (node:internal/process/task_queues:105:5)
    async Test.processPendingSubtests (node:internal/test_runner/test:629:7)
  ...
# Subtest: edit mode lets a plain click enter a dynamic page and tracks which page is being edited
ok 72 - edit mode lets a plain click enter a dynamic page and tracks which page is being edited
  ---
  duration_ms: 0.470193
  ...
# Subtest: editor data requires authentication and the retired records endpoint stays unavailable
ok 73 - editor data requires authentication and the retired records endpoint stays unavailable
  ---
  duration_ms: 23.221596
  ...
# Subtest: editor login reports role-check failures separately from wrong passwords
not ok 74 - editor login reports role-check failures separately from wrong passwords
  ---
  duration_ms: 6.167477
  location: '/home/ubuntu/elan-scents/tests/editor-login-errors.test.js:10:1'
  failureType: 'testCodeFailure'
  error: |-
    Expected values to be strictly deep-equal:
    + actual - expected
    
      {
    +   error: 'forbidden',
    +   status: 403
    -   error: 'role_check_failed',
    -   status: 502
      }
    
  code: 'ERR_ASSERTION'
  name: 'AssertionError'
  expected:
    status: 502
    error: 'role_check_failed'
  actual:
    status: 403
    error: 'forbidden'
  operator: 'deepStrictEqual'
  stack: |-
    TestContext.<anonymous> (/home/ubuntu/elan-scents/tests/editor-login-errors.test.js:34:12)
    async Test.run (node:internal/test_runner/test:932:9)
    async startSubtestAfterBootstrap (node:internal/test_runner/harness:296:3)
  ...
# Subtest: edits may replace the media of an element with an allowed url only
not ok 75 - edits may replace the media of an element with an allowed url only
  ---
  duration_ms: 4.611187
  location: '/home/ubuntu/elan-scents/tests/editor-media-edit.test.js:6:1'
  failureType: 'testCodeFailure'
  error: |-
    edits.all.hero.media: not editable,edits.all.sec:cats.media: not editable
    
    false !== true
    
  code: 'ERR_ASSERTION'
  name: 'AssertionError'
  expected: true
  actual: false
  operator: 'strictEqual'
  stack: |-
    TestContext.<anonymous> (/home/ubuntu/elan-scents/tests/editor-media-edit.test.js:8:10)
    Test.runInAsyncScope (node:async_hooks:211:14)
    Test.run (node:internal/test_runner/test:931:25)
    Test.start (node:internal/test_runner/test:829:17)
    startSubtestAfterBootstrap (node:internal/test_runner/harness:296:17)
  ...
# Subtest: uploads accept real mp4 and webm files, nothing else posing as video
not ok 76 - uploads accept real mp4 and webm files, nothing else posing as video
  ---
  duration_ms: 14.12007
  location: '/home/ubuntu/elan-scents/tests/editor-media-edit.test.js:16:1'
  failureType: 'testCodeFailure'
  error: |-
    The expression evaluated to a falsy value:
    
      assert.ok(media.looksLike(Buffer.concat([Buffer.from([0, 0, 0, 24]), Buffer.from('ftypmp42')]), 'video/mp4'))
    
  code: 'ERR_ASSERTION'
  name: 'AssertionError'
  expected: true
  actual: false
  operator: '=='
  stack: |-
    TestContext.<anonymous> (/home/ubuntu/elan-scents/tests/editor-media-edit.test.js:17:10)
    Test.runInAsyncScope (node:async_hooks:211:14)
    Test.run (node:internal/test_runner/test:931:25)
    Test.processPendingSubtests (node:internal/test_runner/test:629:18)
    Test.postRun (node:internal/test_runner/test:1042:19)
    Test.run (node:internal/test_runner/test:970:12)
    async startSubtestAfterBootstrap (node:internal/test_runner/harness:296:3)
  ...
# Subtest: the storefront layer paints replaced media and the live edit mode can set it
not ok 77 - the storefront layer paints replaced media and the live edit mode can set it
  ---
  duration_ms: 3.402701
  location: '/home/ubuntu/elan-scents/tests/editor-media-edit.test.js:23:1'
  failureType: 'testCodeFailure'
  error: |-
    The input did not match the regular expression /function paintMedia\(entry, m\)/. Input:
    
    '/* Élan Scents — storefront design layer.\n' +
      '   Reads /design/home.json and applies it on top of the existing page after every render().\n' +
      '   Safe by construction: if the file is missing, invalid or empty, the page is left exactly as it is. */\n' +
      '(function () {\n' +
      "  'use strict';\n" +
      '  var ED = window.ElanDesign;\n' +
      '  if (!ED) return;\n' +
      '\n' +
      '  var design = null;\n' +
      '  var editing = false;\n' +
      '  var touched = [];\n' +
      '  var lastDevice = null;\n' +
      "  var SEC_NAMES = { brands: 'الماركات', offers: 'العروض', new: 'وصل حديثًا', cats: 'الأقسام', master: 'الأعلى مبيعًا', occ: 'المناسبات', notes: 'النوتات العطرية', soon: 'قريبًا', stores: 'المتاجر' };\n" +
      "  var STYLE_ID = 'elan-design-style';\n" +
      '  var CSS = [\n' +
      "    '.elan-block{max-width:900px;margin:18px auto;padding:0 16px;box-sizing:border-box}',\n" +
      "    '.elan-align-start{text-align:start}.elan-align-center{text-align:center}.elan-align-end{text-align:end}',\n" +
      "    '.elan-text p{margin:0;line-height:1.9;white-space:pre-line}',\n" +
      "    '.elan-size-sm p,.elan-size-sm h3{font-size:14px}.elan-size-md p,.elan-size-md h3{font-size:17px}',\n" +
      "    '.elan-size-lg p,.elan-size-lg h3{font-size:22px}.elan-size-xl p,.elan-size-xl h3{font-size:30px}',\n" +
      "    '.elan-banner{position:relative;overflow:hidden;border-radius:14px;padding:36px 20px;background-size:cover;background-position:center}',\n" +
      `    '.elan-banner:before{content:"";position:absolute;inset:0;background:rgba(20,12,4,.35)}',\n` +
      "    '.elan-banner>*{position:relative}.elan-banner h3,.elan-banner p{margin:6px 0;color:#fff}',\n" +
      "    '.elan-image img{max-width:100%;height:auto;display:block;margin:0 auto;border-radius:12px}',\n" +
      "    '.elan-block a{color:inherit;text-decoration:none;display:block}',\n" +
      "    '.elan-smart{max-width:1200px}.elan-smart h3{margin:0 0 12px;text-align:start}'\n" +
      "  ].join('\\n');\n" +
      '\n' +
      "  function lang() { return document.documentElement.lang === 'en' ? 'en' : 'ar'; }\n" +
      "  function pick(o) { return o ? (o[lang()] || o.ar || o.en || '') : ''; }\n" +
      '\n' +
      '  function ensureStyle() {\n' +
      '    if (document.getElementById(STYLE_ID)) return;\n' +
      "    var s = document.createElement('style');\n" +
      '    s.id = STYLE_ID;\n' +
      '    s.textContent = CSS;\n' +
      '    document.head.appendChild(s);\n' +
      '  }\n' +
      '\n' +
      '  function el(tag, cls) {\n' +
      '    var e = document.createElement(tag);\n' +
      '    if (cls) e.className = cls;\n' +
      '    return e;\n' +
      '  }\n' +
      '\n' +
      '\n' +
      '  // ----- smart sections: definition + items live in Supabase (public read; RLS hides archived/expired ones) -----\n' +
      '  var smartCache = {};\n' +
      '  window.ElanPendingSections = window.ElanPendingSections || {};   // edit mode only: drafts not saved yet\n' +
      '  function perfumeBy(id) { try { return PERFUMES.filter(function (x) { return String(x.id) === String(id); })[0] || null; } catch (e) { return null; } }\n' +
      '  function autoList(f) {\n' +
      '    f = f || {};\n' +
      '    var l = [];\n' +
      '    try { l = PERFUMES.map(function (p) { return { p: p, b: best(p) }; }).filter(function (x) { return x.b; }); } catch (e) { return []; }\n' +
      '    l = l.filter(function (x) {\n' +
      '      var p = x.p;\n' +
      '      if (f.brand && p.brand !== f.brand) return false;\n' +
      "      if (f.cat && !(p.cats || []).some(function (i) { return nmOf('cats', i) === f.cat; })) return false;\n" +
      "      if (f.occ && !(p.occs || []).some(function (i) { return nmOf('occ', i) === f.occ; })) return false;\n" +
      "      if (f.note && !(p.notes || []).some(function (i) { return nmOf('notes', i) === f.note; })) return false;\n" +
      '      if (f.store && !p.offers.some(function (o) { return o.store === f.store; })) return false;\n' +
      '      if (f.flag && !p.offers.some(function (o) { return (o.flags || []).indexOf(f.flag) > -1; })) return false;\n' +
      "      if (f.min !== undefined && f.min !== '' && x.b.price < +f.min) return false;\n" +
      "      if (f.max !== undefined && f.max !== '' && x.b.price > +f.max) return false;\n" +
      '      return true;\n' +
      '    });\n' +
      "    if (f.sort === 'price_asc') l.sort(function (a, b) { return a.b.price - b.b.price; });\n" +
      "    else if (f.sort === 'price_desc') l.sort(function (a, b) { return b.b.price - a.b.price; });\n" +
      '    else l.sort(function (a, b) { return (b.p.rel || 0) - (a.p.rel || 0); });\n' +
      '    return l.slice(0, Math.max(1, Math.min(24, +f.limit || 12)));\n' +
      '  }\n' +
      '  function manualList(ids) {\n' +
      '    return ids.map(perfumeBy).filter(Boolean).map(function (p) { return { p: p, b: best(p) }; });\n' +
      '  }\n' +
      '  function paint(root, name, list) {\n' +
      "    root.textContent = '';\n" +
      "    if (name) { var h = el('h3'); h.textContent = name; root.appendChild(h); }\n" +
      "    var g = el('div', 'grid section-perfume-grid');\n" +
      "    g.innerHTML = list.map(function (x) { return pc(x); }).join('');   // pc() output is built from the storefront's own escaped data\n" +
      '    root.appendChild(g);\n' +
      '  }\n' +
      '  function fillSmart(root, ref) {\n' +
      '    var pend = window.ElanPendingSections[ref];\n' +
      "    if (pend) { paint(root, pend.name, pend.mode === 'auto' ? autoList(pend.filters) : manualList(pend.items || [])); return; }\n" +
      "    if (typeof SB === 'undefined' || !SB || !SB.url) { root.remove(); return; }\n" +
      '    var hit = smartCache[ref];\n' +
      '    if (hit && Date.now() - hit.t < 60000) { if (hit.def) paint(root, hit.def.name, hit.list()); else root.remove(); return; }\n' +
      "    var H = { apikey: SB.key, Authorization: 'Bearer ' + SB.key };\n" +
      "    fetch(SB.url + '/rest/v1/editor_sections?element_id=eq.' + encodeURIComponent(ref) + '&select=id,name,selection_mode,filters&limit=1', { headers: H })\n" +
      '      .then(function (r) { return r.ok ? r.json() : []; })\n' +
      '      .then(function (rows) {\n' +
      '        if (!rows.length) { smartCache[ref] = { t: Date.now(), def: null }; root.remove(); return null; }\n' +
      '        var def = rows[0];\n' +
      "        if (def.selection_mode === 'auto') { smartCache[ref] = { t: Date.now(), def: def, list: function () { return autoList(def.filters); } }; paint(root, def.name, autoList(def.filters)); return null; }\n" +
      "        return fetch(SB.url + '/rest/v1/editor_section_items?section_id=eq.' + def.id + '&select=product_size_id&order=sort_order', { headers: H })\n" +
      '          .then(function (r) { return r.ok ? r.json() : []; })\n' +
      '          .then(function (items) { var ids = items.map(function (i) { return i.product_size_id; }); smartCache[ref] = { t: Date.now(), def: def, list: function () { return manualList(ids); } }; paint(root, def.name, manualList(ids)); });\n' +
      '      })\n' +
      '      .catch(function () { root.remove(); });\n' +
      '  }\n' +
      '\n' +
      '  function buildBlock(b) {\n' +
      '    var st = b.style || {};\n' +
      "    var root = el('div', 'elan-block elan-' + b.type + ' elan-size-' + (st.size || 'md') + ' elan-align-' + (st.align || 'center'));\n" +
      "    root.setAttribute('data-elan-id', b.id);\n" +
      "    root.setAttribute('data-elan-custom', '1');\n" +
      '    if (st.color) root.style.color = st.color;\n' +
      '    if (st.background) root.style.backgroundColor = st.background;\n' +
      '    var inner = root;\n' +
      "    if (b.href && b.type !== 'smart') {\n" +
      "      var a = el('a');\n" +
      "      a.setAttribute('href', b.href);\n" +
      '      root.appendChild(a);\n' +
      '      inner = a;\n' +
      '    }\n' +
      "    if (b.type === 'smart') {\n" +
      "      root.classList.add('elan-smart');\n" +
      '      fillSmart(root, b.ref);\n' +
      "    } else if (b.type === 'text') {\n" +
      "      var p = el('p');\n" +
      '      p.textContent = pick(b.text);\n' +
      '      inner.appendChild(p);\n' +
      "    } else if (b.type === 'banner') {\n" +
      `      if (b.image) root.style.backgroundImage = 'url("' + b.image + '")';\n` +
      '      var t = pick(b.title);\n' +
      '      var s = pick(b.subtitle);\n' +
      "      if (t) { var h = el('h3'); h.textContent = t; inner.appendChild(h); }\n" +
      "      if (s) { var sp = el('p'); sp.textContent = s; inner.appendChild(sp); }\n" +
      "    } else if (b.type === 'image') {\n" +
      "      var img = el('img');\n" +
      "      img.setAttribute('src', b.src);\n" +
      "      img.setAttribute('alt', pick(b.alt));\n" +
      "      img.setAttribute('loading', 'lazy');\n" +
      '      inner.appendChild(img);\n' +
      '    }\n' +
      '    return root;\n' +
      '  }\n' +
      '\n' +
      '  function hash(str) { var h = 5381, i; for (i = 0; i < str.length; i++) h = ((h << 5) + h + str.charCodeAt(i)) >>> 0; return h.toString(36); }\n' +
      '\n' +
      '  /* Every element the editor can touch, with a stable id that does not change between renders. */\n' +
      "  var SERIF = { 'Amiri': 1, 'Noto Naskh Arabic': 1, 'Playfair Display': 1, 'Cormorant Garamond': 1, 'Libre Baskerville': 1, 'Merriweather': 1, 'Georgia': 1, 'Times New Roman': 1 };\n" +
      '  var loadedFonts = {};\n' +
      '  function loadFont(name) {                       // adds one Google Fonts stylesheet per web font that is actually used\n' +
      '    if (loadedFonts[name] || ED.WEB_FONTS.indexOf(name) === -1) return;\n' +
      '    loadedFonts[name] = 1;\n' +
      "    var l = document.createElement('link'); l.rel = 'stylesheet';\n" +
      "    l.href = 'https://fonts.googleapis.com/css2?family=' + name.replace(/ /g, '+') + ':wght@400;700&display=swap';\n" +
      '    document.head.appendChild(l);\n' +
      '  }\n' +
      '  function elements() {\n' +
      '    var out = [], seen = {};\n' +
      '    function add(id, el, kind, name) { if (!el || seen[id]) return; seen[id] = 1; out.push({ id: id, el: el, kind: kind, name: name }); }\n' +
      "    var hero = document.getElementById('hero');\n" +
      '    if (hero) {\n' +
      "      add('hero', hero, 'hero', 'الواجهة الرئيسية');\n" +
      "      add('hero:magic', hero.querySelector('.magic'), 'hero-text', 'نص الواجهة');\n" +
      "      add('hero:counters', hero.querySelector('.counters'), 'hero-counters', 'العدّادات');\n" +
      '    }\n' +
      "    var V = document.getElementById('view');\n" +
      "    if (V && document.body.classList.contains('inner')) {\n" +
      "      var pk = hash(pageKey() || 'page'), vn = 0;\n" +
      "      var vt = V.querySelector('h3'); if (vt) add('pg:' + pk + ':title', vt, 'title', 'عنوان الصفحة');\n" +
      "      Array.prototype.slice.call(V.querySelectorAll('[data-elan-custom]')).forEach(function (b) { add(b.getAttribute('data-elan-id'), b, 'block', 'بلوك إضافي'); });\n" +
      "      Array.prototype.slice.call(V.querySelectorAll('.card')).forEach(function (card, i) {\n" +
      "        var base = 'pcard:' + pk + hash(card.getAttribute('data-go') || 'i' + i), id = base;\n" +
      "        while (seen[id]) id = base + '-' + (++vn);\n" +
      "        var h4 = card.querySelector('h4');\n" +
      "        add(id, card, 'card', 'كارت ' + ((h4 && h4.textContent.trim().slice(0, 24)) || (i + 1)));\n" +
      '      });\n' +
      '    }\n' +
      "    var main = document.getElementById('main');\n" +
      '    if (!main) return out;\n' +
      '    Array.prototype.slice.call(main.children).forEach(function (c) {\n' +
      "      if (c.hasAttribute('data-elan-custom')) { add(c.getAttribute('data-elan-id'), c, 'block', 'بلوك إضافي'); return; }\n" +
      "      if (c.tagName !== 'SECTION' || !c.id || ED.BUILTIN.indexOf(c.id) === -1) return;\n" +
      '      add('... 10270 more characters
    
  code: 'ERR_ASSERTION'
  name: 'AssertionError'
  expected:
  actual: |-
    /* Élan Scents — storefront design layer.
       Reads /design/home.json and applies it on top of the existing page after every render().
       Safe by construction: if the file is missing, invalid or empty, the page is left exactly as it is. */
    (function () {
      'use strict';
      var ED = window.ElanDesign;
      if (!ED) return;
    
      var design = null;
      var editing = false;
      var touched = [];
      var lastDevice = null;
      var SEC_NAMES = { brands: 'الماركات', offers: 'العروض', new: 'وصل حديثًا', cats: 'الأقسام', master: 'الأعلى مبيعًا', occ: 'المناسبات', notes: 'النوتات العطرية', soon: 'قريبًا', stores: 'المتاجر' };
      var STYLE_ID = 'elan-design-style';
      var CSS = [
        '.elan-block{max-width:900px;margin:18px auto;padding:0 16px;box-sizing:border-box}',
        '.elan-align-start{text-align:start}.elan-align-center{text-align:center}.elan-align-end{text-align:end}',
        '.elan-text p{margin:0;line-height:1.9;white-space:pre-line}',
        '.elan-size-sm p,.elan-size-sm h3{font-size:14px}.elan-size-md p,.elan-size-md h3{font-size:17px}',
        '.elan-size-lg p,.elan-size-lg h3{font-size:22px}.elan-size-xl p,.elan-size-xl h3{font-size:30px}',
        '.elan-banner{position:relative;overflow:hidden;border-radius:14px;padding:36px 20px;background-size:cover;background-position:center}',
        '.elan-banner:before{content:"";position:absolute;inset:0;background:rgba(20,12,4,.35)}',
        '.elan-banner>*{position:relative}.elan-banner h3,.elan-banner p{margin:6px 0;color:#fff}',
        '.elan-image img{max-width:100%;height:auto;display:block;margin:0 auto;border-radius:12px}',
        '.elan-block a{color:inherit;text-decoration:none;display:block}',
        '.elan-smart{max-width:1200px}.elan-smart h3{margin:0 0 12px;text-align:start}'
      ].join('\n');
    
      function lang() { return document.documentElement.lang === 'en' ? 'en' : 'ar'; }
      function pick(o) { return o ? (o[lang()] || o.ar || o.en || '') : ''; }
    
      function ensureStyle() {
        if (document.getElementById(STYLE_ID)) return;
        var s = document.createElement('style');
        s.id = STYLE_ID;
        s.textContent = CSS;
        document.head.appendChild(s);
      }
    
      function el(tag, cls) {
        var e = document.createElement(tag);
        if (cls) e.className = cls;
        return e;
      }
    
    
      // ----- smart sections: definition + items live in Supabase (public read; RLS hides archived/expired ones) -----
      var smartCache = {};
      window.ElanPendingSections = window.ElanPendingSections || {};   // edit mode only: drafts not saved yet
      function perfumeBy(id) { try { return PERFUMES.filter(function (x) { return String(x.id) === String(id); })[0] || null; } catch (e) { return null; } }
      function autoList(f) {
        f = f || {};
        var l = [];
        try { l = PERFUMES.map(function (p) { return { p: p, b: best(p) }; }).filter(function (x) { return x.b; }); } catch (e) { return []; }
        l = l.filter(function (x) {
          var p = x.p;
          if (f.brand && p.brand !== f.brand) return false;
          if (f.cat && !(p.cats || []).some(function (i) { return nmOf('cats', i) === f.cat; })) return false;
          if (f.occ && !(p.occs || []).some(function (i) { return nmOf('occ', i) === f.occ; })) return false;
          if (f.note && !(p.notes || []).some(function (i) { return nmOf('notes', i) === f.note; })) return false;
          if (f.store && !p.offers.some(function (o) { return o.store === f.store; })) return false;
          if (f.flag && !p.offers.some(function (o) { return (o.flags || []).indexOf(f.flag) > -1; })) return false;
          if (f.min !== undefined && f.min !== '' && x.b.price < +f.min) return false;
          if (f.max !== undefined && f.max !== '' && x.b.price > +f.max) return false;
          return true;
        });
        if (f.sort === 'price_asc') l.sort(function (a, b) { return a.b.price - b.b.price; });
        else if (f.sort === 'price_desc') l.sort(function (a, b) { return b.b.price - a.b.price; });
        else l.sort(function (a, b) { return (b.p.rel || 0) - (a.p.rel || 0); });
        return l.slice(0, Math.max(1, Math.min(24, +f.limit || 12)));
      }
      function manualList(ids) {
        return ids.map(perfumeBy).filter(Boolean).map(function (p) { return { p: p, b: best(p) }; });
      }
      function paint(root, name, list) {
        root.textContent = '';
        if (name) { var h = el('h3'); h.textContent = name; root.appendChild(h); }
        var g = el('div', 'grid section-perfume-grid');
        g.innerHTML = list.map(function (x) { return pc(x); }).join('');   // pc() output is built from the storefront's own escaped data
        root.appendChild(g);
      }
      function fillSmart(root, ref) {
        var pend = window.ElanPendingSections[ref];
        if (pend) { paint(root, pend.name, pend.mode === 'auto' ? autoList(pend.filters) : manualList(pend.items || [])); return; }
        if (typeof SB === 'undefined' || !SB || !SB.url) { root.remove(); return; }
        var hit = smartCache[ref];
        if (hit && Date.now() - hit.t < 60000) { if (hit.def) paint(root, hit.def.name, hit.list()); else root.remove(); return; }
        var H = { apikey: SB.key, Authorization: 'Bearer ' + SB.key };
        fetch(SB.url + '/rest/v1/editor_sections?element_id=eq.' + encodeURIComponent(ref) + '&select=id,name,selection_mode,filters&limit=1', { headers: H })
          .then(function (r) { return r.ok ? r.json() : []; })
          .then(function (rows) {
            if (!rows.length) { smartCache[ref] = { t: Date.now(), def: null }; root.remove(); return null; }
            var def = rows[0];
            if (def.selection_mode === 'auto') { smartCache[ref] = { t: Date.now(), def: def, list: function () { return autoList(def.filters); } }; paint(root, def.name, autoList(def.filters)); return null; }
            return fetch(SB.url + '/rest/v1/editor_section_items?section_id=eq.' + def.id + '&select=product_size_id&order=sort_order', { headers: H })
              .then(function (r) { return r.ok ? r.json() : []; })
              .then(function (items) { var ids = items.map(function (i) { return i.product_size_id; }); smartCache[ref] = { t: Date.now(), def: def, list: function () { return manualList(ids); } }; paint(root, def.name, manualList(ids)); });
          })
          .catch(function () { root.remove(); });
      }
    
      function buildBlock(b) {
        var st = b.style || {};
        var root = el('div', 'elan-block elan-' + b.type + ' elan-size-' + (st.size || 'md') + ' elan-align-' + (st.align || 'center'));
        root.setAttribute('data-elan-id', b.id);
        root.setAttribute('data-elan-custom', '1');
        if (st.color) root.style.color = st.color;
        if (st.background) root.style.backgroundColor = st.background;
        var inner = root;
        if (b.href && b.type !== 'smart') {
          var a = el('a');
          a.setAttribute('href', b.href);
          root.appendChild(a);
          inner = a;
        }
        if (b.type === 'smart') {
          root.classList.add('elan-smart');
          fillSmart(root, b.ref);
        } else if (b.type === 'text') {
          var p = el('p');
          p.textContent = pick(b.text);
          inner.appendChild(p);
        } else if (b.type === 'banner') {
          if (b.image) root.style.backgroundImage = 'url("' + b.image + '")';
          var t = pick(b.title);
          var s = pick(b.subtitle);
          if (t) { var h = el('h3'); h.textContent = t; inner.appendChild(h); }
          if (s) { var sp = el('p'); sp.textContent = s; inner.appendChild(sp); }
        } else if (b.type === 'image') {
          var img = el('img');
          img.setAttribute('src', b.src);
          img.setAttribute('alt', pick(b.alt));
          img.setAttribute('loading', 'lazy');
          inner.appendChild(img);
        }
        return root;
      }
    
      function hash(str) { var h = 5381, i; for (i = 0; i < str.length; i++) h = ((h << 5) + h + str.charCodeAt(i)) >>> 0; return h.toString(36); }
    
      /* Every element the editor can touch, with a stable id that does not change between renders. */
      var SERIF = { 'Amiri': 1, 'Noto Naskh Arabic': 1, 'Playfair Display': 1, 'Cormorant Garamond': 1, 'Libre Baskerville': 1, 'Merriweather': 1, 'Georgia': 1, 'Times New Roman': 1 };
      var loadedFonts = {};
      function loadFont(name) {                       // adds one Google Fonts stylesheet per web font that is actually used
        if (loadedFonts[name] || ED.WEB_FONTS.indexOf(name) === -1) return;
        loadedFonts[name] = 1;
        var l = document.createElement('link'); l.rel = 'stylesheet';
        l.href = 'https://fonts.googleapis.com/css2?family=' + name.replace(/ /g, '+') + ':wght@400;700&display=swap';
        document.head.appendChild(l);
      }
      function elements() {
        var out = [], seen = {};
        function add(id, el, kind, name) { if (!el || seen[id]) return; seen[id] = 1; out.push({ id: id, el: el, kind: kind, name: name }); }
        var hero = document.getElementById('hero');
        if (hero) {
          add('hero', hero, 'hero', 'الواجهة الرئيسية');
          add('hero:magic', hero.querySelector('.magic'), 'hero-text', 'نص الواجهة');
          add('hero:counters', hero.querySelector('.counters'), 'hero-counters', 'العدّادات');
        }
        var V = document.getElementById('view');
        if (V && document.body.classList.contains('inner')) {
          var pk = hash(pageKey() || 'page'), vn = 0;
          var vt = V.querySelector('h3'); if (vt) add('pg:' + pk + ':title', vt, 'title', 'عنوان الصفحة');
          Array.prototype.slice.call(V.querySelectorAll('[data-elan-custom]')).forEach(function (b) { add(b.getAttribute('data-elan-id'), b, 'block', 'بلوك إضافي'); });
          Array.prototype.slice.call(V.querySelectorAll('.card')).forEach(function (card, i) {
            var base = 'pcard:' + pk + hash(card.getAttribute('data-go') || 'i' + i), id = base;
            while (seen[id]) id = base + '-' + (++vn);
            var h4 = card.querySelector('h4');
            add(id, card, 'card', 'كارت ' + ((h4 && h4.textContent.trim().slice(0, 24)) || (i + 1)));
          });
        }
        var main = document.getElementById('main');
        if (!main) return out;
        Array.prototype.slice.call(main.children).forEach(function (c) {
          if (c.hasAttribute('data-elan-custom')) { add(c.getAttribute('data-elan-id'), c, 'block', 'بلوك إضافي'); return; }
          if (c.tagName !== 'SECTION' || !c.id || ED.BUILTIN.indexOf(c.id) === -1) return;
          add('sec:' + c.id, c, 'section', 'سيكشن ' + (SEC_NAMES[c.id] || c.id));
          add('sec:' + c.id + ':title', c.querySelector('h3'), 'title', 'عنوان ' + (SEC_NAMES[c.id] || c.id));
          var n = 0;
          Array.prototype.slice.call(c.querySelectorAll('.card')).forEach(function (card, i) {
            var base = 'card:' + hash(c.id + '|' + (card.getAttribute('data-go') || 'i' + i)), id = base;
            while (seen[id]) id = base + '-' + (++n);
            var h4 = card.querySelector('h4');
            add(id, card, 'card', 'كارت ' + ((h4 && h4.textContent.trim().slice(0, 24)) || (i + 1)));
          });
        });
        return out;
      }
    
      function textTarget(e) {
        if (e.kind === 'title') return e.el;
        if (e.kind === 'hero-text') return e.el.querySelector('h2');
        if (e.kind === 'card') return e.el.querySelector('h4');
        if (e.kind === 'block') return e.el.querySelector('p, h3');
        return null;
      }
    
      function unpaint(el) {
        if (el.__elanBase !== undefined) {
          if (el.__elanBase) el.setAttribute('style', el.__elanBase); else el.removeAttribute('style');
          delete el.__elanBase; el.removeAttribute('data-elan-edited');
        }
        if (el.__elanText) { el.__elanText.node.textContent = el.__elanText.value; delete el.__elanText; }
        if (el.__elanStrip) { var st = el.__elanStrip; if (st.base) st.node.setAttribute('style', st.base); else st.node.removeAttribute('style'); delete el.__elanStrip; }
      }
    
      function paint(entry, ed) {
        var el = entry.el, st = ed.style || {};
        el.__elanBase = el.getAttribute('style') || '';
        el.setAttribute('data-elan-edited', '1');
        if (ed.hidden || ed.archived) { el.style.display = 'none'; return; }
        if (ed.dx || ed.dy) {
          el.style.transform = 'translate(' + (ed.dx || 0) + 'px,' + (ed.dy || 0) + 'px)';
          el.style.position = el.style.position || 'relative';
          el.style.zIndex = '3';
          var strip = entry.kind === 'card' && el.closest('.strip');
          if (strip && !el.__elanStrip) { el.__elanStrip = { node: strip, base: strip.getAttribute('style') || '' }; strip.style.overflow = 'visible'; }
        }
        if (ed.w) { el.style.width = ed.w + 'px'; el.style.maxWidth = 'none'; el.style.flex = '0 0 auto'; }
        if (ed.h) { el.style.height = ed.h + 'px'; }
        if (st.color) el.style.color = st.color;
        if (st.background) el.style.backgroundColor = st.background;
        if (st.media) {
          el.style.backgroundImage = 'url("' + st.media.replace(/([\\"'])/g, '\\$1') + '")';
          el.style.backgroundSize = st.fit === 'contain' ? 'contain' : 'cover';
          el.style.backgroundPosition = 'center';
          el.style.backgroundRepeat = 'no-repeat';
        }
        if (st.fontSize) el.style.fontSize = st.fontSize + 'px';
        if (st.weight) el.style.fontWeight = String(st.weight);
        if (st.radius !== undefined) el.style.borderRadius = st.radius + 'px';
        if (st.align) el.style.textAlign = ({ start: 'start', end: 'end', center: 'center', left: 'left', right: 'right' })[st.align] || 'center';
        if (st.fontFamily) { loadFont(st.fontFamily); el.style.fontFamily = '"' + st.fontFamily + '", ' + (SERIF[st.fontFamily] ? 'serif' : 'sans-serif'); }
        if (st.effect === 'soft') { el.style.textShadow = '0 1px 0 #fff,0 3px 4px rgba(0,0,0,.22)'; el.style.boxShadow = '0 7px 18px rgba(0,0,0,.14)'; }
        if (st.effect === 'gold') { el.style.color = st.color || '#ae852e'; el.style.textShadow = '0 1px 0 #fceab1,0 2px 0 #77541e,0 4px 6px rgba(80,52,0,.3)'; el.style.boxShadow = '0 2px 0 #d6bc79,0 9px 22px rgba(101,72,18,.22)'; }
        if (st.effect === 'deep') { el.style.textShadow = '1px 1px 0 rgba(255,255,255,.6),2px 3px 3px rgba(0,0,0,.3)'; el.style.boxShadow = '0 4px 0 rgba(0,0,0,.13),0 14px 26px rgba(0,0,0,.2)'; }
        if (st.opacity !== undefined) el.style.opacity = String(st.opacity);
        if (ed.text) {
          var node = textTarget(entry), t = ed.text[lang()] || ed.text.ar || ed.text.en;
          if (node && t) { el.__elanText = { node: node, value: node.textContent }; node.textContent = t; }
        }
      }
    
      /* Free-form edits for the current screen size. Idempotent: always undo the last paint first. */
      function applyEdits() {
        touched.forEach(unpaint);
        touched = [];
        if (!design || !design.edits) return;
        var dev = ED.deviceOf(window.innerWidth);
        elements().forEach(function (entry) {
          var ed = ED.editFor(design, dev, entry.id);
          if (!ed) return;
          paint(entry, ed);
          touched.push(entry.el);
        });
      }
    
      function apply() {
        var main = document.getElementById('main');
        if (!main || !design) return;
        if (ED.isEmpty(design)) { applyEdits(); return; }
    
        // Idempotent: drop what we added before, then re-apply on the freshly rendered page.
        Array.prototype.slice.call(main.querySelectorAll('[data-elan-custom]')).forEach(function (n) { n.remove(); });
    
        var nodes = {};
        var present = [];
        Array.prototype.slice.call(main.children).forEach(function (c) {
          if (c.tagName === 'SECTION' && c.id && ED.BUILTIN.indexOf(c.id) !== -1) { nodes[c.id] = c; present.push(c.id); }
        });
    
        var plan = ED.plan(design, present, lang());
    
        plan.hide.forEach(function (id) {
          nodes[id].setAttribute('data-elan-hidden', '1');
          if (editing) nodes[id].style.opacity = '.4'; else nodes[id].style.display = 'none';
        });
        Object.keys(plan.titles).forEach(function (id) {
          var h = nodes[id].querySelector('h3');
          if (h) h.textContent = plan.titles[id];
        });
        plan.blocks.forEach(function (b) { nodes[b.id] = buildBlock(b); });
    
        // Only touch the order when the design asks for it or adds blocks.
        plan.order.forEach(function (id) { if (nodes[id]) main.appendChild(nodes[id]); });
        applyEdits(); // free-form edits from the visual editor, for the current screen size
      }
    
    
      // Inner pages (brands, stores, categories, occasions, notes, collections): blocks go at the top or bottom of #view.
      function pageKey() {
        if (!document.body.classList.contains('inner')) return 'home';
        try {
          var x = P[P.length - 1];
          if (!x) return null;
          if (x.k === 'sec') return 'sec:' + x.id;
          if (x.k === 'col') return 'col:' + x.id + ':' + x.i;
          if (x.k === 'brand') return 'brand:' + x.n;
          if (x.k === 'store') return 'store:' + x.n;
        } catch (e) { /* no page stack yet */ }
        return null;
      }
    
      function applyPage() {
        var V = document.getElementById('view');
        if (!V || !design) return;
        Array.prototype.slice.call(V.querySelectorAll('[data-elan-custom]')).forEach(function (n) { n.remove(); });
        var key = pageKey(), pg = design.pages && key && design.pages[key];
        if (!pg) return;
        var top = pg.blocks.filter(function (b) { return b.slot !== 'bottom'; });
        var bottom = pg.blocks.filter(function (b) { return b.slot === 'bottom'; });
        var h = V.querySelector('h3'), ref = h || null;
        top.forEach(function (b) {
          var n = buildBlock(b);
          if (ref) { ref.parentNode.insertBefore(n, ref.nextSibling); ref = n; } else { V.insertBefore(n, V.firstChild); ref = n; }
        });
        bottom.forEach(function (b) { V.appendChild(buildBlock(b)); });
      }
    
      /* An element that opens another page when a visitor clicks it (cards, lists): its go-target, or null. */
      function goTargetOf(el) {
        var n = el && el.closest ? el.closest('[data-go]') : null;
        return n ? n.getAttribute('data-go') : null;
      }
    
      function wrapView() {
        var orig = window.view;
        if (typeof orig !== 'function' || orig.__elanDesign) return;
        var wrapped = function () {
          var r = orig.apply(this, arguments);
          try { applyPage(); applyEdits(); } catch (e) { console.error('design layer', e); }
          return r;
        };
        wrapped.__elanDesign = true;
        window.view = wrapped;
      }
    
      function waitFor(test, cb, timeoutMs) {
        var t0 = Date.now();
        (function tick() {
          if (test()) return cb();
          if (Date.now() - t0 > timeoutMs) return;
          setTimeout(tick, 60);
        })();
      }
    
      function wrapRender() {
        var orig = window.render;
        if (typeof orig !== 'function' || orig.__elanDesign) return;
        var wrapped = function () {
          var r = orig.apply(this, arguments);
          try { apply(); } catch (e) { console.error('design layer', e); }
          return r;
        };
        wrapped.__elanDesign = true;
        window.render = wrapped;
      }
    
      function start(json) {
        var n = ED.normalize(json, { strict: false });
        if (!n.ok || ED.isEmpty(n.design)) return; // nothing to do: page stays untouched
        design = n.design;
        ensureStyle();
        if (typeof D === 'object' && D) ED.applyTexts(D, design);
        wrapRender(); wrapView();
        if (typeof window.render === 'function') window.render();
        if (document.body.classList.contains('inner') && typeof window.view === 'function') window.view();
      }
    
      // Used only by the editor's edit mode: swap in a draft design and redraw. Customers never call this.
      function set(json, opts) {
        var n = ED.normalize(json, { strict: false });
        if (!n.ok) return false;
        editing = !!(opts && opts.editing);
        design = n.design;
        ensureStyle();
        if (typeof D === 'object' && D) ED.applyTexts(D, design);
        wrapRender(); wrapView();
        if (typeof window.render === 'function') window.render();
        if (document.body.classList.contains('inner') && typeof window.view === 'function') window.view();
        return true;
      }
    
      window.ElanDesignLayer = { apply: apply, set: set, pageKey: pageKey, current: function () { return design; }, applyEdits: applyEdits, elements: elements, textTarget: textTarget, goTargetOf: goTargetOf };
    
      // A different screen size means a different set of free-form edits.
      window.addEventListener('resize', function () {
        if (!design || !design.edits) return;
        var d = ED.deviceOf(window.innerWidth);
        if (d !== lastDevice) { lastDevice = d; try { applyEdits(); } catch (e) { /* keep the page usable */ } }
      });
      lastDevice = ED.deviceOf(window.innerWidth);
    
      fetch('/design/home.json', { cache: 'no-store' })
        .then(function (r) { return r.ok ? r.json() : null; })
        .then(function (json) {
          if (!json) return;
          waitFor(function () { return typeof window.render === 'function' && document.getElementById('main'); },
            function () { start(json); }, 15000);
        })
        .catch(function () { /* design is optional */ });
    })();
    
  operator: 'match'
  stack: |-
    TestContext.<anonymous> (/home/ubuntu/elan-scents/tests/editor-media-edit.test.js:25:10)
    Test.runInAsyncScope (node:async_hooks:211:14)
    Test.run (node:internal/test_runner/test:931:25)
    Test.processPendingSubtests (node:internal/test_runner/test:629:18)
    Test.postRun (node:internal/test_runner/test:1042:19)
    Test.run (node:internal/test_runner/test:970:12)
    async Test.processPendingSubtests (node:internal/test_runner/test:629:7)
  ...
# Subtest: media library and upload need an admin session and use that session, never a service key
ok 78 - media library and upload need an admin session and use that session, never a service key
  ---
  duration_ms: 108.772717
  ...
# Subtest: uploads are checked: only real images, size-limited, same-origin, and a failed record is reported
ok 79 - uploads are checked: only real images, size-limited, same-origin, and a failed record is reported
  ---
  duration_ms: 82.721215
  ...
# Subtest: the editor window hands media tools to its own picker
ok 80 - the editor window hands media tools to its own picker
  ---
  duration_ms: 2.243556
  ...
# Subtest: the editor is served only after login and never remembers the session in the browser
ok 81 - the editor is served only after login and never remembers the session in the browser
  ---
  duration_ms: 3.074813
  ...
# Subtest: edit mode loads only inside the editor window and never for customers
ok 82 - edit mode loads only inside the editor window and never for customers
  ---
  duration_ms: 0.462828
  ...
# Subtest: edit mode talks to its own editor window only
ok 83 - edit mode talks to its own editor window only
  ---
  duration_ms: 0.720352
  ...
# Subtest: moving an element is one mouse gesture armed from the menu, with no arrow pad or arrow keys
ok 84 - moving an element is one mouse gesture armed from the menu, with no arrow pad or arrow keys
  ---
  duration_ms: 4.113696
  ...
# Subtest: a dynamic element opens as its own page and the menu can go back
ok 85 - a dynamic element opens as its own page and the menu can go back
  ---
  duration_ms: 0.662838
  ...
# Subtest: inner-page element ids are accepted by the design schema so their edits can be saved
ok 86 - inner-page element ids are accepted by the design schema so their edits can be saved
  ---
  duration_ms: 1.999011
  ...
# Subtest: new capabilities are added by registering a tool, not by editing the editor
ok 87 - new capabilities are added by registering a tool, not by editing the editor
  ---
  duration_ms: 0.523264
  ...
# Subtest: when the editor cannot start, it says why instead of showing no tools
ok 88 - when the editor cannot start, it says why instead of showing no tools
  ---
  duration_ms: 11.490182
  ...
# Subtest: a refused GitHub save is explained in plain words, without writing any file
ok 89 - a refused GitHub save is explained in plain words, without writing any file
  ---
  duration_ms: 1.292013
  ...
# Subtest: every font in the editor panel is accepted by the design schema and loadable on the page
ok 90 - every font in the editor panel is accepted by the design schema and loadable on the page
  ---
  duration_ms: 2.80407
  ...
# Subtest: the live format panel sends a colour only when the owner changed it
ok 91 - the live format panel sends a colour only when the owner changed it
  ---
  duration_ms: 1.736839
  ...
# Subtest: editor iframe preview does not start guest identity, analytics, or persisted customer actions
ok 92 - editor iframe preview does not start guest identity, analytics, or persisted customer actions
  ---
  duration_ms: 84.222912
  ...
# Subtest: editor preview mode does not activate when the storefront is opened as a normal top-level page
ok 93 - editor preview mode does not activate when the storefront is opened as a normal top-level page
  ---
  duration_ms: 1.151513
  ...
# Subtest: search finds existing brands by part of the name
ok 94 - search finds existing brands by part of the name
  ---
  duration_ms: 3.846948
  ...
# Subtest: sync matches an existing record instead of duplicating it (case and spacing ignored)
ok 95 - sync matches an existing record instead of duplicating it (case and spacing ignored)
  ---
  duration_ms: 0.936527
  ...
# Subtest: sync creates a new brand once, with a unique slug, and only the allowed columns
ok 96 - sync creates a new brand once, with a unique slug, and only the allowed columns
  ---
  duration_ms: 1.156407
  ...
# Subtest: sync creates a store and keeps commission and status at the database defaults
ok 97 - sync creates a store and keeps commission and status at the database defaults
  ---
  duration_ms: 1.499214
  ...
# Subtest: bad input is refused before any database write
ok 98 - bad input is refused before any database write
  ---
  duration_ms: 0.787192
  ...
# Subtest: a database refusal stops the sync and is reported, not hidden
ok 99 - a database refusal stops the sync and is reported, not hidden
  ---
  duration_ms: 0.582682
  ...
# Subtest: EDITOR_ROOT_REDIRECT=1 sends the root of the editor service to /editor; the storefront is unchanged otherwise
ok 100 - EDITOR_ROOT_REDIRECT=1 sends the root of the editor service to /editor; the storefront is unchanged otherwise
  ---
  duration_ms: 84.441808
  ...
# Subtest: storefront html links versioned css/js bundles
ok 101 - storefront html links versioned css/js bundles
  ---
  duration_ms: 1.358922
  ...
# Subtest: app.js loads versioned app-core
ok 102 - app.js loads versioned app-core
  ---
  duration_ms: 0.348676
  ...
# Subtest: style.css imports versioned theme sheets
ok 103 - style.css imports versioned theme sheets
  ---
  duration_ms: 0.447907
  ...
# Subtest: critical frontend files exist
ok 104 - critical frontend files exist
  ---
  duration_ms: 0.326358
  ...
# Subtest: app-core source resolves (local or pinned)
ok 105 - app-core source resolves (local or pinned)
  ---
  duration_ms: 1.699884
  ...
# Subtest: customer analytics summaries are available only to platform administrators
ok 106 - customer analytics summaries are available only to platform administrators
  ---
  duration_ms: 56.856034
  ...
# Subtest: admin summary accepts both customer groups and all supported date ranges
ok 107 - admin summary accepts both customer groups and all supported date ranges
  ---
  duration_ms: 6.013498
  ...
# Subtest: limiter allows up to max per window, then blocks, then recovers when the window ends
ok 108 - limiter allows up to max per window, then blocks, then recovers when the window ends
  ---
  duration_ms: 1.269924
  ...
# Subtest: limiter memory is bounded
ok 109 - limiter memory is bounded
  ---
  duration_ms: 1.451702
  ...
# Subtest: clientIp prefers the proxy header and never throws on missing data
ok 110 - clientIp prefers the proxy header and never throws on missing data
  ---
  duration_ms: 0.270078
  ...
# Subtest: guest-cart answers 429 with Retry-After after 30 resolves from one address and still serves others
ok 111 - guest-cart answers 429 with Retry-After after 30 resolves from one address and still serves others
  ---
  duration_ms: 59.017218
  ...
# Subtest: guest cart API rejects invalid methods and non-random browser keys
ok 112 - guest cart API rejects invalid methods and non-random browser keys
  ---
  duration_ms: 1.404947
  ...
# Subtest: resolve stores only server HMACs and returns this browser basket
ok 113 - resolve stores only server HMACs and returns this browser basket
  ---
  duration_ms: 49.042822
  ...
# Subtest: legacy guest activity route accepts cart removal and writes to the unified detailed ledger
ok 114 - legacy guest activity route accepts cart removal and writes to the unified detailed ledger
  ---
  duration_ms: 1.369045
  ...
# Subtest: guest capture is automatic, browser-local, and its migration keeps only isolated analytics after claim
ok 115 - guest capture is automatic, browser-local, and its migration keeps only isolated analytics after claim
  ---
  duration_ms: 2.468832
  ...
# Subtest: same browser storage reuses its random visitor ID and another browser receives a different ID
ok 116 - same browser storage reuses its random visitor ID and another browser receives a different ID
  ---
  duration_ms: 72.197761
  ...
# Subtest: logout ends the registered session with its token and rotates the browser session id
ok 117 - logout ends the registered session with its token and rotates the browser session id
  ---
  duration_ms: 4.062312
  ...
# Subtest: portal logout prepares activity session before removing the saved auth session
ok 118 - portal logout prepares activity session before removing the saved auth session
  ---
  duration_ms: 0.315152
  ...
# Subtest: railway host does not serve server-side code or internal reports, but still serves the design file
ok 119 - railway host does not serve server-side code or internal reports, but still serves the design file
  ---
  duration_ms: 107.586877
  ...
# Subtest: app-core.js is self-contained (no external script loading)
ok 120 - app-core.js is self-contained (no external script loading)
  ---
  duration_ms: 1.392698
  ...
# Subtest: login and signup menu entries open their sheets
ok 121 - login and signup menu entries open their sheets
  ---
  duration_ms: 0.437515
  ...
# Subtest: migration files follow the <14-digit version>_<name>.sql format
ok 122 - migration files follow the <14-digit version>_<name>.sql format
  ---
  duration_ms: 1.342669
  ...
# Subtest: migration versions are unique and strictly ascending
ok 123 - migration versions are unique and strictly ascending
  ---
  duration_ms: 1.485117
  ...
# Subtest: a migration name never appears twice under different versions
ok 124 - a migration name never appears twice under different versions
  ---
  duration_ms: 0.239655
  ...
# Subtest: pending migrations are newer than every applied migration
ok 125 - pending migrations are newer than every applied migration
  ---
  duration_ms: 0.241357
  ...
# Subtest: migration and test SQL contain no secrets
ok 126 - migration and test SQL contain no secrets
  ---
  duration_ms: 5.189401
  ...
# Subtest: customer summary rejects non-admin users before querying counts
ok 127 - customer summary rejects non-admin users before querying counts
  ---
  duration_ms: 54.469583
  ...
# Subtest: customer summary returns counts only and fetches at most one identifier per group
ok 128 - customer summary returns counts only and fetches at most one identifier per group
  ---
  duration_ms: 3.187124
  ...
# Subtest: platform customer dashboard requires a platform admin role
ok 129 - platform customer dashboard requires a platform admin role
  ---
  duration_ms: 56.645311
  ...
# Subtest: customer lists expose exact totals and independently page registered users and guests
ok 130 - customer lists expose exact totals and independently page registered users and guests
  ---
  duration_ms: 9.970762
  ...
# Subtest: registered basket summary paginates beyond 5,000 cart rows without truncation
ok 131 - registered basket summary paginates beyond 5,000 cart rows without truncation
  ---
  duration_ms: 15.339494
  ...
# Subtest: platform dashboard links to detailed admin tools and contains only aggregate order/customer/store sections
ok 132 - platform dashboard links to detailed admin tools and contains only aggregate order/customer/store sections
  ---
  duration_ms: 1.46824
  ...
# Subtest: platform dashboard requests aggregate-only counts and does not render customer order details
ok 133 - platform dashboard requests aggregate-only counts and does not render customer order details
  ---
  duration_ms: 29.621078
  ...
# Subtest: customer tabs toggle visitor and registered-customer lists
ok 134 - customer tabs toggle visitor and registered-customer lists
  ---
  duration_ms: 1.865154
  ...
# Subtest: customer dashboard loads insights lazily for the active tab and reuses the cached tab results
ok 135 - customer dashboard loads insights lazily for the active tab and reuses the cached tab results
  ---
  duration_ms: 16.712455
  ...
# Subtest: customer list paging renders exact totals and enables only valid previous/next controls
ok 136 - customer list paging renders exact totals and enables only valid previous/next controls
  ---
  duration_ms: 2.781695
  ...
# Subtest: guest analytics render the four available rankings into the current two-panel layout safely
ok 137 - guest analytics render the four available rankings into the current two-panel layout safely
  ---
  duration_ms: 2.120625
  ...
# Subtest: registered customer analytics render all four product rankings safely
ok 138 - registered customer analytics render all four product rankings safely
  ---
  duration_ms: 2.209449
  ...
# Subtest: customer analytics fetch and append additional pages for each ranked product list
ok 139 - customer analytics fetch and append additional pages for each ranked product list
  ---
  duration_ms: 3.97338
  ...
# Subtest: platform order summary rejects non-admin users before reading orders
ok 140 - platform order summary rejects non-admin users before reading orders
  ---
  duration_ms: 69.113072
  ...
# Subtest: platform order summary uses count-only HEAD queries and returns aggregate counts
ok 141 - platform order summary uses count-only HEAD queries and returns aggregate counts
  ---
  duration_ms: 3.942699
  ...
# Subtest: store detail API rejects store accounts before querying store data
ok 142 - store detail API rejects store accounts before querying store data
  ---
  duration_ms: 56.839017
  ...
# Subtest: store detail API validates store and section parameters before reading store tables
ok 143 - store detail API validates store and section parameters before reading store tables
  ---
  duration_ms: 1.302535
  ...
# Subtest: overview returns store profile, safe account links and the existing operational summary
ok 144 - overview returns store profile, safe account links and the existing operational summary
  ---
  duration_ms: 3.679939
  ...
# Subtest: overview loads linked accounts beyond the former 100-row ceiling
ok 145 - overview loads linked accounts beyond the former 100-row ceiling
  ---
  duration_ms: 2.414528
  ...
# Subtest: catalog products are joined to their product size, fragrance and brand
ok 146 - catalog products are joined to their product size, fragrance and brand
  ---
  duration_ms: 2.641889
  ...
# Subtest: order details never return customer contact fields or raw notification and reconciliation payloads
ok 147 - order details never return customer contact fields or raw notification and reconciliation payloads
  ---
  duration_ms: 2.954363
  ...
# Subtest: order detail loads every page of items and reconciliation checks beyond 500 rows
ok 148 - order detail loads every page of items and reconciliation checks beyond 500 rows
  ---
  duration_ms: 13.342582
  ...
# Subtest: reconciliation pagination follows request rows and strips raw check payloads
ok 149 - reconciliation pagination follows request rows and strips raw check payloads
  ---
  duration_ms: 1.682368
  ...
# Subtest: offers, shipments, commissions and sync logs return their bounded store-only fields
ok 150 - offers, shipments, commissions and sync logs return their bounded store-only fields
  ---
  duration_ms: 7.790673
  ...
# Subtest: store admin UI exposes read-only operational sections and routes detail reads through the admin API
ok 151 - store admin UI exposes read-only operational sections and routes detail reads through the admin API
  ---
  duration_ms: 1.163602
  ...
# Subtest: unlinked store-operation records are admin-only
ok 152 - unlinked store-operation records are admin-only
  ---
  duration_ms: 52.906422
  ...
# Subtest: unlinked notifications are paginated and raw payloads are never returned
ok 153 - unlinked notifications are paginated and raw payloads are never returned
  ---
  duration_ms: 2.996382
  ...
# Subtest: session-level operation events are shown without payload or actor identifiers
ok 154 - session-level operation events are shown without payload or actor identifiers
  ---
  duration_ms: 1.521913
  ...
# Subtest: platform stores API requires a platform admin and makes no store queries for customers
ok 155 - platform stores API requires a platform admin and makes no store queries for customers
  ---
  duration_ms: 56.191251
  ...
# Subtest: platform stores API returns store-only aggregates without customer order details
ok 156 - platform stores API returns store-only aggregates without customer order details
  ---
  duration_ms: 3.017663
  ...
# Subtest: platform stores API reads every page beyond 500 stores
ok 157 - platform stores API reads every page beyond 500 stores
  ---
  duration_ms: 6.274926
  ...
# Subtest: railway host serves the storefront, API routes, rewrites and blocks private files
ok 158 - railway host serves the storefront, API routes, rewrites and blocks private files
  ---
  duration_ms: 131.848813
  ...
# Subtest: railway host supports byte ranges for the hero video
ok 159 - railway host supports byte ranges for the hero video
  ---
  duration_ms: 19.296364
  ...
# Subtest: all JavaScript files pass syntax validation
ok 160 - all JavaScript files pass syntax validation
  ---
  duration_ms: 1408.104339
  ...
# Subtest: main menu routes to the customer dashboard and footer artwork is configured
not ok 161 - main menu routes to the customer dashboard and footer artwork is configured
  ---
  duration_ms: 3.033981
  location: '/home/ubuntu/elan-scents/tests/regression.test.js:30:1'
  failureType: 'testCodeFailure'
  error: |-
    The input did not match the regular expression /class="footer-background"/. Input:
    
    '<!DOCTYPE html>\n' +
      '<html lang="ar" dir="rtl">\n' +
      '<head>\n' +
      '<meta charset="utf-8">\n' +
      '<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">\n' +
      '<title>Élan Scents</title>\n' +
      '<!-- Bump this version whenever frontend assets change to avoid stale browser caches. -->\n' +
      '<link rel="stylesheet" href="/fonts.css?v=20261014-05">\n' +
      '<link rel="stylesheet" href="/style.css?v=20261014-05">\n' +
      '</head>\n' +
      '<body><svg width="0" height="0" style="position:absolute"><defs><linearGradient id="gg" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#f0c04a"/><stop offset=".5" stop-color="#c8962a"/><stop offset="1" stop-color="#8a5e0c"/></linearGradient></defs></svg>\n' +
      '<div id="bar"><div class="gold" id="barT"></div></div>\n' +
      '<header>\n' +
      '<div class="ic"><button id="mb" aria-label="menu"><svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="url(#gg)" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" ><path d="M4 7h16M4 12h16M4 17h10"/></svg></button><button data-sheet="notif"><svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="url(#gg)" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" ><path d="M6 16V11a6 6 0 0112 0v5l2 2H4zM10 20a2 2 0 004 0"/></svg></button><button id="quickSearchBtn" aria-label="quick search"><svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="url(#gg)" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" ><circle cx="11" cy="11" r="6"/><path d="M16 16l4 4"/></svg></button></div>\n' +
      '<a class="logo home-logo" href="/" aria-label="Élan Scents home"><div><b class="gold en">Élan</b> <span class="en">Scents</span></div><small class="en">THE HOME OF GULF FRAGRANCES</small><i></i></a>\n' +
      '<div class="ic"><button data-sheet="fav"><svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="url(#gg)" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" ><path d="M12 20s-7-4.5-7-10a4 4 0 017-2.5A4 4 0 0119 10c0 5.5-7 10-7 10z"/></svg></button><button data-sheet="cart"><svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="url(#gg)" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><circle cx="9" cy="20" r="1"/><circle cx="17" cy="20" r="1"/><path d="M3 3h2l.4 2M7 13h10l4-8H5.4M7 13L5.4 5M7 13l-2.293 2.293c-.63.63-.184 1.707.707 1.707H17m0 0a2 2 0 100 4 2 2 0 000-4zm-8 2a2 2 0 11-4 0 2 2 0 014 0z"/></svg></button><button id="lg" class="en">EN</button></div>\n' +
      '</header>\n' +
      '<div id="quickSearch" hidden><form id="quickSearchForm"><input id="quickSearchInput" type="search" autocomplete="off"><button type="submit" aria-label="search">⌕</button></form><div id="quickSearchResults"></div></div>\n' +
      '<nav id="menu"></nav><div id="mov"></div>\n' +
      '<div id="sheet" hidden><div class="sb" id="sheetB"></div></div>\n' +
      '<div id="hero">\n' +
      '<video id="heroVideo" autoplay muted loop playsinline webkit-playsinline preload="auto" poster="/assets/hero-poster.jpg?v=20261009-11" x-webkit-airplay="allow">\n' +
      '<source src="/assets/hero.mp4?v=20261009-11" type="video/mp4">\n' +
      '</video>\n' +
      '<button id="heroPlay" type="button" aria-label="تشغيل فيديو العرض / Play hero video">▶</button>\n' +
      '<div class="hero-overlay"></div>\n' +
      '<div class="magic" data-go="sec|all"><h2 data-i="magic"></h2><p class="sub" data-i="view"></p></div>\n' +
      '<div class="counters">\n' +
      '<div><b id="cbn">9</b><span data-i="cb"></span></div>\n' +
      '<div><b id="csn">2</b><span data-i="cs"></span></div>\n' +
      '<div><b id="cnt">0</b><span data-i="cp"></span></div>\n' +
      '</div>\n' +
      '</div>\n' +
      '<main id="main"></main>\n' +
      '<div id="view"></div>\n' +
      '<section class="about" id="about"><div class="alogo"><div class="logo"><div><b class="gold en">Élan</b> <span class="en">Scents</span></div><small class="en">THE HOME OF GULF FRAGRANCES</small><i></i></div></div><div id="abIn"></div></section>\n' +
      '<section id="contact">\n' +
      '<h3 data-i="contactT"></h3><span class="sub" style="cursor:default"></span>\n' +
      '<form onsubmit="return sendMsg(event)"><select id="kind"></select>\n' +
      '<input data-p="name" required><input data-p="email" type="email" required><input data-p="phone" type="tel"><textarea data-p="msg" rows="4" required></textarea>\n' +
      '<button class="btn" data-i="send"></button>\n' +
      '</form>\n' +
      '</section>\n' +
      '<footer>\n' +
      '<img class="footer-logo" src="/assets/elan-scents-logo.png" alt="Élan Scents" width="2048" height="2048">\n' +
      '<div class="fdiv"></div>\n' +
      '<div id="fcols" class="fcols"></div>\n' +
      '<div id="fch" class="fch"></div>\n' +
      '<div class="fph" id="fph"></div>\n' +
      '<div class="fbar" id="fbar"></div>\n' +
      '<p class="fcred" id="fcr"></p>\n' +
      '</footer>\n' +
      `<a id="wa" href="#contact" onclick="if(CFG.waNumber){event.preventDefault();window.open('https://wa.me/'+CFG.waNumber)}"><span aria-hidden="true"><svg viewBox="0 0 32 32"><path d="M16 3.2A12.8 12.8 0 0 0 5 22.5L3.3 28.7l6.4-1.7A12.8 12.8 0 1 0 16 3.2Z" fill="none" stroke="currentColor" stroke-width="2.1"/><path d="M11.4 10.7c.4-.4 1-.4 1.4.1l1.2 1.7c.3.4.3.9 0 1.3l-.7.8c.8 1.7 2.1 3 3.8 3.8l.8-.7c.4-.3.9-.3 1.3 0l1.7 1.2c.5.4.5 1 .1 1.4l-.6.6c-.6.6-1.5.8-2.3.5-4.2-1.5-7.2-4.5-8.7-8.7-.3-.8-.1-1.7.5-2.3l.6-.6Z" fill="currentColor"/></svg></span><b class="en">Contact Us</b></a>\n` +
      '<div id="toast"></div>\n' +
      '<script src="/guest-identity.js?v=20261014-05"></script>\n' +
      '<script src="/texts.js?v=20261014-05"></script>\n' +
      '<script src="/app.js?v=20261014-05"></script>\n' +
      '<script src="/design-schema.js?v=20261014-05"></script>\n' +
      '<script src="/design-layer.js?v=20261014-05"></script>\n' +
      '<script src="/edit-boot.js?v=20261014-05"></script>\n' +
      '<script>\n' +
      '(function(){\n' +
      "  var v=document.getElementById('heroVideo');\n" +
      "  var playButton=document.getElementById('heroPlay');\n" +
      '  if(!v)return;\n' +
      '  v.__elanHeroVisible=true;\n' +
      '  v.muted=true;\n' +
      '  v.defaultMuted=true;\n' +
      '  v.autoplay=true;\n' +
      '  v.loop=true;\n' +
      '  v.playsInline=true;\n' +
      "  v.setAttribute('muted','');\n" +
      "  v.setAttribute('playsinline','');\n" +
      "  v.setAttribute('webkit-playsinline','');\n" +
      '  var pauseRetries=0,retryTimer=0;\n' +
      '  function showButton(show){\n' +
      '    if(!playButton)return;\n' +
      "    if(show)playButton.removeAttribute('hidden');else playButton.setAttribute('hidden','');\n" +
      '  }\n' +
      '  function tryPlay(){\n' +
      '    if(v.__elanHeroVisible===false||document.hidden){v.pause();return;}\n' +
      '    v.muted=true;\n' +
      '    var p;\n' +
      '    try{p=v.play();}catch(e){showButton(true);return;}\n' +
      '    if(p&&p.then)p.then(function(){showButton(false);},function(){showButton(true);});\n' +
      '  }\n' +
      '  function setHeroVisibility(visible){v.__elanHeroVisible=visible;if(visible)tryPlay();else v.pause();}\n' +
      "  if(playButton)playButton.addEventListener('click',function(e){e.preventDefault();e.stopPropagation();tryPlay();});\n" +
      "  if('IntersectionObserver' in window){var heroObserver=new IntersectionObserver(function(entries){entries.forEach(function(entry){setHeroVisibility(entry.isIntersecting&&entry.intersectionRatio>=0.05);});},{threshold:[0,0.05]});heroObserver.observe(v.parentElement);}\n" +
      "  else{var checkHeroVisibility=function(){var r=v.parentElement.getBoundingClientRect();setHeroVisibility(r.bottom>0&&r.top<window.innerHeight);};window.addEventListener('scroll',checkHeroVisibility,{passive:true});window.addEventListener('resize',checkHeroVisibility,{passive:true});checkHeroVisibility();}\n" +
      "  v.addEventListener('playing',function(){showButton(false);});\n" +
      '  // Some browsers pause muted autoplay on their own (power saving, tab restore); resume while the hero is on screen.\n' +
      "  v.addEventListener('pause',function(){\n" +
      '    if(v.ended||v.__elanHeroVisible===false||document.hidden||pauseRetries>=10)return;\n' +
      '    pauseRetries++;\n' +
      '    clearTimeout(retryTimer);\n' +
      '    retryTimer=setTimeout(tryPlay,250);\n' +
      '  });\n' +
      '  // Safety net for engines that ignore the loop attribute.\n' +
      "  v.addEventListener('ended',function(){try{v.currentTime=0}catch(e){}tryPlay();});\n" +
      "  v.addEventListener('stalled',function(){if(v.paused)tryPlay();});\n" +
      "  v.addEventListener('suspend',function(){if(v.paused)tryPlay();});\n" +
      "  v.addEventListener('loadedmetadata',tryPlay);\n" +
      "  v.addEventListener('loadeddata',tryPlay);\n" +
      "  v.addEventListener('canplay',tryPlay);\n" +
      "  v.addEventListener('canplaythrough',tryPlay);\n" +
      "  document.addEventListener('visibilitychange',function(){if(document.hidden)v.pause();else{pauseRetries=0;tryPlay();}});\n" +
      "  window.addEventListener('pageshow',function(){pauseRetries=0;tryPlay();});\n" +
      '  // iOS Low Power Mode and strict autoplay policies need one real gesture; touchend/pointerup/keydown count as activation.\n' +
      "  ['touchend','pointerup','click','keydown'].forEach(function(name){document.addEventListener(name,function(){tryPlay();},{once:true,passive:true,capture:true});});\n" +
      '  tryPlay();\n' +
      '  setTimeout(tryPlay,300);\n' +
      '  setTimeout(tryPlay,1000);\n' +
      '  setTimeout(tryPlay,2500);\n' +
      '})();\n' +
      '</script>\n' +
      '</body>\n' +
      '</html>\n'
    
  code: 'ERR_ASSERTION'
  name: 'AssertionError'
  expected:
  actual: |-
    <!DOCTYPE html>
    <html lang="ar" dir="rtl">
    <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
    <title>Élan Scents</title>
    <!-- Bump this version whenever frontend assets change to avoid stale browser caches. -->
    <link rel="stylesheet" href="/fonts.css?v=20261014-05">
    <link rel="stylesheet" href="/style.css?v=20261014-05">
    </head>
    <body><svg width="0" height="0" style="position:absolute"><defs><linearGradient id="gg" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#f0c04a"/><stop offset=".5" stop-color="#c8962a"/><stop offset="1" stop-color="#8a5e0c"/></linearGradient></defs></svg>
    <div id="bar"><div class="gold" id="barT"></div></div>
    <header>
    <div class="ic"><button id="mb" aria-label="menu"><svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="url(#gg)" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" ><path d="M4 7h16M4 12h16M4 17h10"/></svg></button><button data-sheet="notif"><svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="url(#gg)" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" ><path d="M6 16V11a6 6 0 0112 0v5l2 2H4zM10 20a2 2 0 004 0"/></svg></button><button id="quickSearchBtn" aria-label="quick search"><svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="url(#gg)" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" ><circle cx="11" cy="11" r="6"/><path d="M16 16l4 4"/></svg></button></div>
    <a class="logo home-logo" href="/" aria-label="Élan Scents home"><div><b class="gold en">Élan</b> <span class="en">Scents</span></div><small class="en">THE HOME OF GULF FRAGRANCES</small><i></i></a>
    <div class="ic"><button data-sheet="fav"><svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="url(#gg)" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" ><path d="M12 20s-7-4.5-7-10a4 4 0 017-2.5A4 4 0 0119 10c0 5.5-7 10-7 10z"/></svg></button><button data-sheet="cart"><svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="url(#gg)" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><circle cx="9" cy="20" r="1"/><circle cx="17" cy="20" r="1"/><path d="M3 3h2l.4 2M7 13h10l4-8H5.4M7 13L5.4 5M7 13l-2.293 2.293c-.63.63-.184 1.707.707 1.707H17m0 0a2 2 0 100 4 2 2 0 000-4zm-8 2a2 2 0 11-4 0 2 2 0 014 0z"/></svg></button><button id="lg" class="en">EN</button></div>
    </header>
    <div id="quickSearch" hidden><form id="quickSearchForm"><input id="quickSearchInput" type="search" autocomplete="off"><button type="submit" aria-label="search">⌕</button></form><div id="quickSearchResults"></div></div>
    <nav id="menu"></nav><div id="mov"></div>
    <div id="sheet" hidden><div class="sb" id="sheetB"></div></div>
    <div id="hero">
    <video id="heroVideo" autoplay muted loop playsinline webkit-playsinline preload="auto" poster="/assets/hero-poster.jpg?v=20261009-11" x-webkit-airplay="allow">
    <source src="/assets/hero.mp4?v=20261009-11" type="video/mp4">
    </video>
    <button id="heroPlay" type="button" aria-label="تشغيل فيديو العرض / Play hero video">▶</button>
    <div class="hero-overlay"></div>
    <div class="magic" data-go="sec|all"><h2 data-i="magic"></h2><p class="sub" data-i="view"></p></div>
    <div class="counters">
    <div><b id="cbn">9</b><span data-i="cb"></span></div>
    <div><b id="csn">2</b><span data-i="cs"></span></div>
    <div><b id="cnt">0</b><span data-i="cp"></span></div>
    </div>
    </div>
    <main id="main"></main>
    <div id="view"></div>
    <section class="about" id="about"><div class="alogo"><div class="logo"><div><b class="gold en">Élan</b> <span class="en">Scents</span></div><small class="en">THE HOME OF GULF FRAGRANCES</small><i></i></div></div><div id="abIn"></div></section>
    <section id="contact">
    <h3 data-i="contactT"></h3><span class="sub" style="cursor:default"></span>
    <form onsubmit="return sendMsg(event)"><select id="kind"></select>
    <input data-p="name" required><input data-p="email" type="email" required><input data-p="phone" type="tel"><textarea data-p="msg" rows="4" required></textarea>
    <button class="btn" data-i="send"></button>
    </form>
    </section>
    <footer>
    <img class="footer-logo" src="/assets/elan-scents-logo.png" alt="Élan Scents" width="2048" height="2048">
    <div class="fdiv"></div>
    <div id="fcols" class="fcols"></div>
    <div id="fch" class="fch"></div>
    <div class="fph" id="fph"></div>
    <div class="fbar" id="fbar"></div>
    <p class="fcred" id="fcr"></p>
    </footer>
    <a id="wa" href="#contact" onclick="if(CFG.waNumber){event.preventDefault();window.open('https://wa.me/'+CFG.waNumber)}"><span aria-hidden="true"><svg viewBox="0 0 32 32"><path d="M16 3.2A12.8 12.8 0 0 0 5 22.5L3.3 28.7l6.4-1.7A12.8 12.8 0 1 0 16 3.2Z" fill="none" stroke="currentColor" stroke-width="2.1"/><path d="M11.4 10.7c.4-.4 1-.4 1.4.1l1.2 1.7c.3.4.3.9 0 1.3l-.7.8c.8 1.7 2.1 3 3.8 3.8l.8-.7c.4-.3.9-.3 1.3 0l1.7 1.2c.5.4.5 1 .1 1.4l-.6.6c-.6.6-1.5.8-2.3.5-4.2-1.5-7.2-4.5-8.7-8.7-.3-.8-.1-1.7.5-2.3l.6-.6Z" fill="currentColor"/></svg></span><b class="en">Contact Us</b></a>
    <div id="toast"></div>
    <script src="/guest-identity.js?v=20261014-05"></script>
    <script src="/texts.js?v=20261014-05"></script>
    <script src="/app.js?v=20261014-05"></script>
    <script src="/design-schema.js?v=20261014-05"></script>
    <script src="/design-layer.js?v=20261014-05"></script>
    <script src="/edit-boot.js?v=20261014-05"></script>
    <script>
    (function(){
      var v=document.getElementById('heroVideo');
      var playButton=document.getElementById('heroPlay');
      if(!v)return;
      v.__elanHeroVisible=true;
      v.muted=true;
      v.defaultMuted=true;
      v.autoplay=true;
      v.loop=true;
      v.playsInline=true;
      v.setAttribute('muted','');
      v.setAttribute('playsinline','');
      v.setAttribute('webkit-playsinline','');
      var pauseRetries=0,retryTimer=0;
      function showButton(show){
        if(!playButton)return;
        if(show)playButton.removeAttribute('hidden');else playButton.setAttribute('hidden','');
      }
      function tryPlay(){
        if(v.__elanHeroVisible===false||document.hidden){v.pause();return;}
        v.muted=true;
        var p;
        try{p=v.play();}catch(e){showButton(true);return;}
        if(p&&p.then)p.then(function(){showButton(false);},function(){showButton(true);});
      }
      function setHeroVisibility(visible){v.__elanHeroVisible=visible;if(visible)tryPlay();else v.pause();}
      if(playButton)playButton.addEventListener('click',function(e){e.preventDefault();e.stopPropagation();tryPlay();});
      if('IntersectionObserver' in window){var heroObserver=new IntersectionObserver(function(entries){entries.forEach(function(entry){setHeroVisibility(entry.isIntersecting&&entry.intersectionRatio>=0.05);});},{threshold:[0,0.05]});heroObserver.observe(v.parentElement);}
      else{var checkHeroVisibility=function(){var r=v.parentElement.getBoundingClientRect();setHeroVisibility(r.bottom>0&&r.top<window.innerHeight);};window.addEventListener('scroll',checkHeroVisibility,{passive:true});window.addEventListener('resize',checkHeroVisibility,{passive:true});checkHeroVisibility();}
      v.addEventListener('playing',function(){showButton(false);});
      // Some browsers pause muted autoplay on their own (power saving, tab restore); resume while the hero is on screen.
      v.addEventListener('pause',function(){
        if(v.ended||v.__elanHeroVisible===false||document.hidden||pauseRetries>=10)return;
        pauseRetries++;
        clearTimeout(retryTimer);
        retryTimer=setTimeout(tryPlay,250);
      });
      // Safety net for engines that ignore the loop attribute.
      v.addEventListener('ended',function(){try{v.currentTime=0}catch(e){}tryPlay();});
      v.addEventListener('stalled',function(){if(v.paused)tryPlay();});
      v.addEventListener('suspend',function(){if(v.paused)tryPlay();});
      v.addEventListener('loadedmetadata',tryPlay);
      v.addEventListener('loadeddata',tryPlay);
      v.addEventListener('canplay',tryPlay);
      v.addEventListener('canplaythrough',tryPlay);
      document.addEventListener('visibilitychange',function(){if(document.hidden)v.pause();else{pauseRetries=0;tryPlay();}});
      window.addEventListener('pageshow',function(){pauseRetries=0;tryPlay();});
      // iOS Low Power Mode and strict autoplay policies need one real gesture; touchend/pointerup/keydown count as activation.
      ['touchend','pointerup','click','keydown'].forEach(function(name){document.addEventListener(name,function(){tryPlay();},{once:true,passive:true,capture:true});});
      tryPlay();
      setTimeout(tryPlay,300);
      setTimeout(tryPlay,1000);
      setTimeout(tryPlay,2500);
    })();
    </script>
    </body>
    </html>
    
  operator: 'match'
  stack: |-
    TestContext.<anonymous> (/home/ubuntu/elan-scents/tests/regression.test.js:47:10)
    Test.runInAsyncScope (node:async_hooks:211:14)
    Test.run (node:internal/test_runner/test:931:25)
    Test.processPendingSubtests (node:internal/test_runner/test:629:18)
    Test.postRun (node:internal/test_runner/test:1042:19)
    Test.run (node:internal/test_runner/test:970:12)
    async startSubtestAfterBootstrap (node:internal/test_runner/harness:296:3)
  ...
# Subtest: frontend order persistence uses the authenticated Supabase identity
ok 162 - frontend order persistence uses the authenticated Supabase identity
  ---
  duration_ms: 0.590427
  ...
# Subtest: create-store-order validates login and splits one checkout across stores
ok 163 - create-store-order validates login and splits one checkout across stores
  ---
  duration_ms: 54.3866
  ...
# Subtest: store status API normalizes and reconciles completed webhook events
ok 164 - store status API normalizes and reconciles completed webhook events
  ---
  duration_ms: 2.527054
  ...
# Subtest: cancellation API returns the tracking number and restoration token
ok 165 - cancellation API returns the tracking number and restoration token
  ---
  duration_ms: 1.443654
  ...
# Subtest: restore API is idempotent for a pending restoration
ok 166 - restore API is idempotent for a pending restoration
  ---
  duration_ms: 1.801219
  ...
# Subtest: platform, store and customer dashboard APIs enforce their scopes
ok 167 - platform, store and customer dashboard APIs enforce their scopes
  ---
  duration_ms: 6.045054
  ...
# Subtest: store dashboard and order update require store ownership or platform role
ok 168 - store dashboard and order update require store ownership or platform role
  ---
  duration_ms: 3.57301
  ...
# Subtest: store shipment updates stay scoped to the store order and never call a carrier API
ok 169 - store shipment updates stay scoped to the store order and never call a carrier API
  ---
  duration_ms: 3.023365
  ...
# Subtest: shipping UI and migration keep carrier integration out of the platform
ok 170 - shipping UI and migration keep carrier integration out of the platform
  ---
  duration_ms: 0.579818
  ...
# Subtest: notification API returns only UI fields and marks only the customer’s own notification
ok 171 - notification API returns only UI fields and marks only the customer’s own notification
  ---
  duration_ms: 3.438826
  ...
# Subtest: store-admin notifications include every assigned store but never expose raw payloads
ok 172 - store-admin notifications include every assigned store but never expose raw payloads
  ---
  duration_ms: 2.171924
  ...
# Subtest: notification UI refreshes through the sanitized API instead of subscribing to database rows
ok 173 - notification UI refreshes through the sanitized API instead of subscribing to database rows
  ---
  duration_ms: 0.294517
  ...
# Subtest: customer UI keeps the previous basket identity and mobile entry point
ok 174 - customer UI keeps the previous basket identity and mobile entry point
  ---
  duration_ms: 1.613079
  ...
# Subtest: health check answers, unknown paths 404, and the editor refuses anonymous callers
ok 175 - health check answers, unknown paths 404, and the editor refuses anonymous callers
  ---
  duration_ms: 144.74093
  ...
# Subtest: store admins receive only assigned-store orders with minimum delivery data and stable pagination
ok 176 - store admins receive only assigned-store orders with minimum delivery data and stable pagination
  ---
  duration_ms: 62.463291
  ...
# Subtest: store account discovery paginates instead of truncating after 500 linked stores
ok 177 - store account discovery paginates instead of truncating after 500 linked stores
  ---
  duration_ms: 4.732917
  ...
# Subtest: unauthorized roles, malformed pages and status filters are rejected before reading orders
ok 178 - unauthorized roles, malformed pages and status filters are rejected before reading orders
  ---
  duration_ms: 2.335451
  ...
# Subtest: platform admins can request only a validated explicit store scope
ok 179 - platform admins can request only a validated explicit store scope
  ---
  duration_ms: 1.011854
  ...
# Subtest: store portal paginates and displays only delivery contact fields
ok 180 - store portal paginates and displays only delivery contact fields
  ---
  duration_ms: 0.533956
  ...
# Subtest: safeEqual compares secrets in constant time and rejects empty or non-string input
ok 181 - safeEqual compares secrets in constant time and rejects empty or non-string input
  ---
  duration_ms: 1.47965
  ...
# Subtest: checkSecret fails closed when the server secret is missing
ok 182 - checkSecret fails closed when the server secret is missing
  ---
  duration_ms: 1.423398
  ...
# Subtest: store-order-status never reaches the database without a valid webhook secret
ok 183 - store-order-status never reaches the database without a valid webhook secret
  ---
  duration_ms: 54.215651
  ...
# Subtest: store-order-cancelled never reaches the database without a valid webhook secret
ok 184 - store-order-cancelled never reaches the database without a valid webhook secret
  ---
  duration_ms: 2.736294
  ...
# Subtest: dashboard token endpoints use the constant-time comparison and stay closed without a token
ok 185 - dashboard token endpoints use the constant-time comparison and stay closed without a token
  ---
  duration_ms: 3.132434
  ...
# Subtest: source no longer compares secrets with === or falls back to open when unset
ok 186 - source no longer compares secrets with === or falls back to open when unset
  ---
  duration_ms: 0.611871
  ...
1..186
# tests 186
# suites 0
# pass 171
# fail 15
# cancelled 0
# skipped 0
# todo 0
# duration_ms 2720.129855
```
